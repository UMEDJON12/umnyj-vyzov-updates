from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
SRC=ROOT/'src/com/smartcall/ru'

class DialogAndKeySafety(unittest.TestCase):
    def test_modal_download_from_offer(self):
        source=(SRC/'UpdatesController.java').read_text()
        dialog=(SRC/'UpdateDownloadDialog.java').read_text()
        self.assertIn('UpdateDownloadDialog.open(activity, m);', source)
        self.assertNotIn('UpdateProgressActivity.startDownload(activity, m);', source)
        self.assertIn('new AlertDialog.Builder(activity)', dialog)
        self.assertIn('UpdateService.startDownload(', dialog)
        self.assertIn('UpdateProgress.listen(this);', dialog)
        self.assertIn('UpdateProgress.unlisten(this);', dialog)
        self.assertIn('UpdateProgressText.progress(snapshot.downloaded, total)', dialog)
        self.assertIn('progress.setProgress(percent)', dialog)
        self.assertIn('UpdatesController.installDownloaded(activity)', dialog)
        self.assertIn('Build.VERSION.SDK_INT < 30', dialog)
    def test_accessible_button_order(self):
        source=(SRC/'UpdatesController.java').read_text()
        self.assertIn('actions.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR)', source)
        self.assertLess(source.index('postpone.setText("Позже");'),source.index('download.setText("Скачать");'))
    def test_safe_hardware_diagnostic_only(self):
        src=(SRC/'CallControlAccessibilityService.java').read_text()
        receiver=(SRC/'ScreenAndVolumeReceiver.java').read_text()
        self.assertIn('checkOtherAccessibilityKeyFilters()', src)
        self.assertIn('hardwareKeyDownCount++', src)
        self.assertIn('изменение громкости', receiver.lower())
        self.assertNotIn('answerCall(context)', receiver)
        self.assertNotIn('handleHardwareButton(context', receiver)
    def test_version(self):
        build=(ROOT/'build_apk.py').read_text()
        self.assertIn("VERSION_NAME = '2.3.11'", build)
        self.assertIn('VERSION_CODE = 34', build)

if __name__ == '__main__': unittest.main()
