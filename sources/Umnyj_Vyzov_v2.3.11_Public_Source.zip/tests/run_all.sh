#!/bin/sh
# Автономные проверки «Умного Вызова» 2.3.11 (не Android runtime).
# Не требует телефона, ADB или сети. Запуск из корня проекта: sh tests/run_all.sh
set -e
cd "$(dirname "$0")/.."

PY=python3
[ -x /root/workspace/smartcall-work/.venv/bin/python ] && PY=/root/workspace/smartcall-work/.venv/bin/python
ANDROID_JAR=tools/android-35.jar

echo "== 1/5. Статические и дифференциальные тесты исходников =="
$PY tests/test_recovery.py
$PY tests/test_notification_diff.py
$PY tests/test_ui_238.py

echo "== 2/5. Миграция настроек (host JVM) =="
T=$(mktemp -d /tmp/smartcall-migration.XXXXXX)
javac --release 8 -encoding UTF-8 -cp "$ANDROID_JAR" -d "$T" \
  src/com/smartcall/ru/SettingsMigration.java tests/SettingsMigrationTest.java
java -cp "$T:$ANDROID_JAR" com.smartcall.ru.SettingsMigrationTest

echo "== 3/5. Модуль обновлений (host JVM) =="
T=$(mktemp -d /tmp/smartcall-update.XXXXXX)
javac --release 8 -encoding UTF-8 -cp "$ANDROID_JAR" -d "$T" \
  src/com/smartcall/ru/update/*.java tests/update/com/smartcall/ru/update/test/*.java \
  tests/update/com/smartcall/ru/update/test/fake/*.java
java -cp "$T:$ANDROID_JAR" com.smartcall.ru.update.test.UpdateTestsRunner

echo "== 4/5. Представление: статус канала и голоса =="
T=$(mktemp -d /tmp/smartcall-presentation.XXXXXX)
javac --release 8 -encoding UTF-8 -d "$T" \
  src/com/smartcall/ru/update/StatusCode.java \
  src/com/smartcall/ru/UpdateNoticePolicy.java src/com/smartcall/ru/VoiceLabels.java \
  src/com/smartcall/ru/UpdateNoteSummary.java \
  tests/Presentation238Test.java
java -cp "$T" com.smartcall.ru.Presentation238Test

echo "== Дополнительно: сохранение и provider (модели JVM, не Android) =="
T=$(mktemp -d /tmp/smartcall-copy.XXXXXX)
javac --release 8 -encoding UTF-8 -cp "$ANDROID_JAR" -d "$T" \
  src/com/smartcall/ru/update/*.java src/com/smartcall/ru/DownloadStore.java \
  src/com/smartcall/ru/UpdateProgressText.java tests/DownloadStoreTest.java
java -cp "$T:$ANDROID_JAR" com.smartcall.ru.DownloadStoreTest
T=$(mktemp -d /tmp/smartcall-progress.XXXXXX)
javac --release 8 -encoding UTF-8 -d "$T" \
  tests/progress239/android/os/*.java src/com/smartcall/ru/UpdateProgress.java \
  src/com/smartcall/ru/UpdateProgressText.java tests/progress239/com/smartcall/ru/ProgressTest.java
java -cp "$T" com.smartcall.ru.ProgressTest
$PY tests/provider239/run.py
$PY tests/download239/run.py
sh tests/service239/run.sh
$PY tests/channel/test_publish_stable.py
$PY tests/channel239/test_publisher.py
$PY tests/test_update_routes_2310.py
$PY tests/test_dialog_2311.py

echo "== 5/5. Проверка структуры APK именно 2.3.11 =="
if [ -f dist/SmartCall-2.3.11-signed.apk ]; then
  $PY tests/check_dex_links.py dist/SmartCall-2.3.11-signed.apk
  echo "ХОСТОВЫЕ ПРОВЕРКИ ПРОЙДЕНЫ (Android runtime не проверен)"
else
  echo "APK 2.3.11 ещё не собран; его DEX не проверен."
fi
