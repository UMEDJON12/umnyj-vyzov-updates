#!/usr/bin/env python3
"""Reproducible editable-project build: Java sources -> DEX -> APK -> original signature.

Usage:
  python3 build_apk.py --unsigned            # review artifact, never installable
  python3 build_apk.py --key ../keys/private_key.pem --cert ../keys/cert.pem

The original application declared minSdkVersion=24, targetSdkVersion=28
(verified from the released 2.3.6 APK manifest); this build keeps both.
"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'
TOOLS = ROOT / 'tools'
sys.path.insert(0, str(BUILD))

from axml_arsc_gen import (  # noqa: E402
    build_accessibility_config_axml, build_manifest_axml, build_resources_arsc,
)
from apk_signer import build_aligned_zip_sections  # noqa: E402

PACKAGE = 'com.smartcall.ru'
VERSION_NAME = '2.3.11'
VERSION_CODE = 34
MIN_SDK = 24
TARGET_SDK = 28
EXPECTED_CERT_SHA256 = 'baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01'
# Permission required by the GitHub update channel; the 2.3.6 APK had none.
UPDATE_PERMISSIONS = ['android.permission.INTERNET',
                      'android.permission.ACCESS_NETWORK_STATE']


def compile_java(sources_dir: Path, out_dir: Path):
    sources = sorted(str(p) for p in sources_dir.rglob('*.java'))
    if not sources:
        raise SystemExit('no Java sources found')
    subprocess.run(
        ['javac', '-source', '8', '-target', '8', '-encoding', 'UTF-8',
         '-bootclasspath', str(TOOLS / 'android-35.jar'), '-d', str(out_dir)] + sources,
        check=True)


def dex_from_classes(classes_dir: Path, out_dir: Path):
    jar = out_dir / 'classes.jar'
    with zipfile.ZipFile(jar, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(classes_dir.rglob('*.class')):
            z.write(f, f.relative_to(classes_dir).as_posix())
    dex_dir = out_dir / 'dex'
    dex_dir.mkdir(exist_ok=True)
    subprocess.run(
        ['java', '-cp', str(TOOLS / 'r8.jar'), 'com.android.tools.r8.D8',
         '--min-api', str(MIN_SDK), '--lib', str(TOOLS / 'android-35.jar'),
         '--output', str(dex_dir), str(jar)], check=True)
    dex_files = sorted(dex_dir.glob('classes*.dex'))
    if not dex_files:
        raise SystemExit('D8 produced no dex')
    return dex_files


def build_entries(dex_files):
    return [
        ('AndroidManifest.xml', build_manifest_axml(
            PACKAGE, VERSION_CODE, VERSION_NAME, MIN_SDK, TARGET_SDK), True),
        *[(f.name, f.read_bytes(), False) for f in dex_files],
        ('res/drawable/ic_launcher.png', (ROOT / 'assets/ic_launcher.png').read_bytes(), True),
        ('res/xml/accessibility_config.xml', build_accessibility_config_axml(), True),
        ('resources.arsc', build_resources_arsc(), False),
    ]


def validate_signing_identity(key_path, cert_path):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
    der_cert = x509.load_der_x509_certificate((cert_path.parent / 'cert.der').read_bytes())
    if cert.fingerprint(hashes.SHA256()).hex() != EXPECTED_CERT_SHA256:
        raise ValueError('Сертификат не соответствует оригинальной подписи приложения')
    if cert.fingerprint(hashes.SHA256()) != der_cert.fingerprint(hashes.SHA256()):
        raise ValueError('PEM и DER сертификаты не совпадают')
    key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
    fmt = (serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    if key.public_key().public_bytes(*fmt) != cert.public_key().public_bytes(*fmt):
        raise ValueError('Закрытый ключ не соответствует сертификату')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--unsigned', action='store_true')
    p.add_argument('--key', type=Path)
    p.add_argument('--cert', type=Path, default=ROOT / 'keys' / 'cert.pem')
    p.add_argument('--output', type=Path, default=None)
    args = p.parse_args()
    if not args.unsigned and not args.key:
        p.error('provide --key for a signed build, or --unsigned')
    if args.unsigned and args.key:
        p.error('--unsigned and --key are mutually exclusive')
    if not args.unsigned:
        validate_signing_identity(args.key, args.cert)

    with tempfile.TemporaryDirectory(prefix='smartcall-build-') as td:
        tmp = Path(td)
        classes = tmp / 'classes'
        classes.mkdir()
        compile_java(ROOT / 'src', classes)
        dex_files = dex_from_classes(classes, tmp)
        entries = build_entries(dex_files)
        out = args.output or ROOT / 'dist' / (
            f'SmartCall_{VERSION_NAME}' + ('-unsigned' if args.unsigned else '') + '.apk')
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            raise SystemExit(f'refusing to overwrite {out}')
        result = tmp / 'release.apk'
        contents, cd, eocd = build_aligned_zip_sections(entries)
        if args.unsigned:
            result.write_bytes(contents + cd + eocd)
        else:
            # Android 7+ supports v2, but the stable GitHub publisher requires
            # BOTH verified v1 and v2. The previous custom signer emitted v2 only.
            from cryptography.hazmat.primitives import serialization
            private = serialization.load_pem_private_key(args.key.read_bytes(), password=None)
            pk8 = tmp / 'signing-key.pk8'
            pk8.write_bytes(private.private_bytes(serialization.Encoding.DER,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
            pk8.chmod(0o600)
            unsigned = tmp / 'unsigned.apk'
            unsigned.write_bytes(contents + cd + eocd)
            signer = ([shutil.which('apksigner')] if shutil.which('apksigner')
                      else ['java', '-jar', str(TOOLS / 'apksigner-31.0.2.jar')])
            subprocess.run(signer + [
                'sign', '--key', str(pk8), '--cert', str(args.cert),
                '--min-sdk-version', str(MIN_SDK),
                '--v1-signing-enabled', 'true',
                '--v2-signing-enabled', 'true',
                '--v3-signing-enabled', 'true',
                '--out', str(result), str(unsigned)], check=True)
            verify = subprocess.run(signer + ['verify', '--verbose', '--print-certs',
                '--min-sdk-version', '23', str(result)], check=True,
                capture_output=True, text=True).stdout
            for scheme in (1, 2):
                if 'Verified using v%d scheme' % scheme not in verify or not any(
                        'v%d scheme' % scheme in line and ': true' in line
                        for line in verify.splitlines()):
                    raise ValueError('APK signing scheme v%d not verified' % scheme)
            if 'Signer #1 certificate SHA-256 digest: ' + EXPECTED_CERT_SHA256 not in verify:
                raise ValueError('Wrong signer after dual-scheme signing')
        for name, _, _ in entries:
            with zipfile.ZipFile(result) as z:
                if name not in z.namelist():
                    raise SystemExit(f'missing entry {name}')
        out.write_bytes(result.read_bytes())
        digest = hashlib.sha256(out.read_bytes()).hexdigest()
        print(json.dumps({'apk': str(out), 'packageName': PACKAGE,
                          'versionName': VERSION_NAME, 'versionCode': VERSION_CODE,
                          'minSdk': MIN_SDK, 'targetSdk': TARGET_SDK,
                          'size': out.stat().st_size, 'sha256': digest}, indent=2))


if __name__ == '__main__':
    main()
