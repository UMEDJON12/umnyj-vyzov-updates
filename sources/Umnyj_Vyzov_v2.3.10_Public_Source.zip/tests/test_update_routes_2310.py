"""Bounded static checks for wiring; not a substitute for Android lifecycle tests."""
import hashlib
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src/com/smartcall/ru'
BASELINE = {
    'CallController.java': '5e9b3a29d9aec4644f47d6a0f9153ab6883fdfe0474e93ff773fd671f4e2eaab',
    'CallControlAccessibilityService.java': 'dd0ba4ed1ff213583dfd8d7f71a49c7647cf8e6866b8525b8cee4b03fad69c2f',
    'CallNotificationListenerService.java': 'df036b07c8b25c3389ec994bc391aa9d27ddeca0aff820208122b725e0f1f49f',
    'ProximitySensorListener.java': '7b04ed501897d006898bc7d820e85240ccf46f84acb7c4db509b660bbe6ffe9e',
    'ScreenAndVolumeReceiver.java': '568876f60c34a66bab71aacbee8a8056a7c3995e2a661815247de12235f46cfd',
    'AnswerFlow.java': '0ab0ec0c7546217b455c5a89997ef012a8ef287f14d94c6f6e5159b39952a479',
    'SettingsMigration.java': 'c05c54e6b691754eba7b673d35888896a87043b4ceeac4d3f3da38cb6730f738',
}

class RouteChecks(unittest.TestCase):
    def test_button_path_logs_and_uses_single_state(self):
        controller = (SRC / 'CallController.java').read_text()
        acc = (SRC / 'CallControlAccessibilityService.java').read_text()
        features = (SRC / 'SmartCallFeatures.java').read_text()
        self.assertIn('int action = keyAction(context, key, state);', controller)
        self.assertIn('boolean dispatched = CallController.handleHardwareButton(this, button);', acc)
        self.assertNotIn('if (!CallController.shouldInterceptKey(this, i))', acc)
        self.assertIn('Событие клавиши:', acc)
        self.assertIn('return CallControlAccessibilityService.clickCallButtonInUi(true);', features)
        self.assertNotIn('CallController.recordActiveCallState(98);', features)
        self.assertIn('if (candidate.isClickable()', acc)
        self.assertIn('return swipeNode(node, answer);', acc)
        self.assertIn('recordActiveCallState(0);', controller)

    def test_other_call_services_preserved(self):
        for name in ('CallNotificationListenerService.java','ProximitySensorListener.java',
                     'ScreenAndVolumeReceiver.java','AnswerFlow.java','SettingsMigration.java'):
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((SRC / name).read_bytes()).hexdigest(), BASELINE[name])

    def test_signed_version_and_manifest_components(self):
        build = (ROOT / 'build_apk.py').read_text()
        self.assertIn("VERSION_NAME = '2.3.10'", build)
        self.assertIn('VERSION_CODE = 33', build)
        manifest = (ROOT / 'build/axml_arsc_gen.py').read_text()
        for required in ('REQUEST_INSTALL_PACKAGES', 'WRITE_EXTERNAL_STORAGE', 'UpdateProgressActivity',
                         'UpdateService', 'UpdateInstallProvider', 'grantUriPermissions'):
            self.assertIn(required, manifest)

    def test_silent_auto_and_manual_splits(self):
        controller = (SRC / 'UpdatesController.java').read_text()
        policy = (SRC / 'UpdateNoticePolicy.java').read_text()
        self.assertIn('return manual;', policy)
        self.assertIn('if (manual) showStatus(activity', controller)
        self.assertIn('if (!UpdateNoticePolicy.shouldShow(manual, status))', controller)
        self.assertIn('if (!e.shouldOffer(m, manual))', controller)
        self.assertIn('busy.set(false);', controller)
        self.assertIn('busy.compareAndSet(false, true)', controller)
        self.assertIn('Не удалось проверить обновления:', controller)

    def test_progress_and_installer_routes(self):
        service = (SRC / 'UpdateService.java').read_text()
        activity = (SRC / 'UpdateProgressActivity.java').read_text()
        controller = (SRC / 'UpdatesController.java').read_text()
        main = (SRC / 'MainActivity.java').read_text()
        provider = (SRC / 'UpdateInstallProvider.java').read_text()
        self.assertIn('UpdateProgressActivity.startDownload(activity, m)', controller)
        self.assertIn('UpdateProgressActivity.openIntent(this)', service)
        self.assertIn('setContentIntent(openProgressIntent())', service)
        self.assertIn('DownloadStore.export(this, verifiedFile, d', service)
        self.assertIn('DownloadStore.snapshotForInstall', controller)
        self.assertIn('InstallVersionPolicy.status(', controller)
        self.assertIn('e.state().knownVersionCode(), record.versionCode', controller)
        self.assertIn('canRequestPackageInstalls()', controller)
        self.assertIn('FLAG_GRANT_READ_URI_PERMISSION', controller)
        self.assertIn('setClipData(', controller)
        install = controller[controller.index('public static void installDownloaded'):]
        self.assertNotIn('.delete(', install, 'install or its cancellation must not delete the exported APK')
        self.assertIn('postponeDownloaded', activity)
        self.assertIn('OpenableColumns.DISPLAY_NAME', provider)
        self.assertIn('OpenableColumns.SIZE', provider)
        self.assertIn('onNewIntent(Intent intent)', main)
        self.assertIn('onInstallPermissionResult(this, requestCode)', main)
        self.assertIn('onInstallPermissionResult(this, requestCode)', activity)
        self.assertIn('ACCESSIBILITY_LIVE_REGION_NONE', activity)
        self.assertIn('UpdateProgressText.progress(s.downloaded, s.total)', activity)
        self.assertNotIn('Обновление установлено', service)

if __name__ == '__main__':
    unittest.main()
