package com.smartcall.ru;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes2-original.dex */
public final class SmartCallFeatures {
    static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final SpeechPolicy.Dedup MESSAGES = new SpeechPolicy.Dedup();
    private static final ArrayDeque<SpeechJob> QUEUE = new ArrayDeque<>();
    public static SpeechJob active;
    private static AnswerFlow answerFlow;
    private static long answerGeneration;
    private static long messageSequence;
    private static long speechSequence;

    private SmartCallFeatures() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void log(String str) {
        CallController.log(str);
    }

    private static SharedPreferences prefs(Context context) {
        SettingsMigration.ensure(context);
        return context.getSharedPreferences("call_prefs", 0);
    }

    public static String cleanCaller(String str) {
        return SpeechPolicy.cleanCaller(str);
    }

    static int clamp(int value, int min, int max) {
        return value < min ? min : (value > max ? max : value);
    }

    public static void showPowerHelp(final Activity activity) {
        new AlertDialog.Builder(activity).setTitle("Кнопка питания и блокировка экрана").setMessage("Системное завершение разговора питанием: " + ((Settings.Secure.getInt(activity.getContentResolver(), "incall_power_button_behavior", 1) & 2) != 0 ? "включено" : "выключено") + ". Для уже принятого обычного разговора включите настройку Android «Кнопка питания завершает вызов». Для входящего вызова система может заглушить звонок и выключить экран до получения события приложением. Обычное приложение не может гарантированно запретить эту блокировку. Резервный сброс по SCREEN_OFF сохранён; для сброса без гашения экрана можно выбрать кнопку громкости. Снятие PIN/пароля приложение не выполняет.").setPositiveButton("Открыть специальные возможности", new DialogInterface.OnClickListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda11
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                activity.startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
            }
        }).setNegativeButton("Закрыть", (DialogInterface.OnClickListener) null).show();
    }

    public static String profileSummary(Context context) {
        SharedPreferences sharedPreferencesPrefs = prefs(context);
        StringBuilder sb = new StringBuilder("Голоса: ");
        String[] strArr = {"sim", "wa", "tg", "other", "sms"};
        for (int i = 0; i < 5; i++) {
            String str = strArr[i];
            StringBuilder sbAppend = sb.append(str).append('=');
            String strVoiceKey = SpeechPolicy.voiceKey(str);
            String string = "default";
            if (str.equals("sim")) {
                string = sharedPreferencesPrefs.getString("tts_voice_name", "default");
            }
            sbAppend.append(sharedPreferencesPrefs.getString(strVoiceKey, string)).append("; ");
        }
        return sb.toString();
    }

    public static void onEngineChanged(Context context, String str) {
        if (str != null && str.startsWith("tts_eng_")) {
            prefs(context).edit().putString(SpeechPolicy.voiceKey(str.substring(8)), "default").apply();
        }
    }

    public static void addVoiceButtons(final Activity activity, LinearLayout linearLayout) {
        String[] strArr = {"sim", "wa", "tg", "other", "sms"};
        String[] strArr2 = {"Голос SIM-звонков", "Голос WhatsApp", "Голос Telegram", "Голос других приложений", "Голос входящих SMS"};
        for (int i = 0; i < 5; i++) {
            final String str = strArr[i];
            final String str2 = strArr2[i];
            final Button button = new Button(activity);
            updateVoiceButton(activity, button, str, str2, "");
            button.setOnClickListener(new View.OnClickListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    SmartCallFeatures.showVoicePicker(activity, str, str2, "", button);
                }
            });
            linearLayout.addView(button);
        }
    }

    static String voiceKeyFor(String prefix, String channel) {
        return (prefix == null || prefix.isEmpty()) ? SpeechPolicy.voiceKey(channel) : prefix + "voice_" + channel;
    }

    static String engineKeyFor(String prefix, String channel) {
        return (prefix == null || prefix.isEmpty()) ? SpeechPolicy.engineKey(channel) : prefix + "eng_" + channel;
    }

    private static void updateVoiceButton(Activity activity, Button button, String str, String str2, String prefix) {
        String fallback = (prefix == null || prefix.isEmpty()) && str.equals("sim")
                ? prefs(activity).getString("tts_voice_name", "default") : "default";
        String string = prefs(activity).getString(voiceKeyFor(prefix, str), fallback);
        StringBuilder sbAppend = new StringBuilder(String.valueOf(str2)).append(": ");
        if ("default".equals(string)) {
            string = "По умолчанию";
        } else {
            String label = prefs(activity).getString(voiceKeyFor(prefix, str) + "_label", null);
            if (label != null && !label.isEmpty()) string = label;
            // Previously saved selections without a label remain identifiable.
            else string = "Выбранный голос (" + string + ")";
        }
        button.setText(sbAppend.append(string).toString());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void showVoicePicker(final Activity activity, final String str, final String str2, final Button button) {
        showVoicePicker(activity, str, str2, "", button);
    }

    /** prefix "" = legacy keys, "call_"/"msg_" = 2.3.7 per-profile keys. */
    public static void showVoicePicker(final Activity activity, final String str, final String str2, final String prefix, final Button button) {
        final String string = prefs(activity).getString(engineKeyFor(prefix, str), "default");
        final TextToSpeech[] textToSpeechArr = new TextToSpeech[1];
        final AlertDialog alertDialogCreate = new AlertDialog.Builder(activity).setMessage("Загружаются голоса выбранного синтезатора…").setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).create();
        final boolean[] zArr = new boolean[1];
        alertDialogCreate.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda12
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                SmartCallFeatures.lambda$2(zArr, textToSpeechArr, dialogInterface);
            }
        });
        alertDialogCreate.show();
        TextToSpeech.OnInitListener onInitListener = new TextToSpeech.OnInitListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda13
            @Override // android.speech.tts.TextToSpeech.OnInitListener
            public final void onInit(int i) {
                SmartCallFeatures.MAIN.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        SmartCallFeatures.lambda$4(zArr, activity, textToSpeechArr, i, alertDialogCreate, str2, string, str, prefix, button);
                    }
                });
            }
        };
        textToSpeechArr[0] = "default".equals(string) ? new TextToSpeech(activity, onInitListener) : new TextToSpeech(activity, onInitListener, string);
        MAIN.postDelayed(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                SmartCallFeatures.lambda$7(zArr, alertDialogCreate);
            }
        }, 15000L);
    }

    static /* synthetic */ void lambda$2(boolean[] zArr, TextToSpeech[] textToSpeechArr, DialogInterface dialogInterface) {
        zArr[0] = true;
        if (textToSpeechArr[0] != null) {
            textToSpeechArr[0].shutdown();
        }
    }

    static /* synthetic */ void lambda$4(boolean[] zArr, final Activity activity, TextToSpeech[] textToSpeechArr, int i, AlertDialog alertDialog, final String str, String str2, final String str3, final String prefix, final Button button) {
        int i2 = 0;
        if (zArr[0] || activity.isFinishing()) {
            if (textToSpeechArr[0] != null) {
                textToSpeechArr[0].shutdown();
                return;
            }
            return;
        }
        if (i != 0 || textToSpeechArr[0] == null) {
            alertDialog.dismiss();
            new AlertDialog.Builder(activity).setMessage("Синтезатор не загрузился. Проверьте выбранный движок и его голоса.").setPositiveButton("Закрыть", (DialogInterface.OnClickListener) null).show();
            return;
        }
        try {
            Set<Voice> voices = textToSpeechArr[0].getVoices();
            final ArrayList arrayList = new ArrayList();
            if (voices != null) {
                arrayList.addAll(voices);
            }
            // Equivalent name ordering without API-24 java.util.function or Comparator.comparing.
            Collections.sort(arrayList, new Comparator<Voice>() {
                @Override public int compare(Voice a, Voice b) {
                    return a.getName().compareTo(b.getName());
                }
            });
            final String[] strArr = new String[arrayList.size() + 1];
            strArr[0] = "По умолчанию (голос выбранного движка)";
            java.util.HashMap<String, Integer> languageOrdinals = new java.util.HashMap<>();
            while (i2 < arrayList.size()) {
                Voice voice = (Voice) arrayList.get(i2);
                i2++;
                java.util.Locale locale = voice.getLocale();
                String languageKey = locale == null ? "" : locale.toLanguageTag();
                Integer previous = languageOrdinals.get(languageKey);
                int ordinal = previous == null ? 1 : previous + 1;
                languageOrdinals.put(languageKey, ordinal);
                strArr[i2] = VoiceLabels.label(locale, ordinal, voice.isNetworkConnectionRequired());
            }
            alertDialog.dismiss();
            new AlertDialog.Builder(activity).setTitle(String.valueOf(str) + "; " + str2).setItems(strArr, new DialogInterface.OnClickListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda1
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i3) {
                    SmartCallFeatures.lambda$6(arrayList, activity, str3, button, str, prefix, strArr, dialogInterface, i3);
                }
            }).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
        } catch (RuntimeException e) {
            alertDialog.dismiss();
            log("Ошибка списка голосов: " + e);
        }
    }

    static /* synthetic */ void lambda$6(ArrayList arrayList, Activity activity, String str, Button button, String str2, String prefix, String[] labels, DialogInterface dialogInterface, int i) {
        // The engine's exact identifier remains the stored selection; labels are presentation only.
        if (i < 0 || i > arrayList.size() || i >= labels.length) return;
        String name = i == 0 ? "default" : ((Voice) arrayList.get(i - 1)).getName();
        prefs(activity).edit().putString(voiceKeyFor(prefix, str), name)
                .putString(voiceKeyFor(prefix, str) + "_label", i == 0 ? "По умолчанию" : labels[i]).apply();
        updateVoiceButton(activity, button, str, str2, prefix);
        // Refresh compact visible and accessibility labels after selecting a voice.
        if (activity instanceof MainActivity) ((MainActivity) activity).refreshProfileLabels();
        log("Голос сохранён: " + voiceKeyFor(prefix, str) + "=" + name);
        boolean callJob = (prefix != null && prefix.startsWith("call_"))
                || ((prefix == null || prefix.isEmpty()) && !"sms".equals(str));
        enqueueTest(activity, "Проверка выбранного голоса", str, callJob, 1);
    }

    static /* synthetic */ void lambda$7(boolean[] zArr, AlertDialog alertDialog) {
        if (zArr[0]) {
            return;
        }
        alertDialog.dismiss();
        log("Голоса: истекло ожидание инициализации синтезатора");
    }

    public static void speak(Context context, String str, String str2, int i) {
        String strSubstring = (str2 == null || !str2.startsWith("tts_eng_")) ? "sim" : str2.substring(8);
        enqueue(context, SpeechPolicy.cleanCaller(str), strSubstring, i, !strSubstring.equals("sms"), null);
    }

    public static void speakLegacy(Context context, String str, String str2, int i) {
        enqueue(context, str, "sim", i, true, str2);
    }

    private static void enqueue(Context context, String str, String str2, int i, boolean z, String str3) {
        enqueueInternal(context, str, str2, i, z, str3, 0);
    }

    /** testMode 1 = single test utterance regardless of the profile repeat count. */
    static void enqueueTest(Context context, String str, String str2, boolean callJob, int testMode) {
        enqueueInternal(context, str, str2, 1, callJob, null, testMode);
    }

    private static void enqueueInternal(Context context, String str, String str2, int i, boolean z, String str3, int testMode) {
        if (context == null || str == null || str.trim().isEmpty()) {
            return;
        }
        final SpeechJob speechJob = new SpeechJob(context.getApplicationContext(), str.trim(), str2, Math.max(1, Math.min(5, i)), z, str3);
        speechJob.testMode = testMode;
        MAIN.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                SmartCallFeatures.lambda$8(speechJob);
            }
        });
    }

    static /* synthetic */ void lambda$8(SpeechJob speechJob) {
        if (QUEUE.size() >= 32) {
            log("TTS: очередь переполнена; сообщение не добавлено");
        } else {
            QUEUE.add(speechJob);
            pump();
        }
    }

    public static void stopSpeech() {
        MAIN.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                SmartCallFeatures.lambda$9();
            }
        });
    }

    static /* synthetic */ void lambda$9() {
        ArrayList arrayList = new ArrayList();
        while (!QUEUE.isEmpty()) {
            SpeechJob speechJobRemove = QUEUE.remove();
            if (!speechJobRemove.call) {
                arrayList.add(speechJobRemove);
            }
        }
        QUEUE.addAll(arrayList);
        if (active == null || !active.call) {
            return;
        }
        finish(active);
    }

    private static void pump() {
        if (active != null || QUEUE.isEmpty()) {
            return;
        }
        final SpeechJob speechJobRemove = QUEUE.remove();
        active = speechJobRemove;
        SharedPreferences sharedPreferencesPrefs = prefs(speechJobRemove.context);
        String profilePrefix = speechJobRemove.call ? "call_" : "msg_";
        String legacyEngine = SpeechPolicy.engineKey(speechJobRemove.channel);
        String legacyVoice = SpeechPolicy.voiceKey(speechJobRemove.channel);
        String string = speechJobRemove.explicitEngine != null
                ? speechJobRemove.explicitEngine
                : sharedPreferencesPrefs.getString(profilePrefix + "eng_" + speechJobRemove.channel,
                        sharedPreferencesPrefs.getString(legacyEngine, "default"));
        String voiceDefault = speechJobRemove.channel.equals("sim")
                ? sharedPreferencesPrefs.getString("tts_voice_name", "default") : "default";
        speechJobRemove.voice = sharedPreferencesPrefs.getString(profilePrefix + "voice_" + speechJobRemove.channel,
                sharedPreferencesPrefs.getString(legacyVoice, voiceDefault));
        if (speechJobRemove.testMode == 1) {
            // A voice check speaks exactly once, but keeps engine/voice/rate/audio.
            speechJobRemove.repeat = 1;
            speechJobRemove.delaySeconds = 0;
        } else if (speechJobRemove.call) {
            speechJobRemove.repeat = clamp(sharedPreferencesPrefs.getInt(
                    "call_repeat_" + speechJobRemove.channel, speechJobRemove.repeat), 1, 5);
            speechJobRemove.delaySeconds = clamp(sharedPreferencesPrefs.getInt(
                    "call_delay_" + speechJobRemove.channel, 0), 0, 30);
        } else {
            // Text messages are always spoken exactly once, without repeats or delays.
            speechJobRemove.repeat = 1;
            speechJobRemove.delaySeconds = 0;
        }
        speechJobRemove.step = 0;
        // В журнал не попадают имя, номер и текст сообщения — только параметры озвучки.
        log("TTS профиль=" + speechJobRemove.channel + ", движок=" + string + ", голос=" + speechJobRemove.voice
                + ", повторов=" + speechJobRemove.repeat + ", задержка=" + speechJobRemove.delaySeconds
                + "с, длина текста=" + (speechJobRemove.text == null ? 0 : speechJobRemove.text.length()));
        TextToSpeech.OnInitListener onInitListener = new TextToSpeech.OnInitListener() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda9
            @Override // android.speech.tts.TextToSpeech.OnInitListener
            public final void onInit(int i) {
                SmartCallFeatures.MAIN.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() {
                        SmartCallFeatures.lambda$11(speechJobRemove, i);
                    }
                });
            }
        };
        try {
            speechJobRemove.tts = "default".equals(string) ? new TextToSpeech(speechJobRemove.context, onInitListener) : new TextToSpeech(speechJobRemove.context, onInitListener, string);
        } catch (RuntimeException e) {
            log("TTS: " + e);
            finish(speechJobRemove);
        }
        MAIN.postDelayed(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                SmartCallFeatures.lambda$12(speechJobRemove);
            }
        }, 120000L);
    }

    static /* synthetic */ void lambda$11(SpeechJob speechJob, int i) {
        boolean z;
        if (active != speechJob) {
            return;
        }
        if (i != 0 || speechJob.tts == null) {
            log("TTS: ошибка инициализации " + i);
            finish(speechJob);
            return;
        }
        try {
            if (!"default".equals(speechJob.voice)) {
                Set<Voice> voices = speechJob.tts.getVoices();
                z = false;
                if (voices != null) {
                    Iterator<Voice> it = voices.iterator();
                    while (it.hasNext()) {
                        Voice next = it.next();
                        if (speechJob.voice.equals(next.getName())) {
                            int voice = speechJob.tts.setVoice(next);
                            z = voice == 0;
                            log("TTS: setVoice=" + next.getName() + ", результат=" + voice);
                            break;
                        }
                    }
                }
                if (!z) {
                    log("TTS: выбранный голос отсутствует/не принят, используется стандартный голос этого движка");
                }
            }
            TextToSpeech textToSpeech = speechJob.tts;
            speechJob.tts.setOnUtteranceProgressListener(new AnonymousClass1(speechJob));
            CallController.recordActiveCallState(99);
            if (speechJob.lastId != null) {
                return;
            }
            finish(speechJob);
        } catch (RuntimeException e) {
            log("TTS: " + e);
            finish(speechJob);
        }
    }

    /* JADX INFO: renamed from: com.smartcall.ru.SmartCallFeatures$1, reason: invalid class name */
    static class AnonymousClass1 extends UtteranceProgressListener {
        private final /* synthetic */ SpeechJob val$job;

        AnonymousClass1(SpeechJob speechJob) {
            this.val$job = speechJob;
        }

        @Override // android.speech.tts.UtteranceProgressListener
        public void onStart(String str) {
        }

        @Override // android.speech.tts.UtteranceProgressListener
        public void onDone(final String str) {
            if (str != null && str.equals(this.val$job.lastId)) {
                Handler handler = SmartCallFeatures.MAIN;
                final SpeechJob speechJob = this.val$job;
                handler.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        AnonymousClass1.nextRepeat(speechJob, str);
                    }
                });
            }
        }

        /** Continues repeats only after the previous utterance really finished. */
        static void nextRepeat(SpeechJob job, String finishedId) {
            if (SmartCallFeatures.active != job || job.lastId == null
                    || !job.lastId.equals(finishedId)) {
                return;
            }
            if (job.step + 1 >= job.repeat) {
                SmartCallFeatures.finish(job);
                return;
            }
            job.step++;
            final long delayMs = job.delaySeconds * 1000L;
            if (delayMs > 0) {
                SmartCallFeatures.MAIN.postDelayed(new Runnable() {
                    @Override // java.lang.Runnable
                    public void run() {
                        CallController.speakStep(job);
                    }
                }, delayMs);
            } else {
                CallController.speakStep(job);
            }
        }

        static /* synthetic */ void lambda$1(String str, SpeechJob speechJob) {
            SmartCallFeatures.log("TTS: ошибка произнесения " + str);
            SmartCallFeatures.finish(speechJob);
        }

        @Override // android.speech.tts.UtteranceProgressListener
        public void onError(final String str) {
            Handler handler = SmartCallFeatures.MAIN;
            final SpeechJob speechJob = this.val$job;
            handler.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    SmartCallFeatures.AnonymousClass1.lambda$1(str, speechJob);
                }
            });
        }
    }

    static /* synthetic */ void lambda$12(SpeechJob speechJob) {
        // Initialization watchdog only: repeats have their own per-step watchdog.
        if (active == speechJob && speechJob.lastId == null) {
            log("TTS: истекло ожидание инициализации");
            finish(speechJob);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void finish(SpeechJob speechJob) {
        if (active != speechJob) {
            return;
        }
        if (speechJob.tts != null) {
            try {
                speechJob.tts.stop();
                speechJob.tts.shutdown();
            } catch (RuntimeException e) {
            }
        }
        active = null;
        pump();
    }

    /* JADX INFO: Access modifiers changed from: private */
    static final class SpeechJob {
        final boolean call;
        final String channel;
        final Context context;
        final String explicitEngine;
        volatile String lastId;
        int repeat;
        int testMode;
        int delaySeconds;
        int step;
        android.os.Bundle params;
        final String text;
        TextToSpeech tts;
        String voice;

        SpeechJob(Context context, String str, String str2, int i, boolean z, String str3) {
            this.context = context;
            this.text = str;
            this.channel = str2;
            this.repeat = i;
            this.call = z;
            this.explicitEngine = str3;
        }
    }

    public static void announceSms(Context context, String str, String str2, String str3) {
        String strChannel = SpeechPolicy.channel(str);
        String str4 = "sms:" + str + ":" + str2;
        StringBuilder sbAppend = new StringBuilder(String.valueOf(str3 == null ? "" : str3)).append(":");
        long j = messageSequence + 1;
        messageSequence = j;
        announceMessage(context, strChannel, str2, str3, str4, sbAppend.append(j).toString());
    }

    private static void announceMessage(Context context, String str, String str2, String str3, String str4, String str5) {
        String str6;
        SharedPreferences sharedPreferencesPrefs = prefs(context);
        if (str2 == null) {
            str2 = "";
        }
        if (str3 == null) {
            str3 = "";
        }
        // 2.3.7 profile schema; before migration the legacy gates apply unchanged.
        boolean hasProfile = sharedPreferencesPrefs.contains("msg_enabled_" + str);
        boolean enabled = hasProfile
                ? sharedPreferencesPrefs.getBoolean("msg_enabled_" + str, false)
                : (sharedPreferencesPrefs.getBoolean("tts_enabled", true)
                        && sharedPreferencesPrefs.getBoolean("tts_app_" + str, true)
                        && sharedPreferencesPrefs.getBoolean("tts_sms_text", true));
        if (!enabled) {
            return;
        }
        boolean readText = hasProfile
                ? sharedPreferencesPrefs.getBoolean("msg_read_text_" + str, false)
                : sharedPreferencesPrefs.getBoolean("tts_sms_text", true);
        int lockMode = hasProfile ? sharedPreferencesPrefs.getInt("msg_lock_mode_" + str, 0) : 0;
        boolean locked = isScreenLocked(context);
        if (locked && lockMode == 0) {
            log("Сообщение не озвучено: экран заблокирован, режим «Не озвучивать»");
            return;
        }
        if (!(str2.isEmpty() && str3.isEmpty()) && MESSAGES.accept(str4, str5)) {
            if (!str2.matches(".*[\\p{L}].*")) {
                try {
                    String strLookupContactName = CallController.lookupContactName(context, str2);
                    if (strLookupContactName != null && !strLookupContactName.isEmpty()) {
                        str2 = strLookupContactName;
                    }
                } catch (RuntimeException e) {
                }
            }
            if (str.equals("wa")) {
                str6 = "WhatsApp ";
            } else if (str.equals("tg")) {
                str6 = "Telegram ";
            } else {
                str6 = str.equals("sms") ? "СМС " : "Сообщение ";
            }
            String str7 = String.valueOf(str6) + str2;
            // Body reading is controlled by its own switch and never bypassed by
            // the locked-screen mode: mode 1 speaks only the sender, mode 2 the
            // sender plus the text, and only when reading text is allowed.
            boolean speakBody = readText && (!locked || lockMode == 2);
            String str8 = (speakBody && !str3.isEmpty()) ? String.valueOf(str7) + "\n" + str3 : str7;
            // Do not put the sender or message text into the diagnostics log.
            log("Получено сообщение: профиль=" + str + ", текст=" + (speakBody ? "да" : "нет")
                    + ", экран=" + (locked ? "заблокирован" : "разблокирован"));
            enqueue(context, str8, str, 1, false, null);
        }
    }

    private static boolean isScreenLocked(Context context) {
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager)
                    context.getSystemService(Context.KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (RuntimeException e) {
            // Fail closed: treat an unknown state as locked.
            return true;
        }
    }

    public static boolean handleMessageNotification(Context context, StatusBarNotification statusBarNotification) {
        Notification notification;
        String str;
        long timestamp;
        CharSequence[] charSequenceArray;
        List<Notification.MessagingStyle.Message> messagesFromBundleArray;
        if (statusBarNotification == null) {
            return false;
        }
        String packageName = statusBarNotification.getPackageName();
        String strChannel = SpeechPolicy.channel(packageName);
        if ((!strChannel.equals("wa") && !strChannel.equals("tg") && !strChannel.equals("sms") && !packageName.contains("viber") && !packageName.contains("imo")) || (notification = statusBarNotification.getNotification()) == null || "call".equals(notification.category)) {
            return false;
        }
        if (notification.extras != null && (notification.extras.get("android.answerIntent") != null || notification.extras.getInt("android.callType", 0) != 0)) {
            return false;
        }
        if ((strChannel.equals("sms") && CallController.hasPermission(context, "android.permission.RECEIVE_SMS")) || (notification.flags & 512) != 0) {
            return true;
        }
        if ((notification.flags & 2) != 0 && !"msg".equals(notification.category) && (notification.extras == null || !notification.extras.containsKey("android.messages"))) {
            return true;
        }
        try {
            Bundle bundle = notification.extras;
            if (bundle == null) {
                return true;
            }
            String strString = string(bundle.getCharSequence("android.title"));
            String strString2 = string(bundle.getCharSequence("android.bigText"));
            if (strString2.isEmpty()) {
                strString2 = string(bundle.getCharSequence("android.text"));
            }
            Parcelable[] parcelableArray = bundle.getParcelableArray("android.messages");
            if (parcelableArray != null && Build.VERSION.SDK_INT >= 30 && (messagesFromBundleArray = Notification.MessagingStyle.Message.getMessagesFromBundleArray(parcelableArray)) != null && !messagesFromBundleArray.isEmpty()) {
                Notification.MessagingStyle.Message message = messagesFromBundleArray.get(messagesFromBundleArray.size() - 1);
                if (message.getSender() != null) {
                    strString = message.getSender().toString();
                }
                strString2 = string(message.getText());
                timestamp = message.getTimestamp();
                str = strString;
            } else {
                str = strString;
                timestamp = 0;
            }
            String strString3 = (!strString2.isEmpty() || (charSequenceArray = bundle.getCharSequenceArray("android.textLines")) == null || charSequenceArray.length <= 0) ? strString2 : string(charSequenceArray[charSequenceArray.length - 1]);
            if (strString3.isEmpty()) {
                log("Сообщение: уведомление без доступного текста, пакет=" + packageName);
                return true;
            }
            if (timestamp == 0) {
                timestamp = notification.when;
            }
            announceMessage(context, strChannel, str, strString3, statusBarNotification.getKey(), String.valueOf(str) + "\n" + strString3 + "\n" + timestamp);
            return true;
        } catch (RuntimeException e) {
            log("Ошибка чтения уведомления сообщения: " + e);
            return true; // DEX catch continues at L179.
        }
    }

    private static String string(CharSequence charSequence) {
        return charSequence == null ? "" : charSequence.toString().trim();
    }

    public static String findCallerName(AccessibilityService accessibilityService) {
        if (accessibilityService == null) {
            return null;
        }
        try {
            String strFindCaller = findCaller(accessibilityService, accessibilityService.getRootInActiveWindow(), 0);
            if (strFindCaller != null) {
                return strFindCaller;
            }
            List<AccessibilityWindowInfo> windows = accessibilityService.getWindows();
            if (windows != null) {
                Iterator<AccessibilityWindowInfo> it = windows.iterator();
                while (it.hasNext()) {
                    String strFindCaller2 = findCaller(accessibilityService, it.next().getRoot(), 0);
                    if (strFindCaller2 != null) {
                        return strFindCaller2;
                    }
                }
            }
        } catch (RuntimeException e) {
            log("Имя из окна: " + e);
        }
        return null;
    }

    private static String findCaller(Context context, AccessibilityNodeInfo accessibilityNodeInfo, int i) {
        if (accessibilityNodeInfo == null || i > 24) {
            return null;
        }
        String strString = string(accessibilityNodeInfo.getPackageName());
        if (strString.equals("com.smartcall.ru") || strString.contains("launcher") || strString.contains("systemui") || !callPackage(context, strString)) {
            return null;
        }
        String strString2 = string(accessibilityNodeInfo.getText());
        if (accessibilityNodeInfo.isVisibleToUser() && SpeechPolicy.callerNode(accessibilityNodeInfo.getViewIdResourceName(), strString2, accessibilityNodeInfo.isEditable())) {
            return SpeechPolicy.cleanCaller(strString2);
        }
        for (int i2 = 0; i2 < Math.min(accessibilityNodeInfo.getChildCount(), 100); i2++) {
            String strFindCaller = findCaller(context, accessibilityNodeInfo.getChild(i2), i + 1);
            if (strFindCaller != null) {
                return strFindCaller;
            }
        }
        return null;
    }

    public static void cancelAnswer() {
        answerGeneration++;
        if (answerFlow != null) {
            answerFlow.cancel();
        }
        answerFlow = null;
    }

    public static void answer(final Context context) {
        final long j = answerGeneration + 1;
        answerGeneration = j;
        MAIN.post(new Runnable() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                SmartCallFeatures.lambda$13(j, context);
            }
        });
    }

    static /* synthetic */ void lambda$13(long j, final Context context) {
        if (j != answerGeneration) {
            return;
        }
        if (answerFlow != null) {
            answerFlow.cancel();
        }
        CallController.stopTts();
        final long j2 = CallController.callRingStartTime;
        answerFlow = new AnswerFlow(new AnswerFlow.Actions() { // from class: com.smartcall.ru.SmartCallFeatures.2
            @Override // com.smartcall.ru.AnswerFlow.Actions
            public int liveState() {
                if (j2 == 0 || CallController.callRingStartTime == 0 || CallController.callRingStartTime == j2) {
                    return SmartCallFeatures.readLiveState(context);
                }
                return 0;
            }

            @Override // com.smartcall.ru.AnswerFlow.Actions
            public void telecom() {
                TelecomManager telecomManager;
                if (Build.VERSION.SDK_INT < 26 || (telecomManager = (TelecomManager) context.getSystemService("telecom")) == null) {
                    return;
                }
                telecomManager.acceptRingingCall();
                log("Ответ: запрос acceptRingingCall отправлен; ожидаем реальное состояние");
            }

            @Override // com.smartcall.ru.AnswerFlow.Actions
            public void notification() {
                log("Ответ: действие уведомления отправлено=" + CallNotificationListenerService.triggerCallNotificationAction(true));
            }

            @Override // com.smartcall.ru.AnswerFlow.Actions
            public void ui() {
                log("Ответ: кнопка/жест интерфейса отправлены=" + SmartCallFeatures.answerUi(context));
            }

            @Override // com.smartcall.ru.AnswerFlow.Actions
            public void completed(int i) {
                CallController.recordActiveCallState(i);
            }

            @Override // com.smartcall.ru.AnswerFlow.Actions
            public void log(String str) {
                SmartCallFeatures.log(str);
            }
        }, new AnswerFlow.Scheduler() { // from class: com.smartcall.ru.SmartCallFeatures$$ExternalSyntheticLambda4
            @Override // com.smartcall.ru.AnswerFlow.Scheduler
            public final void later(Runnable runnable, long j3) {
                SmartCallFeatures.MAIN.postDelayed(runnable, j3);
            }
        });
        answerFlow.start();
    }

    private static int phoneState(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService("phone");
            if (telephonyManager == null) {
                return 0;
            }
            return telephonyManager.getCallState();
        } catch (RuntimeException e) {
            return 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int readLiveState(Context context) {
        boolean z;
        boolean z2;
        Bundle bundle;
        boolean z3;
        boolean z4;
        int iPhoneState = phoneState(context);
        if (iPhoneState == 1) {
            return 1;
        }
        if (iPhoneState == 2) {
            return 2;
        }
        try {
            CallNotificationListenerService callNotificationListenerService = CallNotificationListenerService.instance;
            StatusBarNotification[] activeNotifications = callNotificationListenerService == null ? null : callNotificationListenerService.getActiveNotifications();
            if (activeNotifications != null) {
                z = false;
                z2 = false;
                for (StatusBarNotification statusBarNotification : activeNotifications) {
                    Notification notification = statusBarNotification.getNotification();
                    if (notification != null && "call".equals(notification.category) && !statusBarNotification.getPackageName().equals("com.smartcall.ru") && (bundle = notification.extras) != null) {
                        int i = bundle.getInt("android.callType", 0);
                        if (i == 1 || bundle.get("android.answerIntent") != null) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z |= z3;
                        if (i == 2 || bundle.get("android.hangUpIntent") != null) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        z2 |= z4;
                    }
                }
            } else {
                z = false;
                z2 = false;
            }
            int iDetectCallUiState = CallControlAccessibilityService.detectCallUiState();
            if (z || iDetectCallUiState == 1) {
                return 1;
            }
            if (z2 || iDetectCallUiState == 2) {
                return 2;
            }
            return 0;
        } catch (RuntimeException e) {
            log("Ответ: проверка уведомлений/окна: " + e);
            return 0; // DEX catch continues at L8d.
        }
    }

    private static boolean callPackage(Context context, String str) {
        if (str.contains("dialer") || str.contains("incallui") || str.contains("telecom") || str.contains("contacts")) {
            return phoneState(context) == 1;
        }
        try {
            CallNotificationListenerService callNotificationListenerService = CallNotificationListenerService.instance;
            if (callNotificationListenerService != null) {
                for (StatusBarNotification statusBarNotification : callNotificationListenerService.getActiveNotifications()) {
                    if (str.equals(statusBarNotification.getPackageName()) && "call".equals(statusBarNotification.getNotification().category)) {
                        return true;
                    }
                }
            }
        } catch (RuntimeException e) {
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean answerUi(Context context) {
        if (CallControlAccessibilityService.instance == null || readLiveState(context) != 1) {
            return false;
        }
        try {
            // Returning true before actually clicking the answer control masked the failure.
            return CallControlAccessibilityService.clickCallButtonInUi(true);
        } catch (RuntimeException e) {
            log("Ответ: ошибка интерфейса " + e);
            return false;
        }
    }

    private static boolean answerNode(Context context, AccessibilityService accessibilityService, AccessibilityNodeInfo accessibilityNodeInfo, int i) {
        if (accessibilityNodeInfo == null || i > 24 || !callPackage(context, string(accessibilityNodeInfo.getPackageName()))) {
            return false;
        }
        String lowerCase = (String.valueOf(string(accessibilityNodeInfo.getText())) + " " + string(accessibilityNodeInfo.getContentDescription()) + " " + accessibilityNodeInfo.getViewIdResourceName()).toLowerCase(Locale.ROOT);
        boolean z = lowerCase.contains("ответить") || lowerCase.contains("принять") || lowerCase.contains("answer") || lowerCase.contains("accept_call") || lowerCase.contains("answer_call");
        boolean z2 = lowerCase.contains("перезвон") || lowerCase.contains("callback") || lowerCase.contains("call_back") || lowerCase.contains("reject") || lowerCase.contains("decline");
        if (z && !z2 && accessibilityNodeInfo.isVisibleToUser() && accessibilityNodeInfo.isEnabled()) {
            int i2 = 0;
            for (AccessibilityNodeInfo parent = accessibilityNodeInfo; i2 < 3 && parent != null; parent = parent.getParent()) {
                if (parent.isClickable() && parent.performAction(16)) {
                    return true;
                }
                i2++;
            }
            if (Build.VERSION.SDK_INT < 24) return false; // No gesture fallback on API 21–23.
            Rect rect = new Rect();
            accessibilityNodeInfo.getBoundsInScreen(rect);
            if (rect.width() > 0 && rect.height() > 0 && readLiveState(context) == 1) {
                Path path = new Path();
                path.moveTo(rect.centerX(), rect.centerY());
                path.lineTo(rect.centerX(), Math.max(1, rect.centerY() - Math.max(160, rect.height() * 2)));
                return accessibilityService.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, 280L)).build(), null, null);
            }
        }
        for (int i3 = 0; i3 < Math.min(accessibilityNodeInfo.getChildCount(), 100); i3++) {
            if (answerNode(context, accessibilityService, accessibilityNodeInfo.getChild(i3), i + 1)) {
                return true;
            }
        }
        return false;
    }
}
