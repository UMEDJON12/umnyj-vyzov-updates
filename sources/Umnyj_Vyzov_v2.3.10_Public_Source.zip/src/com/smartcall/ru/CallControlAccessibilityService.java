package com.smartcall.ru;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class CallControlAccessibilityService extends AccessibilityService {
    public static CallControlAccessibilityService instance;
    public static boolean receiverRegistered;
    private int consumedKeyCode;
    private ScreenAndVolumeReceiver receiver;

    public static boolean clickCallButtonInUi(boolean z) {
        AccessibilityNodeInfo root;
        try {
            CallControlAccessibilityService callControlAccessibilityService = instance;
            if (callControlAccessibilityService == null) {
                return false;
            }
            AccessibilityNodeInfo rootInActiveWindow = callControlAccessibilityService.getRootInActiveWindow();
            if (rootInActiveWindow != null && clickNodeTree(rootInActiveWindow, z)) {
                return true;
            }
            List<AccessibilityWindowInfo> windows = callControlAccessibilityService.getWindows();
            if (windows == null) {
                return false;
            }
            int size = windows.size();
            for (int i = 0; i < size; i++) {
                AccessibilityWindowInfo accessibilityWindowInfo = windows.get(i);
                if (accessibilityWindowInfo != null && (root = accessibilityWindowInfo.getRoot()) != null && clickNodeTree(root, z)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    /** Dispatch only one UI action per button: click OR a fallback gesture. */
    public static boolean clickNodeTree(AccessibilityNodeInfo node, boolean answer) {
        if (node == null) return false;
        try {
            if (!matchesNode(node, answer)) {
                for (int i = 0; i < Math.min(node.getChildCount(), 100); i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null && clickNodeTree(child, answer)) return true;
                }
                return false;
            }
            if (!node.isVisibleToUser() || !node.isEnabled()) return false;
            AccessibilityNodeInfo candidate = node;
            for (int parent = 0; parent < 3 && candidate != null; parent++) {
                if (candidate.isClickable() && candidate.isEnabled()
                        && candidate.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    CallController.log("Экран: отправлен ACTION_CLICK " + (answer ? "ответа" : "сброса"));
                    return true;
                }
                candidate = candidate.getParent();
            }
            return swipeNode(node, answer);
        } catch (Throwable ex) {
            CallController.log("Экран: ошибка кнопки " + ex.getClass().getSimpleName());
            return false;
        }
    }

    public static int detectCallUiState() {
        AccessibilityNodeInfo root;
        int iScanNodeTree = 0;
        try {
            CallControlAccessibilityService callControlAccessibilityService = instance;
            if (callControlAccessibilityService == null) {
                return 0;
            }
            AccessibilityNodeInfo rootInActiveWindow = callControlAccessibilityService.getRootInActiveWindow();
            if (rootInActiveWindow != null) {
                iScanNodeTree = scanNodeTree(rootInActiveWindow);
                if ((iScanNodeTree & 1) != 0) {
                    return 1;
                }
            }
            List<AccessibilityWindowInfo> windows = callControlAccessibilityService.getWindows();
            if (windows != null) {
                int size = windows.size();
                for (int i = 0; i < size; i++) {
                    AccessibilityWindowInfo accessibilityWindowInfo = windows.get(i);
                    if (accessibilityWindowInfo != null && (root = accessibilityWindowInfo.getRoot()) != null) {
                        iScanNodeTree |= scanNodeTree(root);
                        if ((iScanNodeTree & 1) != 0) {
                            return 1;
                        }
                    }
                }
            }
            if ((iScanNodeTree & 1) != 0 || CallController.voipIncoming) {
                return 1;
            }
            return (iScanNodeTree & 2) == 0 ? 0 : 2;
        } catch (Throwable th) {
            return 0;
        }
    }

    public static String findCallerNameInUi() {
        AccessibilityNodeInfo rootInActiveWindow;
        AccessibilityNodeInfo root;
        String strFindCallerNodeRec;
        CallControlAccessibilityService callControlAccessibilityService = instance;
        if (callControlAccessibilityService == null) {
            return null;
        }
        String strFindCallerName = SmartCallFeatures.findCallerName(callControlAccessibilityService);
        if (strFindCallerName != null || ((rootInActiveWindow = callControlAccessibilityService.getRootInActiveWindow()) != null && (strFindCallerName = findCallerNodeRec(rootInActiveWindow)) != null)) {
            return strFindCallerName;
        }
        List<AccessibilityWindowInfo> windows = callControlAccessibilityService.getWindows();
        if (windows == null) {
            return null;
        }
        int size = windows.size();
        for (int i = 0; i < size; i++) {
            AccessibilityWindowInfo accessibilityWindowInfo = windows.get(i);
            if (accessibilityWindowInfo != null && (root = accessibilityWindowInfo.getRoot()) != null && (strFindCallerNodeRec = findCallerNodeRec(root)) != null) {
                return strFindCallerNodeRec;
            }
        }
        return null;
    }

    public static String findCallerNodeRec(AccessibilityNodeInfo accessibilityNodeInfo) {
        String strFindCallerNodeRec;
        String string;
        int length;
        if (accessibilityNodeInfo != null) {
            try {
                CharSequence packageName = accessibilityNodeInfo.getPackageName();
                if (packageName != null) {
                    String lowerCase = packageName.toString().toLowerCase();
                    if (!"com.smartcall.ru".equals(lowerCase) && !lowerCase.contains("launcher") && !lowerCase.contains("systemui") && !lowerCase.contains("miui.home") && (lowerCase.contains("dialer") || lowerCase.contains("incallui") || lowerCase.contains("telecom") || lowerCase.contains("phone"))) {
                        CharSequence text = accessibilityNodeInfo.getText();
                        if (text != null && (length = (string = text.toString()).length()) > 2 && length < 45 && !string.contains(":") && !string.contains("%") && !CallNotificationListenerService.isPositiveText(string) && !CallNotificationListenerService.isNegativeText(string)) {
                            String lowerCase2 = string.toLowerCase();
                            if (!CallNotificationListenerService.isExcludedText(lowerCase2) && !lowerCase2.contains("вызов") && !lowerCase2.contains("звонок") && !lowerCase2.contains("входящ") && !lowerCase2.contains("sim") && !lowerCase2.contains("кб/с")) {
                                return string;
                            }
                        }
                        int childCount = accessibilityNodeInfo.getChildCount();
                        for (int i = 0; i < childCount; i++) {
                            AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
                            if (child != null && (strFindCallerNodeRec = findCallerNodeRec(child)) != null) {
                                return strFindCallerNodeRec;
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                return null;
            }
        }
        return null;
    }

    public static int getActiveCapabilities() {
        AccessibilityServiceInfo serviceInfo;
        try {
            CallControlAccessibilityService callControlAccessibilityService = instance;
            if (callControlAccessibilityService == null || (serviceInfo = callControlAccessibilityService.getServiceInfo()) == null) {
                return 0;
            }
            return serviceInfo.getCapabilities();
        } catch (Throwable th) {
            return 0;
        }
    }

    public static boolean matchesNode(AccessibilityNodeInfo accessibilityNodeInfo, boolean z) {
        CharSequence packageName;
        if (accessibilityNodeInfo == null || (packageName = accessibilityNodeInfo.getPackageName()) == null) {
            return false;
        }
        String lowerCase = packageName.toString().toLowerCase();
        if ("com.smartcall.ru".equals(lowerCase)) {
            return false;
        }
        if (!lowerCase.contains("systemui")) {
            if (lowerCase.contains("launcher") || lowerCase.contains("miui.home")) {
                return false;
            }
            if (!lowerCase.contains("dialer") && !lowerCase.contains("incallui") && !lowerCase.contains("telecom") && !lowerCase.contains("phone")) {
                if (!CallController.voipIncoming && !CallController.voipOngoing) {
                    return false;
                }
                if (!lowerCase.contains("whatsapp") && !lowerCase.contains("telegram") && !lowerCase.contains("nekogram") && !lowerCase.contains("viber") && !lowerCase.contains("imo")) {
                    return false;
                }
            }
        }
        CharSequence text = accessibilityNodeInfo.getText();
        if (text != null) {
            String string = text.toString();
            if (z) {
                if (CallNotificationListenerService.isPositiveText(string)) {
                    return true;
                }
            } else if (CallNotificationListenerService.isNegativeText(string)) {
                return true;
            }
        }
        CharSequence contentDescription = accessibilityNodeInfo.getContentDescription();
        if (contentDescription != null) {
            String string2 = contentDescription.toString();
            if (z) {
                if (CallNotificationListenerService.isPositiveText(string2)) {
                    return true;
                }
            } else if (CallNotificationListenerService.isNegativeText(string2)) {
                return true;
            }
        }
        String viewIdResourceName = accessibilityNodeInfo.getViewIdResourceName();
        if (viewIdResourceName == null) {
            return false;
        }
        if (z) {
            return CallNotificationListenerService.isPositiveText(viewIdResourceName);
        }
        return CallNotificationListenerService.isNegativeText(viewIdResourceName);
    }

    public static void performDelayedSwipeUp(Context context) {
        if (Build.VERSION.SDK_INT < 24) return;
        CallControlAccessibilityService callControlAccessibilityService;
        if (context != null) {
            try {
                if (CallController.getCallState(context) != 1 || (callControlAccessibilityService = instance) == null) {
                    return;
                }
                int i = CallController.pendingSwipeX;
                int i2 = CallController.pendingSwipeY;
                if (i <= 0 || i2 <= 0) {
                    return;
                }
                float f = i;
                float f2 = i2;
                int i3 = (((i2 - 120) - 120) - 120) - 120;
                if (i3 <= 0) {
                    i3 = 100;
                }
                Path path = new Path();
                path.moveTo(f, f2);
                path.lineTo(f, i3);
                callControlAccessibilityService.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, 220L)).build(), null, null);
                CallController.log("Экран: свайп вверх по кнопке ответа");
            } catch (Throwable th) {
            }
        }
    }

    public static int scanNodeTree(AccessibilityNodeInfo accessibilityNodeInfo) {
        int iScanNodeTree = 0;
        if (accessibilityNodeInfo != null) {
            try {
                CharSequence packageName = accessibilityNodeInfo.getPackageName();
                if (packageName == null || !packageName.toString().contains("systemui")) {
                    iScanNodeTree = matchesNode(accessibilityNodeInfo, true) ? 0 | 1 : 0;
                    if (matchesNode(accessibilityNodeInfo, false)) {
                        iScanNodeTree |= 2;
                    }
                    int childCount = accessibilityNodeInfo.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        AccessibilityNodeInfo child = accessibilityNodeInfo.getChild(i);
                        if (child != null) {
                            iScanNodeTree |= scanNodeTree(child);
                            if ((iScanNodeTree & 1) != 0) {
                                break;
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                return iScanNodeTree;
            }
        }
        return iScanNodeTree;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0095 A[Catch: all -> 0x00a2, TryCatch #0 {all -> 0x00a2, blocks: (B:2:0x0000, B:5:0x0006, B:9:0x001c, B:11:0x0024, B:17:0x0069, B:18:0x0081, B:20:0x0095, B:21:0x009c, B:14:0x0040, B:16:0x0047), top: B:25:0x0000 }] */
    /* JADX WARN: Code duplicated, block: B:21:0x009c A[Catch: all -> 0x00a2, TRY_LEAVE, TryCatch #0 {all -> 0x00a2, blocks: (B:2:0x0000, B:5:0x0006, B:9:0x001c, B:11:0x0024, B:17:0x0069, B:18:0x0081, B:20:0x0095, B:21:0x009c, B:14:0x0040, B:16:0x0047), top: B:25:0x0000 }] */
    /** The return value means a gesture was submitted, not that the call was answered. */
    public static boolean swipeNode(AccessibilityNodeInfo node, boolean answer) {
        if (Build.VERSION.SDK_INT < 24 || node == null || instance == null) return false;
        try {
            Rect rect = new Rect();
            node.getBoundsInScreen(rect);
            if (rect.width() <= 0 || rect.height() <= 0) return false;
            int x = rect.centerX(), y = rect.centerY();
            if (x <= 0 || y <= 0) return false;
            Path path = new Path();
            path.moveTo(x, y);
            if (y >= 600) {
                path.lineTo(x, answer ? Math.max(1, y - 360) : y + 360);
            } else {
                path.lineTo(x, y); // tap for compact notification buttons
            }
            boolean sent = instance.dispatchGesture(new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0L, y >= 600 ? 240L : 55L))
                    .build(), null, null);
            CallController.log("Экран: жест " + (answer ? "ответа" : "сброса") + ", отправлен=" + sent);
            return sent;
        } catch (Throwable ex) {
            CallController.log("Экран: ошибка жеста " + ex.getClass().getSimpleName());
            return false;
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        CallController.startRingtoneWatcher(this);
    }

    @Override // android.app.Service
    public void onDestroy() {
        try {
            ScreenAndVolumeReceiver screenAndVolumeReceiver = this.receiver;
            if (screenAndVolumeReceiver != null) {
                unregisterReceiver(screenAndVolumeReceiver);
            }
        } catch (Throwable th) {
        }
        instance = null;
        receiverRegistered = false;
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
    }

    @Override // android.accessibilityservice.AccessibilityService
    protected boolean onKeyEvent(KeyEvent keyEvent) {
        if (keyEvent == null) return false;
        int code = keyEvent.getKeyCode();
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        int action = keyEvent.getAction();
        if (action == KeyEvent.ACTION_UP) {
            if (code != consumedKeyCode) return false;
            consumedKeyCode = 0;
            return true;
        }
        if (action != KeyEvent.ACTION_DOWN) return false;
        if (keyEvent.getRepeatCount() > 0) return code == consumedKeyCode;
        CallController.log("Событие клавиши: " + (code == KeyEvent.KEYCODE_VOLUME_UP ? "UP" : "DOWN")
                + ", action=DOWN, источник=AccessibilityService");
        int button = code == KeyEvent.KEYCODE_VOLUME_UP ? 1 : 2;
        boolean dispatched = CallController.handleHardwareButton(this, button);
        if (dispatched) consumedKeyCode = code;
        return dispatched;
    }

    @Override // android.accessibilityservice.AccessibilityService
    protected void onServiceConnected() {
        instance = this;
        CallController.ensureNotificationListenerBound(this);
        try {
            AccessibilityServiceInfo serviceInfo = getServiceInfo();
            if (serviceInfo != null) {
                serviceInfo.eventTypes = -1;
                serviceInfo.flags |= 115;
                setServiceInfo(serviceInfo);
                CallController.log("СпецВозм подключена: cap=" + serviceInfo.getCapabilities() + ", flags=" + serviceInfo.flags + ", keyFilterRequested=" + ((serviceInfo.flags & 32) != 0));
            }
            ScreenAndVolumeReceiver screenAndVolumeReceiver = new ScreenAndVolumeReceiver();
            this.receiver = screenAndVolumeReceiver;
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.media.VOLUME_CHANGED_ACTION");
            if (Build.VERSION.SDK_INT - 33 >= 0) {
                registerReceiver(screenAndVolumeReceiver, intentFilter, 2);
            } else {
                registerReceiver(screenAndVolumeReceiver, intentFilter);
            }
            receiverRegistered = true;
            CallController.log("Приёмник событий громкости зарегистрирован (НЕ отслеживает нажатия)");
        } catch (Throwable th) {
            receiverRegistered = false;
            CallController.log("Ошибка подключения службы/приёмника громкости:");
            CallController.log(th.toString());
        }
    }
}
