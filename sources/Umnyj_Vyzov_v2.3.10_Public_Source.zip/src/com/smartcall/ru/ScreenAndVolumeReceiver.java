package com.smartcall.ru;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.telephony.SmsMessage;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class ScreenAndVolumeReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action;
        Object obj;
        Object[] objArr;
        int length;
        SmsMessage smsMessageCreateFromPdu;
        if (intent == null || (action = intent.getAction()) == null) {
            return;
        }
        if ("android.intent.action.PHONE_STATE".equals(action)) {
            String stringExtra = intent.getStringExtra("state");
            if (stringExtra != null) {
                if ("RINGING".equals(stringExtra)) {
                    CallController.simRinging = true;
                    CallController.recordActiveCallState(1);
                    CallController.startRingtoneWatcher(context);
                    String stringExtra2 = intent.getStringExtra("incoming_number");
                    if (stringExtra2 == null || stringExtra2.length() <= 0) {
                        return;
                    }
                    CallController.announceIncomingCall(context, "sim", stringExtra2);
                    return;
                }
                if ("OFFHOOK".equals(stringExtra)) {
                    CallController.recordActiveCallState(2);
                    CallController.stopTts();
                    return;
                } else {
                    if ("IDLE".equals(stringExtra)) {
                        CallController.recordActiveCallState(0);
                        CallController.stopTts();
                        return;
                    }
                    return;
                }
            }
            return;
        }
        if (!"android.provider.Telephony.SMS_RECEIVED".equals(action)) {
            // Volume broadcasts are not evidence of a physical key press.
            return;
        }
        try {
            Bundle extras = intent.getExtras();
            if (extras == null || (obj = extras.get("pdus")) == null || (length = (objArr = (Object[]) obj).length) <= 0) {
                return;
            }
            String str = "";
            StringBuilder sb = new StringBuilder();
            for (int i2 = 0; i2 < length; i2++) {
                Object obj2 = objArr[i2];
                if (obj2 != null && (smsMessageCreateFromPdu = SmsMessage.createFromPdu((byte[]) obj2)) != null) {
                    String originatingAddress = smsMessageCreateFromPdu.getOriginatingAddress();
                    if (originatingAddress != null) {
                        str = originatingAddress;
                    }
                    String messageBody = smsMessageCreateFromPdu.getMessageBody();
                    if (messageBody != null) {
                        sb = sb.append(messageBody);
                    }
                }
            }
            if (CallController.isPrefEnabled(context, "tts_enabled", true) && CallController.isPrefEnabled(context, "tts_app_sms", true) && CallController.isPrefEnabled(context, "tts_sms_text", true)) {
                String string = sb.toString();
                CallController.log("Получено входящее SMS (SMS_RECEIVED)");
                CallController.lastSmsPkg = "sim";
                CallController.announceIncomingSms(context, str, string);
            }
        } catch (Throwable th) {
        }
    }
}
