#!/usr/bin/env python3
"""Fail-closed validation of the pre-signed draft candidate.

The APK is signed locally using the owner's original private key, which is
NEVER stored in this public repository. CI separately compiles the same source
as an unsigned APK and checks the locally signed candidate before the draft.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'build'))
from axml_arsc_gen import build_manifest_axml
APK=ROOT/'ci/SmartCall-2.3.10-signed.apk'
EXPECTED_SHA256='d0367e4467f3b3b7679106c71e906b4a764812ed637bd49a353c45e635f5efd9'

assert APK.is_file(), 'signed candidate missing'
assert hashlib.sha256(APK.read_bytes()).hexdigest()==EXPECTED_SHA256, 'signed candidate checksum mismatch'
with ZipFile(APK) as z:
    assert z.testzip() is None, 'ZIP CRC failure'
    assert z.read('AndroidManifest.xml') == build_manifest_axml(
        'com.smartcall.ru',33,'2.3.10',24,28), 'manifest version/package mismatch'
    assert any(n.endswith('.dex') for n in z.namelist()), 'DEX missing'
print('Verified signed APK bytes and Android package/version: 2.3.10 (33)')
