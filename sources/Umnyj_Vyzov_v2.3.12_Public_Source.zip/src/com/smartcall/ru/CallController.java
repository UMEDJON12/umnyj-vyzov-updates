package com.smartcall.ru;

import android.app.Notification;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.AudioPlaybackConfiguration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.telecom.TelecomManager;
import android.view.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class CallController {
    public static String cachedEnginesSummary;
    public static long callRingStartTime;
    public static String diagLog;
    public static long lastActionTime;
    public static String lastCallPkg;
    public static int lastCallState;
    public static long lastCallTime;
    public static String lastCallerTitle;
    public static boolean lastSmsBodySpoken;
    public static String lastSmsPkg;
    public static String lastTtsText;
    public static long lastTtsTime;
    public static int pendingSwipeX;
    public static int pendingSwipeY;
    public static int proxEarTicks;
    public static ProximitySensorListener proxListener;
    public static long proxRegTime;
    public static boolean proxSawFar;
    public static int ringPeakMask;
    public static boolean ringWatcherRunning;
    public static boolean simRinging;
    public static TextToSpeech ttsInstance;
    public static boolean voipIncoming;
    public static boolean voipOngoing;
    public static volatile String lastAnswerMethod = "нет";
    public static volatile String lastAnswerResult = "попыток нет";
    private static final HardwareKeyGate HARDWARE_KEY_GATE = new HardwareKeyGate();

    public static void announceIncomingCall(Context context, String str, String str2) {
        String str3;
        String str4;
        String str5;
        if (context == null || str2 == null) {
            return;
        }
        String strCleanCaller = SmartCallFeatures.cleanCaller(str2);
        if (strCleanCaller.length() <= 0 || !isPrefEnabled(context, "tts_enabled", true)) {
            return;
        }
        if (str == null) {
            str = "sim";
        }
        if (SystemClock.elapsedRealtime() - lastTtsTime >= 5000) {
            lastTtsTime = SystemClock.elapsedRealtime();
            lastTtsText = strCleanCaller;
            lastCallPkg = str;
            lastCallerTitle = strCleanCaller;
            String lowerCase = str.toLowerCase();
            String channel;
            if (lowerCase.contains("whatsapp")) {
                channel = "wa";
            } else if (lowerCase.contains("telegram") || lowerCase.contains("nekogram") || lowerCase.contains("challegram")) {
                channel = "tg";
            } else if (lowerCase.contains("viber")) {
                channel = "viber";
            } else if (lowerCase.contains("imo")) {
                channel = "imo";
            } else if (!lowerCase.contains(".") || isSystemCallUi(lowerCase) || getCallState(context) == 1) {
                // A phone number, a system dialer UI or a confirmed SIM ring uses the SIM profile.
                channel = "sim";
            } else {
                // Any other identified application gets its own profile instead of SIM.
                channel = "other";
            }
            str3 = "tts_app_" + (("viber".equals(channel) || "imo".equals(channel)) ? "other" : channel);
            str4 = "tts_eng_" + channel;
            str5 = "";
            SharedPreferences profilePrefs = getPrefs(context);
            boolean callEnabled = profilePrefs.contains("call_enabled_" + channel)
                    ? profilePrefs.getBoolean("call_enabled_" + channel, false)
                    : isPrefEnabled(context, str3, true);
            if (callEnabled) {
                if (!hasLetters(strCleanCaller)) {
                    String strLookupContactName = lookupContactName(context, strCleanCaller);
                    if (strLookupContactName != null) {
                        strCleanCaller = strLookupContactName;
                    } else {
                        if (!isPrefEnabled(context, "tts_read_unknown", true)) {
                            log("TTS: номер не в контактах (чтение незнакомых номеров отключено)");
                            return;
                        }
                        strCleanCaller = strCleanCaller.length() > 0 ? formatDigitsForSpeech(strCleanCaller) : "неизвестный номер";
                    }
                }
                SmartCallFeatures.speak(context, str5 + strCleanCaller, str4, getPrefInt(context, "tts_repeat", 2));
            }
        }
    }

    public static void announceIncomingSms(Context context, String str, String str2) {
        SmartCallFeatures.announceSms(context, lastSmsPkg, str, str2);
    }

    /** Packages of system dialers / in-call UIs: they signal a SIM call, not a messenger. */
    private static boolean isSystemCallUi(String pkg) {
        return pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom")
                || pkg.contains("contacts") || pkg.contains("android.phone")
                || pkg.endsWith(".phone") || pkg.contains("server.telecom");
    }

    public static void answerCall(Context context) {
        if (canTriggerNow()) {
            log("Команда: ПОДНЯТЬ ТРУБКУ");
            ringWatcherRunning = false;
            unregisterProximitySensor(context);
            stopTts();
            answerCallPulse(context);
        }
    }

    public static void answerCallPulse(Context context) {
        SmartCallFeatures.answer(context);
    }

    public static boolean areAllPermissionsGranted(Context context) {
        if (hasPhonePermissions(context) && isAccessibilityEnabled(context) && isNotificationListenerEnabled(context)) {
            return isBatteryOptimizationIgnored(context);
        }
        return false;
    }

    public static boolean canTriggerNow() {
        if (SystemClock.elapsedRealtime() - lastActionTime < 350) {
            return false;
        }
        lastActionTime = SystemClock.elapsedRealtime();
        return true;
    }

    public static void checkDelayedCaller(Context context) {
        String str;
        if (context == null || SystemClock.elapsedRealtime() - lastActionTime < 4500) {
            return;
        }
        try {
            if (getCallState(context) == 1) {
                String strFindActiveCallTitle = CallNotificationListenerService.findActiveCallTitle();
                if (strFindActiveCallTitle == null || strFindActiveCallTitle.length() <= 0) {
                    strFindActiveCallTitle = CallControlAccessibilityService.findCallerNameInUi();
                    if (strFindActiveCallTitle == null) {
                        return;
                    } else {
                        str = "sim";
                    }
                } else {
                    str = lastCallPkg;
                    if (str != null) {
                        str = "sim";
                    }
                }
                announceIncomingCall(context, str, strFindActiveCallTitle);
            }
        } catch (Throwable th) {
        }
    }

    public static void checkRingtoneStep(Context context) {
        if (context != null && ringWatcherRunning) {
            try {
                if (getCallState(context) == 1) {
                    registerProximitySensor(context);
                    // Audio ducking/silence does not prove a hardware button press.
                    new Handler(Looper.getMainLooper()).postDelayed(new DelayedActionRunnable(context, 5), 150L);
                    return;
                }
            } catch (Throwable th) {
                ringWatcherRunning = false;
                return;
            }
        }
        ringWatcherRunning = false;
        ringPeakMask = 0;
        unregisterProximitySensor(context);
    }

    public static void clearDiagLog() {
        diagLog = "";
        log("Журнал очищен. Готов к проверке.");
    }

    public static void configureAndSpeakActiveJob() {
        try {
            SmartCallFeatures.SpeechJob speechJob = SmartCallFeatures.active;
            if (speechJob == null || speechJob.tts == null || speechJob.context == null || speechJob.text == null) {
                return;
            }
            String channel = speechJob.channel == null ? "sim" : speechJob.channel;
            SharedPreferences prefs = getPrefs(speechJob.context);
            String prefix = speechJob.call ? "call_" : "msg_";
            int rate = prefs.getInt(prefix + "rate_" + channel, prefs.getInt("tts_rate_" + channel, 100));
            int audioMode = prefs.getInt("tts_audio_mode", 0);
            int volume = prefs.getInt("tts_custom_vol", 100);
            int usage = 11;
            int stream = 10;
            if (audioMode == 1 || audioMode == 3) {
                usage = 1;
                stream = 3;
            } else if (audioMode == 2) {
                usage = 6;
                stream = 2;
            }
            speechJob.tts.setPitch(1.0f);
            speechJob.tts.setSpeechRate(pctToFloat(rate));
            speechJob.tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(usage).setContentType(1).build());
            Bundle params = new Bundle();
            if (audioMode != 0) {
                params.putInt("streamType", stream);
            }
            params.putFloat("volume", pctToFloat(volume));
            speechJob.params = params;
            speechJob.step = 0;
            lastTtsTime = SystemClock.elapsedRealtime();
            log("TTS: скорость=" + rate + "%, канал=" + formatAudioModeLabel(audioMode) + ", громк=" + volume + "%");
            speakStep(speechJob);
        } catch (Throwable th) {
        }
    }

    /** Speaks one repeat and arms a watchdog; the next repeat starts only after onDone. */
    static void speakStep(final SmartCallFeatures.SpeechJob job) {
        try {
            if (SmartCallFeatures.active != job || job.tts == null || job.text == null) {
                return;
            }
            final int step = job.step;
            final String id = "sc_step_" + step;
            job.lastId = id;
            int result = job.tts.speak(job.text,
                    step == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                    job.params == null ? new Bundle() : job.params, id);
            if (result != TextToSpeech.SUCCESS) {
                job.lastId = null;
                log("TTS: speak отклонён, код=" + result);
                SmartCallFeatures.finish(job);
                return;
            }
            long watchdogMs = Math.max(60000L, job.delaySeconds * 1000L + 60000L);
            SmartCallFeatures.MAIN.postDelayed(new Runnable() {
                @Override // java.lang.Runnable
                public void run() {
                    if (SmartCallFeatures.active == job && id.equals(job.lastId)) {
                        log("TTS: повтор " + (step + 1) + " не завершился; озвучивание остановлено");
                        SmartCallFeatures.finish(job);
                    }
                }
            }, watchdogMs);
        } catch (RuntimeException e) {
            log("TTS: " + e);
            SmartCallFeatures.finish(job);
        }
    }

    public static void confirmRingtoneSilenced(Context context) {
        // Legacy callbacks are intentionally inert, matching the patched DEX generator.
    }

    public static void dispatchMediaKey(Context context, int i) {
        try {
            AudioManager audioManager = (AudioManager) context.getSystemService("audio");
            if (audioManager != null) {
                audioManager.dispatchMediaKeyEvent(new KeyEvent(0, i));
                audioManager.dispatchMediaKeyEvent(new KeyEvent(1, i));
            }
        } catch (Throwable th) {
        }
    }

    public static void endCall(Context context) {
        SmartCallFeatures.cancelAnswer();
        if (canTriggerNow()) {
            log("Команда: ЗАВЕРШИТЬ ЗВОНОК");
            ringWatcherRunning = false;
            voipIncoming = false;
            voipOngoing = false;
            lastCallState = 0;
            lastCallTime = 0L;
            callRingStartTime = 0L;
            unregisterProximitySensor(context);
            stopTts();
            endCallPulse(context);
        }
    }

    public static void endCallPulse(Context context) {
        TelecomManager telecomManager;
        stopTts();
        boolean zEndCall = false;
        try {
            if (Build.VERSION.SDK_INT >= 28 && (telecomManager = (TelecomManager) context.getSystemService("telecom")) != null && (zEndCall = telecomManager.endCall())) {
                log("Telecom: endCall выполнен");
            }
            if (zEndCall) {
                return;
            }
        } catch (Throwable th) {
            log("Telecom: ошибка endCall, проверяем резервные способы");
            log(th.toString());
        }
        if (CallNotificationListenerService.triggerCallNotificationAction(false) || CallControlAccessibilityService.clickCallButtonInUi(false)) {
            return;
        }
        dispatchMediaKey(context, 6);
    }

    public static void ensureNotificationListenerBound(Context context) {
        if (context != null && CallNotificationListenerService.instance == null && isNotificationListenerEnabled(context)) {
            try {
                PackageManager packageManager = context.getPackageManager();
                ComponentName componentName = new ComponentName(context, "com.smartcall.ru.CallNotificationListenerService");
                if (packageManager != null) {
                    packageManager.setComponentEnabledSetting(componentName, 2, 1);
                    packageManager.setComponentEnabledSetting(componentName, 1, 1);
                }
                NotificationListenerService.requestRebind(componentName);
            } catch (Throwable th) {
            }
        }
    }

    public static String formatAudioModeLabel(int i) {
        if (i == 1) {
            return "Канал Мультимедиа (Медиа)";
        }
        if (i == 2) {
            return "Канал Звонка (Мелодия вызова)";
        }
        return i == 3 ? "Собственная громкость (Отдельно)" : "Канал Специальные возможности";
    }

    public static String formatDigitsForSpeech(String str) {
        if (str != null) {
            try {
                StringBuilder sb = new StringBuilder();
                int length = str.length();
                for (int i = 0; i < length; i++) {
                    char cCharAt = str.charAt(i);
                    if (cCharAt >= '0' && cCharAt <= '9') {
                        sb = sb.append(cCharAt - '0').append(" ");
                    } else if (cCharAt == '+') {
                        sb = sb.append("плюс ");
                    }
                }
                String string = sb.toString();
                if (string.length() > 0) {
                    return string;
                }
            } catch (Throwable th) {
            }
        }
        return str;
    }

    public static String formatEngineLabel(String str) {
        return (str == null || str.length() <= 0 || "default".equals(str) || str.contains("preset_")) ? "По умолчанию" : str;
    }

    public static String formatRateLabel(int i) {
        if (i == 50) {
            return "0.5x (Очень медленно)";
        }
        if (i == 75) {
            return "0.75x (Медленно)";
        }
        if (i == 90) {
            return "0.9x (Чуть медленнее)";
        }
        if (i == 115) {
            return "1.15x (Чуть быстрее)";
        }
        if (i == 125) {
            return "1.25x (Быстро)";
        }
        if (i == 150) {
            return "1.5x (Очень быстро)";
        }
        if (i == 175) {
            return "1.75x (Ускоренная)";
        }
        return i == 200 ? "2.0x (Максимальная)" : "1.0x (Обычная)";
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x005a, code lost:
    
        if (com.smartcall.ru.CallControlAccessibilityService.detectCallUiState() != 1) goto L47;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static int getCallState(android.content.Context r6) {
        /*
            long r0 = android.os.SystemClock.elapsedRealtime()
            long r2 = com.smartcall.ru.CallController.lastActionTime
            long r0 = r0 - r2
            r2 = 2200(0x898, double:1.087E-320)
            int r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r4 >= 0) goto L13
            int r4 = com.smartcall.ru.CallController.lastCallState
            r0 = 1
            if (r4 == r0) goto L13
            return r4
        L13:
            ensureNotificationListenerBound(r6)
            com.smartcall.ru.CallNotificationListenerService.refreshCallStatus()
            r3 = 0
            java.lang.String r1 = "phone"
            java.lang.Object r1 = r6.getSystemService(r1)     // Catch: java.lang.Throwable -> L2a
            android.telephony.TelephonyManager r1 = (android.telephony.TelephonyManager) r1     // Catch: java.lang.Throwable -> L2a
            if (r1 == 0) goto L28
            int r3 = r1.getCallState()     // Catch: java.lang.Throwable -> L2a
        L28:
            goto L2b
        L2a:
            r1 = move-exception
        L2b:
            r0 = 1
            if (r3 == r0) goto L79
            r0 = 2
            if (r3 == r0) goto L7e
            boolean r0 = com.smartcall.ru.CallController.simRinging
            if (r0 != 0) goto L79
            boolean r0 = com.smartcall.ru.CallController.voipIncoming
            if (r0 != 0) goto L79
            int r4 = getRingtoneMask(r6)
            r4 = r4 & 5
            if (r4 != 0) goto L79
            r5 = 0
            java.lang.String r1 = "telecom"
            java.lang.Object r1 = r6.getSystemService(r1)     // Catch: java.lang.Throwable -> L52
            android.telecom.TelecomManager r1 = (android.telecom.TelecomManager) r1     // Catch: java.lang.Throwable -> L52
            if (r1 == 0) goto L50
            boolean r5 = r1.isInCall()     // Catch: java.lang.Throwable -> L52
        L50:
            goto L53
        L52:
            r1 = move-exception
        L53:
            if (r5 == 0) goto L5e
            int r4 = com.smartcall.ru.CallControlAccessibilityService.detectCallUiState()
            r1 = 1
            if (r4 == r1) goto L79
            goto L7e
        L5e:
            boolean r1 = com.smartcall.ru.CallController.voipOngoing
            if (r1 != 0) goto L7e
            r0 = 0
            java.lang.String r1 = "audio"
            java.lang.Object r1 = r6.getSystemService(r1)     // Catch: java.lang.Throwable -> L73
            android.media.AudioManager r1 = (android.media.AudioManager) r1     // Catch: java.lang.Throwable -> L73
            if (r1 == 0) goto L71
            int r0 = r1.getMode()     // Catch: java.lang.Throwable -> L73
        L71:
            goto L74
        L73:
            r1 = move-exception
        L74:
            r1 = 2
            if (r0 == r1) goto L7e
            r4 = 0
            return r4
        L79:
            r4 = 1
            recordActiveCallState(r4)
            return r4
        L7e:
            r4 = 2
            recordActiveCallState(r4)
            return r4
        */
        // Reconstructed from the original DEX instruction dump above; not runtime-verified.
        // Never return stale IDLE during the first seconds of a new incoming call.
        ensureNotificationListenerBound(r6);
        CallNotificationListenerService.refreshCallStatus();
        int phoneState = 0;
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager) r6.getSystemService("phone");
            if (tm != null) phoneState = tm.getCallState();
        } catch (Throwable ignored) { }
        int result;
        if (phoneState == 1) result = 1;
        else if (phoneState == 2) result = 2;
        else if (simRinging || voipIncoming || (getRingtoneMask(r6) & 5) != 0) result = 1;
        else {
            boolean inCall = false;
            try {
                TelecomManager telecom = (TelecomManager) r6.getSystemService("telecom");
                if (telecom != null) inCall = telecom.isInCall();
            } catch (Throwable ignored) { }
            if (inCall) result = CallControlAccessibilityService.detectCallUiState() == 1 ? 1 : 2;
            else if (voipOngoing) result = 2;
            else if (CallControlAccessibilityService.detectCallUiState() == 1) {
                // Some Android 16 dialers expose ringing only through their accessibility UI.
                result = 1;
            } else {
                int mode = 0;
                try {
                    AudioManager audio = (AudioManager) r6.getSystemService("audio");
                    if (audio != null) mode = audio.getMode();
                } catch (Throwable ignored) { }
                if (mode != 2) {
                    recordActiveCallState(0);
                    return 0;
                }
                result = 2;
            }
        }
        recordActiveCallState(result);
        return result;
    }

    public static String getDiagReport(Context context) {
        try {
            sanitizeButtonPrefs(context);
            StringBuilder sbAppend = new StringBuilder().append("=== ДИАГНОСТИКА «УМНЫЙ ВЫЗОВ» v").append(AppVersion.name(context)).append(" ===\nУстройство: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append(" (").append(Build.DEVICE).append(") | Android ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(") | Cap=").append(CallControlAccessibilityService.getActiveCapabilities()).append("\nПрошивка: ").append(Build.DISPLAY).append("\nРазрешения: Тел=").append(hasPhonePermissions(context)).append(", Контакты=").append(hasContactsPermission(context)).append(", SMS=").append(hasSmsPermission(context)).append(", СпецВозм=").append(isAccessibilityEnabled(context)).append(", Уведомл=").append(isNotificationListenerEnabled(context)).append(", Батарея=").append(isBatteryOptimizationIgnored(context)).append("\nКнопки: Master=").append(isPrefEnabled(context, "enabled", true)).append(", AnsUp=").append(isPrefEnabled(context, "ans_vol_up", true)).append(", AnsDn=").append(isPrefEnabled(context, "ans_vol_down", false)).append(", EndDn=").append(isPrefEnabled(context, "end_vol_down", true)).append(", EndUp=").append(isPrefEnabled(context, "end_vol_up", false)).append(", Ухо=").append(isPrefEnabled(context, "ear_pickup", true)).append("\nОзвучка (TTS): Вкл=").append(isPrefEnabled(context, "tts_enabled", true)).append(", НезнакомНомера=").append(isPrefEnabled(context, "tts_read_unknown", true)).append(", Повтор=").append(getPrefInt(context, "tts_repeat", 2)).append(", SIM=").append(isPrefEnabled(context, "tts_app_sim", true)).append(", WA=").append(isPrefEnabled(context, "tts_app_wa", true)).append(", TG=").append(isPrefEnabled(context, "tts_app_tg", true)).append(", Другие=").append(isPrefEnabled(context, "tts_app_other", true)).append(", SMS=").append(isPrefEnabled(context, "tts_app_sms", true)).append(", ТекстSMS=").append(isPrefEnabled(context, "tts_sms_text", true)).append("\nДвижки TTS: SIM=").append(formatEngineLabel(getPrefStr(context, "tts_eng_sim", "default"))).append(", WA=").append(formatEngineLabel(getPrefStr(context, "tts_eng_wa", "default"))).append(", TG=").append(formatEngineLabel(getPrefStr(context, "tts_eng_tg", "default"))).append(", Др=").append(formatEngineLabel(getPrefStr(context, "tts_eng_other", "default"))).append(", SMS=").append(formatEngineLabel(getPrefStr(context, "tts_eng_sms", "default"))).append("\n").append(SmartCallFeatures.profileSummary(context)).append("\nСкорость TTS: SIM=").append(getPrefInt(context, "tts_rate_sim", 100)).append("%, WA=").append(getPrefInt(context, "tts_rate_wa", 100)).append("%, TG=").append(getPrefInt(context, "tts_rate_tg", 100)).append("%, Др=").append(getPrefInt(context, "tts_rate_other", 100)).append("%, SMS=").append(getPrefInt(context, "tts_rate_sms", 100)).append("%\nАудиоканал TTS: ").append(formatAudioModeLabel(getPrefInt(context, "tts_audio_mode", 0))).append(", СобствГромк=").append(getPrefInt(context, "tts_custom_vol", 100)).append("%").append("\nУстановленные TTS: ").append(getInstalledTtsSummary(context)).append("\n").append(CallControlAccessibilityService.hardwareKeyDiagnostic()).append("\nОтвет: способ=").append(lastAnswerMethod).append(", результат=").append(lastAnswerResult).append("\nСостояние: CallState=").append(lastCallState).append(", RingMask=").append(getRingtoneMask(context)).append(", VoIP(Inc=").append(voipIncoming).append(",Ong=").append(voipOngoing).append(")\n--- ЖУРНАЛ СОБЫТИЙ ---\n");
            String str = diagLog;
            if (str == null) {
                str = "(Событий пока нет — позвоните для проверки)\n";
            }
            return sbAppend.append(str).toString();
        } catch (Throwable th) {
            return th.toString();
        }
    }

    public static String getInstalledTtsSummary(Context context) {
        int size;
        String str;
        String str2 = cachedEnginesSummary;
        if (str2 != null) {
            return str2;
        }
        String string = "нет данных";
        if (context == null) {
            return "нет данных";
        }
        try {
            TextToSpeech textToSpeech = ttsInstance;
            if (textToSpeech == null) {
                textToSpeech = new TextToSpeech(context, null);
            }
            List<TextToSpeech.EngineInfo> engines = textToSpeech.getEngines();
            if (engines == null || (size = engines.size()) <= 0) {
                return "нет данных";
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < size; i++) {
                TextToSpeech.EngineInfo engineInfo = engines.get(i);
                if (engineInfo != null && (str = engineInfo.name) != null) {
                    sb = sb.append(str).append("; ");
                }
            }
            string = sb.toString();
            cachedEnginesSummary = string;
            return string;
        } catch (Throwable th) {
            return string;
        }
    }

    public static int getPrefInt(Context context, String str, int i) {
        return getPrefs(context).getInt(str, i);
    }

    public static String getPrefStr(Context context, String str, String str2) {
        String string = getPrefs(context).getString(str, str2);
        return string != null ? string : str2;
    }

    public static SharedPreferences getPrefs(Context context) {
        SettingsMigration.ensure(context);
        return context.getSharedPreferences("call_prefs", 0);
    }

    public static int getRingtoneMask(Context context) {
        List<AudioPlaybackConfiguration> activePlaybackConfigurations;
        int size;
        AudioAttributes audioAttributes;
        if (context == null) {
            return 0;
        }
        try {
            AudioManager audioManager = (AudioManager) context.getSystemService("audio");
            if (audioManager == null) {
                return 0;
            }
            int i = audioManager.getMode() == 1 ? 0 | 1 : 0;
            if (!audioManager.isStreamMute(2)) {
                i |= 2;
            }
            if (Build.VERSION.SDK_INT < 26 || (activePlaybackConfigurations = audioManager.getActivePlaybackConfigurations()) == null || (size = activePlaybackConfigurations.size()) <= 0) {
                return i;
            }
            for (int i2 = 0; i2 < size; i2++) {
                AudioPlaybackConfiguration audioPlaybackConfiguration = activePlaybackConfigurations.get(i2);
                if (audioPlaybackConfiguration != null && (audioAttributes = audioPlaybackConfiguration.getAudioAttributes()) != null && audioAttributes.getUsage() == 6) {
                    return i | 4;
                }
            }
            return i;
        } catch (Throwable th) {
            return 0;
        }
    }

    /** One state snapshot decides both interception and the action; never consume without action. */
    private static int keyAction(Context context, int key, int state) {
        if (context == null || !isPrefEnabled(context, "enabled", true) || state == 0) return 0;
        if (state == 1) {
            if (key == 1) {
                if (isPrefEnabled(context, "ans_vol_up", true)) return 1;
                return !isPrefEnabled(context, "end_vol_down", true)
                        && isPrefEnabled(context, "end_vol_up", false) ? 2 : 0;
            }
            if (key == 2) {
                if (!isPrefEnabled(context, "ans_vol_up", true)
                        && isPrefEnabled(context, "ans_vol_down", false)) return 1;
                return isPrefEnabled(context, "end_vol_down", true) ? 2 : 0;
            }
            return 0;
        }
        if (state != 2) return 0;
        if (key == 2 && isPrefEnabled(context, "end_vol_down", true)) return 2;
        if (key == 1 && !isPrefEnabled(context, "end_vol_down", true)
                && isPrefEnabled(context, "end_vol_up", false)) return 2;
        return 0;
    }

    /** Hardware shortcut must not infer RINGING from media/TTS playback or RingMask. */
    public static int hardwareCallState(Context context) {
        if (context == null) return 0;
        try {
            android.telephony.TelephonyManager tm =
                    (android.telephony.TelephonyManager) context.getSystemService("phone");
            if (tm != null) {
                int state = tm.getCallState();
                if (state == 1 || state == 2) return state;
            }
        } catch (SecurityException e) {
            log("Клавиши: чтение состояния SIM запрещено: " + e.getClass().getSimpleName());
        } catch (RuntimeException e) {
            log("Клавиши: ошибка определения SIM: " + e.getClass().getSimpleName());
        }
        // Fallback only if a call-specific, accessible screen is actually visible.
        // RingMask and volume broadcasts MUST NOT be used as proof of a call.
        int ui = CallControlAccessibilityService.detectCallUiState();
        if (ui == 1 && (simRinging || voipIncoming)) return 1;
        return 0;
    }

    public static void resetHardwareKeyGate() {
        HARDWARE_KEY_GATE.reset();
    }

    public static int keyActionForHardware(Context context, int key, int state) {
        return keyAction(context, key, state);
    }

    /** A single state snapshot is shared by logging and selection of the action. */
    public static boolean handleHardwareButton(Context context, int key, int state) {
        if (context == null || (key != 1 && key != 2)) return false;
        int action = keyAction(context, key, state);
        log("Аппаратная кнопка: " + (key == 1 ? "ГРОМКОСТЬ ВВЕРХ" : "ГРОМКОСТЬ ВНИЗ")
                + ", снимок состояния=" + state + ", действие="
                + (action == 1 ? "ответ" : action == 2 ? "сброс" : "нет"));
        if (action == 0) return false;
        if (!HARDWARE_KEY_GATE.allow(key, action, SystemClock.elapsedRealtime())) {
            log("Клавиши: повторная команда отклонена, вызов не обрабатываем второй раз");
            return true; // consume while call remains active, not additional command
        }
        if (action == 1) {
            lastAnswerResult = "запрос принят, OFFHOOK пока не подтверждён";
            lastAnswerMethod = "ожидается TelecomManager";
            answerCall(context);
        } else {
            endCall(context);
        }
        return true;
    }

    public static boolean handleHardwareButton(Context context, int key) {
        return handleHardwareButton(context, key, hardwareCallState(context));
    }

    public static boolean hasPermission(Context context, String permission) {
        if (context == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= 23) return context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
            return context.getPackageManager().checkPermission(permission, context.getPackageName()) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    public static boolean hasContactsPermission(Context context) {
        return hasPermission(context, "android.permission.READ_CONTACTS");
    }

    public static boolean hasLetters(String str) {
        if (str != null) {
            try {
                int length = str.length();
                for (int i = 0; i < length; i++) {
                    if (str.charAt(i) >= 'A') {
                        return true;
                    }
                }
            } catch (Throwable th) {
                return false;
            }
        }
        return false;
    }

    public static boolean hasPhonePermissions(Context context) {
        if (!hasPermission(context, "android.permission.READ_PHONE_STATE") || !hasPermission(context, "android.permission.CALL_PHONE")) {
            return false;
        }
        if (Build.VERSION.SDK_INT < 26 || hasPermission(context, "android.permission.ANSWER_PHONE_CALLS")) {
            return Build.VERSION.SDK_INT < 33 || hasPermission(context, "android.permission.POST_NOTIFICATIONS");
        }
        return false;
    }

    public static boolean hasSmsPermission(Context context) {
        return hasPermission(context, "android.permission.RECEIVE_SMS");
    }

    public static boolean isAccessibilityEnabled(Context context) {
        try {
            String string = Settings.Secure.getString(context.getContentResolver(), "enabled_accessibility_services");
            if (string != null) {
                return string.contains("com.smartcall.ru");
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean isBatteryOptimizationIgnored(Context context) {
        if (Build.VERSION.SDK_INT < 23) return true; // Doze exemptions do not exist before API 23.
        try {
            PowerManager powerManager = (PowerManager) context.getSystemService("power");
            if (powerManager != null) {
                return powerManager.isIgnoringBatteryOptimizations(context.getPackageName());
            }
            return true;
        } catch (Throwable th) {
            return true;
        }
    }

    public static boolean isMediaOrOngoingNotification(StatusBarNotification statusBarNotification) {
        CharSequence charSequence;
        CallNotificationListenerService callNotificationListenerService;
        AudioManager audioManager;
        if (statusBarNotification == null) {
            return false;
        }
        try {
            Notification notification = statusBarNotification.getNotification();
            if (notification == null) {
                return false;
            }
            String str = notification.category;
            if (str != null) {
                if ("call".equals(str)) {
                    return false;
                }
                if ("transport".equals(str) || "service".equals(str) || "progress".equals(str) || "status".equals(str) || "sys".equals(str)) {
                    return true;
                }
            }
            if ((notification.flags & 546) != 0) {
                return true;
            }
            Bundle bundle = notification.extras;
            if (bundle != null) {
                if (bundle.containsKey("android.mediaSession") || bundle.getInt("android.progressMax", 0) > 0) {
                    return true;
                }
                Object obj = bundle.get("android.template");
                if (obj != null && obj.toString().toLowerCase().contains("media")) {
                    return true;
                }
                Object obj2 = bundle.get("android.text");
                if (obj2 != null) {
                    String lowerCase = obj2.toString().toLowerCase();
                    if (lowerCase.contains("голосовое сообщ") || lowerCase.contains("voice message") || lowerCase.contains("🎤") || lowerCase.contains("🎵") || lowerCase.contains("🎧")) {
                        return true;
                    }
                }
                if (!voipOngoing && (callNotificationListenerService = CallNotificationListenerService.instance) != null && (audioManager = (AudioManager) callNotificationListenerService.getSystemService("audio")) != null && audioManager.getMode() == 3) {
                    return true;
                }
            }
            Notification.Action[] actionArr = notification.actions;
            if (actionArr == null) {
                return false;
            }
            for (Notification.Action action : actionArr) {
                if (action != null && (charSequence = action.title) != null) {
                    String lowerCase2 = charSequence.toString().toLowerCase();
                    if (lowerCase2.contains("пауза") || lowerCase2.contains("pause") || lowerCase2.contains("воспроизв") || lowerCase2.contains("play") || lowerCase2.contains("стоп") || lowerCase2.contains("stop")) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean isNotificationListenerEnabled(Context context) {
        try {
            String string = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
            if (string != null) {
                return string.contains("com.smartcall.ru");
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean isPrefEnabled(Context context, String str, boolean z) {
        return getPrefs(context).getBoolean(str, z);
    }

    public static void log(String str) {
        try {
            String strSubstring = diagLog;
            if (strSubstring == null) {
                strSubstring = "";
            }
            if (strSubstring.length() > 48000) {
                strSubstring = strSubstring.substring(12000);
            }
            if (str != null && str.length() > 220) {
                str = str.substring(0, 220);
            }
            diagLog = strSubstring + "• [" + SystemClock.elapsedRealtime() + "ms] " + str + "\n";
        } catch (Throwable th) {
        }
    }

    public static String lookupContactName(Context context, String str) {
        Cursor cursorQuery;
        String string = null;
        if (context != null && str != null && str.length() > 0 && hasContactsPermission(context)) {
            try {
                String strEncode = Uri.encode(str);
                if (strEncode != null) {
                    Uri uri = Uri.parse("content://com.android.contacts/phone_lookup/" + strEncode);
                    ContentResolver contentResolver = context.getContentResolver();
                    if (contentResolver != null && (cursorQuery = contentResolver.query(uri, new String[]{"display_name"}, null, null, null)) != null) {
                        string = cursorQuery.moveToFirst() ? cursorQuery.getString(0) : null;
                        cursorQuery.close();
                    }
                }
            } catch (Throwable th) {
                return string;
            }
        }
        return string;
    }

    public static float pctToFloat(int i) {
        if (i == 15) {
            return 0.15f;
        }
        if (i == 30) {
            return 0.3f;
        }
        if (i == 45) {
            return 0.45f;
        }
        if (i == 50) {
            return 0.5f;
        }
        if (i == 60) {
            return 0.6f;
        }
        if (i == 75) {
            return 0.75f;
        }
        if (i == 90) {
            return 0.9f;
        }
        if (i == 115) {
            return 1.15f;
        }
        if (i == 125) {
            return 1.25f;
        }
        if (i == 150) {
            return 1.5f;
        }
        if (i == 175) {
            return 1.75f;
        }
        return i == 200 ? 2.0f : 1.0f;
    }

    public static void recordActiveCallState(int i) {
        if (i == 99) {
            configureAndSpeakActiveJob();
            return;
        }
        if (i == 98) {
            CallControlAccessibilityService.clickCallButtonInUi(true);
            return;
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (i != 1) {
            callRingStartTime = 0L;
            simRinging = false;
        } else if (lastCallState != 1 || callRingStartTime == 0) {
            callRingStartTime = jElapsedRealtime;
        }
        lastCallState = i;
        lastCallTime = jElapsedRealtime;
    }

    public static void registerProximitySensor(Context context) {
        if (context == null || proxListener != null) {
            return;
        }
        try {
            if (isPrefEnabled(context, "enabled", true) && isPrefEnabled(context, "ear_pickup", true)) {
                proxSawFar = false;
                proxEarTicks = 0;
                proxRegTime = SystemClock.elapsedRealtime();
                SensorManager sensorManager = (SensorManager) context.getSystemService("sensor");
                if (sensorManager != null) {
                    ProximitySensorListener proximitySensorListener = new ProximitySensorListener(context);
                    proxListener = proximitySensorListener;
                    Sensor defaultSensor = sensorManager.getDefaultSensor(8, true);
                    if (defaultSensor != null) {
                        sensorManager.registerListener(proximitySensorListener, defaultSensor, 1);
                    }
                    Sensor defaultSensor2 = sensorManager.getDefaultSensor(8, false);
                    if (defaultSensor2 != null) {
                        sensorManager.registerListener(proximitySensorListener, defaultSensor2, 1);
                    } else {
                        Sensor defaultSensor3 = sensorManager.getDefaultSensor(8);
                        if (defaultSensor3 != null) {
                            sensorManager.registerListener(proximitySensorListener, defaultSensor3, 1);
                        }
                    }
                    log("Датчик приближения и поднесения к уху активен");
                }
            }
        } catch (Throwable th) {
            log(th.toString());
        }
    }

    public static void reinitTts(Context context, String str) {
        if (context != null) {
            stopTts();
            try {
                TtsInitListener ttsInitListener = new TtsInitListener(null, null, 0, "default");
                TextToSpeech textToSpeech = (str == null || "default".equals(str) || str.length() <= 0) ? new TextToSpeech(context, ttsInitListener) : new TextToSpeech(context, ttsInitListener, str);
                ttsInitListener.tts = textToSpeech;
                ttsInstance = textToSpeech;
            } catch (Throwable th) {
            }
        }
    }

    public static void sanitizeButtonPrefs(Context context) {
        if (context != null) {
            try {
                if (isPrefEnabled(context, "ans_vol_up", true) && isPrefEnabled(context, "ans_vol_down", false)) {
                    setPrefEnabled(context, "ans_vol_down", false);
                }
                if (isPrefEnabled(context, "end_vol_down", true) && isPrefEnabled(context, "end_vol_up", false)) {
                    setPrefEnabled(context, "end_vol_up", false);
                }
            } catch (Throwable th) {
            }
        }
    }

    public static String saveDiagToDownload(Context context) {
        byte[] bytes = getDiagReport(context).getBytes();
        try {
            File file = new File(Environment.getExternalStoragePublicDirectory("Download"), "Umnyj_Vyzov_Diagnostika.txt");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(bytes);
            fileOutputStream.close();
            return file.getAbsolutePath();
        } catch (Throwable th) {
            try {
                File file2 = new File(context.getExternalFilesDir(null), "Umnyj_Vyzov_Diagnostika.txt");
                FileOutputStream fileOutputStream2 = new FileOutputStream(file2);
                fileOutputStream2.write(bytes);
                fileOutputStream2.close();
                return file2.getAbsolutePath();
            } catch (Throwable th2) {
                return th2.toString();
            }
        }
    }

    public static void setPrefEnabled(Context context, String str, boolean z) {
        getPrefs(context).edit().putBoolean(str, z).apply();
    }

    public static void setPrefInt(Context context, String str, int i) {
        getPrefs(context).edit().putInt(str, i).apply();
    }

    public static void setPrefStr(Context context, String str, String str2) {
        getPrefs(context).edit().putString(str, str2).apply();
    }

    public static boolean shouldInterceptKey(Context context, int key) {
        return context != null && keyAction(context, key, hardwareCallState(context)) != 0;
    }

    public static void speakText(Context context, String str, String str2, int i) {
        SmartCallFeatures.speakLegacy(context, str, str2, i);
    }

    public static void startRingtoneWatcher(Context context) {
        if (context == null || ringWatcherRunning || SystemClock.elapsedRealtime() - lastActionTime < 4500) {
            return;
        }
        try {
            if (getCallState(context) == 1) {
                ringWatcherRunning = true;
                registerProximitySensor(context);
                ringPeakMask = 0;
                log("Контроль мелодии звонка активен");
                Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new DelayedActionRunnable(context, 7), 350L);
                handler.postDelayed(new DelayedActionRunnable(context, 5), 150L);
            }
        } catch (Throwable th) {
            ringWatcherRunning = false;
            simRinging = false;
        }
    }

    public static void stopTts() {
        try {
            TextToSpeech textToSpeech = ttsInstance;
            if (textToSpeech != null) {
                textToSpeech.stop();
                textToSpeech.shutdown();
                ttsInstance = null;
            }
            SmartCallFeatures.stopSpeech();
        } catch (Throwable th) {
            SmartCallFeatures.stopSpeech();
        }
    }

    public static void unregisterProximitySensor(Context context) {
        SensorManager sensorManager;
        try {
            ProximitySensorListener proximitySensorListener = proxListener;
            if (proximitySensorListener != null) {
                proxListener = null;
                proxSawFar = false;
                proxEarTicks = 0;
                if (context == null || (sensorManager = (SensorManager) context.getSystemService("sensor")) == null) {
                    return;
                }
                sensorManager.unregisterListener(proximitySensorListener);
            }
        } catch (Throwable th) {
        }
    }
}
