"""Host-only source checks and original AnswerFlow/SpeechPolicy JVM tests.

These checks do not execute Android methods or simulate the DEX VM.
"""
from pathlib import Path
import re
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src/com/smartcall/ru'


def method(text, name):
    match = re.search(r'\b' + re.escape(name) + r'\s*\([^)]*\)\s*\{', text)
    if not match:
        raise AssertionError('method not found: ' + name)
    start = match.end() - 1
    depth = 0
    for p in range(start, len(text)):
        if text[p] == '{': depth += 1
        elif text[p] == '}':
            depth -= 1
            if not depth:
                return text[start + 1:p]
    raise AssertionError('unclosed method: ' + name)


class RecoveryTests(unittest.TestCase):
    def test_volume_and_mask_do_not_dispatch(self):
        controller = (SRC / 'CallController.java').read_text()
        watcher = method(controller, 'checkRingtoneStep')
        confirm = method(controller, 'confirmRingtoneSilenced')
        receiver = method((SRC / 'ScreenAndVolumeReceiver.java').read_text(), 'onReceive')
        for forbidden in ['handleHardwareButton(', 'answerCall(', 'endCall(', 'getRingtoneMask(', 'startRingtoneWatcher(']:
            self.assertNotIn(forbidden, watcher)
            self.assertNotIn(forbidden, confirm)
        self.assertNotRegex(watcher, r'new DelayedActionRunnable\s*\(\s*context\s*,\s*6\s*\)')
        self.assertNotIn('handleHardwareButton(', receiver)
        self.assertIn('registerProximitySensor(context)', watcher)
        self.assertIn('DelayedActionRunnable(context, 5)', watcher)

    def test_dialog_boundary_and_assignments(self):
        body = method((SRC / 'MainActivity.java').read_text(), 'onDialogPositiveAction')
        self.assertIn('if (i2 < 0 || i2 > 3)', body)
        self.assertIn('if (i < 21 || i > 25)', body)
        self.assertIn('CallController.setPrefInt(this, "tts_audio_mode", i2)', body)
        for key in ('sim', 'wa', 'tg', 'other', 'sms'):
            self.assertIn('"tts_rate_' + key + '"', body)
            self.assertIn('"tts_eng_' + key + '"', body)
        for rate in (50, 75, 90, 100, 115, 125, 150, 175, 200):
            self.assertRegex(body, r'\b' + str(rate) + r'\b')

    def test_hardware_button_all_combinations(self):
        source = (SRC / 'CallController.java').read_text()
        body = method(source, 'handleHardwareButton')
        intercept = method(source, 'shouldInterceptKey')
        selector = method(source, 'keyAction')
        harness = r'''
import java.util.*;
class Context {}
class SystemClock { static long elapsedRealtime(){return 2000000L;} }
class HardwareKeyGate { boolean allow(int key,int action,long when){return true;} }
public class HardwareHarness {
 static final HardwareKeyGate HARDWARE_KEY_GATE=new HardwareKeyGate();
 static String lastAnswerResult, lastAnswerMethod;
 static Map<String,Boolean> prefs=new HashMap<>(); static int state; static String action;
 static boolean isPrefEnabled(Context c, String k, boolean d) { return prefs.containsKey(k)?prefs.get(k):d; }
 static int getCallState(Context c) { return state; }
 static int hardwareCallState(Context c) { return state; }
 static void answerCall(Context c) { if(action!=null) throw new AssertionError("multiple actions"); action="answer"; }
 static void endCall(Context c) { if(action!=null) throw new AssertionError("multiple actions"); action="end"; }
 static void log(String msg) {}
 static int keyAction(Context context, int key, int state) { SELECTOR }
 static boolean handleHardwareButton(Context context, int key, int state) { BODY }
 static boolean handleHardwareButton(Context context, int key){ return handleHardwareButton(context,key,hardwareCallState(context)); }
 static boolean shouldInterceptKey(Context context, int key) { INTERCEPT }
 public static void main(String[] args) {
  Context c=new Context(); int cases=0;
  for(int enabled=0;enabled<=1;enabled++) for(int flags=0;flags<16;flags++)
   for(state=0;state<=3;state++) for(int key=0;key<=3;key++) {
    boolean au=(flags&1)!=0, ad=(flags&2)!=0, ed=(flags&4)!=0, eu=(flags&8)!=0;
    prefs.put("enabled",enabled!=0); prefs.put("ans_vol_up",au); prefs.put("ans_vol_down",ad);
    prefs.put("end_vol_down",ed); prefs.put("end_vol_up",eu);
    String want=null;
    if(enabled!=0 && state!=0 && (key==1 || key==2)) {
     if(state==1 && ((key==1 && au) || (key==2 && !au && ad))) want="answer";
     else if((key==2 && ed) || (key==1 && !ed && eu && state==1) || (key==1 && !ed && eu && state==2)) want=state==2 || state==1 ? "end" : null;
     if(state!=1 && state!=2) want=null;
    }
    action=null; boolean intercept=shouldInterceptKey(c,key); boolean result=handleHardwareButton(c,key); cases++;
    if(intercept!=(want!=null) || !Objects.equals(want,action) || result!=(want!=null))
     throw new AssertionError("enabled="+enabled+" flags="+flags+" state="+state+" key="+key+" expected="+want+" actual="+action+" result="+result);
   }
  System.out.println("PASS "+cases+" hardware routing cases");
 }
}
'''.replace('BODY', body).replace('INTERCEPT', intercept).replace('SELECTOR', selector)
        with tempfile.TemporaryDirectory(prefix='smartcall-hardware-') as td:
            file = Path(td) / 'HardwareHarness.java'; file.write_text(harness)
            subprocess.run(['javac', '-d', td, str(file)], check=True)
            result = subprocess.run(['java', '-cp', td, 'HardwareHarness'], check=True, capture_output=True, text=True)
            self.assertIn('PASS 512 hardware routing cases', result.stdout)

    def test_real_dialog_method_on_jvm_with_stubs(self):
        body = method((SRC / 'MainActivity.java').read_text(), 'onDialogPositiveAction')
        harness = r'''
class CallController {
 static String key; static int value; static int writes;
 static void setPrefInt(Harness c, String k, int v) { key=k; value=v; writes++; }
 static void setPrefStr(Harness c, String k, String v) { key=k; writes++; }
 static void reinitTts(Harness c, String s) {}
 static void log(String s) {}
 static String formatEngineLabel(String s) { return s; }
}
class SmartCallFeatures {
 static String engine; static int calls;
 static void speak(Harness c, String msg, String e, int n) { engine=e; calls++; }
 static void onEngineChanged(Harness c, String s) {}
}
public class Harness {
 String[] dialogEnginePkgs = {"dummy"};
 void requestPhonePermissionsNow(boolean b) {}
 void openSystemSetting(String s, boolean b) {}
 void refreshStatusText() {}
 void onDialogPositiveAction(int i, int i2) { BODY }
 static void reset() { CallController.key=null; CallController.writes=0; SmartCallFeatures.calls=0; }
 static void check(boolean ok, String msg) { if(!ok) throw new AssertionError(msg); }
 public static void main(String[] args) {
  Harness h=new Harness(); String[] keys={"sim","wa","tg","other","sms"};
  int[] rates={50,75,90,100,115,125,150,175,200};
  for(int mode=21;mode<=25;mode++) for(int idx=0;idx<9;idx++) {
   reset(); h.onDialogPositiveAction(mode,idx); String key=keys[mode-21];
   check(CallController.writes==1 && ("tts_rate_"+key).equals(CallController.key) && CallController.value==rates[idx] && SmartCallFeatures.calls==1 && ("tts_eng_"+key).equals(SmartCallFeatures.engine), "rate");
  }
  for(int idx=-1;idx<=4;idx++) {
   reset(); h.onDialogPositiveAction(26,idx);
   boolean valid=idx>=0 && idx<=3;
   check(CallController.writes==(valid?1:0) && SmartCallFeatures.calls==(valid?1:0), "audio count");
   if(valid) check("tts_audio_mode".equals(CallController.key) && CallController.value==idx, "audio value");
  }
  for(int mode=11;mode<=16;mode++) { reset(); h.onDialogPositiveAction(mode,0); check(CallController.writes==1 && !CallController.key.startsWith("tts_rate_"), "engine route"); }
  System.out.println("PASS 57 dialog routes on host JVM with stubs");
 }
}
'''.replace('BODY', body)
        with tempfile.TemporaryDirectory(prefix='smartcall-dialog-') as td:
            file = Path(td) / 'Harness.java'
            file.write_text(harness)
            subprocess.run(['javac', '-d', td, str(file)], check=True)
            result = subprocess.run(['java', '-cp', td, 'Harness'], check=True, capture_output=True, text=True)
            self.assertIn('PASS 57 dialog routes', result.stdout)

    def test_pure_java_original_tests(self):
        with tempfile.TemporaryDirectory(prefix='smartcall-test-') as td:
            test = ROOT / 'tests' / 'reference' / 'FeatureTests.java'
            subprocess.run(['javac', '-source', '8', '-target', '8', '-d', td,
                            str(SRC/'AnswerFlow.java'), str(SRC/'SpeechPolicy.java'), str(test)], check=True)
            result = subprocess.run(['java', '-cp', td, 'com.smartcall.ru.FeatureTests'], check=True, text=True, capture_output=True)
            self.assertIn('PASS: 34 host JVM assertions', result.stdout)

if __name__ == '__main__':
    unittest.main(verbosity=2)
