================================================================================
ПАРАМЕТРЫ ЦИФРОВОЙ ПОДПИСИ ПРОЕКТА «УМНЫЙ ВЫЗОВ» (com.smartcall.ru) — v2.3.6
================================================================================

1. НАЗВАНИЯ И РАСПОЛОЖЕНИЕ ФАЙЛОВ КЛЮЧЕЙ ВНУТРИ АРХИВА:
   - keystore/release.keystore            — Основное хранилище ключей PKCS#12 (для apksigner, jarsigner, Gradle, keytool)
   - keystore/release_android.p12         — Идентичная копия хранилища PKCS#12 в формате .p12
   - keystore/release.p12                 — Идентичное хранилище PKCS#12 (синхронизировано с тем же паролем и алиасом)
   - keystore/private_key.pem             — Оригинальный закрытый ключ RSA-2048 в формате PEM (с атрибутами OpenSSL, без пароля)
   - keystore/private_key_pkcs8.pem       — Чистый закрытый ключ RSA-2048 в формате PKCS#8 PEM (без пароля)
   - keystore/cert.pem                    — Сертификат разработчика X.509 в формате PEM
   - keystore/cert.der                    — Сертификат разработчика X.509 в бинарном формате DER
   - previous_signing_certificate.pem     — Копия сертификата X.509 в корне проекта (используется скриптом build_release.py)

2. ПАРОЛИ И ПСЕВДОНИМ КЛЮЧА (ДЛЯ ВСЕХ ФАЙЛОВ .keystore / .p12):
   - Пароль хранилища ключей (storePassword): android
   - Псевдоним ключа (keyAlias):              smartcall
   - Пароль самого ключа (keyPassword):       android
   - Пароль файла keystore/release.p12:       android (алиас: smartcall)
   - Пароль файлов private_key.pem / private_key_pkcs8.pem: отсутствует (ключ хранится в открытом PEM-формате)

3. ПАРАМЕТРЫ СЕРТИФИКАТА И ОТПЕЧАТКИ:
   - Идентификатор пакета (packageName):      com.smartcall.ru
   - Владелец / Издатель (Subject / Issuer):  CN=CallButtonCommander, OU=Mobile, O=CallButtonCommander, L=Dushanbe, ST=TJ, C=TJ
   - Серийный номер (Decimal):                15396231850532863750
   - Серийный номер (Hex):                    0xd5aa674b9a90ff06
   - Срок действия:                           с 22.10.2026 по 09.03.2054
   - Алгоритм ключа и подписи:                RSA 2048 бит, SHA256withRSA (JAR Signing v1 + APK Signature Scheme v2)
   - SHA-1 отпечаток сертификата:             f2e736f28ada0744a16c76d679b8d800dab1ae22
   - SHA-256 отпечаток сертификата:           baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01

4. НАЗНАЧЕНИЕ ФАЙЛОВ И КАКОЕ ХРАНИЛИЩЕ ИСПОЛЬЗУЕТСЯ ДЛЯ ПОДПИСИ ОБНОВЛЕНИЙ:
   - Встроенный в проект Python-сборщик (`build_release.py` / `build_apk.py` / `apk_signer.py`) напрямую использует пару:
       `keystore/private_key.pem` + `previous_signing_certificate.pem` (или `keystore/cert.pem`).
   - Стандартные утилиты Android SDK (`apksigner`, `jarsigner`, `keytool`, Gradle) используют хранилище:
       `keystore/release.keystore` (или `keystore/release_android.p12` / `keystore/release.p12`)
       с параметрами: `storePassword=android`, `keyAlias=smartcall`, `keyPassword=android`.
   - Примечание по `keystore/release.p12`: ранее в архиве лежал промежуточный контейнер с нестандартным паролем; теперь `keystore/release.p12` перепакован с тем же самым закрытым ключом RSA-2048, тем же сертификатом (`SHA-256: baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01`), паролем `android` и алиасом `smartcall`. Все три файла (`release.keystore`, `release_android.p12`, `release.p12`) проверены и открываются паролем `android`.

5. ИНСТРУКЦИЯ ПО ИСПОЛЬЗОВАНИЮ СУЩЕСТВУЮЩЕГО КЛЮЧА:
   А) Автоматическая сборка и подпись через Python (рекомендуется):
      python3 build_apk.py
      или:
      python3 build_release.py --key keystore/private_key.pem --cert previous_signing_certificate.pem --output dist/Umnyj_Vyzov_v2.3.6.apk

   Б) Подпись стороннего/пересобранного APK через Android SDK `apksigner`:
      apksigner sign --ks keystore/release.keystore --ks-key-alias smartcall --ks-pass pass:android --key-pass pass:android app.apk

   В) Проверка хранилища через `keytool`:
      keytool -list -v -keystore keystore/release.keystore -storepass android
================================================================================
