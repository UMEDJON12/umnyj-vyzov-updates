#!/usr/bin/env python3
"""Fail-closed validation of the pre-signed draft candidate.

The APK is signed locally using the owner's original private key, which is
NEVER stored in this public repository. CI separately compiles the same source
as an unsigned APK and checks the locally signed candidate before the draft.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'build'))
from axml_arsc_gen import build_manifest_axml
APK=ROOT/'ci/SmartCall-2.3.12-signed.apk'
EXPECTED_SHA256='05ae4d798809de13a19e807fd0beb2eaa7bc8e1f8443b400a180688251348f87'

assert APK.is_file(), 'signed candidate missing'
assert hashlib.sha256(APK.read_bytes()).hexdigest()==EXPECTED_SHA256, 'signed candidate checksum mismatch'
with ZipFile(APK) as z:
    assert z.testzip() is None, 'ZIP CRC failure'
    assert z.read('AndroidManifest.xml') == build_manifest_axml(
        'com.smartcall.ru',35,'2.3.12',24,28), 'manifest version/package mismatch'
    assert any(n.endswith('.dex') for n in z.namelist()), 'DEX missing'
# The binary uploaded as a draft must contain the exact compiled application
# produced by CI from this source, not an unrelated pre-signed payload.
BUILT=ROOT/'dist/SmartCall-2.3.12-CI-unsigned.apk'
assert BUILT.is_file(), 'CI unsigned compilation missing'
with ZipFile(BUILT) as source, ZipFile(APK) as signed:
    source_names=set(source.namelist())
    payload_names={name for name in signed.namelist() if not name.startswith('META-INF/')}
    assert source_names == payload_names, 'signed payload entries differ from CI output'
    for name in sorted(source_names):
        assert source.read(name)==signed.read(name), 'signed payload mismatch at '+name
print('Verified byte-for-byte compiled DEX and resources against signed candidate')

print('Verified signed APK bytes and Android package/version: 2.3.12 (35)')
