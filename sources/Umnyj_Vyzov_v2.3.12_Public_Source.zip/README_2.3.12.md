# Умный Вызов 2.3.12

Исходники на Java открыты и доступны для редактирования.
Подпись оригинальным сертификатом сохраняется для установки поверх 2.3.11.

Сборка в распакованном каталоге:

```bash
python3 -m pip install -r requirements.txt
python3 build_apk.py --key keys/private_key.pem --cert keys/cert.pem --output dist/SmartCall-2.3.12-signed.apk
sh tests/run_all.sh
```

Для отдельной публичной GitHub Actions сборки используется `build_apk.py --unsigned`
(ключи никогда не загружаются в GitHub). Подписанный владельцем APK
сравнивается с заново собранным из того же исходного кода.

**Тест на реальном Xiaomi не выполнен.** Подробнее: `DIAGNOSTIC_2312.md`.

Важно: private ZIP содержит закрытый ключ подписи; храните его только в личном хранилище.
