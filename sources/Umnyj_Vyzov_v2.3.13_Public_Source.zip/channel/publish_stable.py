#!/usr/bin/env python3
"""Проверить публичный релиз и сформировать updates/stable.json без токена."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import urllib.request
import urllib.parse
from pathlib import Path

EXPECTED_PACKAGE = "com.smartcall.ru"
EXPECTED_CERT_SHA256 = "baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01"
OWNER, REPO = "UMEDJON12", "umnyj-vyzov-updates"
MAX_APK_BYTES = 100 * 1024 * 1024
UA = "SmartCall-StablePublisher/1.0"


class Rejected(Exception):
    pass


def check_transport_url(url, downloads):
    try:
        parsed = urllib.parse.urlsplit(url)
        host = (parsed.hostname or '').lower()
        allowed = (host == 'github.com' or host.endswith('.github.com') or
                   host.endswith('.githubusercontent.com')) if downloads else host in {
                       'api.github.com', 'github.com', 'raw.githubusercontent.com'}
        if (parsed.scheme.lower() != 'https' or not host or not allowed or
                parsed.username is not None or parsed.password is not None or parsed.fragment or
                parsed.port not in (None, 443)):
            raise ValueError()
    except ValueError:
        raise Rejected('недопустимый URL или редирект')


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    max_redirections = 5

    def __init__(self, downloads):
        super().__init__()
        self.downloads = downloads

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_transport_url(newurl, self.downloads)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def open_url(req, timeout, downloads=False):
    check_transport_url(req.full_url, downloads)
    return urllib.request.build_opener(SafeRedirect(downloads)).open(req, timeout=timeout)


def http_get(url, limit=None, headers=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/vnd.github+json", **(headers or {})})
    with open_url(req, timeout=60) as resp:
        if limit is not None and int(resp.headers.get("Content-Length") or 0) > limit:
            raise Rejected("ответ больше лимита")
        data = resp.read(limit + 1 if limit is not None else None)
        if limit is not None and len(data) > limit:
            raise Rejected("тело ответа больше лимита")
        return data


def release_from_api(owner, repo, tag):
    suffix = 'latest' if tag is None else f'tags/{tag}'
    return json.loads(http_get(f"https://api.github.com/repos/{owner}/{repo}/releases/{suffix}", limit=256 * 1024))


def valid_tag(tag):
    if not isinstance(tag, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", tag):
        raise Rejected("недопустимый tagName")


def validate_release(release, tag):
    if not isinstance(release, dict) or release.get("draft") is not False or release.get("prerelease") is not False:
        raise Rejected("draft и prerelease должны явно быть false")
    if release.get("tag_name") != tag:
        raise Rejected("тег релиза изменился")


def pick_apk(release, asset_name=None):
    assets = release.get("assets")
    if not isinstance(assets, list) or any(not isinstance(a, dict) or not isinstance(a.get("name"), str) for a in assets):
        raise Rejected("некорректный список ассетов")
    apks = [a for a in assets if a['name'].lower().endswith('.apk') and (asset_name is None or a['name'] == asset_name)]
    if len(apks) != 1:
        raise Rejected(f"нужен ровно один APK-ассет, найдено {len(apks)}")
    asset = apks[0]
    name = asset['name']
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", name) or not name.endswith('.apk') or '..' in name:
        raise Rejected("недопустимое имя APK")
    if asset.get('state') != 'uploaded':
        raise Rejected("ассет не загружен")
    if type(asset.get('size')) is not int or not 0 < asset['size'] <= MAX_APK_BYTES:
        raise Rejected("недопустимый размер APK")
    return asset


def validate_asset(release, tag, asset_name=None):
    validate_release(release, tag)
    asset = pick_apk(release, asset_name)
    canonical = f"https://github.com/{OWNER}/{REPO}/releases/download/{tag}/{asset['name']}"
    if asset.get('browser_download_url') != canonical:
        raise Rejected("URL не соответствует каноническому URL клиента")
    return asset


def download(url, dest, expected_size):
    if type(expected_size) is not int or not 0 < expected_size <= MAX_APK_BYTES:
        raise Rejected("недопустимый размер APK")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    total = 0
    with open_url(req, timeout=120, downloads=True) as resp, open(dest, "wb") as out:
        while True:
            chunk = resp.read(256 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_APK_BYTES or total > expected_size:
                raise Rejected("APK больше допустимого размера")
            out.write(chunk)
    if total != expected_size:
        raise Rejected("размер APK не совпадает")
    return total


def run_tool(args):
    proc = subprocess.run(args, capture_output=True, text=True, timeout=180)
    if proc.returncode != 0:
        raise Rejected(f"инструмент не прошёл: {args[0]}: {proc.stderr.strip()[:300]}")
    return proc.stdout


def apk_identity(apk, aapt, apksigner):
    badging = run_tool([aapt, 'dump', 'badging', apk])
    pkgs = re.findall(r"^package: name='([^']+)' versionCode='([0-9]+)'[^\n]*\bversionName='([^']*)'", badging, re.M)
    sdks = re.findall(r"^sdkVersion:'([0-9]+)'\s*$", badging, re.M)
    if len(pkgs) != 1 or len(sdks) != 1:
        raise Rejected("aapt: пакет/versionName/minSdk не определены")
    package, code, version = pkgs[0]
    sdk = int(sdks[0])
    if package != EXPECTED_PACKAGE or not 1 <= int(code) <= 2147483647 or not re.fullmatch(r'[A-Za-z0-9._+\-]{1,64}', version):
        raise Rejected("несовместимые package/versionCode/versionName")
    if not 1 <= sdk <= 24:
        raise Rejected("minSdk несовместим с Android 24")
    if re.search(r'^application-test-only(?:\s|$)', badging, re.M):
        raise Rejected("testOnly APK")
    # badging не всегда выводит testOnly: проверяем бинарный манифест также через xmltree.
    tree = run_tool([aapt, 'dump', 'xmltree', apk, 'AndroidManifest.xml'])
    apps = list(re.finditer(r'^(\s*)E: application\b[^\n]*$', tree, re.M))
    if len(apps) != 1:
        raise Rejected("aapt: application не определён")
    app = apps[0]
    following = tree[app.end():]
    attrs = []
    for line in following.splitlines():
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip())
        if indent <= len(app.group(1)) or line.lstrip().startswith('E:'):
            break
        if re.search(r'\b(?:android:)?testOnly\b', line):
            attrs.append(line)
    if len(attrs) > 1 or (attrs and not re.search(r'\(type 0x12\)0x0\s*$', attrs[0])):
        raise Rejected("testOnly=true или нераспознанное значение")
    signing = run_tool([apksigner, 'verify', '--verbose', '--print-certs', '--min-sdk-version', '23', apk])
    for scheme in (1, 2):
        if len(re.findall(rf'^Verified using v{scheme} scheme \([^\n]*\): true\s*$', signing, re.M)) != 1:
            raise Rejected(f"отсутствует проверенная подпись v{scheme}")
    counts = re.findall(r'^Number of signers: ([0-9]+)\s*$', signing, re.M)
    certs = re.findall(r'^Signer #([0-9]+) certificate SHA-256 digest: ([^\r\n]+)', signing, re.M)
    all_cert_lines = re.findall(r'^Signer #[^\r\n]*certificate SHA-256 digest:[^\r\n]*', signing, re.M)
    if counts != ['1'] or len(certs) != 1 or len(all_cert_lines) != 1 or certs[0][0] != '1' or certs[0][1].lower() != EXPECTED_CERT_SHA256:
        raise Rejected("ожидался ровно один оригинальный подписант")
    return {'packageName': package, 'versionCode': int(code), 'versionName': version, 'minSdk': sdk, 'testOnly': False, 'certSha256': EXPECTED_CERT_SHA256}


def load_previous(stable_path):
    if not stable_path.exists():
        return 0, None
    try:
        data = json.loads(stable_path.read_text(encoding='utf-8'))
        code = data['versionCode']
        if type(code) is not int or not 1 <= code <= 2147483647:
            raise ValueError()
        return code, data
    except (ValueError, TypeError, KeyError, OSError):
        raise Rejected("существующий stable.json повреждён — исправьте вручную")


def clean_notes(body):
    if body is None:
        return ''
    if not isinstance(body, str):
        raise Rejected("некорректное описание релиза")
    result, units = [], 0
    for c in body.strip():
        n = ord(c)
        if (n < 32 and c not in '\n\r\t') or 0xD800 <= n <= 0xDFFF:
            continue
        width = 2 if n > 0xFFFF else 1
        if units + width > 4000:
            break
        result.append(c)
        units += width
    return ''.join(result)


def build_stable(identity, asset, apk_url, sha256, size, notes, tag, published_at):
    return {'schemaVersion': 1, 'packageName': identity['packageName'], 'variant': 'standard',
            'testOnly': identity['testOnly'], 'versionCode': identity['versionCode'],
            'versionName': identity['versionName'], 'minSdk': identity['minSdk'],
            'signingCertificateSha256': identity['certSha256'], 'sizeBytes': size,
            'sha256': sha256, 'apkFileName': asset['name'], 'apkUrl': apk_url,
            'releaseNotes': notes, 'ready': True, 'tagName': tag, 'publishedAt': published_at}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('event', 'owner', 'repo', 'output'):
        p.add_argument('--' + name, required=True)
    p.add_argument('--aapt', default='aapt')
    p.add_argument('--apksigner', default='apksigner')
    p.add_argument('--asset-name')
    p.add_argument('--package', default=EXPECTED_PACKAGE)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    if (a.owner, a.repo, a.package) != (OWNER, REPO, EXPECTED_PACKAGE):
        raise Rejected("репозиторий или пакет не совпадает с конфигурацией клиента")
    event = json.loads(Path(a.event).read_text(encoding='utf-8'))
    release = event.get('release') or {}
    tag = release.get('tag_name')
    valid_tag(tag)
    validate_release(release, tag)
    fresh = release_from_api(a.owner, a.repo, tag)
    asset = validate_asset(fresh, tag, a.asset_name)
    # Clients validate against /releases/latest, so a non-latest release must not become stable.
    latest_public = release_from_api(a.owner, a.repo, None)
    latest_asset = validate_asset(latest_public, tag, a.asset_name)
    if (latest_asset.get('id'), latest_asset.get('size'), latest_asset.get('browser_download_url')) != (
            asset.get('id'), asset.get('size'), asset.get('browser_download_url')):
        raise Rejected('latest не соответствует публикуемому ассету')
    stable_path = Path(a.output) / 'updates' / 'stable.json'
    prev_version, previous = load_previous(stable_path)
    with tempfile.TemporaryDirectory(prefix='stable-pub-') as td:
        apk = str(Path(td) / 'release.apk')
        download(asset['browser_download_url'], apk, asset['size'])
        sha256 = hashlib.sha256(Path(apk).read_bytes()).hexdigest()
        declared_digest = asset.get('digest')
        if declared_digest is not None:
            if not isinstance(declared_digest, str) or not re.fullmatch(r'sha256:[0-9a-fA-F]{64}', declared_digest):
                raise Rejected('некорректный digest ассета GitHub')
            if declared_digest[7:].lower() != sha256:
                raise Rejected('digest ассета GitHub не совпадает со скачанным APK')
        identity = apk_identity(apk, a.aapt, a.apksigner)
    latest = release_from_api(a.owner, a.repo, tag)
    latest_asset = validate_asset(latest, tag, a.asset_name)
    latest_public = release_from_api(a.owner, a.repo, None)
    latest_public_asset = validate_asset(latest_public, tag, a.asset_name)
    if (latest_public_asset.get('id'), latest_public_asset.get('size'), latest_public_asset.get('browser_download_url')) != (
            latest_asset.get('id'), latest_asset.get('size'), latest_asset.get('browser_download_url')):
        raise Rejected('latest изменился во время проверки')
    # GitHub увеличивает download_count именно при нашем скачивании; остальные
    # поля релиза и ассетов должны остаться неизменными.
    def without_download_counts(release):
        return {k: ([{ak: av for ak, av in item.items() if ak != 'download_count'}
                     for item in value] if k == 'assets' else value)
                for k, value in release.items()}
    if without_download_counts(latest) != without_download_counts(fresh):
        raise Rejected("релиз изменился после скачивания")
    if load_previous(stable_path) != (prev_version, previous):
        raise Rejected("stable.json изменился во время проверки")
    published_at = fresh.get('published_at') or ''
    if not isinstance(published_at, str) or len(published_at.encode('utf-16-le')) > 128:
        raise Rejected("некорректный publishedAt")
    stable = build_stable(identity, asset, asset['browser_download_url'], sha256, asset['size'], clean_notes(fresh.get('body')), tag, published_at)
    if identity['versionCode'] < prev_version:
        raise Rejected("откат запрещён")
    if identity['versionCode'] == prev_version:
        keys = ('sha256', 'tagName', 'apkFileName', 'versionCode', 'versionName', 'sizeBytes', 'apkUrl')
        if not all(previous.get(k) == stable[k] for k in keys):
            raise Rejected("конфликт той же версии")
        print('Версия уже опубликована — без изменений')
        return 0
    if a.dry_run:
        print(json.dumps(stable, ensure_ascii=False, indent=2))
        return 0
    stable_path.parent.mkdir(parents=True, exist_ok=True)
    stable_path.write_text(json.dumps(stable, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f"stable.json обновлён: {identity['versionName']}, sha256={sha256}")
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Rejected as exc:
        print(f'ОТКАЗ: {exc}', file=sys.stderr)
        sys.exit(1)
