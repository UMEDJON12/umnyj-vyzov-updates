#!/usr/bin/env python3
"""Host-тесты channel/publish_stable.py: без сети и без реальных aapt/apksigner."""
import importlib.util
import json
import os
import stat
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "publish_stable", ROOT / "channel" / "publish_stable.py")
pub = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(pub)

APK = ROOT / "tests" / "update" / "fixtures" / "SmartCall-2.3.7-fixture.apk"


def make_tools(dirpath):
    """Заглушки aapt/apksigner с корректным выводом для фикстуры."""
    aapt = Path(dirpath) / "aapt"
    aapt.write_text(
        "#!/bin/sh\n"
        "if [ \"$2\" = xmltree ]; then echo '    E: application (line=1)'; exit 0; fi\n"
        "echo \"package: name='com.smartcall.ru' versionCode='30' versionName='2.3.7' platformBuildVersionName='14'\"\n"
        "echo \"sdkVersion:'24'\"\n")
    aapt.chmod(aapt.stat().st_mode | stat.S_IEXEC)
    signer = Path(dirpath) / "apksigner"
    signer.write_text(
        "#!/bin/sh\n"
        "echo \"Verifies\"\n"
        "echo \"Verified using v1 scheme (JAR signing): true\"\n"
        "echo \"Verified using v2 scheme (APK Signature Scheme v2): true\"\n"
        "echo \"Number of signers: 1\"\n"
        "echo \"Signer #1 certificate SHA-256 digest: "
        "baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01\"\n")
    signer.chmod(signer.stat().st_mode | stat.S_IEXEC)
    return str(aapt), str(signer)


class PublishStableTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="stable-test-")
        self.dir = Path(self.tmp.name)
        self.event = self.dir / "event.json"
        self.event.write_text(json.dumps({
            "release": {"tag_name": "v2.3.7", "draft": False, "prerelease": False,
                        "body": "Исправления безопасности и новый интерфейс.",
                        "published_at": "2026-11-11T00:00:00Z"}
        }), encoding="utf-8")
        self.release = {
            "tag_name": "v2.3.7", "draft": False, "prerelease": False,
            "body": "Исправления безопасности и новый интерфейс.",
            "published_at": "2026-11-11T00:00:00Z",
            "assets": [{"name": "SmartCall-2.3.7.apk", "state": "uploaded", "size": APK.stat().st_size,
                        "browser_download_url":
                            "https://github.com/UMEDJON12/umnyj-vyzov-updates/releases/download/v2.3.7/SmartCall-2.3.7.apk"}],
        }
        self.repo = self.dir / "repo"
        (self.repo / "updates").mkdir(parents=True)

        # Патчим сеть: событие уже прочитано, API и скачивание локальные.
        self._orig_api = pub.release_from_api
        self._orig_dl = pub.download
        pub.release_from_api = lambda owner, repo, tag: dict(self.release)
        def fake_download(url, dest, size):
            data = APK.read_bytes()
            if len(data) != size:
                raise pub.Rejected(f"размер скачанного файла {len(data)} != заявленному {size}")
            Path(dest).write_bytes(data)
            return len(data)
        pub.download = fake_download

    def tearDown(self):
        pub.release_from_api = self._orig_api
        pub.download = self._orig_dl
        self.tmp.cleanup()

    def run_main(self, *extra):
        aapt, signer = make_tools(self.dir)
        argv = ["publish_stable.py", "--event", str(self.event),
                "--owner", "UMEDJON12", "--repo", "umnyj-vyzov-updates",
                "--output", str(self.repo), "--aapt", aapt, "--apksigner", signer,
                *extra]
        old = sys.argv
        sys.argv = argv
        try:
            return pub.main()
        finally:
            sys.argv = old

    def test_first_publish_writes_channel(self):
        self.assertEqual(self.run_main(), 0)
        data = json.loads((self.repo / "updates" / "stable.json").read_text("utf-8"))
        self.assertEqual(data["packageName"], "com.smartcall.ru")
        self.assertEqual(data["versionCode"], 30)
        self.assertEqual(data["variant"], "standard")
        self.assertFalse(data["testOnly"])
        self.assertTrue(data["ready"])
        self.assertEqual(data["signingCertificateSha256"], pub.EXPECTED_CERT_SHA256)
        self.assertEqual(data["sizeBytes"], APK.stat().st_size)
        self.assertEqual(len(data["sha256"]), 64)
        self.assertEqual(data["apkFileName"], "SmartCall-2.3.7.apk")
        self.assertTrue(data["apkUrl"].startswith("https://"))
        self.assertIn("Исправления безопасности", data["releaseNotes"])

    def test_repeat_same_version_is_idempotent(self):
        self.run_main()
        self.assertEqual(self.run_main(), 0)  # уже опубликовано — без отказа

    def test_rollback_rejected(self):
        self.run_main()
        self.release["tag_name"] = "v2.3.0"
        self.release["assets"][0]["name"] = "Old.apk"
        self.release["assets"][0]["browser_download_url"] = "https://github.com/UMEDJON12/umnyj-vyzov-updates/releases/download/v2.3.0/Old.apk"
        self.event.write_text(json.dumps({
            "release": {"tag_name": "v2.3.0", "draft": False, "prerelease": False}
        }), encoding="utf-8")
        # делаем фейковый ассет младшей версии: подменяем вывод aapt
        aapt = self.dir / "aapt_old"
        aapt.write_text("#!/bin/sh\n"
                        "if [ \"$2\" = xmltree ]; then echo '    E: application (line=1)'; exit 0; fi\n"
                        "echo \"package: name='com.smartcall.ru' versionCode='23' versionName='2.3.0'\"\n"
                        "echo \"sdkVersion:'24'\"\n")
        aapt.chmod(aapt.stat().st_mode | stat.S_IEXEC)
        with self.assertRaisesRegex(pub.Rejected, "откат"):
            self.run_main("--aapt", str(aapt))

    def test_draft_event_rejected(self):
        self.event.write_text(json.dumps({
            "release": {"tag_name": "v9", "draft": True, "prerelease": False}
        }), encoding="utf-8")
        with self.assertRaises(pub.Rejected):
            self.run_main()

    def test_wrong_package_rejected(self):
        aapt = self.dir / "aapt_wrong"
        # подменяем путь aapt внутри run_main через extra-аргумент
        aapt.write_text("#!/bin/sh\n"
                        "echo \"package: name='org.evil.app' versionCode='99' "
                        "versionName='9.9'\"\n")
        aapt.chmod(aapt.stat().st_mode | stat.S_IEXEC)
        with self.assertRaises(pub.Rejected):
            self.run_main("--aapt", str(aapt))

    def test_wrong_signing_cert_rejected(self):
        signer = self.dir / "apksigner_wrong"
        signer.write_text("#!/bin/sh\n"
                          "echo \"Verified using v1 scheme (JAR signing): true\"\n"
                          "echo \"Verified using v2 scheme (APK Signature Scheme v2): true\"\n"
                          "echo \"Number of signers: 1\"\n"
                          "echo \"Signer #1 certificate SHA-256 digest: "
                          + "0" * 64 + "\"\n")
        signer.chmod(signer.stat().st_mode | stat.S_IEXEC)
        with self.assertRaises(pub.Rejected):
            self.run_main("--apksigner", str(signer))

    def test_two_apk_assets_rejected(self):
        self.release["assets"].append(dict(self.release["assets"][0]))
        with self.assertRaises(pub.Rejected):
            self.run_main()

    def test_size_mismatch_rejected(self):
        self.release["assets"][0]["size"] = 12345
        with self.assertRaises(pub.Rejected):
            self.run_main()


if __name__ == "__main__":
    unittest.main(verbosity=2)
