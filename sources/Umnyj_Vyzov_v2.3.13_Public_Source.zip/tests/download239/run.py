#!/usr/bin/env python3
"""Host-JVM API 24–29 contract models, NOT Android, real filesystems, or OEM behavior."""
import pathlib
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
SOURCES = {
'android/net/Uri.java': r'''package android.net;
import java.io.File; import java.net.URI;
public final class Uri {
 private final String value; private Uri(String s){value=s;}
 public static Uri parse(String s){return new Uri(s);} public static Uri fromFile(File f){return new Uri(f.toURI().toString());}
 public String getScheme(){return URI.create(value).getScheme();} public String getAuthority(){return URI.create(value).getAuthority();}
 public String getPath(){return URI.create(value).getPath();} public String toString(){return value;}
}''',
'android/content/ContentValues.java': r'''package android.content;
import java.util.*; public class ContentValues {
 private final Map<String,Object> m=new HashMap<>(); public void put(String k,String v){m.put(k,v);} public void put(String k,Integer v){m.put(k,v);}
 public Object get(String k){return m.get(k);} public void clear(){m.clear();}
}''',
'android/content/SharedPreferences.java': r'''package android.content;
import java.util.*; public class SharedPreferences {
 private final Map<String,Object> data=new HashMap<>(); public final Queue<Boolean> results=new ArrayDeque<>(); public int commits;
 public Map<String,?> getAll(){return new HashMap<>(data);}
 public String getString(String k,String d){return data.containsKey(k)?(String)data.get(k):d;}
 public long getLong(String k,long d){return data.containsKey(k)?(Long)data.get(k):d;}
 public Editor edit(){return new Editor();} public class Editor {
 private final Map<String,Object> staged=new HashMap<>();
 public Editor remove(String k){staged.put(k,null);return this;}
 public Editor putString(String k,String v){staged.put(k,v);return this;} public Editor putLong(String k,long v){staged.put(k,v);return this;}
 public Editor putInt(String k,int v){staged.put(k,v);return this;} public Editor putBoolean(String k,boolean v){staged.put(k,v);return this;}
 public Editor putFloat(String k,float v){staged.put(k,v);return this;} public Editor putStringSet(String k,Set<String> v){staged.put(k,v);return this;}
 public boolean commit(){for(Map.Entry<String,Object> e:staged.entrySet()){if(e.getValue()==null)data.remove(e.getKey());else data.put(e.getKey(),e.getValue());} commits++;return results.isEmpty() || results.remove();}
 }}''',
'android/content/Context.java': r'''package android.content;
import java.io.File; import java.util.*; public class Context {
 private final File files; private final ContentResolver resolver; private final Map<String,SharedPreferences> prefs=new HashMap<>();
 public Context(File f,ContentResolver r){files=f;resolver=r;} public File getFilesDir(){return files;}
 public ContentResolver getContentResolver(){return resolver;}
 public SharedPreferences getSharedPreferences(String n,int mode){if(mode!=0)throw new AssertionError(); return prefs.computeIfAbsent(n,k->new SharedPreferences());}
}''',
'android/content/ContentResolver.java': r'''package android.content;
import android.net.Uri; import android.database.Cursor; import java.io.*;
public abstract class ContentResolver {
 public abstract Uri insert(Uri u,ContentValues v); public abstract OutputStream openOutputStream(Uri u,String mode) throws FileNotFoundException;
 public abstract InputStream openInputStream(Uri u) throws FileNotFoundException;
 public abstract int update(Uri u,ContentValues v,String s,String[] a); public abstract int delete(Uri u,String s,String[] a);
 public abstract Cursor query(Uri u,String[] projection,String s,String[] a,String sort);
}''',
'android/database/Cursor.java': r'''package android.database;
public interface Cursor extends AutoCloseable { boolean moveToFirst(); String getString(int i); void close(); }''',
'android/os/Build.java': 'package android.os; public class Build { public static class VERSION { public static int SDK_INT=29; } }',
'android/os/Environment.java': r'''package android.os; import java.io.File;
public class Environment { public static final String DIRECTORY_DOWNLOADS="Download";
 public static File download; public static File getExternalStoragePublicDirectory(String s){return download;} }''',
'android/provider/OpenableColumns.java': 'package android.provider; public interface OpenableColumns { String DISPLAY_NAME="_display_name"; }',
'android/provider/MediaStore.java': r'''package android.provider; import android.net.Uri;
public class MediaStore { public interface MediaColumns {String DISPLAY_NAME="_display_name", MIME_TYPE="mime_type", RELATIVE_PATH="relative_path", IS_PENDING="is_pending";}
 public static class Downloads {public static final Uri EXTERNAL_CONTENT_URI=Uri.parse("content://media/external/downloads");} }''',
'android/media/MediaScannerConnection.java': r'''package android.media; import android.content.Context;
public class MediaScannerConnection {public static void scanFile(Context c,String[] p,String[] m,Object cb){}}''',
'android/system/ErrnoException.java': r'''package android.system; public class ErrnoException extends Exception {public int errno; public ErrnoException(int e){errno=e;}}''',
'android/system/OsConstants.java': 'package android.system; public class OsConstants {public static final int EEXIST=17, EPERM=1, EOPNOTSUPP=95, ENOSYS=38;}',
'android/system/Os.java': r'''package android.system; import java.nio.file.*; import java.io.IOException;
public class Os {public static int forcedErrno=0, attempts=0;
 public static void link(String a,String b) throws ErrnoException {attempts++; if(forcedErrno!=0) throw new ErrnoException(forcedErrno);
 try {Files.createLink(Paths.get(b),Paths.get(a));} catch(FileAlreadyExistsException e){throw new ErrnoException(OsConstants.EEXIST);}
 catch(IOException e){throw new ErrnoException(OsConstants.EPERM);} }}''',
'DownloadTest.java': r'''import android.content.*; import android.database.Cursor; import android.net.Uri; import android.provider.*;
import com.smartcall.ru.DownloadStore; import com.smartcall.ru.update.*; import java.io.*; import java.nio.file.*;
import java.util.*; import java.util.zip.*;

public class DownloadTest {
 static final String HASH="5e8b27bc72ea024da86ff9e48ec56e956e3499ab2e921ee70006d52890f6ff8d";
 static int checks; static void check(boolean b,String s){checks++; if(!b)throw new AssertionError(s);}
 interface Work {void run() throws Exception;}
 static void fails(Work f,StatusCode code,String label) throws Exception {try{f.run();}catch(UpdateException e){check(e.status()==code,label+" got "+e.status());return;} throw new AssertionError(label+" unexpectedly passed");}
 static final class Row {Uri uri; String name; Path file; boolean pending=true; boolean reread; byte[] readBytes;}
 static final class Model extends ContentResolver {
  final Path dir; final Map<String,Row> rows=new LinkedHashMap<>(); int next=1, inserts, deletes, publishes; boolean corruptRead;
  String lastRead; final List<String> events=new ArrayList<>();
  Model(Path p){dir=p;}
  Row row(Uri u){Row r=rows.get(u.toString());if(r==null)throw new IllegalArgumentException("missing row "+u);return r;}
  Row seed(String name,byte[] data) throws IOException {Row r=new Row(); r.uri=Uri.parse("content://media/external/downloads/"+next++);r.name=name;r.file=dir.resolve("row"+next);r.pending=false;Files.write(r.file,data);rows.put(r.uri.toString(),r);return r;}
  public Uri insert(Uri collection,ContentValues v){
   check(collection.toString().equals(MediaStore.Downloads.EXTERNAL_CONTENT_URI.toString()),"collection");
   check(Integer.valueOf(1).equals(v.get("is_pending")),"insert pending");
   check("Download".equals(v.get("relative_path")),"relative path");check("application/vnd.android.package-archive".equals(v.get("mime_type")),"mime");
   String base=(String)v.get("_display_name"), name=base; int i=1;
   while(hasName(name)){name=base.substring(0,base.length()-4)+" ("+(i++)+").apk";}
   Row r=new Row();r.name=name;r.uri=Uri.parse("content://media/external/downloads/"+next++);r.file=dir.resolve("row"+next);
   rows.put(r.uri.toString(),r);inserts++;events.add("insert");return r.uri;
  }
  boolean hasName(String n){for(Row r:rows.values())if(r.name.equals(n))return true;return false;}
  public OutputStream openOutputStream(Uri u,String mode) throws FileNotFoundException {Row r=row(u);check(r.pending,"write pending");check("w".equals(mode),"write mode");events.add("write");return new FileOutputStream(r.file.toFile());}
  public InputStream openInputStream(Uri u) throws FileNotFoundException {Row r=row(u);lastRead=u.toString();events.add("read:"+u);
   try {byte[] b=Files.readAllBytes(r.file);if(corruptRead && r.pending)b[0]^=1;
    return new ByteArrayInputStream(b){boolean eof=false; public synchronized int read(byte[] out,int off,int len){int n=super.read(out,off,len);if(n==-1){eof=true;r.reread=true;r.readBytes=b.clone();}return n;}
      public synchronized int read(){int n=super.read();if(n==-1){eof=true;r.reread=true;r.readBytes=b.clone();}return n;}};
   }catch(IOException e){throw new FileNotFoundException(e.toString());}}
  public int update(Uri u,ContentValues v,String s,String[] a){Row r=row(u);check(r.pending,"publish pending row");check(Integer.valueOf(0).equals(v.get("is_pending")),"publish flag");
   check(r.reread,"full reread before publish");try {check(Arrays.equals(r.readBytes,Files.readAllBytes(r.file)),"reread exact stored bytes");check(HASH.equals(Sha256.ofBytes(r.readBytes)),"reread sha before publish");}catch(IOException e){throw new RuntimeException(e);}
   r.pending=false;publishes++;events.add("publish");return 1;}
  public int delete(Uri u,String s,String[] a){Row r=rows.remove(u.toString());if(r==null)return 0;try{Files.deleteIfExists(r.file);}catch(IOException e){throw new RuntimeException(e);}deletes++;events.add("delete");return 1;}
  public Cursor query(Uri u,String[] projection,String s,String[] a,String order){Row r=row(u);check(projection.length==1 && projection[0].equals(OpenableColumns.DISPLAY_NAME),"query name");return new Cursor(){public boolean moveToFirst(){return true;} public String getString(int i){return r.name;} public void close(){}};}
 }
 static UpdateState.Downloaded meta(long size,String sha){return new UpdateState.Downloaded(30,"2.3.7",sha,size,"ignored.apk");}
 static File unsigned(Path target,Path fixture) throws IOException {
  try(ZipFile z=new ZipFile(fixture.toFile());ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(target))){Enumeration<? extends ZipEntry> es=z.entries();while(es.hasMoreElements()) {ZipEntry e=es.nextElement();if(e.getName().startsWith("META-INF/"))continue;out.putNextEntry(new ZipEntry(e.getName()));try(InputStream in=z.getInputStream(e)){in.transferTo(out);}out.closeEntry();}}
  return target.toFile();
 }
 public static void main(String[] args) throws Exception {
  Path root=Paths.get(args[0]), fixture=Paths.get(args[1]); byte[] bytes=Files.readAllBytes(fixture);
  check(bytes.length==207113 && HASH.equals(Sha256.ofBytes(bytes)),"fixture independent expected hash and size");
  Path files=Files.createDirectory(root.resolve("private")), media=Files.createDirectory(root.resolve("media"));
  Model m=new Model(media); Context c=new Context(files.toFile(),m); UpdateState.Downloaded d=meta(bytes.length,HASH);
  byte[] old="existing user file".getBytes("UTF-8");Row existing=m.seed("SmartCall-2.3.7-signed.apk",old);
  DownloadStore.Record r=DownloadStore.export(c,fixture.toFile(),d,Downloader.NEVER_CANCELLED); Row exported=m.row(r.uri);
  check(!exported.pending && m.publishes==1,"published");check(Arrays.equals(bytes,Files.readAllBytes(exported.file)),"full exported bytes");
  check(HASH.equals(Sha256.ofBytes(Files.readAllBytes(exported.file))),"export hash");
  check(Arrays.equals(old,Files.readAllBytes(existing.file)),"collision preserves existing bytes");check(!r.name.equals(existing.name)&&r.name.equals(exported.name),"collision actual name returned");
  DownloadStore.Record saved=DownloadStore.read(c);check(saved!=null && saved.uri.toString().equals(r.uri.toString()) && saved.name.equals(r.name) && saved.size==bytes.length && saved.sha256.equals(HASH) && saved.versionCode==30 && saved.versionName.equals("2.3.7"),"persisted full record");
  // Add another row with the original filename to ensure the persisted URI, not name, is used.
  File snap=DownloadStore.snapshotForInstall(c,saved,29);check(m.lastRead.equals(saved.uri.toString()),"snapshot uses saved URI");check(Arrays.equals(bytes,Files.readAllBytes(snap.toPath())),"snapshot bytes");
  Path granted=snap.toPath(); byte[] damaged=bytes.clone();damaged[100]^=1;Files.write(granted,damaged);
  File alternate=DownloadStore.snapshotForInstall(c,saved,29);
  check(!alternate.toPath().equals(granted) && alternate.getName().equals("install-"+HASH+"-1.snapshot"),"corrupt granted snapshot uses alternative");
  check(Arrays.equals(damaged,Files.readAllBytes(granted)) && Arrays.equals(bytes,Files.readAllBytes(alternate.toPath())),"previous granted URI bytes unchanged and alternative valid");
  fails(()->DownloadStore.snapshotForInstall(c,saved,30),StatusCode.UP_TO_DATE,"equal version");fails(()->DownloadStore.snapshotForInstall(c,saved,31),StatusCode.UP_TO_DATE,"older version");
  byte[] changed=bytes.clone();changed[100]^=1;Files.write(exported.file,changed);fails(()->DownloadStore.snapshotForInstall(c,saved,29),StatusCode.HASH_MISMATCH,"changed exported bytes");
  check(m.lastRead.equals(saved.uri.toString()),"tampered snapshot URI");Files.write(exported.file,bytes);
  int beforeRows=m.rows.size(),beforeInserts=m.inserts,beforePublishes=m.publishes;
  Path broken=Files.write(root.resolve("broken.apk"),changed);fails(()->DownloadStore.export(c,broken.toFile(),d,Downloader.NEVER_CANCELLED),StatusCode.HASH_MISMATCH,"corrupted source");
  check(m.rows.size()==beforeRows && m.inserts==beforeInserts,"corrupt source no insert");
  File unsigned=unsigned(root.resolve("unsigned.apk"),fixture);byte[] ub=Files.readAllBytes(unsigned.toPath());
  fails(()->DownloadStore.export(c,unsigned,meta(ub.length,Sha256.ofBytes(ub)),Downloader.NEVER_CANCELLED),StatusCode.CERT_MISMATCH,"unsigned source");
  check(m.rows.size()==beforeRows && m.inserts==beforeInserts,"unsigned no insert");
  fails(()->DownloadStore.export(c,fixture.toFile(),d,()->true),StatusCode.CANCELLED,"cancelled copy");
  check(m.rows.size()==beforeRows && m.deletes==1 && m.publishes==beforePublishes,"cancel cleans pending row");
  m.corruptRead=true;fails(()->DownloadStore.export(c,fixture.toFile(),d,Downloader.NEVER_CANCELLED),StatusCode.HASH_MISMATCH,"corrupt reread");m.corruptRead=false;
  check(m.rows.size()==beforeRows && m.deletes==2 && m.publishes==beforePublishes,"bad reread cleaned, never published");
  check(Arrays.equals(old,Files.readAllBytes(existing.file)),"existing collision remains untouched after failures");
  check(DownloadStore.read(c).uri.toString().equals(saved.uri.toString()),"failures preserve saved record");
  SharedPreferences prefs=c.getSharedPreferences("verified_download_export",0);
  prefs.edit().putString("unrelated","keep").commit(); Map<String,?> prior=prefs.getAll();
  for(boolean rollbackResult:new boolean[]{true,false}) {
   int count=m.rows.size(), deletions=m.deletes, commits=prefs.commits;
   prefs.results.add(false);prefs.results.add(rollbackResult);
   fails(()->DownloadStore.export(c,fixture.toFile(),d,Downloader.NEVER_CANCELLED),StatusCode.STORAGE,"failed preference commit");
   check(prefs.commits==commits+2 && prefs.results.isEmpty(),"save and rollback commits attempted");
   check(prefs.getAll().equals(prior),"all prior preferences restored including unrelated key");
   DownloadStore.Record after=DownloadStore.read(c);
   check(after!=null && after.uri.toString().equals(saved.uri.toString()) && after.name.equals(saved.name) && after.size==saved.size && after.sha256.equals(saved.sha256) && after.versionCode==saved.versionCode && after.versionName.equals(saved.versionName),"full previous record restored");
   check(m.rows.size()==count && m.deletes==deletions+1 && m.rows.containsKey(saved.uri.toString()),"only new row deleted");
   check(Arrays.equals(old,Files.readAllBytes(existing.file)) && Arrays.equals(bytes,Files.readAllBytes(exported.file)),"previous files preserved");
  }
  Context empty=new Context(files.toFile(),m); SharedPreferences ep=empty.getSharedPreferences("verified_download_export",0);
  ep.edit().putBoolean("unrelated",true).putInt("size",42).commit(); Map<String,?> emptyPrior=ep.getAll();
  ep.results.add(false);ep.results.add(false);
  fails(()->DownloadStore.export(empty,fixture.toFile(),d,Downloader.NEVER_CANCELLED),StatusCode.STORAGE,"failed initial commit");
  check(ep.getAll().equals(emptyPrior) && DownloadStore.read(empty)==null,"absent and differently typed fields restored");
  // Legacy models use host hard links, not Android shared storage or SAF.
  for(int api=24;api<=28;api++) {
   android.os.Build.VERSION.SDK_INT=api;
   Path dl=Files.createDirectory(root.resolve("Download"+api)); android.os.Environment.download=dl.toFile();
   Context lc=new Context(files.toFile(),m); Path user=dl.resolve("SmartCall-2.3.7-signed.apk"); Files.write(user,old);
   android.system.Os.attempts=0;
   DownloadStore.Record lr=DownloadStore.export(lc,fixture.toFile(),d,Downloader.NEVER_CANCELLED);
   check(android.system.Os.attempts==2,"legacy atomic collision retry API "+api);
   check(lr.name.equals("SmartCall-2.3.7-signed (1).apk"),"legacy collision actual name API "+api);
   check(Arrays.equals(old,Files.readAllBytes(user)),"legacy original intact API "+api);
   check(Arrays.equals(bytes,Files.readAllBytes(Paths.get(lr.uri.getPath()))),"legacy exported bytes API "+api);
   check(DownloadStore.read(lc).uri.toString().equals(lr.uri.toString()),"legacy record API "+api);
   for(int error:new int[]{android.system.OsConstants.EPERM,android.system.OsConstants.EOPNOTSUPP,android.system.OsConstants.ENOSYS}) {
    android.system.Os.forcedErrno=error;
    try {DownloadStore.export(lc,fixture.toFile(),d,Downloader.NEVER_CANCELLED);throw new AssertionError("unsupported link succeeded");}
    catch(UpdateException e){check(e.status()==StatusCode.STORAGE && e.getMessage().contains("Download") && e.getMessage().contains("SAF"),"unsupported link explanation API "+api);}
    check(DownloadStore.read(lc).uri.toString().equals(lr.uri.toString()),"unsupported preserves record API "+api);
    check(Arrays.equals(old,Files.readAllBytes(user)) && Arrays.equals(bytes,Files.readAllBytes(Paths.get(lr.uri.getPath()))),"unsupported preserves files API "+api);
    try(java.util.stream.Stream<Path> paths=Files.list(dl)){check(paths.count()==2,"unsupported cleans temp API "+api);}
   }
   android.system.Os.forcedErrno=0;
   fails(()->DownloadStore.export(lc,fixture.toFile(),d,()->true),StatusCode.CANCELLED,"legacy cancellation API "+api);
   try(java.util.stream.Stream<Path> paths=Files.list(dl)){check(paths.count()==2,"cancellation cleans temp API "+api);}
   check(DownloadStore.read(lc).uri.toString().equals(lr.uri.toString()) && Arrays.equals(old,Files.readAllBytes(user)),"cancel preserves prior record and user file API "+api);
  }
  System.out.println("PASS: "+checks+" checks; API 24–29 host models only, NOT real Android/filesystem/OEM");
 }
}''',
}

with tempfile.TemporaryDirectory(prefix='download239-') as tmp:
    temp = pathlib.Path(tmp)
    src = temp / 'src'
    classes = temp / 'classes'
    classes.mkdir()
    for name, text in SOURCES.items():
        path = src / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + '\n', encoding='utf-8')
    actual = ROOT / 'src/com/smartcall/ru'
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', str(classes),
                    *map(str, sorted(src.rglob('*.java'))),
                    str(actual / 'DownloadStore.java'),
                    *map(str, sorted((actual / 'update').glob('*.java')))], check=True)
    subprocess.run(['java', '-cp', str(classes), 'DownloadTest', str(temp),
                    str(ROOT / 'tests/update/fixtures/SmartCall-2.3.7-fixture.apk')], check=True)
