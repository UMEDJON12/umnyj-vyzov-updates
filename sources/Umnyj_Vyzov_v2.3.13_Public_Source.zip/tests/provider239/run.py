#!/usr/bin/env python3
"""Host JVM contract tests: no Android runtime, permission grants, or installer."""
import pathlib
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
SOURCES = {
'android/content/ContentProvider.java': r'''package android.content;
import android.database.Cursor; import android.net.Uri; import android.os.ParcelFileDescriptor; import java.io.FileNotFoundException;
public abstract class ContentProvider {
 private Context context; public Context getContext(){return context;} public void attachForTest(Context c){context=c;}
 public abstract boolean onCreate(); public abstract String getType(Uri u);
 public abstract Cursor query(Uri u,String[] p,String s,String[] a,String o);
 public abstract ParcelFileDescriptor openFile(Uri u,String m) throws FileNotFoundException;
 public abstract Uri insert(Uri u,ContentValues v); public abstract int delete(Uri u,String s,String[] a);
 public abstract int update(Uri u,ContentValues v,String s,String[] a);
}''',
'android/content/ContentValues.java': 'package android.content; public class ContentValues {}',
'android/content/Context.java': r'''package android.content;
import java.io.File; import java.util.HashMap; import java.util.Map;
public class Context {
 private final File files; private final Map<String,SharedPreferences> prefs=new HashMap<>();
 public Context(File f){files=f;} public File getFilesDir(){return files;}
 public SharedPreferences getSharedPreferences(String name,int mode){return prefs.computeIfAbsent(name,k->new SharedPreferences());}
}''',
'android/content/SharedPreferences.java': r'''package android.content;
import java.util.HashMap; import java.util.Map;
public class SharedPreferences {
 private final Map<String,String> values=new HashMap<>();
 public String getString(String k,String d){return values.getOrDefault(k,d);}
 public Editor edit(){return new Editor();}
 public class Editor { private final Map<String,String> pending=new HashMap<>();
  public Editor putString(String k,String v){pending.put(k,v);return this;}
  public boolean commit(){values.putAll(pending);return true;}
 }
}''',
'android/database/Cursor.java': r'''package android.database;
public interface Cursor extends AutoCloseable { boolean moveToFirst(); String[] getColumnNames(); String getString(int i); long getLong(int i); boolean isNull(int i); void close(); }''',
'android/database/MatrixCursor.java': r'''package android.database;
public class MatrixCursor implements Cursor {
 private final String[] columns; private final Object[] row; private int next; private boolean positioned;
 public MatrixCursor(String[] c,int capacity){columns=c.clone();row=new Object[c.length];}
 public RowBuilder newRow(){return new RowBuilder();}
 public class RowBuilder { public RowBuilder add(Object v){row[next++]=v; return this;} }
 public boolean moveToFirst(){positioned=next==columns.length; return positioned;}
 public String[] getColumnNames(){return columns.clone();}
 private Object value(int i){if(!positioned)throw new IllegalStateException(); return row[i];}
 public String getString(int i){Object v=value(i);return v==null?null:v.toString();}
 public long getLong(int i){return ((Number)value(i)).longValue();}
 public boolean isNull(int i){return value(i)==null;} public void close(){}
}''',
'android/net/Uri.java': r'''package android.net;
import java.util.ArrayList; import java.util.List;
public final class Uri {
 private final String scheme,authority; private final List<String> paths;
 private Uri(String s,String a,List<String> p){scheme=s;authority=a;paths=new ArrayList<>(p);}
 public String getScheme(){return scheme;} public String getAuthority(){return authority;}
 public List<String> getPathSegments(){return new ArrayList<>(paths);}
 public String toString(){return scheme+"://"+authority+"/"+String.join("/",paths);}
 public static class Builder { private String scheme,authority; private final List<String> paths=new ArrayList<>();
  public Builder scheme(String s){scheme=s;return this;} public Builder authority(String a){authority=a;return this;}
  public Builder appendPath(String p){paths.add(p);return this;} public Uri build(){return new Uri(scheme,authority,paths);}
 }
}''',
'android/os/ParcelFileDescriptor.java': r'''package android.os;
import java.io.*;
public class ParcelFileDescriptor implements AutoCloseable {
 public static final int MODE_READ_ONLY=0x10000000; private final FileInputStream stream;
 private ParcelFileDescriptor(File f) throws FileNotFoundException {stream=new FileInputStream(f);}
 public static ParcelFileDescriptor open(File f,int mode) throws FileNotFoundException {
  if(mode!=MODE_READ_ONLY)throw new IllegalArgumentException("not read only"); return new ParcelFileDescriptor(f);
 }
 public FileInputStream getInputStream(){return stream;} public void close() throws IOException {stream.close();}
}''',
'android/provider/OpenableColumns.java': r'''package android.provider;
public interface OpenableColumns { String DISPLAY_NAME="_display_name"; String SIZE="_size"; }''',
'ProviderTest.java': r'''import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import com.smartcall.ru.UpdateInstallProvider;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;

public class ProviderTest {
 static int checks;
 static void check(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
 interface Throwing { void run() throws Exception; }
 static void fails(Throwing f,Class<? extends Exception> expected,String label) throws Exception {
  try {f.run();} catch(Exception e){check(expected.isInstance(e),label+": wrong exception "+e);return;}
  throw new AssertionError(label+": unexpectedly succeeded");
 }
 static Uri uri(String scheme,String authority,String... paths){
  Uri.Builder b=new Uri.Builder().scheme(scheme).authority(authority);for(String p:paths)b.appendPath(p);return b.build();
 }
 static void denied(UpdateInstallProvider p,Uri u,String label) throws Exception {
  check(p.query(u,null,null,null,null)==null,label+" query");
  check(p.getType(u)==null,label+" type");
  fails(()->p.openFile(u,"r"),FileNotFoundException.class,label+" open");
 }
 public static void main(String[] args) throws Exception {
  Path root=Paths.get(args[0]), updates=Files.createDirectories(root.resolve("updates"));
  Path first=updates.resolve("install-one.snapshot"), second=updates.resolve("install-two.snapshot");
  byte[] payload=new byte[]{1,2,3,4,5}; Files.write(first,payload); Files.write(second,new byte[]{9,8});
  Context context=new Context(root.toFile()); UpdateInstallProvider p=new UpdateInstallProvider();p.attachForTest(context);
  check(p.onCreate(),"onCreate");
  Uri u=UpdateInstallProvider.authorizeSnapshot(context,first.toFile(),"release.apk");
  check("content".equals(u.getScheme()),"scheme"); check(UpdateInstallProvider.AUTHORITY.equals(u.getAuthority()),"authority");
  check(u.getPathSegments().equals(Arrays.asList("update","install-one.snapshot")),"URI path");
  check("application/vnd.android.package-archive".equals(p.getType(u)),"MIME");
  try(Cursor c=p.query(u,null,null,null,null)) {
   check(c!=null && c.moveToFirst(),"default row");
   check(Arrays.equals(c.getColumnNames(),new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}),"default columns");
   check("release.apk".equals(c.getString(0)),"default display"); check(c.getLong(1)==payload.length,"default size");
  }
  try(Cursor c=p.query(u,new String[]{OpenableColumns.SIZE,"unknown",OpenableColumns.DISPLAY_NAME},null,null,null)) {
   check(c!=null && c.moveToFirst(),"selected row");
   check(Arrays.equals(c.getColumnNames(),new String[]{OpenableColumns.SIZE,"unknown",OpenableColumns.DISPLAY_NAME}),"selected columns order");
   check(c.getLong(0)==payload.length,"selected size");check(c.isNull(1),"unknown column null");
   check("release.apk".equals(c.getString(2)),"selected display");
  }
  try(ParcelFileDescriptor fd=p.openFile(u,"r")){check(Arrays.equals(payload,fd.getInputStream().readAllBytes()),"read bytes");}
  for(String mode:new String[]{"w","rw","rwt","wa","", "R"}) fails(()->p.openFile(u,mode),FileNotFoundException.class,"mode "+mode);
  fails(()->p.openFile(u,null),FileNotFoundException.class,"null mode");
  denied(p,uri("content","foreign.authority","update","install-one.snapshot"),"foreign authority");
  denied(p,uri("file",UpdateInstallProvider.AUTHORITY,"update","install-one.snapshot"),"foreign scheme");
  denied(p,uri("content",UpdateInstallProvider.AUTHORITY,"other","install-one.snapshot"),"foreign path");
  denied(p,uri("content",UpdateInstallProvider.AUTHORITY,"update","install-two.snapshot"),"unapproved file");
  denied(p,uri("content",UpdateInstallProvider.AUTHORITY,"update","..","install-one.snapshot"),"extra path");
  Path outside=Files.write(root.resolve("install-outside.snapshot"),new byte[]{7});
  Path link=updates.resolve("install-link.snapshot"); Files.createSymbolicLink(link,outside);
  fails(()->UpdateInstallProvider.authorizeSnapshot(context,link.toFile(),"x.apk"),IOException.class,"authorize symlink escape");
  Files.delete(first);Files.createSymbolicLink(first,outside);
  denied(p,u,"approved path replaced by symlink escape");
  Files.delete(first); Files.write(first,payload);
  try(ParcelFileDescriptor fd=p.openFile(u,"r")){check(Arrays.equals(payload,fd.getInputStream().readAllBytes()),"old URI valid before rotation");}
  Uri newer=UpdateInstallProvider.authorizeSnapshot(context,second.toFile(),"new.apk");
  try(ParcelFileDescriptor fd=p.openFile(u,"r")){check(Arrays.equals(payload,fd.getInputStream().readAllBytes()),"prior granted URI remains valid");}
  try(Cursor c=p.query(newer,null,null,null,null)){check(c!=null&&c.moveToFirst(),"new row");check("new.apk".equals(c.getString(0)),"new display");check(c.getLong(1)==2,"new size");}
  try(ParcelFileDescriptor fd=p.openFile(newer,"r")){check(Arrays.equals(fd.getInputStream().readAllBytes(),new byte[]{9,8}),"new bytes");}
  System.out.println("PASS: "+checks+" checks (host JVM stubs; not Android URI permissions or installer)");
 }
}''',
}

with tempfile.TemporaryDirectory(prefix='provider239-') as tmp:
    temp = pathlib.Path(tmp)
    sources = temp / 'src'
    classes = temp / 'classes'
    classes.mkdir()
    for name, text in SOURCES.items():
        path = sources / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text + '\n', encoding='utf-8')
    provider = ROOT / 'src/com/smartcall/ru/UpdateInstallProvider.java'
    java_files = sorted(str(p) for p in sources.rglob('*.java'))
    subprocess.run(['javac', '-encoding', 'UTF-8', '-d', str(classes), *java_files, str(provider)], check=True)
    files = temp / 'files'
    files.mkdir()
    subprocess.run(['java', '-cp', str(classes), 'ProviderTest', str(files)], check=True)
