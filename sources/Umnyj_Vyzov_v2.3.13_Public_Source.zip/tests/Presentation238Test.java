package com.smartcall.ru;

import java.util.Locale;
import com.smartcall.ru.update.StatusCode;

/** Tests pure presentation policy; no Android device or emulator is used. */
public final class Presentation238Test {
    private static int count;
    private static void check(boolean ok, String what) {
        count++;
        if (!ok) throw new AssertionError(what);
    }
    public static void main(String[] args) {
        for (StatusCode status : StatusCode.values()) {
            check(!UpdateNoticePolicy.shouldShow(false, status), "automatic check silent: " + status);
            check(UpdateNoticePolicy.shouldShow(true, status), "manual check visible: " + status);
        }
        check(StatusCode.NO_PUBLISHED_UPDATES.text().equals("Опубликованных обновлений пока нет"), "exact message");
        String russian = VoiceLabels.label(new Locale("ru", "RU"), 2, false);
        check(russian.toLowerCase(new Locale("ru")).contains("русск"), "human-readable Russian language");
        check(russian.contains("голос 2") && russian.contains("без интернета"), "distinct offline label");
        check(VoiceLabels.label(null, 1, true).contains("требуется интернет"), "unknown locale and online");
        check(!VoiceLabels.label(new Locale("en", "US"), 1, false).equals(
                VoiceLabels.label(new Locale("en", "US"), 2, false)), "distinct ordinal for same locale");
        check(UpdateNoteSummary.summarize(null).isEmpty(), "empty release notes");
        check(UpdateNoteSummary.summarize("# Изменения\n- Раз\n- Два\n- Три\n- Четыре").split("\\n").length == 4, "at most four lines");
        char[] big = new char[500]; java.util.Arrays.fill(big, 'a');
        check(UpdateNoteSummary.summarize(new String(big)).length() <= 360, "bounded release notes");
        System.out.println("PASS: " + count + " presentation assertions");
    }
}
