"""Host-only safety policy tests, not device runtime tests."""
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'src/com/smartcall/ru'
JAVA = '''package com.smartcall.ru;
public class SafetyHarness {
 static void check(boolean ok,String msg) { if(!ok) throw new AssertionError(msg); }
 public static void main(String[] args) {
   HangupPermit p=new HangupPermit();
   check(!p.grant(1,1,false,1000),"disabled hangup forbidden");
   check(!p.claim(1,1001),"disabled cannot authorize");
   check(!p.grant(1,0,true,1100),"idle hangup forbidden");
   check(p.grant(2,2,true,1200),"explicit key down authorized");
   check(!p.claim(1,1201),"wrong key forbidden");
   check(!p.claim(2,1202),"token single-use even on mismatch");
   check(p.grant(2,2,true,1300),"second fresh gesture");
   check(!p.claim(2,2100),"stale grant expired");
   check(p.grant(1,1,true,2300),"new valid key grant");
   check(p.claim(1,2301),"valid permit consumed");
   check(!p.claim(1,2302),"no second hangup");
   SimCallEvidence calls=new SimCallEvidence();
   calls.event(101,1,10000,"TelephonyCallback");
   calls.observed(0,10100);
   check(calls.authoritative(10100,60000)==1,"transient aggregate IDLE cannot erase confirmed ring");
   calls.event(202,0,10120,"TelephonyCallback");
   check(calls.authoritative(10120,60000)==1,"other SIM idle cannot erase ringing SIM");
   calls.event(101,2,10200,"TelephonyCallback");
   check(calls.authoritative(10200,60000)==2,"OFFHOOK recognized");
   calls.event(101,0,10300,"TelephonyCallback");
   check(calls.authoritative(10300,60000)==0,"explicit SIM IDLE clears call");
   calls.event(-1,1,20000,"PHONE_STATE");
   check(calls.authoritative(20001,3000)==1,"global confirmed ring");
   calls.event(-1,0,20003,"PHONE_STATE");
   check(calls.authoritative(20004,3000)==0,"global ending clears global ring");
   System.out.println("PASS 2313 explicit call state and user action guards");
 }
}
'''
class Safety2313(unittest.TestCase):
    def test_pure_jvm_state_and_permit(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'SafetyHarness.java';f.write_text(JAVA)
            subprocess.run(['javac','-d',temp,str(SRC/'HangupPermit.java'),str(SRC/'SimCallEvidence.java'),str(f)],check=True)
            out=subprocess.run(['java','-cp',temp,'com.smartcall.ru.SafetyHarness'],check=True,capture_output=True,text=True)
            self.assertIn('PASS 2313',out.stdout)
    def test_all_hangup_paths_require_permit(self):
        c=(SRC/'CallController.java').read_text()
        delay=(SRC/'DelayedActionRunnable.java').read_text()
        service=(SRC/'CallControlAccessibilityService.java').read_text()
        self.assertIn('HANGUP_PERMIT.claim(',c)
        self.assertIn('HANGUP_PERMIT.grant(',c)
        self.assertIn('if(!permit || !enabled || state==0)',c)
        self.assertNotIn('dispatchMediaKey(context, 6)',c)
        self.assertNotIn('CallController.endCallPulse(context)',delay)
        self.assertIn('KeyEvent.ACTION_UP',service)
        self.assertIn('keyEvent.getEventTime()-keyEvent.getDownTime()<2400L',service)
        self.assertIn('SimCallMonitor.hardwareState(context)',c)
if __name__=='__main__':unittest.main()
