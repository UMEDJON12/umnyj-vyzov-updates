package com.smartcall.ru.update;
import java.io.File; import java.util.concurrent.*;
public class UpdateEngine {public final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1),exited=new CountDownLatch(1); public volatile Downloader.ProgressListener listener; public volatile Downloader.CancelSignal cancel; public volatile boolean fail;
 public void cleanupStaleWork(){} public ReleaseManifest check(long n){return new ReleaseManifest();}
 public ApkVerifier.Result download(long n,ReleaseManifest m,Downloader.ProgressListener p,Downloader.CancelSignal c) throws UpdateException {listener=p;cancel=c;entered.countDown();try {if(!release.await(5,TimeUnit.SECONDS))throw new RuntimeException("timeout");}catch(InterruptedException e){throw new RuntimeException(e);} finally{exited.countDown();} if(c.isCancelled())throw new UpdateException(StatusCode.CANCELLED); if(fail)throw new RuntimeException("failure"); return new ApkVerifier.Result();}
 public ApkVerifier.Result verifyDownloaded(long n) throws UpdateException {return new ApkVerifier.Result();} public UpdateState state(){return new UpdateState();} public File downloadedFile(ApkVerifier.Result o){return o == null ? null : new File("fake.apk");}
}
