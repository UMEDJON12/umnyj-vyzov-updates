package com.smartcall.ru.update; public class Downloader {public interface ProgressListener {void onProgress(long a,long b,int c,long d);} public interface CancelSignal {boolean isCancelled();}}
