package com.smartcall.ru; import android.content.*; public class UpdateProgressActivity {public static Intent openIntent(Context c){return new Intent(c,UpdateProgressActivity.class);}}
