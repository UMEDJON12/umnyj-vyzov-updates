package com.smartcall.ru.update; public class ApprovedRelease {public static boolean matches(ReleaseManifest m,String s){return "approved".equals(s);}}
