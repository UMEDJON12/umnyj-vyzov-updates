package com.smartcall.ru; public class UpdateProgressText {public static int percent(long a,long b){return b==0?-1:(int)(100*a/b);} public static String progress(long a,long b){return a+"/"+b;}}
