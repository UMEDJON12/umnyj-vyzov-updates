package com.smartcall.ru; public class CallController {public static void log(String s){}}
