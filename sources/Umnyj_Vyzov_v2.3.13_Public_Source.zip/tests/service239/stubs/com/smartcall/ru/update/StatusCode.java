package com.smartcall.ru.update; public enum StatusCode {CANCELLED,RELEASE_CHANGED,NO_FILE,STATE,STORAGE}
