package com.smartcall.ru.update; public class ReleaseManifest {public long versionCode=12; public String versionName="v12";}
