package com.smartcall.ru.update;
/** Service model only: cryptographic verification is tested separately. */
public final class ApkVerifier { public static final class Result { } }
