package android.os; public class SystemClock {public static long elapsedRealtime(){return 1000;}}
