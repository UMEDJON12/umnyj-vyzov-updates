package android.os;
import java.util.concurrent.ConcurrentLinkedQueue;
public class Handler { public static final ConcurrentLinkedQueue<Runnable> queue=new ConcurrentLinkedQueue<>();
 public Handler(Looper l){} public boolean post(Runnable r){queue.add(r);return true;}
 public static void drain(){Runnable r;while((r=queue.poll())!=null)r.run();}
}
