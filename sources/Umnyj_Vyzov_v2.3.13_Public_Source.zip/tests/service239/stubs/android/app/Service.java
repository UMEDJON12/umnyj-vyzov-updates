package android.app;
import android.content.*; import android.os.IBinder;
public class Service extends Context {public static final int START_NOT_STICKY=2; public int stoppedId,foregroundCount,stopForegroundCount;public Notification foreground;
 public void onCreate(){} public int onStartCommand(Intent i,int f,int id){return 0;} public void onDestroy(){} public IBinder onBind(Intent i){return null;}
 public void startForeground(int id,Notification n){foregroundCount++;foreground=n;} public void stopForeground(boolean x){stopForegroundCount++;}
 public void stopSelf(int id){stoppedId=id;} public boolean stopSelfResult(int id){stoppedId=id;return true;}
}
