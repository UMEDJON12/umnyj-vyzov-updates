package android.app; public class NotificationManager {public static final int IMPORTANCE_LOW=2; public int count; public Notification last;
 public void notify(int id,Notification n){count++;last=n;} public NotificationChannel getNotificationChannel(String x){return null;} public void createNotificationChannel(NotificationChannel c){} }
