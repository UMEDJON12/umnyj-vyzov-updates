package android.app;
import android.content.*;
public class PendingIntent {public static final int FLAG_UPDATE_CURRENT=1,FLAG_IMMUTABLE=2; public Intent intent; public String kind; public int request,flags;
 static PendingIntent make(String k,int r,Intent i,int f){PendingIntent p=new PendingIntent();p.kind=k;p.request=r;p.intent=i;p.flags=f;return p;}
 public static PendingIntent getActivity(Context c,int r,Intent i,int f){return make("activity",r,i,f);} public static PendingIntent getService(Context c,int r,Intent i,int f){return make("service",r,i,f);}
}
