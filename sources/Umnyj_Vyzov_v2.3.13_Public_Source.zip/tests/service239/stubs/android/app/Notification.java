package android.app;
import android.content.Context;
public class Notification {public PendingIntent content,action;public boolean ongoing;public String text;
 public static class BigTextStyle {public BigTextStyle bigText(String s){return this;}}
 public static class Builder {Notification n=new Notification();public Builder(Context c){} public Builder(Context c,String channel){}
 public Builder setSmallIcon(int x){return this;} public Builder setContentTitle(String x){return this;} public Builder setContentText(String x){n.text=x;return this;}
 public Builder setStyle(BigTextStyle x){return this;} public Builder setOngoing(boolean x){n.ongoing=x;return this;} public Builder setAutoCancel(boolean x){return this;}
 public Builder setOnlyAlertOnce(boolean x){return this;} public Builder setContentIntent(PendingIntent x){n.content=x;return this;}
 public Builder setProgress(int max,int p,boolean i){return this;} public Builder addAction(int x,String s,PendingIntent p){n.action=p;return this;} public Notification build(){return n;}}
}
