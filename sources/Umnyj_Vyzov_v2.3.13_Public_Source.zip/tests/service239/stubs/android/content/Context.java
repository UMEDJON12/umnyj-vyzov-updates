package android.content;
import android.app.NotificationManager;
public class Context {
 public static final String NOTIFICATION_SERVICE="notification";
 public final NotificationManager manager=new NotificationManager();
 public Intent started; public int starts; public boolean failStart;
 public Object getSystemService(String x){return manager;}
 public static int permissionResult=0; public int checkSelfPermission(String permission){return permissionResult;}
 public void startForegroundService(Intent i){startService(i);}
 public void startService(Intent i){if(failStart)throw new IllegalStateException(); started=i; starts++;}
}
