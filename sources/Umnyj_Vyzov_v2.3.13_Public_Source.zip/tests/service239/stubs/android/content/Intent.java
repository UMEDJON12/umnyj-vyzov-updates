package android.content;
import java.util.*;
public class Intent {
 public static final int FLAG_ACTIVITY_CLEAR_TOP=1,FLAG_ACTIVITY_SINGLE_TOP=2;
 public Class<?> target; public String action; public int flags; private final Map<String,Object> extras=new HashMap<>();
 public Intent(Context c,Class<?> t){target=t;}
 public Intent setAction(String a){action=a;return this;} public String getAction(){return action;}
 public Intent putExtra(String k,String v){extras.put(k,v);return this;} public Intent putExtra(String k,long v){extras.put(k,v);return this;}
 public String getStringExtra(String k){return (String)extras.get(k);} public long getLongExtra(String k,long d){Object v=extras.get(k);return v==null?d:(Long)v;}
 public Intent addFlags(int f){flags|=f;return this;}
}
