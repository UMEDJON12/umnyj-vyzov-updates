#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
OUT=$(mktemp -d /tmp/service239.XXXXXXXX)
cd "$ROOT"
python3 -c 'import pathlib,sys; print("\n".join(str(p) for p in pathlib.Path("tests/service239/stubs").rglob("*.java")))' > "$OUT/sources"
printf '%s\n' src/com/smartcall/ru/UpdateService.java src/com/smartcall/ru/UpdateProgress.java >> "$OUT/sources"
javac -encoding UTF-8 -d "$OUT" @"$OUT/sources"
java -cp "$OUT" com.smartcall.ru.ServiceTest
