package com.smartcall.ru;

import com.smartcall.ru.update.Downloader;
import com.smartcall.ru.update.Sha256;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Pure-JVM part of the export pipeline; MediaStore and installer need Android tests. */
public final class DownloadStoreTest {
    private static int count;
    private static void check(boolean b, String m) { count++; if (!b) throw new AssertionError(m); }
    private interface Run { void run() throws Exception; }
    private static void fails(StatusCode status, Run run) throws Exception {
        try { run.run(); throw new AssertionError("expected " + status); }
        catch (UpdateException e) { check(e.status() == status, "expected " + status + ", got " + e.status()); }
    }
    public static void main(String[] args) throws Exception {
        final byte[] data = "verified content".getBytes(StandardCharsets.UTF_8);
        final String hash = Sha256.ofBytes(data);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DownloadStore.copyChecked(new ByteArrayInputStream(data),out,data.length,hash,Downloader.NEVER_CANCELLED);
        check(Arrays.equals(data,out.toByteArray()),"copied bytes exactly");
        fails(StatusCode.HASH_MISMATCH, () -> DownloadStore.copyChecked(new ByteArrayInputStream(data),null,data.length,
                "0000000000000000000000000000000000000000000000000000000000000000",Downloader.NEVER_CANCELLED));
        fails(StatusCode.SIZE_MISMATCH, () -> DownloadStore.copyChecked(new ByteArrayInputStream(data),null,data.length+1,hash,Downloader.NEVER_CANCELLED));
        fails(StatusCode.SIZE_MISMATCH, () -> DownloadStore.copyChecked(new ByteArrayInputStream(data),null,data.length-1,hash,Downloader.NEVER_CANCELLED));
        fails(StatusCode.CANCELLED, () -> DownloadStore.copyChecked(new ByteArrayInputStream(data),null,data.length,hash,() -> true));
        check(UpdateProgressText.percent(0,0)==-1,"unknown total");
        check(UpdateProgressText.percent(0,100)==0,"start");
        check(UpdateProgressText.percent(25,100)==25,"quarter");
        check(UpdateProgressText.percent(100,100)==100,"complete");
        check(UpdateProgressText.percent(101,100)==100,"bounded");
        check(UpdateProgressText.progress(25,100).contains("осталось 75 Б"),"remaining is exact");
        check(UpdateProgressText.progress(5,0).contains("общий размер неизвестен"),"unknown total text");
        System.out.println("PASS: " + count + " copy/progress assertions (host only)");
    }
}
