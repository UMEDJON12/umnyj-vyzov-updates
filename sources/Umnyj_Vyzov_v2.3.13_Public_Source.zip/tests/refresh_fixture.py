#!/usr/bin/env python3
"""Refresh the signed-APK fixture used by the update-module tests.

Run after every rebuild of dist/SmartCall-2.3.7-signed.apk:
    python3 tests/refresh_fixture.py
"""
import hashlib
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'dist' / 'SmartCall-2.3.7-signed.apk'
DST = ROOT / 'tests' / 'update' / 'fixtures' / 'SmartCall-2.3.7-fixture.apk'
FIXTURES = ROOT / 'tests' / 'update' / 'com' / 'smartcall' / 'ru' / 'update' / 'test' / 'Fixtures.java'


def main():
    if not SRC.is_file():
        sys.exit(f'нет подписанного APK: {SRC}')
    shutil.copyfile(SRC, DST)
    data = DST.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    size = len(data)
    text = FIXTURES.read_text(encoding='utf-8')
    text, n1 = re.subn(r'FIXTURE_SHA256 =\s*\n\s*"[0-9a-f]{64}"',
                       f'FIXTURE_SHA256 =\n            "{sha}"', text, count=1)
    text, n2 = re.subn(r'FIXTURE_SIZE = \d+L', f'FIXTURE_SIZE = {size}L', text, count=1)
    if n1 != 1 or n2 != 1:
        sys.exit(f'не удалось обновить Fixtures.java (sha={n1}, size={n2})')
    FIXTURES.write_text(text, encoding='utf-8')
    print(f'fixture updated: size={size} sha256={sha}')


if __name__ == '__main__':
    main()
