from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'src/com/smartcall/ru'

class Hardware2312(unittest.TestCase):
    def test_policy_is_host_executable_and_debounced(self):
        with tempfile.TemporaryDirectory() as td:
            harness = Path(td)/'GateTest.java'
            harness.write_text("""package com.smartcall.ru;
public final class GateTest {
  static void check(boolean b, String m) { if (!b) throw new AssertionError(m); }
  public static void main(String[] args) {
    HardwareKeyGate g = new HardwareKeyGate();
    check(!g.allow(1,0,100),"no action without ringing");
    check(g.allow(1,1,100),"first physical volume-up");
    check(!g.allow(1,1,150),"bounce blocked");
    check(!g.allow(1,1,1599),"rapid double press blocked");
    check(g.allow(1,1,1700),"new deliberate attempt allowed");
    g.reset(); check(g.allow(1,1,1710),"reset on service rebind");
    check(g.allow(2,2,1720),"different key and action allowed");
    System.out.println("PASS hardware gate");
  }
}
""")
            subprocess.run(['javac', '-d', td, str(SRC/'HardwareKeyGate.java'), str(harness)], check=True)
            result=subprocess.run(['java', '-cp',td,'com.smartcall.ru.GateTest'], capture_output=True,text=True,check=True)
            self.assertIn('PASS hardware gate',result.stdout)

    def test_no_false_hardware_fallback(self):
        c=(SRC/'CallController.java').read_text()
        a=(SRC/'CallControlAccessibilityService.java').read_text()
        r=(SRC/'ScreenAndVolumeReceiver.java').read_text()
        self.assertIn('public static int hardwareCallState(Context context)',c)
        start=c.index('public static int hardwareCallState(')
        end=c.index('public static int keyActionForHardware(',start)
        snippet=c[start:end]
        self.assertNotIn('getRingtoneMask(',snippet)
        self.assertNotIn('VOLUME_CHANGED_ACTION',snippet)
        self.assertIn('SimCallMonitor.hardwareState(context)',snippet)
        self.assertIn('KeyEvent.ACTION_DOWN',a)
        self.assertIn('KeyEvent.ACTION_UP',a)
        self.assertIn('hardwareKeyUpCount++',a)
        self.assertIn('keyDuringCallCount++',a)
        self.assertIn('keyOutsideCallCount++',a)
        self.assertIn('isKeyguardLocked()',a)
        self.assertNotIn('handleHardwareButton(',r)
        self.assertNotIn('answerCall(',r)

    def test_offhook_verified(self):
        s=(SRC/'SmartCallFeatures.java').read_text()
        self.assertIn('SmartCallFeatures.phoneState(context) == 2',s)
        self.assertIn('OFFHOOK подтверждён TelephonyManager',s)
        self.assertIn('TelecomManager.acceptRingingCall',s)
        self.assertIn('CallNotificationListenerService.triggerCallNotificationAction(true)',s)
        self.assertIn('SmartCallFeatures.answerUi(context)',s)

if __name__=='__main__': unittest.main()
