package android.os;

import java.util.ArrayDeque;
import java.util.Queue;

/** Deterministic FIFO test double, not an Android event loop. */
public final class Looper {
    private static final Looper MAIN = new Looper();
    private final Queue<Runnable> queue = new ArrayDeque<>();
    private Looper() {}
    public static Looper getMainLooper() { return MAIN; }
    void post(Runnable task) { queue.add(task); }
    public int pending() { return queue.size(); }
    public void drain() {
        while (!queue.isEmpty()) queue.remove().run();
    }
}
