package com.smartcall.ru;

import android.os.Looper;
import java.util.ArrayList;
import java.util.List;
import static com.smartcall.ru.UpdateProgress.Phase;
import static com.smartcall.ru.UpdateProgress.Snapshot;

public final class ProgressTest {
    private static int checks;
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static void eq(Object actual, Object expected) {
        check(expected.equals(actual), "expected " + expected + ", got " + actual);
    }
    private static void snapshot(Snapshot s, Phase phase, String version, long got, long size) {
        eq(s.phase, phase); eq(s.version, version); eq(s.downloaded, got); eq(s.total, size);
    }
    public static void main(String[] args) {
        Looper main = Looper.getMainLooper();
        List<Snapshot> observed = new ArrayList<>();
        UpdateProgress.Listener listener = observed::add;
        UpdateProgress.listen(listener);
        snapshot(observed.get(0), Phase.IDLE, "", 0, 0);
        check(UpdateProgress.begin("v1"), "first begin rejected");
        snapshot(UpdateProgress.current(), Phase.CONNECTING, "v1", 0, 0);
        eq(observed.size(), 1); eq(main.pending(), 1);
        check(!UpdateProgress.begin("other"), "second begin accepted while connecting");
        check(!UpdateProgress.publishIfIdle(Phase.ERROR, "other", "permission denied", 0, 0), "late permission denial must not replace running progress");
        snapshot(UpdateProgress.current(), Phase.CONNECTING, "v1", 0, 0);
        main.drain(); eq(observed.size(), 2);
        snapshot(observed.get(1), Phase.CONNECTING, "v1", 0, 0);
        eq(observed.get(1).message, "Подключение…");
        UpdateProgress.publish(Phase.DOWNLOADING, "v1", "", 256, 1024);
        snapshot(UpdateProgress.current(), Phase.DOWNLOADING, "v1", 256, 1024);
        eq(observed.size(), 2); main.drain();
        snapshot(observed.get(2), Phase.DOWNLOADING, "v1", 256, 1024);
        check(!UpdateProgress.begin("other"), "second begin accepted while downloading");
        UpdateProgress.publish(Phase.VERIFYING, "v1", "", 1024, 1024);
        check(!UpdateProgress.begin("other"), "second begin accepted while verifying");
        UpdateProgress.publish(Phase.SAVING, "v1", "", 1024, 1024);
        check(!UpdateProgress.begin("other"), "second begin accepted while saving");
        main.drain(); snapshot(observed.get(observed.size()-1), Phase.SAVING, "v1", 1024, 1024);
        UpdateProgress.publish(Phase.CANCELLED, "v1", "cancelled", 1024, 1024);
        main.drain(); snapshot(observed.get(observed.size()-1), Phase.CANCELLED, "v1", 1024, 1024);
        check(UpdateProgress.begin("v2"), "begin after cancel rejected");
        long oldEpoch = UpdateProgress.epoch();
        UpdateProgress.publish(Phase.DOWNLOADING, "v2", "", 512, 2048);
        UpdateProgress.publish(Phase.READY, "v2", "ready", 2048, 2048);
        check(UpdateProgress.begin("v3"), "begin after final rejected");
        check(!UpdateProgress.publishFor(oldEpoch, Phase.ERROR, "v2", "late old worker", 5, 6), "stale worker must not overwrite new operation");
        // No drain between old callbacks and new operation: old snapshots must not be delivered.
        int before = observed.size();
        eq(main.pending(), 4);
        main.drain(); eq(observed.size(), before + 1);
        snapshot(observed.get(before), Phase.CONNECTING, "v3", 0, 0);
        snapshot(UpdateProgress.current(), Phase.CONNECTING, "v3", 0, 0);
        UpdateProgress.publish(Phase.ERROR, "v3", "failed", 0, 0);
        main.drain(); check(UpdateProgress.begin("v4"), "begin after error rejected");
        main.drain();
        // Duplicate listen immediately replays current twice, but registers only once.
        int n = observed.size(); UpdateProgress.listen(listener); UpdateProgress.listen(listener);
        eq(observed.size(), n + 2);
        UpdateProgress.publish(Phase.DOWNLOADING, "v4", "", 123, 0);
        n = observed.size(); main.drain(); eq(observed.size(), n + 1);
        snapshot(observed.get(n), Phase.DOWNLOADING, "v4", 123, 0);
        UpdateProgress.publish(Phase.DOWNLOADING, "v4", "", 456, 0);
        UpdateProgress.unlisten(listener); UpdateProgress.unlisten(listener);
        n = observed.size(); main.drain(); eq(observed.size(), n);
        UpdateProgress.listen(listener); eq(observed.size(), n + 1);
        snapshot(observed.get(n), Phase.DOWNLOADING, "v4", 456, 0);
        UpdateProgress.unlisten(listener);
        eq(UpdateProgressText.percent(256, 1024), 25);
        eq(UpdateProgressText.progress(256, 1024), "25% · получено 256 Б из 1,0 КБ · осталось 768 Б".replace("1,0", "1.0"));
        eq(UpdateProgressText.percent(123, 0), -1);
        eq(UpdateProgressText.percent(123, -1), -1);
        eq(UpdateProgressText.progress(123, 0), "Получено 123 Б; общий размер неизвестен");
        eq(UpdateProgressText.progress(123, -1), "Получено 123 Б; общий размер неизвестен");
        eq(UpdateProgressText.percent(0, 1024), 0);
        eq(UpdateProgressText.percent(2048, 1024), 100);
        eq(UpdateProgressText.bytes(1048576), "1.00 МБ");
        UpdateProgress.publish(Phase.ERROR, null, null, -1, -1);
        snapshot(UpdateProgress.current(), Phase.ERROR, "", 0, 0);
        eq(UpdateProgress.current().message, ""); main.drain();
        check(UpdateProgress.begin("v5"), "begin after failure");
        long v5 = UpdateProgress.epoch();
        check(UpdateProgress.publishFor(v5, Phase.RECHECK, "v5", "changed", 0, 0), "release change shown");
        check(UpdateProgress.begin("v6"), "new operation after recheck state");
        check(!UpdateProgress.publishFor(v5, Phase.READY, "v5", "stale", 0, 0), "old worker cannot report ready");
        eq(UpdateProgress.current().version, "v6");
        System.out.println("PASS: " + checks + " checks");
    }
}
