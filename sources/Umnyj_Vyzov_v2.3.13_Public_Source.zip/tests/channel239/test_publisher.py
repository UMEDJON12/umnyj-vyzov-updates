import copy
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('publisher239', ROOT / 'channel/publish_stable.py')
pub = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pub)
CERT = pub.EXPECTED_CERT_SHA256
BADGING = "package: name='com.smartcall.ru' versionCode='30' versionName='2.3.9'\nsdkVersion:'24'\n"
TREE = 'E: manifest (line=2)\n  E: application (line=4)\n    A: android:label(0x01010001)="SmartCall"\n'
SIGN = ('Verifies\nVerified using v1 scheme (JAR signing): true\n'
        'Verified using v2 scheme (APK Signature Scheme v2): true\n'
        'Number of signers: 1\nSigner #1 certificate SHA-256 digest: ' + CERT + '\n')


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.event = self.root / 'event.json'
        self.release = {'tag_name': 'v2.3.9', 'draft': False, 'prerelease': False, 'body': 'ok', 'published_at': '2026-11-11T00:00:00Z', 'assets': [{'name': 'SmartCall.apk', 'size': 3, 'state': 'uploaded', 'browser_download_url': 'https://github.com/UMEDJON12/umnyj-vyzov-updates/releases/download/v2.3.9/SmartCall.apk'}]}
        self.event.write_text(json.dumps({'release': self.release}))
        self.badging, self.tree, self.sign = BADGING, TREE, SIGN
        self.releases = None
        self.latest_release = None
        self.patches = [patch.object(pub, 'release_from_api', side_effect=self.api), patch.object(pub, 'download', side_effect=self.download), patch.object(pub, 'run_tool', side_effect=self.tool)]
        for p in self.patches:
            p.start()
            self.addCleanup(p.stop)

    def api(self, owner, repo, tag):
        if tag is None:
            if self.latest_release is not None:
                return copy.deepcopy(self.latest_release)
            return copy.deepcopy(self.release)
        return copy.deepcopy(self.releases.pop(0) if self.releases is not None else self.release)

    def download(self, url, dest, size):
        Path(dest).write_bytes(b'apk')
        return 3

    def tool(self, args):
        if args[1:3] == ['dump', 'badging']:
            return self.badging
        if args[1:3] == ['dump', 'xmltree']:
            return self.tree
        self.assertIn('23', args)
        return self.sign

    def run_main(self):
        with patch.object(sys, 'argv', ['publisher', '--event', str(self.event), '--owner', pub.OWNER, '--repo', pub.REPO, '--output', str(self.root)]):
            return pub.main()

    def test_bootstrap_and_repeat(self):
        self.assertEqual(self.run_main(), 0)
        stable = json.loads((self.root / 'updates/stable.json').read_text())
        self.assertEqual(stable['minSdk'], 24)
        self.assertEqual(self.run_main(), 0)

    def test_event_and_fresh_booleans(self):
        for key in ('draft', 'prerelease'):
            for value in (None, 0, '', True, 'false'):
                with self.subTest(key=key, value=value):
                    original = self.release[key]
                    self.release[key] = value
                    with self.assertRaises(pub.Rejected): self.run_main()
                    self.release[key] = original
                    event = copy.deepcopy(self.release)
                    event[key] = value
                    self.event.write_text(json.dumps({'release': event}))
                    with self.assertRaises(pub.Rejected): self.run_main()
                    self.event.write_text(json.dumps({'release': self.release}))

    def test_signatures(self):
        variants = [SIGN.replace('v1 scheme (JAR signing): true', 'v1 scheme (JAR signing): false'), SIGN.replace('v2 scheme (APK Signature Scheme v2): true', 'v2 scheme (APK Signature Scheme v2): false'), SIGN.replace('Number of signers: 1', 'Number of signers: 2'), SIGN + 'Signer #2 certificate SHA-256 digest: ' + CERT + '\n', SIGN.replace(CERT, '0' * 64), SIGN.replace('Number of signers: 1\n', '')]
        for value in variants:
            with self.subTest(value=value):
                self.sign = value
                with self.assertRaises(pub.Rejected): self.run_main()

    def test_identity(self):
        for badging in [BADGING.replace("'24'", "'25'"), BADGING.replace("'24'", "'0'"), BADGING.replace("2.3.9", "bad/name"), BADGING.replace('com.smartcall.ru', 'evil.app'), BADGING.replace('30', '2147483648'), BADGING.replace("sdkVersion:'24'\n", '')]:
            self.badging = badging
            with self.subTest(badging=badging), self.assertRaises(pub.Rejected): self.run_main()
        self.badging = BADGING
        self.tree = TREE + '    A: android:testOnly(0x01010272)=(type 0x12)0xffffffff\n'
        with self.assertRaises(pub.Rejected): self.run_main()
        self.tree = TREE + '    A: android:testOnly(0x01010272)=(type 0x12)0x0\n'
        self.assertEqual(self.run_main(), 0)

    def test_asset_contract(self):
        original = copy.deepcopy(self.release['assets'][0])
        for key, value in [('state', 'new'), ('state', None), ('size', 0), ('size', True), ('size', pub.MAX_APK_BYTES + 1), ('name', '../x.apk'), ('name', 'x.APK'), ('browser_download_url', 'https://evil.test/a.apk')]:
            self.release['assets'][0] = dict(original, **{key: value})
            with self.subTest(key=key, value=value), self.assertRaises(pub.Rejected): self.run_main()
        self.release['assets'] = [original, original]
        with self.assertRaises(pub.Rejected): self.run_main()

    def test_notes_utf16(self):
        notes = pub.clean_notes('a' * 3999 + '😀' + 'X\x01')
        self.assertLessEqual(len(notes.encode('utf-16-le')) // 2, 4000)
        self.assertEqual(notes, 'a' * 3999)
        self.assertEqual(pub.clean_notes('Hi\x00\n😀'), 'Hi\n😀')

    def test_corrupt_prior_rollback_conflicts(self):
        path = self.root / 'updates/stable.json'
        path.parent.mkdir()
        for data in ('{}', '{', '{"versionCode":true}', '{"versionCode":0}'):
            path.write_text(data)
            with self.subTest(data=data), self.assertRaises(pub.Rejected): self.run_main()
        path.write_text('{"versionCode":31}')
        with self.assertRaises(pub.Rejected): self.run_main()
        path.unlink()
        self.run_main()
        stable = json.loads(path.read_text())
        for key, value in [('sha256', '0'*64), ('tagName', 'other'), ('apkFileName', 'other.apk'), ('versionName', 'other'), ('apkUrl', 'other'), ('sizeBytes', 1)]:
            altered = dict(stable, **{key:value})
            path.write_text(json.dumps(altered))
            with self.subTest(key=key), self.assertRaises(pub.Rejected): self.run_main()

    def test_release_race(self):
        changed = copy.deepcopy(self.release)
        changed['assets'][0]['size'] = 4
        self.releases = [self.release, changed]
        with self.assertRaises(pub.Rejected): self.run_main()
        self.assertFalse((self.root / 'updates/stable.json').exists())

    def test_download_count_may_change(self):
        first = copy.deepcopy(self.release)
        first['assets'][0]['download_count'] = 3
        second = copy.deepcopy(first)
        second['assets'][0]['download_count'] = 4
        self.releases = [first, second]
        self.assertEqual(self.run_main(), 0)

    def test_prior_race(self):
        original = self.download
        def change_previous(url, dest, size):
            result = original(url, dest, size)
            path = self.root / 'updates/stable.json'
            path.parent.mkdir(exist_ok=True)
            path.write_text('{"versionCode":31}')
            return result
        with patch.object(pub, 'download', side_effect=change_previous):
            with self.assertRaises(pub.Rejected): self.run_main()

    def test_size_boundaries(self):
        asset = self.release['assets'][0]
        asset['size'] = pub.MAX_APK_BYTES
        self.assertEqual(pub.pick_apk(self.release)['size'], pub.MAX_APK_BYTES)
        asset['size'] += 1
        with self.assertRaises(pub.Rejected): pub.pick_apk(self.release)

    def test_redirect_url_policy(self):
        for url in ('http://github.com/x', 'https://evil.com/x', 'https://github.com.evil.com/x', 'https://user@github.com/x', 'https://github.com/x#fragment', 'https://github.com:444/x'):
            with self.subTest(url=url), self.assertRaises(pub.Rejected):
                pub.check_transport_url(url, True)
        for url in ('https://github.com/x', 'https://objects.githubusercontent.com/x', 'https://release-assets.githubusercontent.com/x'):
            pub.check_transport_url(url, True)
        with self.assertRaises(pub.Rejected):
            pub.SafeRedirect(True).redirect_request(None, None, 302, '', {}, 'https://evil.com')

    def test_tag_invalid(self):
        self.event.write_text(json.dumps({'release': dict(self.release, tag_name='v1; touch /tmp/x')}))
        with self.assertRaises(pub.Rejected): self.run_main()

    def test_workflow_no_script_interpolation(self):
        workflow = (ROOT / 'channel/publish-stable.yml').read_text()
        self.assertNotIn('stable ${{', workflow)
        self.assertIn('stable $RELEASE_TAG', workflow)


if __name__ == '__main__':
    unittest.main()
