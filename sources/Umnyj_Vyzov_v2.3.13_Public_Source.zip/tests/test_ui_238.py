"""Static presentation regressions; not a substitute for screen-reader testing."""
from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / 'src/com/smartcall/ru/MainActivity.java'
FEATURES = ROOT / 'src/com/smartcall/ru/SmartCallFeatures.java'
CONTROLLER = ROOT / 'src/com/smartcall/ru/CallController.java'


class UI238Tests(unittest.TestCase):
    def test_profiles_are_reachable_without_changing_existing_keys(self):
        source = MAIN.read_text(encoding='utf-8')
        block = source[source.index('private View buildSpeechSection()'):source.index('private View buildSettingsSection()')]
        self.assertIn('panel.setVisibility(View.GONE)', block)
        self.assertIn('details[j].setVisibility(selected ? View.VISIBLE : View.GONE)', block)
        self.assertIn('CALL_PROFILES[i]', block)
        self.assertIn('MSG_PROFILES[i]', block)
        for name in ('call_enabled_', 'msg_enabled_', 'msg_read_text_'):
            self.assertIn(name, block)
        for method in ('openCallEngineDialog', 'openCallVoicePicker', 'openCallRateDialog',
                       'openCallRepeatDialog', 'openCallDelayDialog', 'openCallTestDialog',
                       'openMsgEngineDialog', 'openMsgVoicePicker', 'openMsgRateDialog',
                       'openMsgLockDialog', 'openMsgTestDialog'):
            self.assertIn(method, block)

    def test_home_summary_does_not_append_boolean_directly(self):
        source = MAIN.read_text(encoding='utf-8')
        block = source[source.index('private String buildOverview()'):source.index('private boolean profileOn')]
        self.assertNotRegex(block, r'\.append\(profileOn\(')
        self.assertIn('включена', source)
        self.assertIn('выключена', source)

    def test_voice_selection_retains_engine_identifier(self):
        source = FEATURES.read_text(encoding='utf-8')
        self.assertIn('VoiceLabels.label(locale, ordinal, voice.isNetworkConnectionRequired())', source)
        self.assertIn('((Voice) arrayList.get(i - 1)).getName()', source)
        self.assertIn('putString(voiceKeyFor(prefix, str), name)', source)

    def test_diagnostic_version_comes_from_package(self):
        source = CONTROLLER.read_text(encoding='utf-8')
        self.assertIn('append(AppVersion.name(context))', source)
        self.assertNotIn('ДИАГНОСТИКА «УМНЫЙ ВЫЗОВ» v2.3.6', source)

    def test_permission_buttons_are_hidden_when_granted(self):
        source = MAIN.read_text(encoding='utf-8')
        self.assertIn('button.setVisibility(granted[index] ? View.GONE : View.VISIBLE)', source)
        self.assertIn('refreshPermissionActions();', source)


if __name__ == '__main__':
    unittest.main()
