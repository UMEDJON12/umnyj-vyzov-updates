"""Differential host test: actual Java refresh body vs project DEX-generator IR.

The Java Android classes are stubs; no ART/device execution or real notifications.
"""
import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from test_recovery import method, SRC

PROJECT = Path(__file__).resolve().parent / 'reference' / 'original-2.3.6'
sys.path.insert(0, str(PROJECT))
spec = importlib.util.spec_from_file_location('generator_tests_for_diff', PROJECT / 'test_regressions.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)


def run_ir(extras, actions):
    """Execute the original working generator's refreshCallStatus instruction tuples."""
    code = original.METHODS['refreshCallStatus']['insns']
    labels = {x[1]: i for i, x in enumerate(code) if x[0] == 'label'}
    notification = {'category':'call', 'extras':extras if extras is not None else 0,
                    'actions':actions if actions is not None else 0}
    item = {'pkg':'external.pkg', 'notification':notification}
    fields = {'instance':1, 'voipIncoming':0, 'voipOngoing':0}
    r = [0]*11; pc=0; result=0
    for _ in range(3000):
        ins=code[pc]; pc+=1; op=ins[0]; v=ins[1:]
        if op == 'label': continue
        if op.startswith('const'): r[v[0]]=v[1]
        elif op.startswith('sget'): r[v[0]]=fields.get(v[1][1],0)
        elif op.startswith('sput'): fields[v[1][1]]=r[v[0]]
        elif op.startswith('iget'): r[v[0]]=r[v[1]].get(v[2][1],0)
        elif op=='array-length': r[v[0]]=len(r[v[1]])
        elif op.startswith('aget'): r[v[0]]=r[v[1]][r[v[2]]]
        elif op.startswith('move-result'): r[v[0]]=result
        elif op=='add-int/lit8': r[v[0]]=r[v[1]]+v[2]
        elif op.startswith('goto'): pc=labels[v[0]]
        elif op.startswith('if-'):
            kind=op[3:]; a=r[v[0]]
            if kind.endswith('z'): b=0; label=v[1]; kind=kind[:-1]
            else: b=r[v[1]]; label=v[2]
            if {'eq':lambda:a==b,'ne':lambda:a!=b,'lt':lambda:a<b,'le':lambda:a<=b,'gt':lambda:a>b,'ge':lambda:a>=b}[kind](): pc=labels[label]
        elif op.startswith('invoke'):
            name=v[1][1]; argv=[r[x] for x in v[0]]; receiver=argv[0]
            if name=='getActiveNotifications': result=[item]
            elif name=='getPackageName': result=receiver['pkg']
            elif name=='getNotification': result=receiver['notification']
            elif name=='equals': result=int(receiver==argv[1])
            elif name=='getInt': result=receiver.get(argv[1],argv[2])
            elif name=='containsKey': result=int(argv[1] in receiver)
            elif name=='toString': result=str(receiver)
            elif name=='isPositiveText': result=int(argv[0]=='positive')
            elif name=='isNegativeText': result=int(argv[0]=='negative')
            else: raise AssertionError(name)
        elif op=='return-void': return bool(fields['voipIncoming']),bool(fields['voipOngoing'])
        else: raise AssertionError(op)
    raise AssertionError('nonterminating generator IR')


class NotificationDifferential(unittest.TestCase):
 def test_exhaustive_notification_paths(self):
    source=(SRC/'CallNotificationListenerService.java').read_text()
    body=method(source,'refreshCallStatus')
    harness=r'''
import java.util.*;
class CallController { static boolean voipIncoming,voipOngoing; }
class Bundle extends HashMap<String,Object> {
 int getInt(String k,int def) { Object x=get(k); return x instanceof Integer ? (Integer)x : def; }
}
class Notification { String category; Bundle extras; Action[] actions; static class Action { CharSequence title; Action(String t){title=t;} } }
class StatusBarNotification { String pkg; Notification n; String getPackageName(){return pkg;} Notification getNotification(){return n;} }
public class NTest {
 static NTest instance; StatusBarNotification[] active;
 StatusBarNotification[] getActiveNotifications(){return active;}
 static boolean isPositiveText(String s){return s.equals("positive");}
 static boolean isNegativeText(String s){return s.equals("negative");}
 static void refreshCallStatus(){ BODY }
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args) {
  Scanner sc=new Scanner(System.in); int n=0;
  while(sc.hasNextInt()) {
   int type=sc.nextInt(), exists=sc.nextInt(), bits=sc.nextInt(), mask=sc.nextInt(), ei=sc.nextInt(), eo=sc.nextInt();
   Notification notif=new Notification(); notif.category="call";
   if(exists==1){ notif.extras=new Bundle(); notif.extras.put("android.callType",type);
    if((bits&1)!=0)notif.extras.put("android.answerIntent",null);
    if((bits&2)!=0)notif.extras.put("android.declineIntent",null);
    if((bits&4)!=0)notif.extras.put("android.hangUpIntent",null);
   }
   if(mask!=0){ ArrayList<Notification.Action> a=new ArrayList<>();
    if((mask&1)!=0)a.add(null); if((mask&2)!=0)a.add(new Notification.Action(null));
    if((mask&4)!=0)a.add(new Notification.Action("positive")); if((mask&8)!=0)a.add(new Notification.Action("negative"));
    notif.actions=a.toArray(new Notification.Action[0]);
   }
   StatusBarNotification sbn=new StatusBarNotification(); sbn.pkg="external.pkg"; sbn.n=notif;
   instance=new NTest(); instance.active=new StatusBarNotification[]{sbn};
   CallController.voipIncoming=true; CallController.voipOngoing=true; refreshCallStatus();
   check(CallController.voipIncoming==(ei!=0)&&CallController.voipOngoing==(eo!=0), "case "+type+" "+exists+" "+bits+" "+mask);
   n++;
  }
  System.out.println("PASS "+n+" IR-differential notification cases");
 }
}
'''.replace('BODY',body).replace('CallNotificationListenerService service = instance;', 'NTest service = instance;')
    inputs=[]
    for typ in (-1,0,1,2,3,4):
     for exists in (0,1):
      for bits in range(8):
       for mask in range(16):
        extras=None if not exists else {'android.callType':typ, **{k:None for bit,k in [(1,'android.answerIntent'),(2,'android.declineIntent'),(4,'android.hangUpIntent')] if bits&bit}}
        actions=None if mask==0 else ([0] if mask&1 else [])+([{'title':0}] if mask&2 else [])+([{'title':'positive'}] if mask&4 else [])+([{'title':'negative'}] if mask&8 else [])
        inc,ongoing=run_ir(extras,actions)
        inputs.append(f'{typ} {exists} {bits} {mask} {int(inc)} {int(ongoing)}')
    with tempfile.TemporaryDirectory(prefix='smartcall-notif-') as td:
     path=Path(td)/'NTest.java'; path.write_text(harness)
     subprocess.run(['javac','-d',td,str(path)],check=True)
     p=subprocess.run(['java','-cp',td,'NTest'],input='\n'.join(inputs),capture_output=True,text=True,check=True)
     self.assertIn('PASS 1536 IR-differential notification cases',p.stdout)

if __name__=='__main__': unittest.main(verbosity=2)
