"""Bounded static checks for wiring; not a substitute for Android lifecycle tests."""
import hashlib
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src/com/smartcall/ru'
BASELINE = {
    'CallController.java': '5e9b3a29d9aec4644f47d6a0f9153ab6883fdfe0474e93ff773fd671f4e2eaab',
    'CallControlAccessibilityService.java': 'dd0ba4ed1ff213583dfd8d7f71a49c7647cf8e6866b8525b8cee4b03fad69c2f',
    'CallNotificationListenerService.java': 'df036b07c8b25c3389ec994bc391aa9d27ddeca0aff820208122b725e0f1f49f',
    'ProximitySensorListener.java': '7b04ed501897d006898bc7d820e85240ccf46f84acb7c4db509b660bbe6ffe9e',
    'ScreenAndVolumeReceiver.java': '568876f60c34a66bab71aacbee8a8056a7c3995e2a661815247de12235f46cfd',
    'AnswerFlow.java': '0ab0ec0c7546217b455c5a89997ef012a8ef287f14d94c6f6e5159b39952a479',
    'SettingsMigration.java': 'c05c54e6b691754eba7b673d35888896a87043b4ceeac4d3f3da38cb6730f738',
}

class RouteChecks(unittest.TestCase):
    def test_legacy_call_and_migration_sources_match_238(self):
        for name, expected in BASELINE.items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((SRC / name).read_bytes()).hexdigest(), expected)

    def test_speech_logic_only_adds_label_refresh(self):
        speech = (SRC / 'SmartCallFeatures.java').read_text()
        added = ('        // Refresh compact visible and accessibility labels after selecting a voice.\n'
                 '        if (activity instanceof MainActivity) ((MainActivity) activity).refreshProfileLabels();\n')
        self.assertEqual(speech.count(added), 1)
        original = speech.replace(added, '')
        self.assertEqual(hashlib.sha256(original.encode()).hexdigest(),
                         '372f511dbe329c6f53eca90a285706262932eaa6456e799fa4eb4d8cec343ff2')

    def test_signed_version_and_manifest_components(self):
        build = (ROOT / 'build_apk.py').read_text()
        self.assertIn("VERSION_NAME = '2.3.9'", build)
        self.assertIn('VERSION_CODE = 32', build)
        manifest = (ROOT / 'build/axml_arsc_gen.py').read_text()
        for required in ('REQUEST_INSTALL_PACKAGES', 'WRITE_EXTERNAL_STORAGE', 'UpdateProgressActivity',
                         'UpdateService', 'UpdateInstallProvider', 'grantUriPermissions'):
            self.assertIn(required, manifest)

    def test_silent_auto_and_manual_splits(self):
        controller = (SRC / 'UpdatesController.java').read_text()
        policy = (SRC / 'UpdateNoticePolicy.java').read_text()
        self.assertIn('return manual;', policy)
        self.assertIn('if (manual) showStatus(activity', controller)
        self.assertIn('if (!UpdateNoticePolicy.shouldShow(manual, status))', controller)
        self.assertIn('if (!e.shouldOffer(m, manual))', controller)
        self.assertIn('busy.set(false);', controller)
        self.assertIn('busy.compareAndSet(false, true)', controller)
        self.assertIn('Не удалось проверить обновления:', controller)

    def test_progress_and_installer_routes(self):
        service = (SRC / 'UpdateService.java').read_text()
        activity = (SRC / 'UpdateProgressActivity.java').read_text()
        controller = (SRC / 'UpdatesController.java').read_text()
        main = (SRC / 'MainActivity.java').read_text()
        provider = (SRC / 'UpdateInstallProvider.java').read_text()
        self.assertIn('UpdateProgressActivity.startDownload(activity, m)', controller)
        self.assertIn('UpdateProgressActivity.openIntent(this)', service)
        self.assertIn('setContentIntent(openProgressIntent())', service)
        self.assertIn('DownloadStore.export(this, verifiedFile, d', service)
        self.assertIn('DownloadStore.snapshotForInstall', controller)
        self.assertIn('InstallVersionPolicy.status(', controller)
        self.assertIn('e.state().knownVersionCode(), record.versionCode', controller)
        self.assertIn('canRequestPackageInstalls()', controller)
        self.assertIn('FLAG_GRANT_READ_URI_PERMISSION', controller)
        self.assertIn('setClipData(', controller)
        install = controller[controller.index('public static void installDownloaded'):]
        self.assertNotIn('.delete(', install, 'install or its cancellation must not delete the exported APK')
        self.assertIn('postponeDownloaded', activity)
        self.assertIn('OpenableColumns.DISPLAY_NAME', provider)
        self.assertIn('OpenableColumns.SIZE', provider)
        self.assertIn('onNewIntent(Intent intent)', main)
        self.assertIn('onInstallPermissionResult(this, requestCode)', main)
        self.assertIn('onInstallPermissionResult(this, requestCode)', activity)
        self.assertIn('ACCESSIBILITY_LIVE_REGION_NONE', activity)
        self.assertIn('UpdateProgressText.progress(s.downloaded, s.total)', activity)
        self.assertNotIn('Обновление установлено', service)

if __name__ == '__main__':
    unittest.main()
