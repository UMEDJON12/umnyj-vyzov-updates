#!/usr/bin/env python3
"""Build an unsigned review artifact or an update signed with the original key."""
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization

from apk_signer import build_aligned_zip_sections, package_and_sign_apk
from axml_arsc_gen import (
    build_manifest_axml, build_accessibility_config_axml, build_resources_arsc,
)
from build_dex import build_classes_dex
from build_features_dex import update_features_dex_file

ROOT = Path(__file__).resolve().parent
EXPECTED_CERT_SHA256 = "baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01"
VERSION_NAME = "2.3.6"
VERSION_CODE = 29  # Update over 2.3.5 (28) and 2.3.0 (23), same package and signing certificate.


def check_identity(key_path, cert_path):
    cert_data = Path(cert_path).read_bytes()
    cert = (x509.load_pem_x509_certificate(cert_data) if b"-----BEGIN" in cert_data
            else x509.load_der_x509_certificate(cert_data))
    if cert.fingerprint(hashes.SHA256()).hex() != EXPECTED_CERT_SHA256:
        raise ValueError("Сертификат отличается от текущего APK. Установка поверх невозможна.")
    key_raw = Path(key_path).read_bytes()
    if b"-----BEGIN" in key_raw:
        key_raw = key_raw[key_raw.index(b"-----BEGIN"):]
    key = serialization.load_pem_private_key(key_raw, password=None)
    public_format = (serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    if key.public_key().public_bytes(*public_format) != cert.public_key().public_bytes(*public_format):
        raise ValueError("Закрытый ключ не соответствует сертификату текущего APK.")
    return cert


def ensure_features_dex(force_rebuild=False):
    dex_file = ROOT / "assets/features.dex"
    meta_file = ROOT / "assets/features-build.json"
    needs_rebuild = force_rebuild or not dex_file.exists() or not meta_file.exists()
    if not needs_rebuild:
        try:
            module = json.loads(meta_file.read_text(encoding="utf-8"))
            for relative, expected in module.get("sources", {}).items():
                if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != expected:
                    needs_rebuild = True
                    break
            if hashlib.sha256(dex_file.read_bytes()).hexdigest() != module.get("dex_sha256"):
                needs_rebuild = True
        except Exception:
            needs_rebuild = True
    if needs_rebuild and not force_rebuild:
        raise RuntimeError(
            "features.dex или его метаданные не соответствуют Java-исходникам. "
            "Автономный генератор НЕ компилирует Java-логику; сначала соберите "
            "модуль с помощью compile_features.py и Android SDK."
        )
    if force_rebuild:
        raise RuntimeError(
            "Автономная пересборка features.dex отключена: она не компилирует "
            "Java-логику и может незаметно потерять изменения. Используйте compile_features.py."
        )
    return dex_file.read_bytes()


def build_entries(version_code=VERSION_CODE, version_name=VERSION_NAME, rebuild_features=False):
    features_bytes = ensure_features_dex(force_rebuild=rebuild_features)
    return [
        ("AndroidManifest.xml", build_manifest_axml(version_code=version_code, version_name=version_name), True),
        ("classes.dex", build_classes_dex(), False),
        ("classes2.dex", features_bytes, False),
        ("res/drawable/ic_launcher.png", (ROOT / "assets/ic_launcher.png").read_bytes(), True),
        ("res/xml/accessibility_config.xml", build_accessibility_config_axml(), True),
        ("resources.arsc", build_resources_arsc(), False),
    ]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--unsigned", action="store_true", help="Неустанавливаемый артефакт для проверки")
    parser.add_argument("--key", type=Path, help="Исходный закрытый ключ в PEM (без пароля)")
    parser.add_argument("--cert", type=Path, default=ROOT / "previous_signing_certificate.pem")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--version-code", type=int, default=VERSION_CODE, help="Код версии (versionCode)")
    parser.add_argument("--version-name", type=str, default=VERSION_NAME, help="Имя версии (versionName)")
    parser.add_argument("--rebuild-features", action="store_true", help="Принудительно пересобрать features.dex из build_features_dex.py")
    args = parser.parse_args()
    if args.unsigned and args.key:
        parser.error("--unsigned и --key нельзя использовать одновременно")
    if not args.unsigned and not args.key:
        parser.error("Нужен исходный закрытый ключ --key. Для проверки доступен --unsigned.")
    cert = check_identity(args.key, args.cert) if not args.unsigned else None
    entries = build_entries(
        version_code=args.version_code,
        version_name=args.version_name,
        rebuild_features=args.rebuild_features,
    )
    entry_map = dict((name, data) for name, data, _ in entries)
    with tempfile.TemporaryDirectory() as temp_dir:
        temp = Path(temp_dir)
        dex1_path = temp / "classes.dex"
        dex2_path = temp / "classes2.dex"
        dex1_path.write_bytes(entry_map["classes.dex"])
        dex2_path.write_bytes(entry_map["classes2.dex"])
        subprocess.run([sys.executable, str(ROOT / "verify_dex.py"), str(dex1_path)], check=True)
        subprocess.run([sys.executable, str(ROOT / "verify_dex.py"), str(dex2_path)], check=True)
        result = temp / "release.apk"
        if args.unsigned:
            contents, cd, eocd = build_aligned_zip_sections(entries)
            result.write_bytes(contents + cd + eocd)
        else:
            cert_pem, cert_der = temp / "cert.pem", temp / "cert.der"
            cert_pem.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
            cert_der.write_bytes(cert.public_bytes(serialization.Encoding.DER))
            package_and_sign_apk(entries, str(args.key), str(cert_pem), str(cert_der), str(result))
        subprocess.run([sys.executable, str(ROOT / "verify_apk_links.py"), str(result)], check=True)
        suffix = "-unsigned" if args.unsigned else ""
        output = args.output or ROOT / "dist" / f"Umnyj_Vyzov_v{args.version_name}{suffix}.apk"
        if args.unsigned and "unsigned" not in output.name.lower():
            parser.error("Неподписанный файл должен содержать unsigned в имени")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(result.read_bytes())
        print(f"Built {output.name}; versionCode={args.version_code}; SHA256={hashlib.sha256(output.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
