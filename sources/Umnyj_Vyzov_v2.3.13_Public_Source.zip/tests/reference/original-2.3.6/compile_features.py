#!/usr/bin/env python3
"""Rebuild assets/features.dex from Java sources (Android SDK + JDK/ECJ)."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile
ROOT = Path(__file__).resolve().parent

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--android-jar', default=os.environ.get('ANDROID_JAR'))
    p.add_argument('--d8-jar', default=os.environ.get('D8_JAR'))
    p.add_argument('--ecj-jar', default=os.environ.get('ECJ_JAR'))
    a = p.parse_args()
    if not a.android_jar or not a.d8_jar:
        p.error('Set --android-jar and --d8-jar (Android SDK API35+ / build-tools).')
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        classes = tmp / 'classes'; classes.mkdir()
        sources = [str(x) for directory in ('java', 'java-stubs') for x in sorted((ROOT / directory).rglob('*.java'))]
        compiler = ['java', '-jar', a.ecj_jar, '-8', '-proc:none', '-bootclasspath', a.android_jar] if a.ecj_jar else ['javac', '-source', '8', '-target', '8', '-bootclasspath', a.android_jar]
        subprocess.run(compiler + ['-d', str(classes)] + sources, check=True)
        jar = tmp / 'features.jar'
        with zipfile.ZipFile(jar, 'w') as z:
            for f in classes.rglob('*.class'):
                if not f.relative_to(classes).as_posix().startswith('com/smartcall/ru/'):
                    continue
                if f.stem in ('CallController', 'CallControlAccessibilityService', 'CallNotificationListenerService'):
                    continue
                z.write(f, f.relative_to(classes).as_posix())
        out = tmp / 'dex'; out.mkdir()
        subprocess.run(['java', '-cp', a.d8_jar, 'com.android.tools.r8.D8', '--min-api', '21', '--lib', a.android_jar, '--output', str(out), str(jar)], check=True)
        result = ROOT / 'assets/features.dex'
        shutil.copy2(out / 'classes.dex', result)
        metadata = {'dex_sha256': hashlib.sha256(result.read_bytes()).hexdigest(), 'sources': {str(Path(x).relative_to(ROOT)): hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in sources}}
        (ROOT / 'assets/features-build.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print('Built features.dex SHA256=' + metadata['dex_sha256'])
if __name__ == '__main__': main()
