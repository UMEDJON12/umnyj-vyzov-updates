#!/usr/bin/env python3
"""
Полный скрипт бинарного патчинга assets/features.dex из базового эталона assets/features.dex.orig
для синхронизации с изменениями версии 2.3.6:
1. AnswerFlow.step (0x1f18):
   - Увеличивает число стадий ответа до 4 (stage 0: telecom, stage 1: notification +250ms,
     stage 2: ui +250ms, stage 3: ui repeat +450ms).
   - Сокращает интервалы ожидания с 400/600 мс до 250/450 мс.
2. SmartCallFeatures.answerUi (0x2a60):
   - Делегирует клик/свайп по кнопке ответа в CallController.recordActiveCallState(98) ->
     CallControlAccessibilityService.clickCallButtonInUi(true), что обеспечивает нажатие кнопки
     ответа как в полноэкранном окне звонка, так и во всплывающем баннере com.android.systemui.
3. SmartCallFeatures.announceMessage (0x343c):
   - Исправляет регистр проверки настроек канала при озвучке входящих сообщений мессенджеров.
4. SmartCallFeatures.lambda$11 (0x3850):
   - Делегирует настройку скорости речи, аудиоканала, громкости и отправку частей текста в TTS
     через CallController.recordActiveCallState(99) -> CallController.configureAndSpeakActiveJob().
5. Пересчитывает контрольные суммы DEX (SHA-1 signature и Adler32 checksum) и обновляет
   assets/features.dex и assets/features-build.json.

Примечание: для полной пересборки второго DEX-модуля с нуля из символьного исходного кода
(при изменении строк интерфейса, добавлении или модификации методов) используйте:
  python3 build_features_dex.py
"""
import hashlib
import json
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def uleb(b, p):
    value, shift = 0, 0
    while True:
        part = b[p]
        p += 1
        value |= (part & 127) << shift
        if not part & 128:
            return value, p
        shift += 7


def apply_v236_patches(orig_bytes: bytes) -> bytes:
    b = bytearray(orig_bytes)

    def word(p):
        return struct.unpack_from("<I", b, p)[0]

    strings = []
    for i in range(word(56)):
        p = word(word(60) + i * 4)
        _, p = uleb(b, p)
        strings.append(b[p : b.index(b"\0", p)].decode("utf-8", "replace"))
    types = [strings[word(word(68) + i * 4)] for i in range(word(64))]
    protos = []
    for i in range(word(72)):
        p = word(76) + i * 12
        ret = types[word(p + 4)]
        params_off = word(p + 8)
        params = (
            []
            if not params_off
            else [types[struct.unpack_from("<H", b, params_off + 4 + j * 2)[0]] for j in range(word(params_off))]
        )
        protos.append((ret, tuple(params)))
    methods = []
    for i in range(word(88)):
        c, p, n = struct.unpack_from("<HHI", b, word(92) + i * 8)
        methods.append((types[c], strings[n], protos[p]))

    code_offs = {}
    for i in range(word(96)):
        p = word(100) + i * 32
        cls = types[word(p)]
        data = word(p + 24)
        if not data:
            continue
        sizes = []
        for _ in range(4):
            size, data = uleb(b, data)
            sizes.append(size)
        for count in sizes[:2]:
            for _ in range(count):
                _, data = uleb(b, data)
                _, data = uleb(b, data)
        for count in sizes[2:]:
            index = 0
            for _ in range(count):
                delta, data = uleb(b, data)
                index += delta
                flags, data = uleb(b, data)
                code_off, data = uleb(b, data)
                m = methods[index]
                code_offs[(cls, m[1])] = code_off

    # 1. Patch AnswerFlow.step (0x1f18): 400ms -> 250ms, 600ms -> 450ms
    step_off = code_offs[("Lcom/smartcall/ru/AnswerFlow;", "step")] + 16
    struct.pack_into("<h", b, step_off + 113 * 2, 250)
    struct.pack_into("<h", b, step_off + 116 * 2, 450)

    # 2. Patch SmartCallFeatures.answerUi (0x2a60): delegate to CallController.recordActiveCallState(98)
    ans_off = code_offs[("Lcom/smartcall/ru/SmartCallFeatures;", "answerUi")] + 16
    # cu 13..57 (45 code units = 90 bytes):
    # const/16 v2, 98 (1302 6200)
    # invoke-static {v2}, CallController.recordActiveCallState(int) (7110 7100 0200)
    # const/4 v0, 1 (1210)
    # return v0 (0f00)
    # followed by nop padding (0x0000) to preserve exact try_item boundary at cu=55..58
    ans_patch = bytes.fromhex("1302620071107100020012100f00") + b"\x00" * (45 * 2 - 14)
    b[ans_off + 13 * 2 : ans_off + 58 * 2] = ans_patch

    # 3. Patch SmartCallFeatures.announceMessage (0x343c): cu=148 register operand
    ann_off = code_offs[("Lcom/smartcall/ru/SmartCallFeatures;", "announceMessage")] + 16
    struct.pack_into("<H", b, ann_off + 148 * 2, 0x0046)

    # 4. Patch SmartCallFeatures.lambda$11 (0x3850): delegate TTS config & speak to CallController.recordActiveCallState(99)
    lam_off = code_offs[("Lcom/smartcall/ru/SmartCallFeatures;", "lambda$11")] + 16
    # Clear old inline voice loop at cu 125..146 (22 code units) with nops
    b[lam_off + 125 * 2 : lam_off + 147 * 2] = b"\x00" * (22 * 2)
    # At cu 157..363 (207 code units):
    # const/16 v6, 99 (1306 6300)
    # invoke-static {v6}, CallController.recordActiveCallState(int) (7110 7100 0600)
    # iget-object v6, v1, SpeechJob.tts (5416 3d00)
    # if-eqz v6, +0xa7 (3806 a700)
    # return-void (0e00)
    # followed by nops up to cu=364 (try block end)
    lam_patch_1 = bytes.fromhex("1306630071107100060054163d003806a7000e00") + b"\x00" * ((330 - 157) * 2 - 20)
    b[lam_off + 157 * 2 : lam_off + 330 * 2] = lam_patch_1
    b[lam_off + 335 * 2 : lam_off + 364 * 2] = b"\x00" * ((364 - 335) * 2)

    # 5. Update class_data_item register metadata byte at 0x8042
    b[0x8042] = 0x09

    # 6. Recompute DEX SHA-1 signature (bytes 12..32) and Adler32 checksum (bytes 8..12)
    b[12:32] = hashlib.sha1(b[32:]).digest()
    struct.pack_into("<I", b, 8, zlib.adler32(b[12:]) & 0xFFFFFFFF)
    return bytes(b)


def main():
    orig_path = ROOT / "assets/features.dex.orig"
    dex_path = ROOT / "assets/features.dex"
    if not orig_path.exists():
        raise FileNotFoundError(f"Missing {orig_path}; use build_features_dex.py to build from scratch.")
    patched = apply_v236_patches(orig_path.read_bytes())
    dex_path.write_bytes(patched)
    sources = [str(x.relative_to(ROOT)) for d in ("java", "java-stubs") for x in sorted((ROOT / d).rglob("*.java"))]
    meta = {
        "dex_sha256": hashlib.sha256(patched).hexdigest(),
        "sources": {s: hashlib.sha256((ROOT / s).read_bytes()).hexdigest() for s in sources},
    }
    (ROOT / "assets/features-build.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    print(f"Patched {dex_path} ({len(patched)} bytes, SHA256={meta['dex_sha256']})")


if __name__ == "__main__":
    main()
