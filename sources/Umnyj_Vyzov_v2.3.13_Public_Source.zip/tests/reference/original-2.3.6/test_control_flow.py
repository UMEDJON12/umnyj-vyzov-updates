"""Host-only tests of generated instruction tuples, not an Android runtime test."""
import ast
import hashlib
import unittest
from pathlib import Path

import build_dex


def instructions():
    tree = ast.parse(Path(build_dex.__file__).read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "code_handle_dlg" for t in node.targets):
            class Names(ast.NodeTransformer):
                def visit_Name(self, n):
                    return ast.copy_location(ast.Constant(n.id), n)
            return ast.literal_eval(Names().visit(node.value))["insns"]
    raise AssertionError("code_handle_dlg not found")


def run(mode, index):
    """Interpret tested prefix and speed/audio paths; stop at engine branch or return."""
    code = instructions()
    labels = {i[1]: p for p, i in enumerate(code) if i[0] == "label"}
    reg = {3: "context", 4: mode, 5: index}
    saved, calls = [], []
    pc = 0
    for _ in range(250):
        inst = code[pc]
        op, args = inst[0], inst[1:]
        pc += 1
        if op == "label":
            if args[0] in ("check_eng_arr", "m1", "m2", "m3", "m4"):
                return args[0], saved, calls
        elif op in ("const/4", "const/16", "const-string"):
            reg[args[0]] = args[1]
        elif op.startswith("goto"):
            pc = labels[args[0]]
        elif op in ("if-eq", "if-ne", "if-lt", "if-le", "if-gt", "if-ge"):
            a, b, target = args
            x, y = reg[a], reg[b]
            if {"if-eq": x == y, "if-ne": x != y, "if-lt": x < y,
                "if-le": x <= y, "if-gt": x > y, "if-ge": x >= y}[op]:
                pc = labels[target]
        elif op in ("if-nez", "if-eqz", "if-ltz"):
            r, target = args
            x = reg[r]
            if {"if-nez": x != 0, "if-eqz": x == 0, "if-ltz": x < 0}[op]:
                pc = labels[target]
        elif op.startswith("invoke-"):
            registers, method = args
            values = tuple(reg[r] for r in registers)
            calls.append((method, values))
            if method == "m_ctrl_set_int":
                saved.append((values[1], values[2]))
        elif op == "return-void":
            return "return", saved, calls
        else:
            raise AssertionError(f"Unexpected instruction in tested path: {inst}")
    raise AssertionError("non-terminating control flow")


class ControlFlowTests(unittest.TestCase):
    def test_all_rates_and_channels(self):
        keys = ["sim", "wa", "tg", "other", "sms"]
        rates = [50, 75, 90, 100, 115, 125, 150, 175, 200]
        for mode, channel in enumerate(keys, 21):
            for index, rate in enumerate(rates):
                with self.subTest(mode=mode, index=index):
                    end, saved, calls = run(mode, index)
                    self.assertEqual(end, "return")
                    self.assertEqual(saved, [("tts_rate_" + channel, rate)])
                    self.assertIn(("m_features_speak", ("context", "Проверка выбранной скорости речи", "tts_eng_" + channel, 1)), calls)

    def test_audio_selection_and_out_of_bounds(self):
        for index in range(4):
            with self.subTest(index=index):
                end, saved, calls = run(26, index)
                self.assertEqual(end, "return")
                self.assertEqual(saved, [("tts_audio_mode", index)])
                self.assertTrue(any(method == "m_features_speak" for method, _ in calls))
        for index in (-1, 4, 100):
            with self.subTest(index=index):
                _, saved, calls = run(26, index)
                self.assertEqual(saved, [])
                self.assertFalse(any(method == "m_features_speak" for method, _ in calls))

    def test_engine_and_voice_routes_unchanged(self):
        for mode in (11, 12, 13, 14, 15, 16):
            with self.subTest(mode=mode):
                end, saved, _ = run(mode, 0)
                self.assertEqual(end, "check_eng_arr")
                self.assertEqual(saved, [])

    def test_permissions_routes_unchanged(self):
        for mode in range(1, 5):
            self.assertEqual(run(mode, 0)[0], "m" + str(mode))

    def test_custom_volume(self):
        for index, volume in enumerate((15, 30, 45, 60, 75, 90, 100)):
            self.assertEqual(run(27, index)[1], [("tts_custom_vol", volume)])

    def test_builder_emits_valid_header_hash_and_checksum(self):
        import struct
        import zlib
        dex = build_dex.build_classes_dex()
        self.assertTrue(dex.startswith(b"dex\n035\0"))
        self.assertEqual(dex[12:32], hashlib.sha1(dex[32:]).digest())
        self.assertEqual(struct.unpack_from("<I", dex, 8)[0], zlib.adler32(dex[12:]) & 0xffffffff)


if __name__ == "__main__":
    unittest.main(verbosity=2)
