#!/usr/bin/env python3
"""
Builds classes.dex for «Умный Вызов» v2.3.0 (com.smartcall.ru):
1. com.smartcall.ru.CallController
2. com.smartcall.ru.CallNotificationListenerService
3. com.smartcall.ru.CallControlAccessibilityService
4. com.smartcall.ru.ScreenAndVolumeReceiver
5. com.smartcall.ru.DelayedActionRunnable
7. com.smartcall.ru.MainActivity
8. com.smartcall.ru.DialogClickListener
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dex_assembler import DexBuilder

PKG = "Lcom/smartcall/ru/"
C_CTRL = f"{PKG}CallController;"
C_NOTIF = f"{PKG}CallNotificationListenerService;"
C_ACC = f"{PKG}CallControlAccessibilityService;"
C_RCVR = f"{PKG}ScreenAndVolumeReceiver;"
C_RUN_ACT = f"{PKG}DelayedActionRunnable;"
C_MAIN = f"{PKG}MainActivity;"
C_DLG = f"{PKG}DialogClickListener;"
C_TTS_L = f"{PKG}TtsInitListener;"
C_PROX_L = f"{PKG}ProximitySensorListener;"

C_TTS = "Landroid/speech/tts/TextToSpeech;"
C_TTS_OIL = "Landroid/speech/tts/TextToSpeech$OnInitListener;"
C_TTS_EI = "Landroid/speech/tts/TextToSpeech$EngineInfo;"
C_CURSOR = "Landroid/database/Cursor;"
C_SMS = "Landroid/telephony/SmsMessage;"
C_LOCALE = "Ljava/util/Locale;"

# Standard Java / Android classes
C_OBJ = "Ljava/lang/Object;"
C_RUNNABLE = "Ljava/lang/Runnable;"
C_STR = "Ljava/lang/String;"
C_CS = "Ljava/lang/CharSequence;"
C_SB = "Ljava/lang/StringBuilder;"
C_THR = "Ljava/lang/Throwable;"
C_SYS = "Ljava/lang/System;"
C_LIST = "Ljava/util/List;"
C_FILE = "Ljava/io/File;"
C_FOS = "Ljava/io/FileOutputStream;"

C_CTX = "Landroid/content/Context;"
C_COMP = "Landroid/content/ComponentName;"
C_PM = "Landroid/content/pm/PackageManager;"
C_INTENT = "Landroid/content/Intent;"
C_IFILTER = "Landroid/content/IntentFilter;"
C_BR = "Landroid/content/BroadcastReceiver;"
C_SP = "Landroid/content/SharedPreferences;"
C_SP_ED = "Landroid/content/SharedPreferences$Editor;"
C_CR = "Landroid/content/ContentResolver;"
C_DLG_IF = "Landroid/content/DialogInterface;"
C_DLG_OCL = "Landroid/content/DialogInterface$OnClickListener;"

C_URI = "Landroid/net/Uri;"
C_BUILD = "Landroid/os/Build;"
C_BUILD_VER = "Landroid/os/Build$VERSION;"
C_BUNDLE = "Landroid/os/Bundle;"
C_ENV = "Landroid/os/Environment;"
C_HANDLER = "Landroid/os/Handler;"
C_LOOPER = "Landroid/os/Looper;"
C_POWER = "Landroid/os/PowerManager;"
C_PM_WL = "Landroid/os/PowerManager$WakeLock;"

C_AO = "Landroid/app/ActivityOptions;"
C_PI = "Landroid/app/PendingIntent;"
C_PI_ONFIN = "Landroid/app/PendingIntent$OnFinished;"
C_ACT = "Landroid/app/Activity;"
C_AD = "Landroid/app/AlertDialog;"
C_AD_B = "Landroid/app/AlertDialog$Builder;"
C_KM = "Landroid/app/KeyguardManager;"
C_KM_KL = "Landroid/app/KeyguardManager$KeyguardLock;"
C_KM_CB = "Landroid/app/KeyguardManager$KeyguardDismissCallback;"
C_NOTIF_OBJ = "Landroid/app/Notification;"
C_NOTIF_ACT = "Landroid/app/Notification$Action;"
C_NOTIF_ACT_ARR = "[Landroid/app/Notification$Action;"

C_NLS = "Landroid/service/notification/NotificationListenerService;"
C_SBN = "Landroid/service/notification/StatusBarNotification;"
C_SBN_ARR = "[Landroid/service/notification/StatusBarNotification;"

C_ACCS = "Landroid/accessibilityservice/AccessibilityService;"
C_ACCSI = "Landroid/accessibilityservice/AccessibilityServiceInfo;"
C_ACCS_GCB = "Landroid/accessibilityservice/AccessibilityService$GestureResultCallback;"
C_GD = "Landroid/accessibilityservice/GestureDescription;"
C_GD_B = "Landroid/accessibilityservice/GestureDescription$Builder;"
C_GD_SD = "Landroid/accessibilityservice/GestureDescription$StrokeDescription;"
C_ACCEV = "Landroid/view/accessibility/AccessibilityEvent;"
C_ACCNI = "Landroid/view/accessibility/AccessibilityNodeInfo;"
C_ACCWI = "Landroid/view/accessibility/AccessibilityWindowInfo;"

C_PATH = "Landroid/graphics/Path;"
C_RECT = "Landroid/graphics/Rect;"
C_KE = "Landroid/view/KeyEvent;"
C_WIN = "Landroid/view/Window;"
C_VIEW = "Landroid/view/View;"
C_VIEW_OCL = "Landroid/view/View$OnClickListener;"
C_VG_LP = "Landroid/view/ViewGroup$LayoutParams;"
C_LL = "Landroid/widget/LinearLayout;"
C_LL_LP = "Landroid/widget/LinearLayout$LayoutParams;"
C_SV = "Landroid/widget/ScrollView;"
C_TV = "Landroid/widget/TextView;"
C_BTN = "Landroid/widget/Button;"
C_CB = "Landroid/widget/CheckBox;"
C_CMP_BTN = "Landroid/widget/CompoundButton;"
C_CMP_OCL = "Landroid/widget/CompoundButton$OnCheckedChangeListener;"

C_TELECOM = "Landroid/telecom/TelecomManager;"
C_TELEPHONY = "Landroid/telephony/TelephonyManager;"
C_AUDIO = "Landroid/media/AudioManager;"
C_APC = "Landroid/media/AudioPlaybackConfiguration;"
C_AATTR = "Landroid/media/AudioAttributes;"
C_SEC = "Landroid/provider/Settings$Secure;"


def build_classes_dex() -> bytes:
    db = DexBuilder()

    C_FEATURES = "Lcom/smartcall/ru/SmartCallFeatures;"
    C_SPEECH_JOB = "Lcom/smartcall/ru/SmartCallFeatures$SpeechJob;"
    f_features_active = (C_FEATURES, "active", C_SPEECH_JOB)
    f_job_tts = (C_SPEECH_JOB, "tts", C_TTS)
    f_job_ctx = (C_SPEECH_JOB, "context", C_CTX)
    f_job_channel = (C_SPEECH_JOB, "channel", C_STR)
    f_job_text = (C_SPEECH_JOB, "text", C_STR)
    f_job_repeat = (C_SPEECH_JOB, "repeat", "I")
    f_job_lastid = (C_SPEECH_JOB, "lastId", C_STR)
    m_features_speak = (C_FEATURES, "speak", ("V", (C_CTX, C_STR, C_STR, "I")))
    m_features_legacy = (C_FEATURES, "speakLegacy", ("V", (C_CTX, C_STR, C_STR, "I")))
    m_features_clean = (C_FEATURES, "cleanCaller", (C_STR, (C_STR,)))
    m_features_stop = (C_FEATURES, "stopSpeech", ("V", ()))
    m_features_answer = (C_FEATURES, "answer", ("V", (C_CTX,)))
    m_features_cancel_answer = (C_FEATURES, "cancelAnswer", ("V", ()))
    m_features_message = (C_FEATURES, "handleMessageNotification", ("Z", (C_CTX, C_SBN)))
    m_features_sms = (C_FEATURES, "announceSms", ("V", (C_CTX, C_STR, C_STR, C_STR)))
    m_features_find = (C_FEATURES, "findCallerName", (C_STR, (C_ACCS,)))
    m_features_voice_buttons = (C_FEATURES, "addVoiceButtons", ("V", (C_ACT, C_LL)))
    m_features_engine_changed = (C_FEATURES, "onEngineChanged", ("V", (C_CTX, C_STR)))
    m_features_profiles = (C_FEATURES, "profileSummary", (C_STR, (C_CTX,)))

    # Common methods
    m_obj_init = (C_OBJ, "<init>", ("V", ()))
    m_sys_time = ("Landroid/os/SystemClock;", "elapsedRealtime", ("J", ()))
    m_cs_tostr = (C_CS, "toString", (C_STR, ()))
    m_obj_tostr = (C_OBJ, "toString", (C_STR, ()))
    m_str_lower = (C_STR, "toLowerCase", (C_STR, ()))
    m_str_contains = (C_STR, "contains", ("Z", (C_CS,)))
    m_str_equals = (C_STR, "equals", ("Z", (C_OBJ,)))
    m_str_len = (C_STR, "length", ("I", ()))
    m_str_sub = (C_STR, "substring", (C_STR, ("I",)))
    m_str_sub2 = (C_STR, "substring", (C_STR, ("I", "I")))
    m_str_bytes = (C_STR, "getBytes", ("[B", ()))
    m_thr_tostr = (C_THR, "toString", (C_STR, ()))

    m_sb_init = (C_SB, "<init>", ("V", ()))
    m_sb_app_str = (C_SB, "append", (C_SB, (C_STR,)))
    m_sb_app_int = (C_SB, "append", (C_SB, ("I",)))
    m_sb_app_bool = (C_SB, "append", (C_SB, ("Z",)))
    m_sb_tostr = (C_SB, "toString", (C_STR, ()))

    # Handler / Looper
    m_looper_main = (C_LOOPER, "getMainLooper", (C_LOOPER, ()))
    m_handler_init = (C_HANDLER, "<init>", ("V", (C_LOOPER,)))
    m_handler_post_del = (C_HANDLER, "postDelayed", ("Z", (C_RUNNABLE, "J")))

    # File IO
    m_file_init_parent = (C_FILE, "<init>", ("V", (C_FILE, C_STR)))
    m_file_get_path = (C_FILE, "getAbsolutePath", (C_STR, ()))
    m_fos_init = (C_FOS, "<init>", ("V", (C_FILE,)))
    m_fos_write = (C_FOS, "write", ("V", ("[B",)))
    m_fos_close = (C_FOS, "close", ("V", ()))
    m_env_get_pub = (C_ENV, "getExternalStoragePublicDirectory", (C_FILE, (C_STR,)))

    # Context / PackageManager / SharedPreferences / ComponentName
    m_comp_init = (C_COMP, "<init>", ("V", (C_CTX, C_STR)))
    m_ctx_get_pm = (C_CTX, "getPackageManager", (C_PM, ()))
    m_pm_set_comp = (C_PM, "setComponentEnabledSetting", ("V", (C_COMP, "I", "I")))
    m_ctx_get_sp = (C_CTX, "getSharedPreferences", (C_SP, (C_STR, "I")))
    m_ctx_get_sys = (C_CTX, "getSystemService", (C_OBJ, (C_STR,)))
    m_ctx_get_cr = (C_CTX, "getContentResolver", (C_CR, ()))
    m_ctx_get_pkg = (C_CTX, "getPackageName", (C_STR, ()))
    m_ctx_get_ext = (C_CTX, "getExternalFilesDir", (C_FILE, (C_STR,)))
    m_ctx_check_perm = (C_CTX, "checkSelfPermission", ("I", (C_STR,)))
    m_ctx_start_act = (C_CTX, "startActivity", ("V", (C_INTENT,)))
    m_ctx_reg_rcvr = (C_CTX, "registerReceiver", (C_INTENT, (C_BR, C_IFILTER)))
    m_ctx_reg_rcvr_flg = (C_CTX, "registerReceiver", (C_INTENT, (C_BR, C_IFILTER, "I")))
    m_ctx_unreg_rcvr = (C_CTX, "unregisterReceiver", ("V", (C_BR,)))

    m_sp_get_bool = (C_SP, "getBoolean", ("Z", (C_STR, "Z")))
    m_sp_edit = (C_SP, "edit", (C_SP_ED, ()))
    m_sped_put_bool = (C_SP_ED, "putBoolean", (C_SP_ED, (C_STR, "Z")))
    m_sped_apply = (C_SP_ED, "apply", ("V", ()))

    # Telecom / Telephony / Audio / Power / Keyguard / Settings
    m_telecom_accept = (C_TELECOM, "acceptRingingCall", ("V", ()))
    m_telecom_end = (C_TELECOM, "endCall", ("Z", ()))
    m_telecom_incall = (C_TELECOM, "isInCall", ("Z", ()))
    m_telephony_state = (C_TELEPHONY, "getCallState", ("I", ()))
    m_telephony_state_sub = (C_TELEPHONY, "getCallStateForSubscription", ("I", ()))
    m_audio_mode = (C_AUDIO, "getMode", ("I", ()))
    m_audio_mute = (C_AUDIO, "isStreamMute", ("Z", ("I",)))
    m_audio_dispatch = (C_AUDIO, "dispatchMediaKeyEvent", ("V", (C_KE,)))
    m_audio_configs = (C_AUDIO, "getActivePlaybackConfigurations", (C_LIST, ()))
    m_apc_attr = (C_APC, "getAudioAttributes", (C_AATTR, ()))
    m_aattr_usage = (C_AATTR, "getUsage", ("I", ()))
    m_power_ignoring = (C_POWER, "isIgnoringBatteryOptimizations", ("Z", (C_STR,)))
    m_power_interactive = (C_POWER, "isInteractive", ("Z", ()))
    m_power_newwl = (C_POWER, "newWakeLock", (C_PM_WL, ("I", C_STR)))
    m_wl_acq = (C_PM_WL, "acquire", ("V", ("J",)))
    m_km_newkl = (C_KM, "newKeyguardLock", (C_KM_KL, (C_STR,)))
    m_km_req_dismiss = (C_KM, "requestDismissKeyguard", ("V", (C_ACT, C_KM_CB)))
    m_kl_disable = (C_KM_KL, "disableKeyguard", ("V", ()))
    m_sec_get_str = (C_SEC, "getString", (C_STR, (C_CR, C_STR)))
    m_sec_put_int = (C_SEC, "putInt", ("Z", (C_CR, C_STR, "I")))

    # SharedPreferences Int & String + String/Char helpers
    m_sp_get_int = (C_SP, "getInt", ("I", (C_STR, "I")))
    m_sp_get_str = (C_SP, "getString", (C_STR, (C_STR, C_STR)))
    m_sped_put_int = (C_SP_ED, "putInt", (C_SP_ED, (C_STR, "I")))
    m_sped_put_str = (C_SP_ED, "putString", (C_SP_ED, (C_STR, C_STR)))
    m_str_charat = (C_STR, "charAt", ("C", ("I",)))
    m_sb_app_long = (C_SB, "append", (C_SB, ("J",)))
    m_uri_encode = (C_URI, "encode", (C_STR, (C_STR,)))
    m_cr_query = (C_CR, "query", (C_CURSOR, (C_URI, "[Ljava/lang/String;", C_STR, "[Ljava/lang/String;", C_STR)))
    m_cur_first = (C_CURSOR, "moveToFirst", ("Z", ()))
    m_cur_get_str = (C_CURSOR, "getString", (C_STR, ("I",)))
    m_cur_close = (C_CURSOR, "close", ("V", ()))
    m_sbn_get_pkg = (C_SBN, "getPackageName", (C_STR, ()))
    m_intent_extras = (C_INTENT, "getExtras", (C_BUNDLE, ()))
    m_sms_pdu = (C_SMS, "createFromPdu", (C_SMS, ("[B",)))
    m_sms_addr = (C_SMS, "getOriginatingAddress", (C_STR, ()))
    m_sms_body = (C_SMS, "getMessageBody", (C_STR, ()))
    m_adb_items = (C_AD_B, "setItems", (C_AD_B, ("[Ljava/lang/CharSequence;", C_DLG_OCL)))

    C_AATTR_B = "Landroid/media/AudioAttributes$Builder;"
    m_aattrb_init = (C_AATTR_B, "<init>", ("V", ()))
    m_aattrb_usage = (C_AATTR_B, "setUsage", (C_AATTR_B, ("I",)))
    m_aattrb_ctype = (C_AATTR_B, "setContentType", (C_AATTR_B, ("I",)))
    m_aattrb_build = (C_AATTR_B, "build", (C_AATTR, ()))
    m_tts_set_attr = (C_TTS, "setAudioAttributes", ("I", (C_AATTR,)))
    m_bundle_init = (C_BUNDLE, "<init>", ("V", ()))
    m_bundle_put_str = (C_BUNDLE, "putString", ("V", (C_STR, C_STR)))
    m_bundle_put_int = (C_BUNDLE, "putInt", ("V", (C_STR, "I")))
    m_bundle_put_flt = (C_BUNDLE, "putFloat", ("V", (C_STR, "F")))
    m_pi_get_act = (C_PI, "getActivity", (C_PI, (C_CTX, "I", C_INTENT, "I")))

    # TextToSpeech & Locale
    m_tts_init_2 = (C_TTS, "<init>", ("V", (C_CTX, C_TTS_OIL)))
    m_tts_init_3 = (C_TTS, "<init>", ("V", (C_CTX, C_TTS_OIL, C_STR)))
    m_tts_engines = (C_TTS, "getEngines", (C_LIST, ()))
    m_tts_set_lang = (C_TTS, "setLanguage", ("I", (C_LOCALE,)))
    m_tts_set_pitch = (C_TTS, "setPitch", ("I", ("F",)))
    m_tts_set_rate = (C_TTS, "setSpeechRate", ("I", ("F",)))
    m_tts_speak = (C_TTS, "speak", ("I", (C_CS, "I", C_BUNDLE, C_STR)))
    m_tts_stop = (C_TTS, "stop", ("I", ()))
    m_tts_shutdown = (C_TTS, "shutdown", ("V", ()))
    f_ttsei_name = (C_TTS_EI, "name", C_STR)
    f_ttsei_label = (C_TTS_EI, "label", C_STR)
    m_loc_default = (C_LOCALE, "getDefault", (C_LOCALE, ()))
    f_build_brand = (C_BUILD, "BRAND", C_STR)
    f_build_device = (C_BUILD, "DEVICE", C_STR)
    f_build_disp = (C_BUILD, "DISPLAY", C_STR)

    # KeyEvent
    m_ke_init = (C_KE, "<init>", ("V", ("I", "I")))
    m_ke_get_code = (C_KE, "getKeyCode", ("I", ()))
    m_ke_repeat = (C_KE, "getRepeatCount", ("I", ()))
    m_ke_get_act = (C_KE, "getAction", ("I", ()))

    # Notification / PendingIntent / ActivityOptions / Bundle
    m_ao_make = (C_AO, "makeBasic", (C_AO, ()))
    m_ao_set_bal = (C_AO, "setPendingIntentBackgroundActivityStartMode", (C_AO, ("I",)))
    m_ao_bundle = (C_AO, "toBundle", (C_BUNDLE, ()))
    m_pi_send = (C_PI, "send", ("V", ()))
    m_pi_send_7 = (
        C_PI,
        "send",
        ("V", (C_CTX, "I", C_INTENT, C_PI_ONFIN, C_HANDLER, C_STR, C_BUNDLE)),
    )
    m_bundle_get_int = (C_BUNDLE, "getInt", ("I", (C_STR, "I")))
    m_bundle_contains = (C_BUNDLE, "containsKey", ("Z", (C_STR,)))
    m_bundle_get = (C_BUNDLE, "get", (C_OBJ, (C_STR,)))

    m_path_init = (C_PATH, "<init>", ("V", ()))
    m_path_move = (C_PATH, "moveTo", ("V", ("F", "F")))
    m_path_line = (C_PATH, "lineTo", ("V", ("F", "F")))
    m_gdsd_init = (C_GD_SD, "<init>", ("V", (C_PATH, "J", "J")))
    m_gdb_init = (C_GD_B, "<init>", ("V", ()))
    m_gdb_add = (C_GD_B, "addStroke", (C_GD_B, (C_GD_SD,)))
    m_gdb_build = (C_GD_B, "build", (C_GD, ()))

    m_sbn_get_notif = (C_SBN, "getNotification", (C_NOTIF_OBJ, ()))
    m_nls_init = (C_NLS, "<init>", ("V", ()))
    m_nls_get_active = (C_NLS, "getActiveNotifications", (C_SBN_ARR, ()))
    m_nls_rebind = (C_NLS, "requestRebind", ("V", (C_COMP,)))

    f_notif_cat = (C_NOTIF_OBJ, "category", C_STR)
    f_notif_flags = (C_NOTIF_OBJ, "flags", "I")
    f_notif_extras = (C_NOTIF_OBJ, "extras", C_BUNDLE)
    f_notif_actions = (C_NOTIF_OBJ, "actions", C_NOTIF_ACT_ARR)
    f_nact_title = (C_NOTIF_ACT, "title", C_CS)
    f_nact_intent = (C_NOTIF_ACT, "actionIntent", C_PI)
    f_sdk_int = (C_BUILD_VER, "SDK_INT", "I")
    f_build_rel = (C_BUILD_VER, "RELEASE", C_STR)
    f_build_manuf = (C_BUILD, "MANUFACTURER", C_STR)
    f_build_model = (C_BUILD, "MODEL", C_STR)

    # AccessibilityService & Gestures
    m_accs_init = (C_ACCS, "<init>", ("V", ()))
    m_accs_get_info = (C_ACCS, "getServiceInfo", (C_ACCSI, ()))
    m_accs_set_info = (C_ACCS, "setServiceInfo", ("V", (C_ACCSI,)))
    m_accs_get_root = (C_ACCS, "getRootInActiveWindow", (C_ACCNI, ()))
    m_accs_get_wins = (C_ACCS, "getWindows", (C_LIST, ()))
    m_accs_disp_gest = (C_ACCS, "dispatchGesture", ("Z", (C_GD, C_ACCS_GCB, C_HANDLER)))
    m_accsi_get_caps = (C_ACCSI, "getCapabilities", ("I", ()))
    f_accsi_events = (C_ACCSI, "eventTypes", "I")
    f_accsi_flags = (C_ACCSI, "flags", "I")

    m_accwi_get_root = (C_ACCWI, "getRoot", (C_ACCNI, ()))
    m_accni_get_pkg = (C_ACCNI, "getPackageName", (C_CS, ()))
    m_accni_get_text = (C_ACCNI, "getText", (C_CS, ()))
    m_accni_get_desc = (C_ACCNI, "getContentDescription", (C_CS, ()))
    m_accni_get_vid = (C_ACCNI, "getViewIdResourceName", (C_STR, ()))
    m_accni_get_cnt = (C_ACCNI, "getChildCount", ("I", ()))
    m_accni_get_child = (C_ACCNI, "getChild", (C_ACCNI, ("I",)))
    m_accni_is_click = (C_ACCNI, "isClickable", ("Z", ()))
    m_accni_get_parent = (C_ACCNI, "getParent", (C_ACCNI, ()))
    m_accni_perf_act = (C_ACCNI, "performAction", ("Z", ("I",)))
    m_accni_bounds = (C_ACCNI, "getBoundsInScreen", ("V", (C_RECT,)))

    m_rect_init = (C_RECT, "<init>", ("V", ()))
    m_rect_cx = (C_RECT, "centerX", ("I", ()))
    m_rect_cy = (C_RECT, "centerY", ("I", ()))

    m_list_size = (C_LIST, "size", ("I", ()))
    m_list_get = (C_LIST, "get", (C_OBJ, ("I",)))

    # BroadcastReceiver / Intent / IntentFilter / Uri
    m_br_init = (C_BR, "<init>", ("V", ()))
    m_intent_init_empty = (C_INTENT, "<init>", ("V", ()))
    m_intent_init_act = (C_INTENT, "<init>", ("V", (C_STR,)))
    m_intent_set_cn = (C_INTENT, "setClassName", (C_INTENT, (C_CTX, C_STR)))
    m_intent_set_data = (C_INTENT, "setData", (C_INTENT, (C_URI,)))
    m_intent_set_type = (C_INTENT, "setType", (C_INTENT, (C_STR,)))
    m_intent_put_str = (C_INTENT, "putExtra", (C_INTENT, (C_STR, C_STR)))
    m_intent_get_int = (C_INTENT, "getIntExtra", ("I", (C_STR, "I")))
    m_intent_add_flags = (C_INTENT, "addFlags", (C_INTENT, ("I",)))
    m_intent_chooser = (C_INTENT, "createChooser", (C_INTENT, (C_INTENT, C_CS)))
    m_intent_get_act = (C_INTENT, "getAction", (C_STR, ()))
    m_intent_get_str = (C_INTENT, "getStringExtra", (C_STR, (C_STR,)))
    m_ifilter_init = (C_IFILTER, "<init>", ("V", ()))
    m_ifilter_add = (C_IFILTER, "addAction", ("V", (C_STR,)))
    m_uri_parse = (C_URI, "parse", (C_URI, (C_STR,)))

    # Activity / Window / View / Widgets / Dialog
    m_act_init = (C_ACT, "<init>", ("V", ()))
    m_act_oncreate = (C_ACT, "onCreate", ("V", (C_BUNDLE,)))
    m_act_onstart = (C_ACT, "onStart", ("V", ()))
    m_act_onresume = (C_ACT, "onResume", ("V", ()))
    m_act_onperm = (C_ACT, "onRequestPermissionsResult", ("V", ("I", "[Ljava/lang/String;", "[I")))
    m_act_set_content = (C_ACT, "setContentView", ("V", (C_VIEW,)))
    m_act_req_perms = (C_ACT, "requestPermissions", ("V", ("[Ljava/lang/String;", "I")))
    m_act_should_rat = (C_ACT, "shouldShowRequestPermissionRationale", ("Z", (C_STR,)))
    m_act_get_win = (C_ACT, "getWindow", (C_WIN, ()))
    m_act_set_show_lock = (C_ACT, "setShowWhenLocked", ("V", ("Z",)))
    m_act_set_turn_on = (C_ACT, "setTurnScreenOn", ("V", ("Z",)))
    m_act_finish = (C_ACT, "finish", ("V", ()))
    m_act_finish_task = (C_ACT, "finishAndRemoveTask", ("V", ()))
    m_act_override_trans = (C_ACT, "overridePendingTransition", ("V", ("I", "I")))
    m_win_add_flags = (C_WIN, "addFlags", ("V", ("I",)))

    m_sv_init = (C_SV, "<init>", ("V", (C_CTX,)))
    m_sv_add = (C_SV, "addView", ("V", (C_VIEW,)))
    m_ll_init = (C_LL, "<init>", ("V", (C_CTX,)))
    m_ll_set_orient = (C_LL, "setOrientation", ("V", ("I",)))
    m_ll_set_pad = (C_LL, "setPadding", ("V", ("I", "I", "I", "I")))
    m_ll_set_bg = (C_LL, "setBackgroundColor", ("V", ("I",)))
    m_ll_add = (C_LL, "addView", ("V", (C_VIEW,)))
    m_ll_add_lp = (C_LL, "addView", ("V", (C_VIEW, C_VG_LP)))
    m_lllp_init = (C_LL_LP, "<init>", ("V", ("I", "I")))
    m_lllp_margins = (C_LL_LP, "setMargins", ("V", ("I", "I", "I", "I")))

    m_tv_init = (C_TV, "<init>", ("V", (C_CTX,)))
    m_tv_set_text = (C_TV, "setText", ("V", (C_CS,)))
    m_tv_set_size = (C_TV, "setTextSize", ("V", ("F",)))
    m_tv_set_color = (C_TV, "setTextColor", ("V", ("I",)))
    m_tv_set_pad = (C_TV, "setPadding", ("V", ("I", "I", "I", "I")))
    m_tv_set_bg = (C_TV, "setBackgroundColor", ("V", ("I",)))

    m_btn_init = (C_BTN, "<init>", ("V", (C_CTX,)))
    m_btn_set_text = (C_BTN, "setText", ("V", (C_CS,)))
    m_btn_set_color = (C_BTN, "setTextColor", ("V", ("I",)))
    m_btn_set_bg = (C_BTN, "setBackgroundColor", ("V", ("I",)))
    m_btn_set_id = (C_BTN, "setId", ("V", ("I",)))
    m_btn_set_ocl = (C_BTN, "setOnClickListener", ("V", (C_VIEW_OCL,)))

    m_cb_init = (C_CB, "<init>", ("V", (C_CTX,)))
    m_cb_set_text = (C_CB, "setText", ("V", (C_CS,)))
    m_cb_set_size = (C_CB, "setTextSize", ("V", ("F",)))
    m_cb_set_color = (C_CB, "setTextColor", ("V", ("I",)))
    m_cb_set_pad = (C_CB, "setPadding", ("V", ("I", "I", "I", "I")))
    m_cb_set_id = (C_CB, "setId", ("V", ("I",)))
    m_cb_set_checked = (C_CB, "setChecked", ("V", ("Z",)))
    m_cb_set_ocl = (C_CB, "setOnCheckedChangeListener", ("V", (C_CMP_OCL,)))

    m_view_init = (C_VIEW, "<init>", ("V", (C_CTX,)))
    m_view_get_id = (C_VIEW, "getId", ("I", ()))
    m_cmp_get_id = (C_CMP_BTN, "getId", ("I", ()))

    m_adb_init = (C_AD_B, "<init>", ("V", (C_CTX,)))
    m_adb_title = (C_AD_B, "setTitle", (C_AD_B, (C_CS,)))
    m_adb_msg = (C_AD_B, "setMessage", (C_AD_B, (C_CS,)))
    m_adb_pos = (C_AD_B, "setPositiveButton", (C_AD_B, (C_CS, C_DLG_OCL)))
    m_adb_neg = (C_AD_B, "setNegativeButton", (C_AD_B, (C_CS, C_DLG_OCL)))
    m_adb_show = (C_AD_B, "show", (C_AD, ()))

    # =========================================================================
    # CLASS 1: CallController
    # =========================================================================
    f_ctrl_last_time = (C_CTRL, "lastActionTime", "J")
    f_ctrl_last_call_time = (C_CTRL, "lastCallTime", "J")
    f_ctrl_ring_start = (C_CTRL, "callRingStartTime", "J")
    f_acc_receiver_ready = (C_ACC, "receiverRegistered", "Z")
    f_ctrl_last_call_state = (C_CTRL, "lastCallState", "I")
    f_ctrl_sim_ringing = (C_CTRL, "simRinging", "Z")
    f_ctrl_voip_inc = (C_CTRL, "voipIncoming", "Z")
    f_ctrl_voip_ong = (C_CTRL, "voipOngoing", "Z")
    f_ctrl_watch_run = (C_CTRL, "ringWatcherRunning", "Z")
    f_ctrl_ring_mask = (C_CTRL, "ringPeakMask", "I")
    f_ctrl_diag = (C_CTRL, "diagLog", C_STR)
    f_ctrl_tts = (C_CTRL, "ttsInstance", C_TTS)
    f_ctrl_last_tts_time = (C_CTRL, "lastTtsTime", "J")
    f_ctrl_last_tts_text = (C_CTRL, "lastTtsText", C_STR)
    f_ctrl_last_call_pkg = (C_CTRL, "lastCallPkg", C_STR)
    f_ctrl_last_caller = (C_CTRL, "lastCallerTitle", C_STR)
    f_ctrl_eng_cache = (C_CTRL, "cachedEnginesSummary", C_STR)
    f_ctrl_swipe_x = (C_CTRL, "pendingSwipeX", "I")
    f_ctrl_swipe_y = (C_CTRL, "pendingSwipeY", "I")
    f_ctrl_prox_l = (C_CTRL, "proxListener", C_PROX_L)
    f_ctrl_prox_far = (C_CTRL, "proxSawFar", "Z")
    f_ctrl_prox_reg_time = (C_CTRL, "proxRegTime", "J")
    f_ctrl_prox_ticks = (C_CTRL, "proxEarTicks", "I")
    f_ctrl_last_sms_body = (C_CTRL, "lastSmsBodySpoken", "Z")
    f_ctrl_last_sms_pkg = (C_CTRL, "lastSmsPkg", C_STR)
    m_ctrl_reg_prox = (C_CTRL, "registerProximitySensor", ("V", (C_CTX,)))
    m_ctrl_unreg_prox = (C_CTRL, "unregisterProximitySensor", ("V", (C_CTX,)))
    m_ctrl_delayed_caller = (C_CTRL, "checkDelayedCaller", ("V", (C_CTX,)))
    m_notif_find_title = (C_NOTIF, "findActiveCallTitle", (C_STR, ()))
    m_notif_send_pi = (C_NOTIF, "sendPiWithBal", ("Z", (C_PI,)))
    m_acc_do_swipe_up = (C_ACC, "performDelayedSwipeUp", ("V", (C_CTX,)))

    m_ctrl_get_int = (C_CTRL, "getPrefInt", ("I", (C_CTX, C_STR, "I")))
    m_ctrl_set_int = (C_CTRL, "setPrefInt", ("V", (C_CTX, C_STR, "I")))
    m_ctrl_get_str = (C_CTRL, "getPrefStr", (C_STR, (C_CTX, C_STR, C_STR)))
    m_ctrl_set_str = (C_CTRL, "setPrefStr", ("V", (C_CTX, C_STR, C_STR)))
    m_ctrl_has_contacts = (C_CTRL, "hasContactsPermission", ("Z", (C_CTX,)))
    m_ctrl_has_sms = (C_CTRL, "hasSmsPermission", ("Z", (C_CTX,)))
    m_ctrl_lookup_contact = (C_CTRL, "lookupContactName", (C_STR, (C_CTX, C_STR)))
    m_ctrl_has_letters = (C_CTRL, "hasLetters", ("Z", (C_STR,)))
    m_ctrl_format_digits = (C_CTRL, "formatDigitsForSpeech", (C_STR, (C_STR,)))
    m_ctrl_speak = (C_CTRL, "speakText", ("V", (C_CTX, C_STR, C_STR, "I")))
    m_ctrl_stop_tts = (C_CTRL, "stopTts", ("V", ()))
    m_ctrl_ann_call = (C_CTRL, "announceIncomingCall", ("V", (C_CTX, C_STR, C_STR)))
    m_ctrl_ann_sms = (C_CTRL, "announceIncomingSms", ("V", (C_CTX, C_STR, C_STR)))
    m_ctrl_is_media_notif = (C_CTRL, "isMediaOrOngoingNotification", ("Z", (C_SBN,)))
    C_SET = "Ljava/util/Set;"
    C_ITER = "Ljava/util/Iterator;"
    C_VOICE = "Landroid/speech/tts/Voice;"
    C_SM = "Landroid/hardware/SensorManager;"
    C_SENSOR = "Landroid/hardware/Sensor;"
    C_SE = "Landroid/hardware/SensorEvent;"
    C_SEL = "Landroid/hardware/SensorEventListener;"
    C_WM = "Landroid/view/WindowManager;"
    C_WM_LP = "Landroid/view/WindowManager$LayoutParams;"
    C_NM = "Landroid/app/NotificationManager;"
    C_NC = "Landroid/app/NotificationChannel;"
    C_NB = "Landroid/app/Notification$Builder;"

    m_set_iter = (C_SET, "iterator", (C_ITER, ()))
    m_iter_has_next = (C_ITER, "hasNext", ("Z", ()))
    m_iter_next = (C_ITER, "next", (C_OBJ, ()))
    m_tts_get_voices = (C_TTS, "getVoices", (C_SET, ()))
    m_tts_set_voice = (C_TTS, "setVoice", ("I", (C_VOICE,)))
    m_voice_get_name = (C_VOICE, "getName", (C_STR, ()))
    m_voice_get_loc = (C_VOICE, "getLocale", (C_LOCALE, ()))
    m_loc_disp = (C_LOCALE, "getDisplayName", (C_STR, ()))

    m_sm_get_def = (C_SM, "getDefaultSensor", (C_SENSOR, ("I",)))
    m_sm_get_def_wake = (C_SM, "getDefaultSensor", (C_SENSOR, ("I", "Z")))
    m_sm_reg = (C_SM, "registerListener", ("Z", (C_SEL, C_SENSOR, "I")))
    m_sm_unreg = (C_SM, "unregisterListener", ("V", (C_SEL,)))
    m_sensor_get_type = (C_SENSOR, "getType", ("I", ()))
    f_se_values = (C_SE, "values", "[F")
    f_se_sensor = (C_SE, "sensor", C_SENSOR)
    m_prox_l_init = (C_PROX_L, "<init>", ("V", (C_CTX,)))

    m_wm_add = (C_WM, "addView", ("V", (C_VIEW, C_VG_LP)))
    m_wm_rem = (C_WM, "removeView", ("V", (C_VIEW,)))
    m_wmlp_init = (C_WM_LP, "<init>", ("V", ("I", "I", "I", "I", "I")))
    f_acc_key = (C_ACC, "consumedKeyCode", "I")

    m_nc_init = (C_NC, "<init>", ("V", (C_STR, C_CS, "I")))
    m_nc_set_lock = (C_NC, "setLockscreenVisibility", ("V", ("I",)))
    m_nm_create_ch = (C_NM, "createNotificationChannel", ("V", (C_NC,)))
    m_nm_notify = (C_NM, "notify", ("V", ("I", C_NOTIF_OBJ)))
    m_nm_cancel = (C_NM, "cancel", ("V", ("I",)))
    m_nb_init_ch = (C_NB, "<init>", ("V", (C_CTX, C_STR)))
    m_nb_init_old = (C_NB, "<init>", ("V", (C_CTX,)))
    m_nb_icon = (C_NB, "setSmallIcon", (C_NB, ("I",)))
    m_nb_title = (C_NB, "setContentTitle", (C_NB, (C_CS,)))
    m_nb_text = (C_NB, "setContentText", (C_NB, (C_CS,)))
    m_nb_cat = (C_NB, "setCategory", (C_NB, (C_STR,)))
    m_nb_prio = (C_NB, "setPriority", (C_NB, ("I",)))
    m_nb_vis = (C_NB, "setVisibility", (C_NB, ("I",)))
    m_nb_fsi = (C_NB, "setFullScreenIntent", (C_NB, (C_PI, "Z")))
    m_nb_auto = (C_NB, "setAutoCancel", (C_NB, ("Z",)))
    m_nb_build = (C_NB, "build", (C_NOTIF_OBJ, ()))

    m_ctrl_fmt_eng = (C_CTRL, "formatEngineLabel", (C_STR, (C_STR,)))
    m_ctrl_pct_flt = (C_CTRL, "pctToFloat", ("F", ("I",)))
    m_ctrl_fmt_rate = (C_CTRL, "formatRateLabel", (C_STR, ("I",)))
    m_ctrl_fmt_amode = (C_CTRL, "formatAudioModeLabel", (C_STR, ("I",)))
    m_ctrl_sanitize_prefs = (C_CTRL, "sanitizeButtonPrefs", ("V", (C_CTX,)))
    m_ctrl_cfg_speak = (C_CTRL, "configureAndSpeakActiveJob", ("V", ()))
    m_ctrl_reinit_tts = (C_CTRL, "reinitTts", ("V", (C_CTX, C_STR)))
    m_ctrl_eng_summary = (C_CTRL, "getInstalledTtsSummary", (C_STR, (C_CTX,)))
    m_tts_l_init = (C_TTS_L, "<init>", ("V", (C_TTS, C_STR, "I", C_STR)))
    f_ttsl_tts = (C_TTS_L, "tts", C_TTS)
    f_ttsl_voice = (C_TTS_L, "voiceName", C_STR)

    m_ctrl_init = (C_CTRL, "<init>", ("V", ()))
    m_ctrl_log = (C_CTRL, "log", ("V", (C_STR,)))
    m_ctrl_get_log = (C_CTRL, "getDiagReport", (C_STR, (C_CTX,)))
    m_ctrl_clear_log = (C_CTRL, "clearDiagLog", ("V", ()))
    m_ctrl_save_log = (C_CTRL, "saveDiagToDownload", (C_STR, (C_CTX,)))
    m_ctrl_get_prefs = (C_CTRL, "getPrefs", (C_SP, (C_CTX,)))
    m_ctrl_is_pref = (C_CTRL, "isPrefEnabled", ("Z", (C_CTX, C_STR, "Z")))
    m_ctrl_set_pref = (C_CTRL, "setPrefEnabled", ("V", (C_CTX, C_STR, "Z")))
    m_ctrl_can_trig = (C_CTRL, "canTriggerNow", ("Z", ()))
    m_ctrl_rec_state = (C_CTRL, "recordActiveCallState", ("V", ("I",)))
    m_ctrl_bind_notif = (C_CTRL, "ensureNotificationListenerBound", ("V", (C_CTX,)))
    m_ctrl_ring_mask = (C_CTRL, "getRingtoneMask", ("I", (C_CTX,)))
    m_ctrl_start_watch = (C_CTRL, "startRingtoneWatcher", ("V", (C_CTX,)))
    m_ctrl_watch_step = (C_CTRL, "checkRingtoneStep", ("V", (C_CTX,)))
    m_ctrl_confirm_sil = (C_CTRL, "confirmRingtoneSilenced", ("V", (C_CTX,)))
    m_ctrl_disp_key = (C_CTRL, "dispatchMediaKey", ("V", (C_CTX, "I")))
    m_ctrl_ans_pulse = (C_CTRL, "answerCallPulse", ("V", (C_CTX,)))
    m_ctrl_ans = (C_CTRL, "answerCall", ("V", (C_CTX,)))
    m_ctrl_end_pulse = (C_CTRL, "endCallPulse", ("V", (C_CTX,)))
    m_ctrl_end = (C_CTRL, "endCall", ("V", (C_CTX,)))
    m_ctrl_get_state = (C_CTRL, "getCallState", ("I", (C_CTX,)))
    m_ctrl_should_key = (C_CTRL, "shouldInterceptKey", ("Z", (C_CTX, "I")))
    m_ctrl_handle_btn = (C_CTRL, "handleHardwareButton", ("Z", (C_CTX, "I")))
    m_ctrl_has_phone = (C_CTRL, "hasPhonePermissions", ("Z", (C_CTX,)))
    m_ctrl_is_acc = (C_CTRL, "isAccessibilityEnabled", ("Z", (C_CTX,)))
    m_ctrl_is_notif = (C_CTRL, "isNotificationListenerEnabled", ("Z", (C_CTX,)))
    m_ctrl_is_batt = (C_CTRL, "isBatteryOptimizationIgnored", ("Z", (C_CTX,)))
    m_ctrl_all_perms = (C_CTRL, "areAllPermissionsGranted", ("Z", (C_CTX,)))

    f_notif_inst = (C_NOTIF, "instance", C_NOTIF)
    m_notif_refresh = (C_NOTIF, "refreshCallStatus", ("V", ()))
    m_notif_trigger = (C_NOTIF, "triggerCallNotificationAction", ("Z", ("Z",)))
    m_acc_click_ui = (C_ACC, "clickCallButtonInUi", ("Z", ("Z",)))
    m_acc_detect_ui = (C_ACC, "detectCallUiState", ("I", ()))
    m_acc_get_caps = (C_ACC, "getActiveCapabilities", ("I", ()))
    m_acc_find_caller = (C_ACC, "findCallerNameInUi", (C_STR, ()))
    m_acc_find_rec = (C_ACC, "findCallerNodeRec", (C_STR, (C_ACCNI,)))
    f_acc_inst = (C_ACC, "instance", C_ACC)

    m_run_act_init = (C_RUN_ACT, "<init>", ("V", (C_CTX, "I")))

    # 1.0a log(String v7) -> void
    code_ctrl_log = {
        "registers": 8, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_ctrl_diag),
            ("if-nez", 0, "has_str"),
            ("const-string", 0, ""),
            ("label", "has_str"),
            ("invoke-virtual", [0], m_str_len),
            ("move-result", 1),
            ("const/16", 2, 12000),
            ("if-le", 1, 2, "append_now"),
            ("const/16", 2, 3000),
            ("invoke-virtual", [0, 2], m_str_sub),
            ("move-result-object", 0),
            ("label", "append_now"),
            ("if-eqz", 7, "do_app_ts"),
            ("invoke-virtual", [7], m_str_len),
            ("move-result", 1),
            ("const/16", 2, 220),
            ("if-le", 1, 2, "do_app_ts"),
            ("const/4", 1, 0),
            ("invoke-virtual", [7, 1, 2], m_str_sub2),
            ("move-result-object", 7),
            ("label", "do_app_ts"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 4),
            ("new-instance", 6, C_SB),
            ("invoke-direct", [6], m_sb_init),
            ("invoke-virtual", [6, 0], m_sb_app_str),
            ("move-result-object", 6),
            ("const-string", 0, "• ["),
            ("invoke-virtual", [6, 0], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 4, 5], m_sb_app_long),
            ("move-result-object", 6),
            ("const-string", 0, "ms] "),
            ("invoke-virtual", [6, 0], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("const-string", 0, "\n"),
            ("invoke-virtual", [6, 0], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6], m_sb_tostr),
            ("move-result-object", 0),
            ("sput-object", 0, f_ctrl_diag),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.0b clearDiagLog() -> void
    code_clear_log = {
        "registers": 2, "ins": 0, "outs": 1,
        "insns": [
            ("const-string", 0, ""),
            ("sput-object", 0, f_ctrl_diag),
            ("const-string", 0, "Журнал очищен. Готов к проверке."),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
    }

    # 1.0c getDiagReport(Context v5) -> String
    code_get_log = {
        "registers": 6, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("invoke-static", [5], m_ctrl_sanitize_prefs),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("const-string", 1, "=== ДИАГНОСТИКА «УМНЫЙ ВЫЗОВ» v2.3.6 ===\nУстройство: "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_build_manuf),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, " "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_build_model),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, " ("),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_build_device),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ") | Android "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_build_rel),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, " (SDK "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget", 2, f_sdk_int),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, ") | Cap="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [], m_acc_get_caps),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "\nПрошивка: "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_build_disp),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),

            ("const-string", 1, "\nРазрешения: Тел="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_has_phone),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Контакты="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_has_contacts),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", SMS="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_has_sms),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", СпецВозм="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_is_acc),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Уведомл="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_is_notif),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Батарея="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_is_batt),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),

            ("const-string", 1, "\nКнопки: Master="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "enabled"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", AnsUp="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "ans_vol_up"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", AnsDn="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "ans_vol_down"),
            ("const/4", 3, 0),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", EndDn="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "end_vol_down"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", EndUp="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "end_vol_up"),
            ("const/4", 3, 0),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Ухо="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "ear_pickup"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),


            # TTS Settings
            ("const-string", 1, "\nОзвучка (TTS): Вкл="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_enabled"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", НезнакомНомера="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_read_unknown"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Повтор="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_repeat"),
            ("const/4", 3, 2),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, ", SIM="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_app_sim"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", WA="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_app_wa"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", TG="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_app_tg"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", Другие="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_app_other"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", SMS="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_app_sms"),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ", ТекстSMS="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_sms_text"),
            ("const/4", 3, 1),
            ("invoke-static", [5, 1, 3], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),

            # Per-App TTS Engines (Russian formatted)
            ("const-string", 1, "\nДвижки TTS: SIM="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_eng_sim"),
            ("const-string", 3, "default"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ", WA="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_eng_wa"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ", TG="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_eng_tg"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ", Др="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_eng_other"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ", SMS="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_eng_sms"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "\n"),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_features_profiles),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "\nСкорость TTS: SIM="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_rate_sim"),
            ("const/16", 3, 100),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%, WA="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_rate_wa"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%, TG="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_rate_tg"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%, Др="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_rate_other"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%, SMS="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_rate_sms"),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%\nАудиоканал TTS: "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_audio_mode"),
            ("const/4", 3, 0),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_amode),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, ", СобствГромк="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "tts_custom_vol"),
            ("const/16", 3, 100),
            ("invoke-static", [5, 1, 3], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, "%"),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),

            # Installed TTS Engines & Audio / Call state
            ("const-string", 1, "\nУстановленные TTS: "),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_eng_summary),
            ("move-result-object", 2),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 1, "\nСостояние: CallState="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget", 2, f_ctrl_last_call_state),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, ", RingMask="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-static", [5], m_ctrl_ring_mask),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 1, ", VoIP(Inc="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-boolean", 2, f_ctrl_voip_inc),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ",Ong="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-boolean", 2, f_ctrl_voip_ong),
            ("invoke-virtual", [0, 2], m_sb_app_bool),
            ("move-result-object", 0),
            ("const-string", 1, ")\n--- ЖУРНАЛ СОБЫТИЙ ---\n"),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("sget-object", 1, f_ctrl_diag),
            ("if-nez", 1, "has_d"),
            ("const-string", 1, "(Событий пока нет — позвоните для проверки)\n"),
            ("label", "has_d"),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-object", 0),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("return-object", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.0d saveDiagToDownload(Context v5) -> String (path or error)
    code_save_log = {
        "registers": 6, "ins": 1, "outs": 3,
        "insns": [
            ("invoke-static", [5], m_ctrl_get_log),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_str_bytes),
            ("move-result-object", 0),

            ("label", "t1_s"),
            ("const-string", 1, "Download"),
            ("invoke-static", [1], m_env_get_pub),
            ("move-result-object", 1),
            ("new-instance", 2, C_FILE),
            ("const-string", 3, "Umnyj_Vyzov_Diagnostika.txt"),
            ("invoke-direct", [2, 1, 3], m_file_init_parent),
            ("new-instance", 4, C_FOS),
            ("invoke-direct", [4, 2], m_fos_init),
            ("invoke-virtual", [4, 0], m_fos_write),
            ("invoke-virtual", [4], m_fos_close),
            ("invoke-virtual", [2], m_file_get_path),
            ("move-result-object", 1),
            ("label", "t1_e"),
            ("return-object", 1),

            ("label", "c1"),
            ("move-exception", 1),
            ("label", "t2_s"),
            ("const/4", 1, 0),
            ("invoke-virtual", [5, 1], m_ctx_get_ext),
            ("move-result-object", 1),
            ("new-instance", 2, C_FILE),
            ("const-string", 3, "Umnyj_Vyzov_Diagnostika.txt"),
            ("invoke-direct", [2, 1, 3], m_file_init_parent),
            ("new-instance", 4, C_FOS),
            ("invoke-direct", [4, 2], m_fos_init),
            ("invoke-virtual", [4, 0], m_fos_write),
            ("invoke-virtual", [4], m_fos_close),
            ("invoke-virtual", [2], m_file_get_path),
            ("move-result-object", 1),
            ("label", "t2_e"),
            ("return-object", 1),

            ("label", "c2"),
            ("move-exception", 1),
            ("invoke-virtual", [1], m_thr_tostr),
            ("move-result-object", 1),
            ("return-object", 1),
        ],
        "tries": [
            {"start_label": "t1_s", "end_label": "t1_e", "handler_label": "c1"},
            {"start_label": "t2_s", "end_label": "t2_e", "handler_label": "c2"},
        ],
    }

    # 1.1 getPrefs(Context v2) -> SharedPreferences
    code_get_prefs = {
        "registers": 3, "ins": 1, "outs": 3,
        "insns": [
            ("const-string", 0, "call_prefs"),
            ("const/4", 1, 0),
            ("invoke-virtual", [2, 0, 1], m_ctx_get_sp),
            ("move-result-object", 0),
            ("return-object", 0),
        ],
    }

    # 1.2 isPrefEnabled(Context v1, String v2, boolean v3) -> boolean
    code_is_pref = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sp_get_bool),
            ("move-result", 0),
            ("return", 0),
        ],
    }

    # 1.3 setPrefEnabled(Context v1, String v2, boolean v3) -> void
    code_set_pref = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sp_edit),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sped_put_bool),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sped_apply),
            ("return-void",),
        ],
    }

    # 1.3b getPrefInt(Context v1, String v2, int v3) -> int
    code_get_int = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sp_get_int),
            ("move-result", 0),
            ("return", 0),
        ],
    }

    # 1.3c setPrefInt(Context v1, String v2, int v3) -> void
    code_set_int = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sp_edit),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sped_put_int),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sped_apply),
            ("return-void",),
        ],
    }

    # 1.3d getPrefStr(Context v1, String v2, String v3) -> String
    code_get_str = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sp_get_str),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_def"),
            ("return-object", 0),
            ("label", "ret_def"),
            ("return-object", 3),
        ],
    }

    # 1.3e setPrefStr(Context v1, String v2, String v3) -> void
    code_set_str = {
        "registers": 4, "ins": 3, "outs": 3,
        "insns": [
            ("invoke-static", [1], m_ctrl_get_prefs),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sp_edit),
            ("move-result-object", 0),
            ("invoke-interface", [0, 2, 3], m_sped_put_str),
            ("move-result-object", 0),
            ("invoke-interface", [0], m_sped_apply),
            ("return-void",),
        ],
    }

    # 1.3f hasContactsPermission(Context v2) -> boolean
    code_has_contacts = {
        "registers": 3, "ins": 1, "outs": 2,
        "insns": [
            ("const-string", 0, "android.permission.READ_CONTACTS"),
            ("invoke-virtual", [2, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_f"),
            ("const/4", 1, 1),
            ("return", 1),
            ("label", "ret_f"),
            ("const/4", 1, 0),
            ("return", 1),
        ],
    }

    # 1.3g hasSmsPermission(Context v2) -> boolean
    code_has_sms = {
        "registers": 3, "ins": 1, "outs": 2,
        "insns": [
            ("const-string", 0, "android.permission.RECEIVE_SMS"),
            ("invoke-virtual", [2, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_f"),
            ("const/4", 1, 1),
            ("return", 1),
            ("label", "ret_f"),
            ("const/4", 1, 0),
            ("return", 1),
        ],
    }

    # 1.3h lookupContactName(Context v8, String v9_number) -> String (or null if not found)
    code_lookup_contact = {
        "registers": 10, "ins": 2, "outs": 6,
        "insns": [
            ("const/4", 7, 0),
            ("if-eqz", 8, "ret"),
            ("if-eqz", 9, "ret"),
            ("invoke-virtual", [9], m_str_len),
            ("move-result", 0),
            ("if-lez", 0, "ret"),
            ("invoke-static", [8], m_ctrl_has_contacts),
            ("move-result", 0),
            ("if-eqz", 0, "ret"),
            ("label", "ts"),
            ("invoke-static", [9], m_uri_encode),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret"),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 2, "content://com.android.contacts/phone_lookup/"),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 0], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-static", [1], m_uri_parse),
            ("move-result-object", 1),
            ("invoke-virtual", [8], m_ctx_get_cr),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret"),
            ("const/4", 3, 1),
            ("new-array", 2, 3, "[Ljava/lang/String;"),
            ("const/4", 3, 0),
            ("const-string", 4, "display_name"),
            ("aput-object", 4, 2, 3),
            ("const/4", 3, 0),
            ("const/4", 4, 0),
            ("const/4", 5, 0),
            ("invoke-virtual/range", [0, 1, 2, 3, 4, 5], m_cr_query),
            ("move-result-object", 6),
            ("if-eqz", 6, "ret"),
            ("invoke-interface", [6], m_cur_first),
            ("move-result", 0),
            ("if-eqz", 0, "close_c"),
            ("const/4", 0, 0),
            ("invoke-interface", [6, 0], m_cur_get_str),
            ("move-result-object", 7),
            ("label", "close_c"),
            ("invoke-interface", [6], m_cur_close),
            ("label", "te"),
            ("label", "ret"),
            ("return-object", 7),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-object", 7),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3i hasLetters(String v5) -> boolean
    # Returns true if v5 contains any alphabetic letter (Latin or Cyrillic: >= 'A' (65))
    code_has_letters = {
        "registers": 6, "ins": 1, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("if-eqz", 5, "ret"),
            ("label", "ts"),
            ("invoke-virtual", [5], m_str_len),
            ("move-result", 1),
            ("const/4", 2, 0),
            ("label", "loop"),
            ("if-ge", 2, 1, "ret"),
            ("invoke-virtual", [5, 2], m_str_charat),
            ("move-result", 3),
            ("const/16", 4, 65),
            ("if-lt", 3, 4, "next"),
            ("const/4", 0, 1),
            ("return", 0),
            ("label", "next"),
            ("add-int/lit8", 2, 2, 1),
            ("goto/16", "loop"),
            ("label", "te"),
            ("label", "ret"),
            ("return", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3j formatDigitsForSpeech(String v6) -> String
    # Spaces out digits ('0'..'9') so TTS reads phone numbers digit by digit clearly
    code_format_digits = {
        "registers": 7, "ins": 1, "outs": 2,
        "insns": [
            ("if-eqz", 6, "ret_orig"),
            ("label", "ts"),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("invoke-virtual", [6], m_str_len),
            ("move-result", 1),
            ("const/4", 2, 0),
            ("label", "loop"),
            ("if-ge", 2, 1, "done_loop"),
            ("invoke-virtual", [6, 2], m_str_charat),
            ("move-result", 3),
            ("const/16", 4, 48),
            ("if-lt", 3, 4, "check_plus"),
            ("const/16", 4, 57),
            ("if-gt", 3, 4, "check_plus"),
            ("add-int/lit8", 4, 3, -48),
            ("invoke-virtual", [0, 4], m_sb_app_int),
            ("move-result-object", 0),
            ("const-string", 5, " "),
            ("invoke-virtual", [0, 5], m_sb_app_str),
            ("move-result-object", 0),
            ("goto/16", "next"),
            ("label", "check_plus"),
            ("const/16", 4, 43),
            ("if-ne", 3, 4, "next"),
            ("const-string", 5, "плюс "),
            ("invoke-virtual", [0, 5], m_sb_app_str),
            ("move-result-object", 0),
            ("label", "next"),
            ("add-int/lit8", 2, 2, 1),
            ("goto/16", "loop"),
            ("label", "done_loop"),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_str_len),
            ("move-result", 1),
            ("if-lez", 1, "ret_orig"),
            ("label", "te"),
            ("return-object", 0),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "ret_orig"),
            ("return-object", 6),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3k stopTts() -> void
    code_stop_tts = {
        "registers": 2, "ins": 0, "outs": 1,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_ctrl_tts),
            ("if-eqz", 0, "te"),
            ("invoke-virtual", [0], m_tts_stop),
            ("move-result", 1),
            ("invoke-virtual", [0], m_tts_shutdown),
            ("const/4", 0, 0),
            ("sput-object", 0, f_ctrl_tts),
            ("label", "te"),
            ("invoke-static", [], m_features_stop),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-static", [], m_features_stop),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3k1 reinitTts(Context v4, String v5_eng) -> void
    code_reinit_tts = {
        "registers": 6, "ins": 2, "outs": 5,
        "insns": [
            ("if-eqz", 4, "done"),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("label", "ts"),
            ("new-instance", 0, C_TTS_L),
            ("const/4", 1, 0),
            ("const/4", 2, 0),
            ("const-string", 3, "default"),
            ("invoke-direct", [0, 1, 1, 2, 3], m_tts_l_init),
            ("if-eqz", 5, "init_def"),
            ("const-string", 1, "default"),
            ("invoke-virtual", [1, 5], m_str_equals),
            ("move-result", 1),
            ("if-nez", 1, "init_def"),
            ("invoke-virtual", [5], m_str_len),
            ("move-result", 1),
            ("if-lez", 1, "init_def"),
            ("new-instance", 1, C_TTS),
            ("invoke-direct", [1, 4, 0, 5], m_tts_init_3),
            ("goto/16", "save_t"),
            ("label", "init_def"),
            ("new-instance", 1, C_TTS),
            ("invoke-direct", [1, 4, 0], m_tts_init_2),
            ("label", "save_t"),
            ("iput-object", 1, 0, f_ttsl_tts),
            ("sput-object", 1, f_ctrl_tts),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3k2 formatEngineLabel(String v2) -> String
    code_fmt_eng = {
        "registers": 3, "ins": 1, "outs": 2,
        "insns": [
            ("if-eqz", 2, "ret_def"),
            ("invoke-virtual", [2], m_str_len),
            ("move-result", 0),
            ("if-lez", 0, "ret_def"),
            ("const-string", 0, "default"),
            ("invoke-virtual", [0, 2], m_str_equals),
            ("move-result", 0),
            ("if-nez", 0, "ret_def"),
            ("const-string", 0, "preset_"),
            ("invoke-virtual", [2, 0], m_str_contains),
            ("move-result", 0),
            ("if-nez", 0, "ret_def"),
            ("return-object", 2),
            ("label", "ret_def"),
            ("const-string", 0, "По умолчанию"),
            ("return-object", 0),
        ],
    }

    # 1.3k3 pctToFloat(int v2) -> float
    code_pct_flt = {
        "registers": 3, "ins": 1, "outs": 0,
        "insns": [
            ("const/16", 0, 15),
            ("if-ne", 2, 0, "c30"),
            ("const", 1, 0x3E19999A),
            ("return", 1),
            ("label", "c30"),
            ("const/16", 0, 30),
            ("if-ne", 2, 0, "c45"),
            ("const", 1, 0x3E99999A),
            ("return", 1),
            ("label", "c45"),
            ("const/16", 0, 45),
            ("if-ne", 2, 0, "c50"),
            ("const", 1, 0x3EE66666),
            ("return", 1),
            ("label", "c50"),
            ("const/16", 0, 50),
            ("if-ne", 2, 0, "c60"),
            ("const", 1, 0x3F000000),
            ("return", 1),
            ("label", "c60"),
            ("const/16", 0, 60),
            ("if-ne", 2, 0, "c75"),
            ("const", 1, 0x3F19999A),
            ("return", 1),
            ("label", "c75"),
            ("const/16", 0, 75),
            ("if-ne", 2, 0, "c90"),
            ("const", 1, 0x3F400000),
            ("return", 1),
            ("label", "c90"),
            ("const/16", 0, 90),
            ("if-ne", 2, 0, "c115"),
            ("const", 1, 0x3F666666),
            ("return", 1),
            ("label", "c115"),
            ("const/16", 0, 115),
            ("if-ne", 2, 0, "c125"),
            ("const", 1, 0x3F933333),
            ("return", 1),
            ("label", "c125"),
            ("const/16", 0, 125),
            ("if-ne", 2, 0, "c150"),
            ("const", 1, 0x3FA00000),
            ("return", 1),
            ("label", "c150"),
            ("const/16", 0, 150),
            ("if-ne", 2, 0, "c175"),
            ("const", 1, 0x3FC00000),
            ("return", 1),
            ("label", "c175"),
            ("const/16", 0, 175),
            ("if-ne", 2, 0, "c200"),
            ("const", 1, 0x3FE00000),
            ("return", 1),
            ("label", "c200"),
            ("const/16", 0, 200),
            ("if-ne", 2, 0, "c100"),
            ("const", 1, 0x40000000),
            ("return", 1),
            ("label", "c100"),
            ("const", 1, 0x3F800000),
            ("return", 1),
        ],
    }

    # 1.3k4 formatRateLabel(int v2) -> String
    code_fmt_rate = {
        "registers": 3, "ins": 1, "outs": 0,
        "insns": [
            ("const/16", 0, 50),
            ("if-ne", 2, 0, "r75"),
            ("const-string", 1, "0.5x (Очень медленно)"),
            ("return-object", 1),
            ("label", "r75"),
            ("const/16", 0, 75),
            ("if-ne", 2, 0, "r90"),
            ("const-string", 1, "0.75x (Медленно)"),
            ("return-object", 1),
            ("label", "r90"),
            ("const/16", 0, 90),
            ("if-ne", 2, 0, "r115"),
            ("const-string", 1, "0.9x (Чуть медленнее)"),
            ("return-object", 1),
            ("label", "r115"),
            ("const/16", 0, 115),
            ("if-ne", 2, 0, "r125"),
            ("const-string", 1, "1.15x (Чуть быстрее)"),
            ("return-object", 1),
            ("label", "r125"),
            ("const/16", 0, 125),
            ("if-ne", 2, 0, "r150"),
            ("const-string", 1, "1.25x (Быстро)"),
            ("return-object", 1),
            ("label", "r150"),
            ("const/16", 0, 150),
            ("if-ne", 2, 0, "r175"),
            ("const-string", 1, "1.5x (Очень быстро)"),
            ("return-object", 1),
            ("label", "r175"),
            ("const/16", 0, 175),
            ("if-ne", 2, 0, "r200"),
            ("const-string", 1, "1.75x (Ускоренная)"),
            ("return-object", 1),
            ("label", "r200"),
            ("const/16", 0, 200),
            ("if-ne", 2, 0, "r100"),
            ("const-string", 1, "2.0x (Максимальная)"),
            ("return-object", 1),
            ("label", "r100"),
            ("const-string", 1, "1.0x (Обычная)"),
            ("return-object", 1),
        ],
    }

    # 1.3k5 formatAudioModeLabel(int v2) -> String
    code_fmt_amode = {
        "registers": 3, "ins": 1, "outs": 0,
        "insns": [
            ("const/4", 0, 1),
            ("if-ne", 2, 0, "m2"),
            ("const-string", 1, "Канал Мультимедиа (Медиа)"),
            ("return-object", 1),
            ("label", "m2"),
            ("const/4", 0, 2),
            ("if-ne", 2, 0, "m3"),
            ("const-string", 1, "Канал Звонка (Мелодия вызова)"),
            ("return-object", 1),
            ("label", "m3"),
            ("const/4", 0, 3),
            ("if-ne", 2, 0, "m0"),
            ("const-string", 1, "Собственная громкость (Отдельно)"),
            ("return-object", 1),
            ("label", "m0"),
            ("const-string", 1, "Канал Специальные возможности"),
            ("return-object", 1),
        ],
    }

    # 1.3k6 sanitizeButtonPrefs(Context v3) -> void
    code_sanitize_prefs = {
        "registers": 4, "ins": 1, "outs": 3,
        "insns": [
            ("if-eqz", 3, "done"),
            ("label", "ts"),
            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 1),
            ("invoke-static", [3, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "check_end"),
            ("const-string", 0, "ans_vol_down"),
            ("const/4", 1, 0),
            ("invoke-static", [3, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-eqz", 2, "check_end"),
            ("invoke-static", [3, 0, 1], m_ctrl_set_pref),

            ("label", "check_end"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [3, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "te"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [3, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-eqz", 2, "te"),
            ("invoke-static", [3, 0, 1], m_ctrl_set_pref),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3k7 configureAndSpeakActiveJob() -> void
    code_cfg_speak = {
        "registers": 12, "ins": 0, "outs": 5,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_features_active),
            ("if-eqz", 0, "done"),
            ("iget-object", 1, 0, f_job_tts),
            ("if-eqz", 1, "done"),
            ("iget-object", 2, 0, f_job_ctx),
            ("if-eqz", 2, "done"),
            ("iget-object", 3, 0, f_job_channel),
            ("if-nez", 3, "has_ch"),
            ("const-string", 3, "sim"),
            ("label", "has_ch"),
            ("iget-object", 4, 0, f_job_text),
            ("if-eqz", 4, "done"),
            ("iget", 5, 0, f_job_repeat),
            ("if-lez", 5, "def_rep"),
            ("goto/16", "calc_rate"),
            ("label", "def_rep"),
            ("const/4", 5, 1),

            # 1. Read tts_rate_<channel> and apply setPitch(1.0f) + setSpeechRate(rate)
            ("label", "calc_rate"),
            ("new-instance", 6, C_SB),
            ("invoke-direct", [6], m_sb_init),
            ("const-string", 7, "tts_rate_"),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 3], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6], m_sb_tostr),
            ("move-result-object", 6),
            ("const/16", 7, 100),
            ("invoke-static", [2, 6, 7], m_ctrl_get_int),
            ("move-result", 9),
            ("invoke-static", [9], m_ctrl_pct_flt),
            ("move-result", 6),
            ("const", 7, 0x3F800000),
            ("invoke-virtual", [1, 7], m_tts_set_pitch),
            ("move-result", 7),
            ("invoke-virtual", [1, 6], m_tts_set_rate),
            ("move-result", 7),

            # 2. Read tts_audio_mode (0=Acc, 1=Media, 2=Ring, 3=CustomVol) and tts_custom_vol
            ("const-string", 6, "tts_audio_mode"),
            ("const/4", 7, 0),
            ("invoke-static", [2, 6, 7], m_ctrl_get_int),
            ("move-result", 10),

            ("const-string", 6, "tts_custom_vol"),
            ("const/16", 7, 100),
            ("invoke-static", [2, 6, 7], m_ctrl_get_int),
            ("move-result", 11),

            # Map audioMode -> v7=usage, v8=streamType
            ("const/16", 7, 11),
            ("const/16", 8, 10),
            ("const/4", 6, 1),
            ("if-ne", 10, 6, "check_am2"),
            ("const/4", 7, 1),
            ("const/4", 8, 3),
            ("goto/16", "apply_aattr"),
            ("label", "check_am2"),
            ("const/4", 6, 2),
            ("if-ne", 10, 6, "check_am3"),
            ("const/4", 7, 6),
            ("const/4", 8, 2),
            ("goto/16", "apply_aattr"),
            ("label", "check_am3"),
            ("const/4", 6, 3),
            ("if-ne", 10, 6, "apply_aattr"),
            ("const/4", 7, 1),
            ("const/4", 8, 3),

            ("label", "apply_aattr"),
            ("new-instance", 6, C_AATTR_B),
            ("invoke-direct", [6], m_aattrb_init),
            ("invoke-virtual", [6, 7], m_aattrb_usage),
            ("move-result-object", 6),
            ("const/4", 7, 1),
            ("invoke-virtual", [6, 7], m_aattrb_ctype),
            ("move-result-object", 6),
            ("invoke-virtual", [6], m_aattrb_build),
            ("move-result-object", 6),
            ("invoke-virtual", [1, 6], m_tts_set_attr),
            ("move-result", 7),

            # 3. Build Bundle (avoid forcing streamType=10 when audioMode==0 so AudioService does not broadcast VOLUME_CHANGED_ACTION)
            ("new-instance", 6, C_BUNDLE),
            ("invoke-direct", [6], m_bundle_init),
            ("if-eqz", 10, "put_vol_b"),
            ("const-string", 7, "streamType"),
            ("invoke-virtual", [6, 7, 8], m_bundle_put_int),
            ("label", "put_vol_b"),
            ("invoke-static", [11], m_ctrl_pct_flt),
            ("move-result", 8),
            ("const-string", 7, "volume"),
            ("invoke-virtual", [6, 7, 8], m_bundle_put_flt),

            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 7),
            ("sput-wide", 7, f_ctrl_last_tts_time),

            # 4. Set job.lastId = "sc_done" and speak chunks
            ("const-string", 7, "sc_done"),
            ("iput-object", 7, 0, f_job_lastid),

            ("const/4", 7, 0),
            ("label", "sp_loop"),
            ("if-ge", 7, 5, "sp_ok"),
            ("const/4", 8, 1),
            ("if-eqz", 7, "q_flush"),
            ("goto/16", "pick_id"),
            ("label", "q_flush"),
            ("const/4", 8, 0),
            ("label", "pick_id"),
            ("add-int/lit8", 2, 5, -1),
            ("if-eq", 7, 2, "id_last"),
            ("const-string", 3, "sc_rep"),
            ("goto/16", "do_sp"),
            ("label", "id_last"),
            ("const-string", 3, "sc_done"),
            ("label", "do_sp"),
            ("invoke-virtual", [1, 4, 8, 6, 3], m_tts_speak),
            ("move-result", 8),
            ("if-nez", 8, "sp_fail"),
            ("add-int/lit8", 7, 7, 1),
            ("goto/16", "sp_loop"),

            ("label", "sp_fail"),
            ("const/4", 7, 0),
            ("iput-object", 7, 0, f_job_lastid),
            ("new-instance", 6, C_SB),
            ("invoke-direct", [6], m_sb_init),
            ("const-string", 7, "TTS: speak отклонён, код="),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 8], m_sb_app_int),
            ("move-result-object", 6),
            ("invoke-virtual", [6], m_sb_tostr),
            ("move-result-object", 6),
            ("invoke-static", [6], m_ctrl_log),
            ("return-void",),

            ("label", "sp_ok"),
            ("new-instance", 6, C_SB),
            ("invoke-direct", [6], m_sb_init),
            ("const-string", 7, "TTS: скорость="),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 9], m_sb_app_int),
            ("move-result-object", 6),
            ("const-string", 7, "%, канал="),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-static", [10], m_ctrl_fmt_amode),
            ("move-result-object", 7),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("const-string", 7, ", громк="),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6, 11], m_sb_app_int),
            ("move-result-object", 6),
            ("const-string", 7, "%"),
            ("invoke-virtual", [6, 7], m_sb_app_str),
            ("move-result-object", 6),
            ("invoke-virtual", [6], m_sb_tostr),
            ("move-result-object", 6),
            ("invoke-static", [6], m_ctrl_log),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3l speakText(Context v5, String v6_text, String v7_enginePkg, int v8_repeatCount) -> void
    code_speak = {"registers": 4, "ins": 4, "outs": 4,
        "insns": [("invoke-static", [0, 1, 2, 3], m_features_legacy), ("return-void",)]}

    # 1.3m announceIncomingCall(Context v8, String v9_pkg, String v10_rawCaller) -> void
    code_ann_call = {
        "registers": 11, "ins": 3, "outs": 4,
        "insns": [
            ("if-eqz", 8, "done"),
            ("if-eqz", 10, "done"),
            ("invoke-static", [10], m_features_clean),
            ("move-result-object", 10),
            ("invoke-virtual", [10], m_str_len),
            ("move-result", 0),
            ("if-lez", 0, "done"),

            ("const-string", 0, "tts_enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [8, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),

            ("if-nez", 9, "has_pkg"),
            ("const-string", 9, "sim"),
            ("label", "has_pkg"),

            # Deduplicate any repeat call announcement within 5000ms so ongoing speech is never cut off!
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sget-wide", 2, f_ctrl_last_tts_time),
            ("sub-long/2addr", 0, 2),
            ("const-wide/16", 2, 5000),
            ("cmp-long", 4, 0, 2),
            ("if-ltz", 4, "done"),

            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sput-wide", 0, f_ctrl_last_tts_time),
            ("sput-object", 10, f_ctrl_last_tts_text),
            ("sput-object", 9, f_ctrl_last_call_pkg),
            ("sput-object", 10, f_ctrl_last_caller),

            ("invoke-virtual", [9], m_str_lower),
            ("move-result-object", 0),
            ("const-string", 1, "whatsapp"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "cat_wa"),

            ("const-string", 1, "telegram"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "cat_tg"),
            ("const-string", 1, "nekogram"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "cat_tg"),

            ("const-string", 1, "viber"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "cat_other"),
            ("const-string", 1, "imo"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "cat_other"),

            # Default: SIM call
            ("const-string", 2, "tts_app_sim"),
            ("const-string", 3, "tts_eng_sim"),
            ("const-string", 4, ""),
            ("goto/16", "check_cat_en"),

            ("label", "cat_wa"),
            ("const-string", 2, "tts_app_wa"),
            ("const-string", 3, "tts_eng_wa"),
            ("const-string", 4, ""),
            ("goto/16", "check_cat_en"),

            ("label", "cat_tg"),
            ("const-string", 2, "tts_app_tg"),
            ("const-string", 3, "tts_eng_tg"),
            ("const-string", 4, ""),
            ("goto/16", "check_cat_en"),

            ("label", "cat_other"),
            ("const-string", 2, "tts_app_other"),
            ("const-string", 3, "tts_eng_other"),
            ("const-string", 4, ""),

            ("label", "check_cat_en"),
            ("const/4", 1, 1),
            ("invoke-static", [8, 2, 1], m_ctrl_is_pref),
            ("move-result", 1),
            ("if-eqz", 1, "done"),

            # Resolve caller name vs unknown number
            ("invoke-static", [10], m_ctrl_has_letters),
            ("move-result", 1),
            ("if-nez", 1, "caller_is_name"),

            ("invoke-static", [8, 10], m_ctrl_lookup_contact),
            ("move-result-object", 5),
            ("if-eqz", 5, "not_in_contacts"),
            ("move-object", 10, 5),
            ("goto/16", "caller_is_name"),

            ("label", "not_in_contacts"),
            ("const-string", 1, "tts_read_unknown"),
            ("const/4", 2, 1),
            ("invoke-static", [8, 1, 2], m_ctrl_is_pref),
            ("move-result", 1),
            ("if-nez", 1, "read_unk_ok"),
            ("const-string", 1, "TTS: номер не в контактах (чтение незнакомых номеров отключено)"),
            ("invoke-static", [1], m_ctrl_log),
            ("return-void",),

            ("label", "read_unk_ok"),
            ("invoke-virtual", [10], m_str_len),
            ("move-result", 1),
            ("if-lez", 1, "unk_fallback"),
            ("invoke-static", [10], m_ctrl_format_digits),
            ("move-result-object", 10),
            ("goto/16", "caller_is_name"),
            ("label", "unk_fallback"),
            ("const-string", 10, "неизвестный номер"),

            ("label", "caller_is_name"),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("invoke-virtual", [0, 4], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0, 10], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 0),

            ("const-string", 1, "tts_repeat"),
            ("const/4", 2, 2),
            ("invoke-static", [8, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [8, 0, 3, 2], m_features_speak),

            ("label", "done"),
            ("return-void",),
        ],
    }

    # 1.3n announceIncomingSms(Context v7, String v8_sender, String v9_body) -> void
    code_ann_sms = {"registers": 4, "ins": 3, "outs": 4,
        "insns": [("sget-object", 0, f_ctrl_last_sms_pkg),
                  ("invoke-static", [1, 0, 2, 3], m_features_sms), ("return-void",)]}

    # 1.3n2 isMediaOrOngoingNotification(StatusBarNotification v6) -> boolean
    # Filters out voice message / music playback notifications, ongoing events, media sessions, and progress bars
    code_is_media_notif = {
        "registers": 7, "ins": 1, "outs": 3,
        "insns": [
            ("if-eqz", 6, "ret_f"),
            ("label", "ts"),
            ("invoke-virtual", [6], m_sbn_get_notif),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_f"),

            # 1. Check category
            ("iget-object", 1, 0, f_notif_cat),
            ("if-eqz", 1, "check_flags"),
            ("const-string", 2, "call"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_f"),
            ("const-string", 2, "transport"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),
            ("const-string", 2, "service"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),
            ("const-string", 2, "progress"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),
            ("const-string", 2, "status"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),
            ("const-string", 2, "sys"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),

            # 2. Check flags: FLAG_ONGOING_EVENT (0x02) | FLAG_NO_CLEAR (0x20) | FLAG_GROUP_SUMMARY (0x200) = 0x222
            ("label", "check_flags"),
            ("iget", 1, 0, f_notif_flags),
            ("const/16", 2, 0x222),
            ("and-int/2addr", 1, 2),
            ("if-nez", 1, "ret_t"),

            # 3. Check extras: android.mediaSession, android.progressMax, android.template (MediaStyle)
            ("iget-object", 1, 0, f_notif_extras),
            ("if-eqz", 1, "check_actions"),
            ("const-string", 2, "android.mediaSession"),
            ("invoke-virtual", [1, 2], m_bundle_contains),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),
            ("const-string", 2, "android.progressMax"),
            ("const/4", 3, 0),
            ("invoke-virtual", [1, 2, 3], m_bundle_get_int),
            ("move-result", 3),
            ("if-gtz", 3, "ret_t"),
            ("const-string", 2, "android.template"),
            ("invoke-virtual", [1, 2], m_bundle_get),
            ("move-result-object", 3),
            ("if-eqz", 3, "check_text_body"),
            ("invoke-virtual", [3], m_obj_tostr),
            ("move-result-object", 3),
            ("invoke-virtual", [3], m_str_lower),
            ("move-result-object", 3),
            ("const-string", 2, "media"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "ret_t"),

            ("label", "check_text_body"),
            ("const-string", 2, "android.text"),
            ("invoke-virtual", [1, 2], m_bundle_get),
            ("move-result-object", 3),
            ("if-eqz", 3, "check_audio_mode"),
            ("invoke-virtual", [3], m_obj_tostr),
            ("move-result-object", 3),
            ("invoke-virtual", [3], m_str_lower),
            ("move-result-object", 3),
            ("const-string", 2, "голосовое сообщ"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "ret_t"),
            ("const-string", 2, "voice message"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "ret_t"),
            ("const-string", 2, "🎤"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "ret_t"),
            ("const-string", 2, "🎵"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "ret_t"),
            ("const-string", 2, "🎧"),
            ("invoke-virtual", [3, 2], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "ret_t"),

            ("label", "check_audio_mode"),
            ("sget-boolean", 2, f_ctrl_voip_ong),
            ("if-nez", 2, "check_actions"),
            ("sget-object", 2, f_notif_inst),
            ("if-eqz", 2, "check_actions"),
            ("const-string", 3, "audio"),
            ("invoke-virtual", [2, 3], m_ctx_get_sys),
            ("move-result-object", 2),
            ("check-cast", 2, C_AUDIO),
            ("if-eqz", 2, "check_actions"),
            ("invoke-virtual", [2], m_audio_mode),
            ("move-result", 2),
            ("const/4", 3, 3),
            ("if-eq", 2, 3, "ret_t"),

            # 4. Check actions: Play / Pause / Stop buttons on voice message / music notifications
            ("label", "check_actions"),
            ("iget-object", 1, 0, f_notif_actions),
            ("if-eqz", 1, "ret_f"),
            ("array-length", 2, 1),
            ("const/4", 3, 0),
            ("label", "act_loop"),
            ("if-ge", 3, 2, "ret_f"),
            ("aget-object", 4, 1, 3),
            ("if-eqz", 4, "act_next"),
            ("iget-object", 4, 4, f_nact_title),
            ("if-eqz", 4, "act_next"),
            ("invoke-interface", [4], m_cs_tostr),
            ("move-result-object", 4),
            ("invoke-virtual", [4], m_str_lower),
            ("move-result-object", 4),
            ("const-string", 5, "пауза"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("const-string", 5, "pause"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("const-string", 5, "воспроизв"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("const-string", 5, "play"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("const-string", 5, "стоп"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("const-string", 5, "stop"),
            ("invoke-virtual", [4, 5], m_str_contains),
            ("move-result", 5),
            ("if-nez", 5, "ret_t"),
            ("label", "act_next"),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "act_loop"),
            ("label", "te"),

            ("label", "ret_f"),
            ("const/4", 0, 0),
            ("return", 0),
            ("label", "ret_t"),
            ("const/4", 0, 1),
            ("return", 0),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 0, 0),
            ("return", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.3o getInstalledTtsSummary(Context v6) -> String
    # Uses cachedEnginesSummary so refreshing UI never creates or touches f_ctrl_tts!
    code_eng_summary = {
        "registers": 7, "ins": 1, "outs": 3,
        "insns": [
            ("sget-object", 0, f_ctrl_eng_cache),
            ("if-eqz", 0, "compute_now"),
            ("return-object", 0),
            ("label", "compute_now"),
            ("const-string", 0, "нет данных"),
            ("if-eqz", 6, "ret"),
            ("label", "ts"),
            ("sget-object", 1, f_ctrl_tts),
            ("if-nez", 1, "has_tts"),
            ("new-instance", 1, C_TTS),
            ("const/4", 2, 0),
            ("invoke-direct", [1, 6, 2], m_tts_init_2),
            ("label", "has_tts"),
            ("invoke-virtual", [1], m_tts_engines),
            ("move-result-object", 1),
            ("if-eqz", 1, "ret"),
            ("invoke-interface", [1], m_list_size),
            ("move-result", 2),
            ("if-lez", 2, "ret"),
            ("new-instance", 3, C_SB),
            ("invoke-direct", [3], m_sb_init),
            ("const/4", 4, 0),
            ("label", "loop"),
            ("if-ge", 4, 2, "done_l"),
            ("invoke-interface", [1, 4], m_list_get),
            ("move-result-object", 5),
            ("check-cast", 5, C_TTS_EI),
            ("if-eqz", 5, "next"),
            ("iget-object", 5, 5, f_ttsei_name),
            ("if-eqz", 5, "next"),
            ("invoke-virtual", [3, 5], m_sb_app_str),
            ("move-result-object", 3),
            ("const-string", 5, "; "),
            ("invoke-virtual", [3, 5], m_sb_app_str),
            ("move-result-object", 3),
            ("label", "next"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "loop"),
            ("label", "done_l"),
            ("invoke-virtual", [3], m_sb_tostr),
            ("move-result-object", 0),
            ("sput-object", 0, f_ctrl_eng_cache),
            ("label", "te"),
            ("label", "ret"),
            ("return-object", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return-object", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4 canTriggerNow() -> boolean (debounce 350ms)
    code_can_trig = {
        "registers": 6, "ins": 0, "outs": 0,
        "insns": [
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sget-wide", 2, f_ctrl_last_time),
            ("sub-long/2addr", 0, 2),
            ("const-wide/16", 2, 350),
            ("cmp-long", 4, 0, 2),
            ("if-gez", 4, "allow"),
            ("const/4", 4, 0),
            ("return", 4),
            ("label", "allow"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sput-wide", 0, f_ctrl_last_time),
            ("const/4", 4, 1),
            ("return", 4),
        ],
    }

    # 1.4a recordActiveCallState(int v6) -> void
    code_rec_state = {
        "registers": 7, "ins": 1, "outs": 1,
        "insns": [
            ("const/16", 2, 99),
            ("if-ne", 6, 2, "check_98"),
            ("invoke-static", [], m_ctrl_cfg_speak),
            ("return-void",),
            ("label", "check_98"),
            ("const/16", 2, 98),
            ("if-ne", 6, 2, "normal_rec"),
            ("const/4", 2, 1),
            ("invoke-static", [2], m_acc_click_ui),
            ("move-result", 2),
            ("return-void",),
            ("label", "normal_rec"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("const/4", 2, 1),
            ("if-ne", 6, 2, "not_inc"),
            ("sget", 3, f_ctrl_last_call_state),
            ("if-ne", 3, 2, "set_rs"),
            ("sget-wide", 2, f_ctrl_ring_start),
            ("const-wide/16", 4, 0),
            ("cmp-long", 4, 2, 4),
            ("if-nez", 4, "save_now"),
            ("label", "set_rs"),
            ("sput-wide", 0, f_ctrl_ring_start),
            ("goto/16", "save_now"),
            ("label", "not_inc"),
            ("const-wide/16", 2, 0),
            ("sput-wide", 2, f_ctrl_ring_start),
            ("const/4", 2, 0),
            ("sput-boolean", 2, f_ctrl_sim_ringing),
            ("label", "save_now"),
            ("sput", 6, f_ctrl_last_call_state),
            ("sput-wide", 0, f_ctrl_last_call_time),
            ("return-void",),
        ],
    }

    # 1.4a2 ensureNotificationListenerBound(Context v5) -> void
    code_bind_notif = {
        "registers": 6, "ins": 1, "outs": 4,
        "insns": [
            ("if-eqz", 5, "done"),
            ("sget-object", 0, f_notif_inst),
            ("if-nez", 0, "done"),
            ("invoke-static", [5], m_ctrl_is_notif),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("label", "ts"),
            ("invoke-virtual", [5], m_ctx_get_pm),
            ("move-result-object", 0),
            ("new-instance", 1, C_COMP),
            ("const-string", 2, "com.smartcall.ru.CallNotificationListenerService"),
            ("invoke-direct", [1, 5, 2], m_comp_init),
            ("if-eqz", 0, "do_rebind"),
            ("const/4", 2, 2),
            ("const/4", 3, 1),
            ("invoke-virtual", [0, 1, 2, 3], m_pm_set_comp),
            ("invoke-virtual", [0, 1, 3, 3], m_pm_set_comp),
            ("label", "do_rebind"),
            ("invoke-static", [1], m_nls_rebind),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4e getRingtoneMask(Context v6) -> int
    code_ring_mask = {
        "registers": 7, "ins": 1, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("if-eqz", 6, "ret"),
            ("label", "ts"),
            ("const-string", 1, "audio"),
            ("invoke-virtual", [6, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_AUDIO),
            ("if-eqz", 1, "ret"),

            # Bit 0: getMode() == 1
            ("invoke-virtual", [1], m_audio_mode),
            ("move-result", 2),
            ("const/4", 3, 1),
            ("if-ne", 2, 3, "check_mute"),
            ("const/4", 5, 1),
            ("or-int/2addr", 0, 5),

            # Bit 1: !isStreamMute(2)
            ("label", "check_mute"),
            ("const/4", 2, 2),
            ("invoke-virtual", [1, 2], m_audio_mute),
            ("move-result", 2),
            ("if-nez", 2, "check_apc"),
            ("const/4", 5, 2),
            ("or-int/2addr", 0, 5),

            # Bit 2 & Bit 3: active AudioPlaybackConfigurations
            ("label", "check_apc"),
            ("sget", 2, f_sdk_int),
            ("const/16", 3, 26),
            ("if-lt", 2, 3, "ret"),
            ("invoke-virtual", [1], m_audio_configs),
            ("move-result-object", 1),
            ("if-eqz", 1, "ret"),
            ("invoke-interface", [1], m_list_size),
            ("move-result", 2),
            ("if-lez", 2, "ret"),
            ("const/4", 3, 0),
            ("label", "loop"),
            ("if-ge", 3, 2, "ret"),
            ("invoke-interface", [1, 3], m_list_get),
            ("move-result-object", 4),
            ("check-cast", 4, C_APC),
            ("if-eqz", 4, "next"),
            ("invoke-virtual", [4], m_apc_attr),
            ("move-result-object", 4),
            ("if-eqz", 4, "next"),
            ("invoke-virtual", [4], m_aattr_usage),
            ("move-result", 4),
            ("const/4", 5, 6),
            ("if-eq", 4, 5, "found_p"),
            ("label", "next"),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "loop"),
            ("label", "found_p"),
            ("const/4", 5, 4),
            ("or-int/2addr", 0, 5),
            ("label", "te"),
            ("label", "ret"),
            ("return", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4f0 checkDelayedCaller(Context v5) -> void
    # Runs 350ms after incoming call starts ringing:
    # 1) Checks CallNotificationListenerService.findActiveCallTitle() (reads android.title from category=="call" notification)
    # 2) If null, checks CallControlAccessibilityService.findCallerNameInUi() (excluding com.android.systemui)
    code_delayed_caller = {
        "registers": 6, "ins": 1, "outs": 3,
        "insns": [
            ("if-eqz", 5, "done"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sget-wide", 2, f_ctrl_last_time),
            ("sub-long/2addr", 0, 2),
            ("const-wide/16", 2, 4500),
            ("cmp-long", 4, 0, 2),
            ("if-ltz", 4, "done"),
            ("label", "ts"),
            ("invoke-static", [5], m_ctrl_get_state),
            ("move-result", 0),
            ("const/4", 1, 1),
            ("if-ne", 0, 1, "done"),
            ("invoke-static", [], m_notif_find_title),
            ("move-result-object", 0),
            ("if-eqz", 0, "try_ui_caller"),
            ("invoke-virtual", [0], m_str_len),
            ("move-result", 1),
            ("if-lez", 1, "try_ui_caller"),
            ("sget-object", 1, f_ctrl_last_call_pkg),
            ("if-nez", 1, "use_sim_pkg"),
            ("goto/16", "do_ann"),
            ("label", "use_sim_pkg"),
            ("const-string", 1, "sim"),
            ("goto/16", "do_ann"),

            ("label", "try_ui_caller"),
            ("invoke-static", [], m_acc_find_caller),
            ("move-result-object", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 1, "sim"),

            ("label", "do_ann"),
            ("invoke-static", [5, 1, 0], m_ctrl_ann_call),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4f_p1 registerProximitySensor(Context v5) -> void
    code_reg_prox = {
        "registers": 6, "ins": 1, "outs": 4,
        "insns": [
            ("if-eqz", 5, "done"),
            ("sget-object", 0, f_ctrl_prox_l),
            ("if-nez", 0, "done"),
            ("label", "ts"),
            ("const-string", 0, "enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [5, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 0, "ear_pickup"),
            ("invoke-static", [5, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),

            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_prox_far),
            ("sput", 0, f_ctrl_prox_ticks),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sput-wide", 0, f_ctrl_prox_reg_time),

            ("const-string", 0, "sensor"),
            ("invoke-virtual", [5, 0], m_ctx_get_sys),
            ("move-result-object", 0),
            ("check-cast", 0, C_SM),
            ("if-eqz", 0, "done"),

            ("new-instance", 2, C_PROX_L),
            ("invoke-direct", [2, 5], m_prox_l_init),
            ("sput-object", 2, f_ctrl_prox_l),

            ("const/16", 1, 8),
            ("const/4", 3, 1),
            ("invoke-virtual", [0, 1, 3], m_sm_get_def_wake),
            ("move-result-object", 3),
            ("if-nez", 3, "reg_p_wake"),
            ("goto/16", "try_p_nowake"),
            ("label", "reg_p_wake"),
            ("const/4", 4, 1),
            ("invoke-virtual", [0, 2, 3, 4], m_sm_reg),
            ("move-result", 4),

            ("label", "try_p_nowake"),
            ("const/16", 1, 8),
            ("const/4", 3, 0),
            ("invoke-virtual", [0, 1, 3], m_sm_get_def_wake),
            ("move-result-object", 3),
            ("if-eqz", 3, "try_p_def"),
            ("const/4", 4, 1),
            ("invoke-virtual", [0, 2, 3, 4], m_sm_reg),
            ("move-result", 4),
            ("goto/16", "try_accel"),

            ("label", "try_p_def"),
            ("const/16", 1, 8),
            ("invoke-virtual", [0, 1], m_sm_get_def),
            ("move-result-object", 3),
            ("if-eqz", 3, "try_accel"),
            ("const/4", 4, 1),
            ("invoke-virtual", [0, 2, 3, 4], m_sm_reg),
            ("move-result", 4),

            ("label", "try_accel"),
            ("label", "log_prox_ok"),
            ("const-string", 0, "Датчик приближения и поднесения к уху активен"),
            ("invoke-static", [0], m_ctrl_log),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4f_p2 unregisterProximitySensor(Context v3) -> void
    code_unreg_prox = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_ctrl_prox_l),
            ("if-eqz", 0, "done"),
            ("const/4", 1, 0),
            ("sput-object", 1, f_ctrl_prox_l),
            ("const/4", 1, 0),
            ("sput-boolean", 1, f_ctrl_prox_far),
            ("sput", 1, f_ctrl_prox_ticks),
            ("if-eqz", 3, "done"),
            ("const-string", 1, "sensor"),
            ("invoke-virtual", [3, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_SM),
            ("if-eqz", 1, "done"),
            ("invoke-virtual", [1, 0], m_sm_unreg),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4f startRingtoneWatcher(Context v5) -> void
    code_start_watch = {
        "registers": 6, "ins": 1, "outs": 4,
        "insns": [
            ("if-eqz", 5, "done"),
            ("sget-boolean", 0, f_ctrl_watch_run),
            ("if-nez", 0, "done"),
            # Cooldown guard: never restart ringtone watcher within 4500ms after answerCall / endCall!
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sget-wide", 2, f_ctrl_last_time),
            ("sub-long/2addr", 0, 2),
            ("const-wide/16", 2, 4500),
            ("cmp-long", 4, 0, 2),
            ("if-ltz", 4, "done"),
            ("label", "ts"),
            ("invoke-static", [5], m_ctrl_get_state),
            ("move-result", 0),
            ("const/4", 1, 1),
            ("if-ne", 0, 1, "done"),

            ("sput-boolean", 1, f_ctrl_watch_run),
            ("invoke-static", [5], m_ctrl_reg_prox),
            ("const/4", 0, 0),
            ("sput", 0, f_ctrl_ring_mask),
            ("const-string", 0, "Контроль мелодии звонка активен"),
            ("invoke-static", [0], m_ctrl_log),

            ("invoke-static", [], m_looper_main),
            ("move-result-object", 0),
            ("new-instance", 1, C_HANDLER),
            ("invoke-direct", [1, 0], m_handler_init),

            # Schedule checkDelayedCaller (mode 7) at +350ms so call notification/banner is ready
            ("new-instance", 0, C_RUN_ACT),
            ("const/4", 2, 7),
            ("invoke-direct", [0, 5, 2], m_run_act_init),
            ("const-wide/16", 2, 350),
            ("invoke-virtual", [1, 0, 2, 3], m_handler_post_del),
            ("move-result", 4),

            # Schedule checkRingtoneStep (mode 5) at +150ms
            ("new-instance", 0, C_RUN_ACT),
            ("const/4", 2, 5),
            ("invoke-direct", [0, 5, 2], m_run_act_init),
            ("const-wide/16", 2, 150),
            ("invoke-virtual", [1, 0, 2, 3], m_handler_post_del),
            ("move-result", 4),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_watch_run),
            ("sput-boolean", 0, f_ctrl_sim_ringing),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4g checkRingtoneStep(Context v5) -> void
    # Keep the proximity listener alive while incoming; audio state never triggers an action.
    code_watch_step = {
        "registers": 6, "ins": 1, "outs": 4,
        "insns": [
            ("if-eqz", 5, "stop_w"),
            ("sget-boolean", 0, f_ctrl_watch_run),
            ("if-eqz", 0, "stop_w"),
            ("label", "ts"),
            ("invoke-static", [5], m_ctrl_get_state),
            ("move-result", 0),
            ("const/4", 1, 1),
            ("if-ne", 0, 1, "stop_w"),
            ("invoke-static", [5], m_ctrl_reg_prox),

            # Do not infer button presses from audio or restart the watcher.
            ("label", "re_post"),
            ("invoke-static", [], m_looper_main),
            ("move-result-object", 0),
            ("new-instance", 1, C_HANDLER),
            ("invoke-direct", [1, 0], m_handler_init),
            ("new-instance", 0, C_RUN_ACT),
            ("const/4", 2, 5),
            ("invoke-direct", [0, 5, 2], m_run_act_init),
            ("const-wide/16", 2, 150),
            ("invoke-virtual", [1, 0, 2, 3], m_handler_post_del),
            ("move-result", 4),
            ("return-void",),
            ("label", "te"),

            ("label", "stop_w"),
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_watch_run),
            ("sput", 0, f_ctrl_ring_mask),
            ("invoke-static", [5], m_ctrl_unreg_prox),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_watch_run),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.4h confirmRingtoneSilenced(Context v5) -> void
    # Legacy scheduled callbacks are inert; no restart or call action.
    code_confirm_sil = {
        "registers": 1, "ins": 1, "outs": 0,
        "insns": [("return-void",)],
    }

    # 1.5 dispatchMediaKey(Context v4, int v5) -> void
    code_disp_key = {
        "registers": 6, "ins": 2, "outs": 3,
        "insns": [
            ("label", "try_s"),
            ("const-string", 0, "audio"),
            ("invoke-virtual", [4, 0], m_ctx_get_sys),
            ("move-result-object", 0),
            ("check-cast", 0, C_AUDIO),
            ("if-eqz", 0, "done"),
            ("new-instance", 1, C_KE),
            ("const/4", 2, 0),
            ("invoke-direct", [1, 2, 5], m_ke_init),
            ("invoke-virtual", [0, 1], m_audio_dispatch),
            ("new-instance", 1, C_KE),
            ("const/4", 2, 1),
            ("invoke-direct", [1, 2, 5], m_ke_init),
            ("invoke-virtual", [0, 1], m_audio_dispatch),
            ("label", "try_e"),
            ("label", "done"),
            ("return-void",),
            ("label", "catch_all"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "try_s", "end_label": "try_e", "handler_label": "catch_all"}],
    }

    # 1.6a answerCallPulse(Context v4) -> void
    code_ans_pulse = {"registers": 1, "ins": 1, "outs": 1,
        "insns": [("invoke-static", [0], m_features_answer), ("return-void",)]}

    # 1.6b answerCall(Context v5) -> void
    # Single clean execution pulse (no +240ms duplicate tap!)
    code_ans = {
        "registers": 6, "ins": 1, "outs": 2,
        "insns": [
            ("invoke-static", [], m_ctrl_can_trig),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 1, "Команда: ПОДНЯТЬ ТРУБКУ"),
            ("invoke-static", [1], m_ctrl_log),
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_watch_run),
            ("invoke-static", [5], m_ctrl_unreg_prox),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("invoke-static", [5], m_ctrl_ans_pulse),
            ("label", "done"),
            ("return-void",),
        ],
    }

    # 1.7a endCallPulse(Context v4) -> void
    # Crucial Fix for Telegram Auto-Callback:
    # If TelecomManager.endCall() OR triggerCallNotificationAction(false) succeeded,
    # DO NOT tap the UI screen (because Telegram immediately switches to its post-call
    # "Call Back / Перезвонить" screen at the exact same bottom coordinates)!
    code_end_pulse = {
        "registers": 5, "ins": 1, "outs": 2,
        "insns": [
            ("invoke-static", [], m_ctrl_stop_tts),
            ("const/4", 3, 0),
            # 1. TelecomManager.endCall()
            ("label", "t1_s"),
            ("sget", 0, f_sdk_int),
            ("const/16", 1, 28),
            ("if-lt", 0, 1, "t1_e"),
            ("const-string", 1, "telecom"),
            ("invoke-virtual", [4, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_TELECOM),
            ("if-eqz", 1, "t1_e"),
            ("invoke-virtual", [1], m_telecom_end),
            ("move-result", 3),
            ("if-eqz", 3, "t1_e"),
            ("const-string", 1, "Telecom: endCall выполнен"),
            ("invoke-static", [1], m_ctrl_log),
            ("label", "t1_e"),
            ("if-nez", 3, "done"),
            ("goto/16", "step_notif_end"),
            ("label", "c1"),
            ("move-exception", 1),
            ("const-string", 0, "Telecom: ошибка endCall, проверяем резервные способы"),
            ("invoke-static", [0], m_ctrl_log),
            ("invoke-virtual", [1], m_thr_tostr),
            ("move-result-object", 1),
            ("invoke-static", [1], m_ctrl_log),

            # 2. NotificationListenerService (declineIntent / hangUpIntent / negative action button)
            ("label", "step_notif_end"),
            ("const/4", 0, 0),
            ("invoke-static", [0], m_notif_trigger),
            ("move-result", 2),
            # If Notification action (CallStyle hangUpIntent / declineIntent / negative button) succeeded,
            # DO NOT tap the screen (prevents tapping Telegram's post-call "Call Back" button)!
            ("if-nez", 2, "done"),

            # 3. Accessibility UI Click (only when Notification action did NOT handle the hangup)
            ("const/4", 0, 0),
            ("invoke-static", [0], m_acc_click_ui),
            ("move-result", 3),

            ("if-nez", 3, "done"),
            # 4. KEYCODE_ENDCALL (6) — ends call without ever answering or calling back
            ("const/4", 0, 6),
            ("invoke-static", [4, 0], m_ctrl_disp_key),
            ("label", "done"),
            ("return-void",),
        ],
        "tries": [{"start_label": "t1_s", "end_label": "t1_e", "handler_label": "c1"}],
    }

    # 1.7b endCall(Context v5) -> void
    # Single clean execution pulse (no +220ms delayed repeat pulse that could tap post-call UI!)
    code_end = {
        "registers": 6, "ins": 1, "outs": 2,
        "insns": [
            ("invoke-static", [], m_features_cancel_answer),
            ("invoke-static", [], m_ctrl_can_trig),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 1, "Команда: ЗАВЕРШИТЬ ЗВОНОК"),
            ("invoke-static", [1], m_ctrl_log),
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_watch_run),
            ("sput-boolean", 0, f_ctrl_voip_inc),
            ("sput-boolean", 0, f_ctrl_voip_ong),
            ("sput", 0, f_ctrl_last_call_state),
            ("const-wide/16", 2, 0),
            ("sput-wide", 2, f_ctrl_last_call_time),
            ("sput-wide", 2, f_ctrl_ring_start),
            ("invoke-static", [5], m_ctrl_unreg_prox),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("invoke-static", [5], m_ctrl_end_pulse),
            ("label", "done"),
            ("return-void",),
        ],
    }

    # 1.8 getCallState(Context v6) -> int (0=IDLE, 1=INCOMING, 2=ONGOING)
    code_get_state = {
        "registers": 7, "ins": 1, "outs": 2,
        "insns": [
            # If answerCall (state=2) or endCall (state=0) ran within the last 2200ms,
            # return that authoritative state immediately so stale MODE_RINGTONE never re-triggers incoming state!
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 0),
            ("sget-wide", 2, f_ctrl_last_time),
            ("sub-long/2addr", 0, 2),
            ("const-wide/16", 2, 2200),
            ("cmp-long", 4, 0, 2),
            ("if-gez", 4, "normal_state_check"),
            ("sget", 4, f_ctrl_last_call_state),
            ("const/4", 0, 1),
            ("if-eq", 4, 0, "normal_state_check"),
            ("return", 4),

            ("label", "normal_state_check"),
            ("invoke-static", [6], m_ctrl_bind_notif),
            ("invoke-static", [], m_notif_refresh),

            # 1. Check TelephonyManager.getCallState() FIRST -> v3
            ("const/4", 3, 0),
            ("label", "tt_s"),
            ("const-string", 1, "phone"),
            ("invoke-virtual", [6, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_TELEPHONY),
            ("if-eqz", 1, "tt_e"),
            ("invoke-virtual", [1], m_telephony_state),
            ("move-result", 3),
            ("label", "tt_e"),
            ("goto/16", "after_tt"),
            ("label", "ct"),
            ("move-exception", 1),

            ("label", "after_tt"),
            ("const/4", 0, 1),
            ("if-eq", 3, 0, "ret_inc"),
            ("const/4", 0, 2),
            ("if-eq", 3, 0, "ret_ong"),

            # 2. Check simRinging (from PHONE_STATE broadcast) or VoIP / CallStyle incoming notification
            ("sget-boolean", 0, f_ctrl_sim_ringing),
            ("if-nez", 0, "ret_inc"),
            ("sget-boolean", 0, f_ctrl_voip_inc),
            ("if-nez", 0, "ret_inc"),

            # 3. Check Ringtone mask: bit 0 (getMode()==1) or bit 2 (AudioPlaybackConfig USAGE_NOTIFICATION_RINGTONE==6)
            ("invoke-static", [6], m_ctrl_ring_mask),
            ("move-result", 4),
            ("and-int/lit8", 4, 4, 5),
            ("if-nez", 4, "ret_inc"),

            # 4. Check TelecomManager.isInCall() -> v5
            ("const/4", 5, 0),
            ("label", "ttc_s"),
            ("const-string", 1, "telecom"),
            ("invoke-virtual", [6, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_TELECOM),
            ("if-eqz", 1, "ttc_e"),
            ("invoke-virtual", [1], m_telecom_incall),
            ("move-result", 5),
            ("label", "ttc_e"),
            ("goto/16", "after_ttc"),
            ("label", "ctc"),
            ("move-exception", 1),

            ("label", "after_ttc"),
            ("if-eqz", 5, "check_voip_ong"),
            # TelecomManager.isInCall() is TRUE: check if Answer button is on screen -> 1, else 2
            ("invoke-static", [], m_acc_detect_ui),
            ("move-result", 4),
            ("const/4", 1, 1),
            ("if-eq", 4, 1, "ret_inc"),
            ("goto/16", "ret_ong"),

            # 5. Check VoIP ongoing notification or AudioManager mode == 2 (MODE_IN_CALL, never MODE_IN_COMMUNICATION=3!)
            ("label", "check_voip_ong"),
            ("sget-boolean", 1, f_ctrl_voip_ong),
            ("if-nez", 1, "ret_ong"),

            ("const/4", 0, 0),
            ("label", "ta_s"),
            ("const-string", 1, "audio"),
            ("invoke-virtual", [6, 1], m_ctx_get_sys),
            ("move-result-object", 1),
            ("check-cast", 1, C_AUDIO),
            ("if-eqz", 1, "ta_e"),
            ("invoke-virtual", [1], m_audio_mode),
            ("move-result", 0),
            ("label", "ta_e"),
            ("goto/16", "after_ta"),
            ("label", "ca"),
            ("move-exception", 1),

            ("label", "after_ta"),
            ("const/4", 1, 2),
            ("if-eq", 0, 1, "ret_ong"),

            ("label", "ret_idle"),
            ("const/4", 4, 0),
            ("return", 4),

            ("label", "ret_inc"),
            ("const/4", 4, 1),
            ("invoke-static", [4], m_ctrl_rec_state),
            ("return", 4),

            ("label", "ret_ong"),
            ("const/4", 4, 2),
            ("invoke-static", [4], m_ctrl_rec_state),
            ("return", 4),
        ],
        "tries": [
            {"start_label": "tt_s", "end_label": "tt_e", "handler_label": "ct"},
            {"start_label": "ttc_s", "end_label": "ttc_e", "handler_label": "ctc"},
            {"start_label": "ta_s", "end_label": "ta_e", "handler_label": "ca"},
        ],
    }

    # 1.9 shouldInterceptKey(Context v4, int v5) -> boolean
    # v5: 1 = VolUp, 2 = VolDown
    code_should_key = {
        "registers": 6, "ins": 2, "outs": 3,
        "insns": [
            ("const-string", 0, "enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "check_state"),
            ("const/4", 2, 0),
            ("return", 2),

            ("label", "check_state"),
            ("invoke-static", [4], m_ctrl_get_state),
            ("move-result", 2),
            ("if-eqz", 2, "ret_false"),

            ("const/4", 3, 1),
            ("if-eq", 2, 3, "state_incoming"),

            # State == 2 (ONGOING): mutually exclusive end_vol_down vs end_vol_up
            ("const/4", 3, 1),
            ("if-eq", 5, 3, "ong_vol_up"),
            ("const/4", 3, 2),
            ("if-eq", 5, 3, "ong_vol_down"),
            ("goto/16", "ret_false"),

            ("label", "ong_vol_up"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_false"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("return", 2),

            ("label", "ong_vol_down"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("return", 2),

            # State == 1 (INCOMING): mutually exclusive ans_vol_up vs ans_vol_down, end_vol_down vs end_vol_up
            ("label", "state_incoming"),
            ("const/4", 3, 1),
            ("if-eq", 5, 3, "inc_vol_up"),
            ("const/4", 3, 2),
            ("if-eq", 5, 3, "inc_vol_down"),
            ("goto/16", "ret_false"),

            ("label", "inc_vol_up"),
            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_true"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_false"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("return", 2),

            ("label", "inc_vol_down"),
            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "inc_dn_check_end"),
            ("const-string", 0, "ans_vol_down"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_true"),
            ("label", "inc_dn_check_end"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [4, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("return", 2),

            ("label", "ret_true"),
            ("const/4", 2, 1),
            ("return", 2),

            ("label", "ret_false"),
            ("const/4", 2, 0),
            ("return", 2),
        ],
    }

    # 1.10 handleHardwareButton(Context v6, int v7) -> boolean
    # v7: 1 = VolUp, 2 = VolDown
    code_handle_btn = {
        "registers": 8, "ins": 2, "outs": 3,
        "insns": [
            ("const-string", 0, "enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "st"),
            ("const/4", 2, 0),
            ("return", 2),

            ("label", "st"),
            ("const/4", 3, 1),
            ("if-eq", 7, 3, "valid_vol_key"),
            ("const/4", 3, 2),
            ("if-eq", 7, 3, "valid_vol_key"),
            ("goto/16", "ret_false"),

            ("label", "valid_vol_key"),
            ("invoke-static", [6], m_ctrl_get_state),
            ("move-result", 4),
            ("if-eqz", 4, "ret_false"),

            ("const/4", 3, 1),
            ("if-eq", 4, 3, "incoming"),

            # ONGOING (state == 2) for Volume buttons (mutually exclusive)
            ("const/4", 3, 1),
            ("if-eq", 7, 3, "o_up"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_end"),
            ("goto/16", "ret_false"),

            ("label", "o_up"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_false"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_end"),
            ("goto/16", "ret_false"),

            # INCOMING (state == 1) for Volume buttons (mutually exclusive)
            ("label", "incoming"),
            ("const/4", 3, 1),
            ("if-eq", 7, 3, "i_up"),

            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "i_dn_check_end"),
            ("const-string", 0, "ans_vol_down"),
            ("const/4", 1, 0),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_ans"),
            ("label", "i_dn_check_end"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_end"),
            ("goto/16", "ret_false"),

            ("label", "i_up"),
            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_ans"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "ret_false"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 2),
            ("if-nez", 2, "do_end"),
            ("goto/16", "ret_false"),

            ("label", "do_ans"),
            ("invoke-static", [6], m_ctrl_ans),
            ("const/4", 2, 1),
            ("return", 2),

            ("label", "do_end"),
            ("invoke-static", [6], m_ctrl_end),
            ("const/4", 2, 1),
            ("return", 2),

            ("label", "ret_false"),
            ("const/4", 2, 0),
            ("return", 2),
        ],
    }

    # 1.11 hasPhonePermissions(Context v3) -> boolean
    code_has_phone = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("const-string", 0, "android.permission.READ_PHONE_STATE"),
            ("invoke-virtual", [3, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_false"),

            ("const-string", 0, "android.permission.CALL_PHONE"),
            ("invoke-virtual", [3, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_false"),

            ("sget", 1, f_sdk_int),
            ("const/16", 2, 26),
            ("if-lt", 1, 2, "check_33"),
            ("const-string", 0, "android.permission.ANSWER_PHONE_CALLS"),
            ("invoke-virtual", [3, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_false"),

            ("label", "check_33"),
            ("sget", 1, f_sdk_int),
            ("const/16", 2, 33),
            ("if-lt", 1, 2, "ret_true"),
            ("const-string", 0, "android.permission.POST_NOTIFICATIONS"),
            ("invoke-virtual", [3, 0], m_ctx_check_perm),
            ("move-result", 1),
            ("if-nez", 1, "ret_false"),

            ("label", "ret_true"),
            ("const/4", 1, 1),
            ("return", 1),

            ("label", "ret_false"),
            ("const/4", 1, 0),
            ("return", 1),
        ],
    }

    # 1.12 isAccessibilityEnabled(Context v3) -> boolean
    code_is_acc = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("invoke-virtual", [3], m_ctx_get_cr),
            ("move-result-object", 0),
            ("const-string", 1, "enabled_accessibility_services"),
            ("invoke-static", [0, 1], m_sec_get_str),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_f"),
            ("const-string", 1, "com.smartcall.ru"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("label", "te"),
            ("return", 2),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.13 isNotificationListenerEnabled(Context v3) -> boolean
    code_is_notif = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("invoke-virtual", [3], m_ctx_get_cr),
            ("move-result-object", 0),
            ("const-string", 1, "enabled_notification_listeners"),
            ("invoke-static", [0, 1], m_sec_get_str),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_f"),
            ("const-string", 1, "com.smartcall.ru"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("label", "te"),
            ("return", 2),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.14 isBatteryOptimizationIgnored(Context v3) -> boolean
    code_is_batt = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("const-string", 0, "power"),
            ("invoke-virtual", [3, 0], m_ctx_get_sys),
            ("move-result-object", 0),
            ("check-cast", 0, C_POWER),
            ("if-eqz", 0, "ret_t"),
            ("invoke-virtual", [3], m_ctx_get_pkg),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_power_ignoring),
            ("move-result", 2),
            ("label", "te"),
            ("return", 2),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "ret_t"),
            ("const/4", 2, 1),
            ("return", 2),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # 1.15 areAllPermissionsGranted(Context v2) -> boolean
    code_all_perms = {
        "registers": 3, "ins": 1, "outs": 1,
        "insns": [
            ("invoke-static", [2], m_ctrl_has_phone),
            ("move-result", 0),
            ("if-nez", 0, "c2"),
            ("const/4", 0, 0),
            ("return", 0),

            ("label", "c2"),
            ("invoke-static", [2], m_ctrl_is_acc),
            ("move-result", 0),
            ("if-nez", 0, "c3"),
            ("const/4", 0, 0),
            ("return", 0),

            ("label", "c3"),
            ("invoke-static", [2], m_ctrl_is_notif),
            ("move-result", 0),
            ("if-nez", 0, "c4"),
            ("const/4", 0, 0),
            ("return", 0),

            ("label", "c4"),
            ("invoke-static", [2], m_ctrl_is_batt),
            ("move-result", 0),
            ("return", 0),
        ],
    }

    db.add_class(
        C_CTRL,
        C_OBJ,
        0x0001,
        static_fields=[
            (f_ctrl_last_time, 0x0009),
            (f_ctrl_last_call_time, 0x0009),
            (f_ctrl_ring_start, 0x0009),
            (f_ctrl_last_call_state, 0x0009),
            (f_ctrl_sim_ringing, 0x0009),
            (f_ctrl_voip_inc, 0x0009),
            (f_ctrl_voip_ong, 0x0009),
            (f_ctrl_watch_run, 0x0009),
            (f_ctrl_ring_mask, 0x0009),
            (f_ctrl_diag, 0x0009),
            (f_ctrl_tts, 0x0009),
            (f_ctrl_last_tts_time, 0x0009),
            (f_ctrl_last_tts_text, 0x0009),
            (f_ctrl_last_call_pkg, 0x0009),
            (f_ctrl_last_caller, 0x0009),
            (f_ctrl_eng_cache, 0x0009),
            (f_ctrl_swipe_x, 0x0009),
            (f_ctrl_swipe_y, 0x0009),
            (f_ctrl_prox_l, 0x0009),
            (f_ctrl_prox_far, 0x0009),
            (f_ctrl_prox_reg_time, 0x0009),
            (f_ctrl_prox_ticks, 0x0009),
            (f_ctrl_last_sms_body, 0x0009),
            (f_ctrl_last_sms_pkg, 0x0009),
        ],
        direct_methods=[
            (
                m_ctrl_init,
                0x10001,
                {
                    "registers": 1, "ins": 1, "outs": 1,
                    "insns": [("invoke-direct", [0], m_obj_init), ("return-void",)],
                },
            ),
            (m_ctrl_log, 0x0009, code_ctrl_log),
            (m_ctrl_clear_log, 0x0009, code_clear_log),
            (m_ctrl_get_log, 0x0009, code_get_log),
            (m_ctrl_save_log, 0x0009, code_save_log),
            (m_ctrl_get_prefs, 0x0009, code_get_prefs),
            (m_ctrl_is_pref, 0x0009, code_is_pref),
            (m_ctrl_set_pref, 0x0009, code_set_pref),
            (m_ctrl_get_int, 0x0009, code_get_int),
            (m_ctrl_set_int, 0x0009, code_set_int),
            (m_ctrl_get_str, 0x0009, code_get_str),
            (m_ctrl_set_str, 0x0009, code_set_str),
            (m_ctrl_has_contacts, 0x0009, code_has_contacts),
            (m_ctrl_has_sms, 0x0009, code_has_sms),
            (m_ctrl_lookup_contact, 0x0009, code_lookup_contact),
            (m_ctrl_has_letters, 0x0009, code_has_letters),
            (m_ctrl_format_digits, 0x0009, code_format_digits),
            (m_ctrl_fmt_eng, 0x0009, code_fmt_eng),
            (m_ctrl_pct_flt, 0x0009, code_pct_flt),
            (m_ctrl_fmt_rate, 0x0009, code_fmt_rate),
            (m_ctrl_fmt_amode, 0x0009, code_fmt_amode),
            (m_ctrl_sanitize_prefs, 0x0009, code_sanitize_prefs),
            (m_ctrl_cfg_speak, 0x0009, code_cfg_speak),
            (m_ctrl_stop_tts, 0x0009, code_stop_tts),
            (m_ctrl_reinit_tts, 0x0009, code_reinit_tts),
            (m_ctrl_speak, 0x0009, code_speak),
            (m_ctrl_ann_call, 0x0009, code_ann_call),
            (m_ctrl_ann_sms, 0x0009, code_ann_sms),
            (m_ctrl_is_media_notif, 0x0009, code_is_media_notif),
            (m_ctrl_eng_summary, 0x0009, code_eng_summary),
            (m_ctrl_can_trig, 0x0009, code_can_trig),
            (m_ctrl_rec_state, 0x0009, code_rec_state),
            (m_ctrl_bind_notif, 0x0009, code_bind_notif),
            (m_ctrl_ring_mask, 0x0009, code_ring_mask),
            (m_ctrl_reg_prox, 0x0009, code_reg_prox),
            (m_ctrl_unreg_prox, 0x0009, code_unreg_prox),
            (m_ctrl_delayed_caller, 0x0009, code_delayed_caller),
            (m_ctrl_start_watch, 0x0009, code_start_watch),
            (m_ctrl_watch_step, 0x0009, code_watch_step),
            (m_ctrl_confirm_sil, 0x0009, code_confirm_sil),
            (m_ctrl_disp_key, 0x0009, code_disp_key),
            (m_ctrl_ans_pulse, 0x0009, code_ans_pulse),
            (m_ctrl_ans, 0x0009, code_ans),
            (m_ctrl_end_pulse, 0x0009, code_end_pulse),
            (m_ctrl_end, 0x0009, code_end),
            (m_ctrl_get_state, 0x0009, code_get_state),
            (m_ctrl_should_key, 0x0009, code_should_key),
            (m_ctrl_handle_btn, 0x0009, code_handle_btn),
            (m_ctrl_has_phone, 0x0009, code_has_phone),
            (m_ctrl_is_acc, 0x0009, code_is_acc),
            (m_ctrl_is_notif, 0x0009, code_is_notif),
            (m_ctrl_is_batt, 0x0009, code_is_batt),
            (m_ctrl_all_perms, 0x0009, code_all_perms),
        ],
    )

    # =========================================================================
    # CLASS 2: CallNotificationListenerService
    # =========================================================================
    m_notif_init = (C_NOTIF, "<init>", ("V", ()))
    m_notif_conn = (C_NOTIF, "onListenerConnected", ("V", ()))
    m_notif_disc = (C_NOTIF, "onListenerDisconnected", ("V", ()))
    m_notif_post = (C_NOTIF, "onNotificationPosted", ("V", (C_SBN,)))
    m_notif_rem = (C_NOTIF, "onNotificationRemoved", ("V", (C_SBN,)))
    m_notif_is_excl = (C_NOTIF, "isExcludedText", ("Z", (C_STR,)))
    m_notif_is_pos = (C_NOTIF, "isPositiveText", ("Z", (C_STR,)))
    m_notif_is_neg = (C_NOTIF, "isNegativeText", ("Z", (C_STR,)))
    m_notif_send_pi = (C_NOTIF, "sendPiWithBal", ("Z", (C_PI,)))

    # sendPiWithBal(PendingIntent v8) -> boolean (false for null/canceled/error)
    code_send_pi = {
        "registers": 9, "ins": 1, "outs": 8,
        "insns": [
            ("if-eqz", 8, "done"),
            ("sget", 0, f_sdk_int),
            ("const/16", 1, 34),
            ("if-lt", 0, 1, "legacy_send"),
            ("label", "tb_s"),
            ("invoke-static", [], m_ao_make),
            ("move-result-object", 0),
            ("const/4", 1, 1),
            ("invoke-virtual", [0, 1], m_ao_set_bal),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_ao_bundle),
            ("move-result-object", 7),
            ("move-object", 0, 8),
            ("const/4", 1, 0),
            ("const/4", 2, 0),
            ("const/4", 3, 0),
            ("const/4", 4, 0),
            ("const/4", 5, 0),
            ("const/4", 6, 0),
            ("invoke-virtual/range", [0, 1, 2, 3, 4, 5, 6, 7], m_pi_send_7),
            ("label", "tb_e"),
            ("const/4", 0, 1),
            ("return", 0),
            ("label", "cb"),
            ("move-exception", 0),

            ("label", "legacy_send"),
            ("label", "tl_s"),
            ("invoke-virtual", [8], m_pi_send),
            ("label", "tl_e"),
            ("const/4", 0, 1),
            ("return", 0),
            ("label", "cl"),
            ("move-exception", 0),
            ("label", "done"),
            ("const/4", 0, 0),
            ("return", 0),
        ],
        "tries": [
            {"start_label": "tb_s", "end_label": "tb_e", "handler_label": "cb"},
            {"start_label": "tl_s", "end_label": "tl_e", "handler_label": "cl"},
        ],
    }

    # isExcludedText(String v3_lower) -> boolean
    # Includes "перезвон", "обратн", "снова", "callback", "call back", "again", "close", "закрыт"
    # so post-call "Call Back / Перезвонить" buttons are NEVER matched!
    code_is_excl = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("if-eqz", 3, "ret_f"),
            ("const-string", 1, "сообщ"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "быстр"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "sms"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "смс"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "msg"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "message"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "reply"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "напомн"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "remind"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "перезвон"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "обратн"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "снова"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "callback"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "call back"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "again"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "не отвеч"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "без ответ"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "автоответ"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "picker"),
            ("invoke-virtual", [3, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
            ("label", "ret_t"),
            ("const/4", 2, 1),
            ("return", 2),
        ],
    }

    code_is_pos = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("if-eqz", 3, "ret_f"),
            ("invoke-virtual", [3], m_str_lower),
            ("move-result-object", 0),
            ("invoke-static", [0], m_notif_is_excl),
            ("move-result", 2),
            ("if-nez", 2, "ret_f"),
            ("const-string", 1, "ответить"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "принять"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "поднять"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "соединить"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "answer"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "accept"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "pickup"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "voip_accept"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "btn_answer"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "call_answer"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "puck"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
            ("label", "ret_t"),
            ("const/4", 2, 1),
            ("return", 2),
        ],
    }

    code_is_neg = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("if-eqz", 3, "ret_f"),
            ("invoke-virtual", [3], m_str_lower),
            ("move-result-object", 0),
            ("invoke-static", [0], m_notif_is_excl),
            ("move-result", 2),
            ("if-nez", 2, "ret_f"),
            ("const-string", 1, "отклон"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "сброс"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "заверш"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "отбой"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "полож"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "decline"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "reject"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "hang"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "end_call"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "end call"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "endcall"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "leave"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "disconnect"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("const-string", 1, "puck"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
            ("label", "ret_t"),
            ("const/4", 2, 1),
            ("return", 2),
        ],
    }

    # refreshCallStatus() -> void
    code_notif_refresh = {
        "registers": 11, "ins": 0, "outs": 3,
        "insns": [
            ("const/4", 0, 0),
            ("sput-boolean", 0, f_ctrl_voip_inc),
            ("sput-boolean", 0, f_ctrl_voip_ong),
            ("label", "ts"),
            ("sget-object", 1, f_notif_inst),
            ("if-eqz", 1, "te"),
            ("invoke-virtual", [1], m_nls_get_active),
            ("move-result-object", 2),
            ("if-eqz", 2, "te"),
            ("array-length", 3, 2),
            ("const/4", 4, 0),
            ("label", "loop"),
            ("if-ge", 4, 3, "te"),
            ("aget-object", 5, 2, 4),
            ("if-eqz", 5, "next"),
            ("invoke-virtual", [5], m_sbn_get_pkg),
            ("move-result-object", 8),
            ("if-eqz", 8, "next"),
            ("const-string", 10, "com.smartcall.ru"),
            ("invoke-virtual", [10, 8], m_str_equals),
            ("move-result", 0),
            ("if-nez", 0, "next"),
            ("invoke-virtual", [5], m_sbn_get_notif),
            ("move-result-object", 5),
            ("if-eqz", 5, "next"),

            # Step 0: MUST have category == "call"
            ("iget-object", 8, 5, f_notif_cat),
            ("if-eqz", 8, "next"),
            ("const-string", 10, "call"),
            ("invoke-virtual", [10, 8], m_str_equals),
            ("move-result", 0),
            ("if-eqz", 0, "next"),

            # Step 1: Check CallStyle callType, answerIntent, declineIntent
            ("iget-object", 6, 5, f_notif_extras),
            ("if-eqz", 6, "check_actions"),

            ("const-string", 7, "android.callType"),
            ("const/4", 8, 0),
            ("invoke-virtual", [6, 7, 8], m_bundle_get_int),
            ("move-result", 8),
            ("const/4", 0, 1),
            ("if-eq", 8, 0, "found_inc"),
            ("const/4", 0, 3),
            ("if-eq", 8, 0, "found_inc"),
            ("const/4", 0, 2),
            ("if-eq", 8, 0, "found_ong"),

            ("const-string", 7, "android.answerIntent"),
            ("invoke-virtual", [6, 7], m_bundle_contains),
            ("move-result", 8),
            ("if-nez", 8, "found_inc"),

            ("const-string", 7, "android.declineIntent"),
            ("invoke-virtual", [6, 7], m_bundle_contains),
            ("move-result", 8),
            ("if-nez", 8, "found_inc"),

            # Step 2: Check Notification.actions for positive button ("Ответить"/"Принять") BEFORE hangUpIntent!
            ("label", "check_actions"),
            ("iget-object", 7, 5, f_notif_actions),
            ("if-eqz", 7, "check_hangup"),
            ("array-length", 8, 7),
            ("if-lez", 8, "check_hangup"),

            ("const/4", 9, 0),
            ("label", "act_loop"),
            ("if-ge", 9, 8, "after_act_loop"),
            ("aget-object", 0, 7, 9),
            ("if-eqz", 0, "act_next"),
            ("iget-object", 0, 0, f_nact_title),
            ("if-eqz", 0, "act_next"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_notif_is_pos),
            ("move-result", 1),
            ("if-nez", 1, "found_inc"),

            ("label", "act_next"),
            ("add-int/lit8", 9, 9, 1),
            ("goto/16", "act_loop"),

            ("label", "after_act_loop"),
            ("const/4", 9, 0),
            ("label", "neg_act_loop"),
            ("if-ge", 9, 8, "check_hangup"),
            ("aget-object", 0, 7, 9),
            ("if-eqz", 0, "neg_act_next"),
            ("iget-object", 0, 0, f_nact_title),
            ("if-eqz", 0, "neg_act_next"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_notif_is_neg),
            ("move-result", 1),
            ("if-nez", 1, "found_ong"),
            ("label", "neg_act_next"),
            ("add-int/lit8", 9, 9, 1),
            ("goto/16", "neg_act_loop"),

            # Step 3: Check hangUpIntent (never default to found_ong if hangUpIntent is absent!)
            ("label", "check_hangup"),
            ("if-eqz", 6, "next"),
            ("const-string", 7, "android.hangUpIntent"),
            ("invoke-virtual", [6, 7], m_bundle_contains),
            ("move-result", 8),
            ("if-nez", 8, "found_ong"),
            ("goto/16", "next"),

            ("label", "found_inc"),
            ("const/4", 0, 1),
            ("sput-boolean", 0, f_ctrl_voip_inc),
            ("goto/16", "next"),

            ("label", "found_ong"),
            ("const/4", 0, 1),
            ("sput-boolean", 0, f_ctrl_voip_ong),

            ("label", "next"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "loop"),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 1),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # findActiveCallTitle() -> String
    # Scans active notifications with category == "call", saves package in f_ctrl_last_call_pkg,
    # and returns android.title (caller name or phone number)!
    code_notif_find_title = {
        "registers": 8, "ins": 0, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("label", "ts"),
            ("sget-object", 1, f_notif_inst),
            ("if-eqz", 1, "ret"),
            ("invoke-virtual", [1], m_nls_get_active),
            ("move-result-object", 2),
            ("if-eqz", 2, "ret"),
            ("array-length", 3, 2),
            ("const/4", 4, 0),
            ("label", "loop"),
            ("if-ge", 4, 3, "ret"),
            ("aget-object", 5, 2, 4),
            ("if-eqz", 5, "next"),
            ("invoke-virtual", [5], m_sbn_get_pkg),
            ("move-result-object", 6),
            ("invoke-virtual", [5], m_sbn_get_notif),
            ("move-result-object", 5),
            ("if-eqz", 5, "next"),
            ("iget-object", 7, 5, f_notif_cat),
            ("if-eqz", 7, "next"),
            ("const-string", 1, "call"),
            ("invoke-virtual", [1, 7], m_str_equals),
            ("move-result", 1),
            ("if-eqz", 1, "next"),
            ("iget-object", 5, 5, f_notif_extras),
            ("if-eqz", 5, "next"),
            ("const-string", 1, "android.title"),
            ("invoke-virtual", [5, 1], m_bundle_get),
            ("move-result-object", 5),
            ("if-eqz", 5, "next"),
            ("invoke-virtual", [5], m_obj_tostr),
            ("move-result-object", 5),
            ("invoke-virtual", [5], m_str_len),
            ("move-result", 1),
            ("if-lez", 1, "next"),
            ("sput-object", 6, f_ctrl_last_call_pkg),
            ("return-object", 5),
            ("label", "next"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "loop"),
            ("label", "te"),
            ("label", "ret"),
            ("return-object", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return-object", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # triggerCallNotificationAction(boolean v11_isAnswer) -> boolean
    # Sends at most one successfully dispatched PendingIntent. A successful send
    # does not prove the target app completed the call action; test on real devices.
    code_notif_trigger = {
        "registers": 12, "ins": 1, "outs": 2,
        "insns": [
            ("const/4", 10, 0),
            ("label", "ts"),
            ("sget-object", 0, f_notif_inst),
            ("if-eqz", 0, "ret_res"),
            ("invoke-virtual", [0], m_nls_get_active),
            ("move-result-object", 1),
            ("if-eqz", 1, "ret_res"),
            ("array-length", 2, 1),
            ("const/4", 3, 0),
            ("label", "outer_loop"),
            ("if-ge", 3, 2, "ret_res"),
            ("aget-object", 4, 1, 3),
            ("if-eqz", 4, "outer_next"),
            ("invoke-virtual", [4], m_sbn_get_notif),
            ("move-result-object", 4),
            ("if-eqz", 4, "outer_next"),

            # Require category == "call"
            ("iget-object", 8, 4, f_notif_cat),
            ("if-eqz", 8, "outer_next"),
            ("const-string", 9, "call"),
            ("invoke-virtual", [9, 8], m_str_equals),
            ("move-result", 0),
            ("if-eqz", 0, "outer_next"),

            # Pass 0: Check Android 12-17 Notification.CallStyle extras via Bundle.get(String)
            ("iget-object", 5, 4, f_notif_extras),
            ("if-eqz", 5, "pass_actions"),
            ("if-eqz", 11, "extra_end"),
            ("const-string", 8, "android.answerIntent"),
            ("invoke-virtual", [5, 8], m_bundle_get),
            ("move-result-object", 9),
            ("if-eqz", 9, "pass_actions"),
            ("check-cast", 9, C_PI),
            ("invoke-static", [9], m_notif_send_pi),
            ("move-result", 0),
            ("if-eqz", 0, "pass_actions"),
            ("const-string", 8, "Уведомление: отправлен CallStyle answerIntent"),
            ("invoke-static", [8], m_ctrl_log),
            ("const/4", 10, 1),
            ("goto/16", "ret_res"),

            ("label", "extra_end"),
            ("const-string", 8, "android.declineIntent"),
            ("invoke-virtual", [5, 8], m_bundle_get),
            ("move-result-object", 9),
            ("if-eqz", 9, "check_hangup_extra"),
            ("check-cast", 9, C_PI),
            ("invoke-static", [9], m_notif_send_pi),
            ("move-result", 0),
            ("if-eqz", 0, "check_hangup_extra"),
            ("const-string", 8, "Уведомление: отправлен CallStyle declineIntent"),
            ("invoke-static", [8], m_ctrl_log),
            ("const/4", 10, 1),
            ("goto/16", "ret_res"),

            ("label", "check_hangup_extra"),
            ("const-string", 8, "android.hangUpIntent"),
            ("invoke-virtual", [5, 8], m_bundle_get),
            ("move-result-object", 9),
            ("if-eqz", 9, "pass_actions"),
            ("check-cast", 9, C_PI),
            ("invoke-static", [9], m_notif_send_pi),
            ("move-result", 0),
            ("if-eqz", 0, "pass_actions"),
            ("const-string", 8, "Уведомление: отправлен CallStyle hangUpIntent"),
            ("invoke-static", [8], m_ctrl_log),
            ("const/4", 10, 1),
            ("goto/16", "ret_res"),

            # Pass 1: Notification.Action[]
            ("label", "pass_actions"),
            ("iget-object", 5, 4, f_notif_actions),
            ("if-eqz", 5, "outer_next"),
            ("array-length", 6, 5),
            ("if-lez", 6, "outer_next"),

            ("const/4", 7, 0),
            ("label", "inner_loop"),
            ("if-ge", 7, 6, "outer_next"),
            ("aget-object", 8, 5, 7),
            ("if-eqz", 8, "inner_next"),
            ("iget-object", 9, 8, f_nact_title),
            ("if-eqz", 9, "inner_next"),
            ("invoke-interface", [9], m_cs_tostr),
            ("move-result-object", 9),
            ("if-eqz", 11, "check_neg_kw"),
            ("invoke-static", [9], m_notif_is_pos),
            ("move-result", 0),
            ("if-nez", 0, "fire_act"),
            ("goto/16", "inner_next"),

            ("label", "check_neg_kw"),
            ("invoke-static", [9], m_notif_is_neg),
            ("move-result", 0),
            ("if-nez", 0, "fire_act"),

            ("label", "inner_next"),
            ("add-int/lit8", 7, 7, 1),
            ("goto/16", "inner_loop"),

            ("label", "fire_act"),
            ("if-eqz", 8, "outer_next"),
            ("iget-object", 9, 8, f_nact_intent),
            ("if-eqz", 9, "outer_next"),
            ("invoke-static", [9], m_notif_send_pi),
            ("move-result", 0),
            ("if-eqz", 0, "inner_next"),
            ("const-string", 8, "Уведомление: нажата кнопка действия"),
            ("invoke-static", [8], m_ctrl_log),
            ("const/4", 10, 1),
            ("goto/16", "ret_res"),

            ("label", "outer_next"),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "outer_loop"),
            ("label", "te"),

            ("label", "ret_res"),
            ("return", 10),
            ("label", "ca"),
            ("move-exception", 0),
            ("return", 10),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # onNotificationPosted(StatusBarNotification v7) -> void
    code_notif_post = {
        "registers": 8, "ins": 2, "outs": 3,
        "insns": [
            # v6 = this, v7 = StatusBarNotification
            ("sput-object", 6, f_notif_inst),
            ("label", "ts"),
            # Strictly gate message notification reading by tts_enabled, tts_app_sms, and tts_sms_text!
            ("const-string", 0, "tts_enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "after_msg_check"),
            ("const-string", 0, "tts_app_sms"),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "after_msg_check"),
            ("const-string", 0, "tts_sms_text"),
            ("invoke-static", [6, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "after_msg_check"),
            ("invoke-static", [7], m_ctrl_is_media_notif),
            ("move-result", 0),
            ("if-nez", 0, "after_msg_check"),
            ("invoke-static", [6, 7], m_features_message),
            ("move-result", 0),
            ("if-nez", 0, "done"),

            ("label", "after_msg_check"),
            ("invoke-static", [], m_notif_refresh),
            ("if-eqz", 7, "check_state_flags"),
            ("invoke-virtual", [7], m_sbn_get_pkg),
            ("move-result-object", 0),
            ("if-eqz", 0, "check_state_flags"),
            ("const-string", 1, "com.smartcall.ru"),
            ("invoke-virtual", [1, 0], m_str_equals),
            ("move-result", 1),
            ("if-nez", 1, "done"),
            ("invoke-virtual", [7], m_sbn_get_notif),
            ("move-result-object", 1),
            ("if-eqz", 1, "check_state_flags"),
            ("iget-object", 2, 1, f_notif_cat),
            ("iget-object", 3, 1, f_notif_extras),
            ("const-string", 4, ""),
            ("if-eqz", 3, "check_cat"),
            ("const-string", 4, "android.title"),
            ("invoke-virtual", [3, 4], m_bundle_get),
            ("move-result-object", 4),
            ("if-eqz", 4, "no_title"),
            ("invoke-virtual", [4], m_obj_tostr),
            ("move-result-object", 4),
            ("goto/16", "check_cat"),
            ("label", "no_title"),
            ("const-string", 4, ""),

            ("label", "check_cat"),
            ("if-eqz", 2, "check_state_flags"),
            ("const-string", 3, "call"),
            ("invoke-virtual", [3, 2], m_str_equals),
            ("move-result", 3),
            ("if-eqz", 3, "check_state_flags"),

            ("label", "is_call_notif"),
            ("sput-object", 0, f_ctrl_last_call_pkg),
            ("sput-object", 4, f_ctrl_last_caller),
            ("sget-boolean", 3, f_ctrl_voip_inc),
            ("if-eqz", 3, "check_ring_for_call_notif"),
            ("goto/16", "do_call_ann"),
            ("label", "check_ring_for_call_notif"),
            ("invoke-static", [6], m_ctrl_ring_mask),
            ("move-result", 3),
            ("and-int/lit8", 3, 3, 5),
            ("if-eqz", 3, "check_state_flags"),
            ("const/4", 3, 1),
            ("sput-boolean", 3, f_ctrl_voip_inc),
            ("label", "do_call_ann"),
            ("invoke-virtual", [4], m_str_len),
            ("move-result", 3),
            ("if-lez", 3, "check_state_flags"),
            ("invoke-static", [6, 0, 4], m_ctrl_ann_call),

            ("label", "check_state_flags"),
            ("sget-boolean", 0, f_ctrl_voip_inc),
            ("if-eqz", 0, "check_ong"),
            ("const/4", 0, 1),
            ("invoke-static", [0], m_ctrl_rec_state),
            ("invoke-static", [6], m_ctrl_start_watch),
            ("return-void",),
            ("label", "check_ong"),
            ("sget-boolean", 0, f_ctrl_voip_ong),
            ("if-eqz", 0, "done"),
            # Never overwrite INCOMING with ONGOING if ringtone is actively playing!
            ("invoke-static", [6], m_ctrl_ring_mask),
            ("move-result", 0),
            ("and-int/lit8", 0, 0, 5),
            ("if-nez", 0, "is_really_ringing"),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("const/4", 0, 2),
            ("invoke-static", [0], m_ctrl_rec_state),
            ("return-void",),
            ("label", "is_really_ringing"),
            ("const/4", 0, 1),
            ("invoke-static", [0], m_ctrl_rec_state),
            ("invoke-static", [6], m_ctrl_start_watch),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    db.add_class(
        C_NOTIF,
        C_NLS,
        0x0001,
        static_fields=[(f_notif_inst, 0x0009)],
        direct_methods=[
            (
                m_notif_init,
                0x10001,
                {
                    "registers": 1, "ins": 1, "outs": 1,
                    "insns": [
                        ("invoke-direct", [0], m_nls_init),
                        ("sput-object", 0, f_notif_inst),
                        ("return-void",),
                    ],
                },
            ),
            (m_notif_send_pi, 0x0009, code_send_pi),
            (m_notif_is_excl, 0x0009, code_is_excl),
            (m_notif_is_pos, 0x0009, code_is_pos),
            (m_notif_is_neg, 0x0009, code_is_neg),
            (m_notif_refresh, 0x0009, code_notif_refresh),
            (m_notif_find_title, 0x0009, code_notif_find_title),
            (m_notif_trigger, 0x0009, code_notif_trigger),
        ],
        virtual_methods=[
            (
                m_notif_conn,
                0x0001,
                {
                    "registers": 2, "ins": 1, "outs": 1,
                    "insns": [
                        ("sput-object", 1, f_notif_inst),
                        ("const-string", 0, "Служба уведомлений подключена"),
                        ("invoke-static", [0], m_ctrl_log),
                        ("invoke-static", [], m_notif_refresh),
                        ("return-void",),
                    ],
                },
            ),
            (
                m_notif_disc,
                0x0001,
                {
                    "registers": 2, "ins": 1, "outs": 0,
                    "insns": [
                        ("const/4", 0, 0),
                        ("sput-object", 0, f_notif_inst),
                        ("return-void",),
                    ],
                },
            ),
            (m_notif_post, 0x0001, code_notif_post),
            (
                m_notif_rem,
                0x0001,
                {
                    "registers": 3, "ins": 2, "outs": 1,
                    "insns": [
                        ("sput-object", 1, f_notif_inst),
                        ("invoke-static", [], m_notif_refresh),
                        ("sget-boolean", 0, f_ctrl_voip_inc),
                        ("if-nez", 0, "done"),
                        ("invoke-static", [], m_ctrl_stop_tts),
                        ("sget-boolean", 0, f_ctrl_voip_ong),
                        ("if-nez", 0, "done"),
                        ("invoke-static", [1], m_ctrl_ring_mask),
                        ("move-result", 0),
                        ("and-int/lit8", 0, 0, 5),
                        ("if-nez", 0, "done"),
                        ("const/4", 0, 0),
                        ("invoke-static", [0], m_ctrl_rec_state),
                        ("label", "done"),
                        ("return-void",),
                    ],
                },
            ),
        ],
    )

    # =========================================================================
    # CLASS 3: ScreenAndVolumeReceiver
    # Handles:
    # 2) VOLUME_CHANGED_ACTION (Volume Up/Down during ringing Regular SIM call)
    # 3) SMS_RECEIVED (android.provider.Telephony.SMS_RECEIVED for Incoming SMS TTS)
    # =========================================================================
    m_rcvr_init = (C_RCVR, "<init>", ("V", ()))
    m_rcvr_onrec = (C_RCVR, "onReceive", ("V", (C_CTX, C_INTENT)))

    code_rcvr_onrec = {
        "registers": 10, "ins": 3, "outs": 3,
        "insns": [
            # v7 = this, v8 = Context, v9 = Intent
            ("if-eqz", 9, "done"),
            ("invoke-virtual", [9], m_intent_get_act),
            ("move-result-object", 0),
            ("if-eqz", 0, "done"),

            # 0. Check android.intent.action.PHONE_STATE
            ("const-string", 1, "android.intent.action.PHONE_STATE"),
            ("invoke-virtual", [1, 0], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "check_sms_act"),

            ("const-string", 1, "state"),
            ("invoke-virtual", [9, 1], m_intent_get_str),
            ("move-result-object", 1),
            ("if-eqz", 1, "done"),
            ("const-string", 2, "RINGING"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "check_ps_offhook"),

            # State is RINGING
            ("const/4", 2, 1),
            ("sput-boolean", 2, f_ctrl_sim_ringing),
            ("invoke-static", [2], m_ctrl_rec_state),
            ("invoke-static", [8], m_ctrl_start_watch),
            ("const-string", 1, "incoming_number"),
            ("invoke-virtual", [9, 1], m_intent_get_str),
            ("move-result-object", 1),
            ("if-eqz", 1, "done"),
            ("invoke-virtual", [1], m_str_len),
            ("move-result", 2),
            ("if-lez", 2, "done"),
            ("const-string", 2, "sim"),
            ("invoke-static", [8, 2, 1], m_ctrl_ann_call),
            ("return-void",),

            ("label", "check_ps_offhook"),
            ("const-string", 2, "OFFHOOK"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "check_ps_idle"),
            ("const/4", 2, 2),
            ("invoke-static", [2], m_ctrl_rec_state),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("return-void",),

            ("label", "check_ps_idle"),
            ("const-string", 2, "IDLE"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "done"),
            ("const/4", 2, 0),
            ("invoke-static", [2], m_ctrl_rec_state),
            ("invoke-static", [], m_ctrl_stop_tts),
            ("return-void",),

            # 1. Check SMS_RECEIVED
            ("label", "check_sms_act"),
            ("const-string", 1, "android.provider.Telephony.SMS_RECEIVED"),
            ("invoke-virtual", [1, 0], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "check_vol_act"),

            ("label", "ts_sms"),
            ("invoke-virtual", [9], m_intent_extras),
            ("move-result-object", 1),
            ("if-eqz", 1, "done"),
            ("const-string", 2, "pdus"),
            ("invoke-virtual", [1, 2], m_bundle_get),
            ("move-result-object", 1),
            ("if-eqz", 1, "done"),
            ("check-cast", 1, "[Ljava/lang/Object;"),
            ("array-length", 2, 1),
            ("if-lez", 2, "done"),
            ("const-string", 4, ""),
            ("new-instance", 5, C_SB),
            ("invoke-direct", [5], m_sb_init),
            ("const/4", 0, 0),
            ("label", "pdu_loop"),
            ("if-ge", 0, 2, "pdu_done"),
            ("aget-object", 3, 1, 0),
            ("if-eqz", 3, "pdu_next"),
            ("check-cast", 3, "[B"),
            ("invoke-static", [3], m_sms_pdu),
            ("move-result-object", 3),
            ("if-eqz", 3, "pdu_next"),
            ("invoke-virtual", [3], m_sms_addr),
            ("move-result-object", 6),
            ("if-eqz", 6, "get_pdu_b"),
            ("move-object", 4, 6),
            ("label", "get_pdu_b"),
            ("invoke-virtual", [3], m_sms_body),
            ("move-result-object", 6),
            ("if-eqz", 6, "pdu_next"),
            ("invoke-virtual", [5, 6], m_sb_app_str),
            ("move-result-object", 5),
            ("label", "pdu_next"),
            ("add-int/lit8", 0, 0, 1),
            ("goto/16", "pdu_loop"),
            ("label", "pdu_done"),
            ("const-string", 0, "tts_enabled"),
            ("const/4", 1, 1),
            ("invoke-static", [8, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 0, "tts_app_sms"),
            ("invoke-static", [8, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("const-string", 0, "tts_sms_text"),
            ("invoke-static", [8, 0, 1], m_ctrl_is_pref),
            ("move-result", 0),
            ("if-eqz", 0, "done"),
            ("invoke-virtual", [5], m_sb_tostr),
            ("move-result-object", 5),
            ("const-string", 6, "Получено входящее SMS (SMS_RECEIVED)"),
            ("invoke-static", [6], m_ctrl_log),
            ("const-string", 6, "sim"),
            ("sput-object", 6, f_ctrl_last_sms_pkg),
            ("invoke-static", [8, 4, 5], m_ctrl_ann_sms),
            ("label", "te_sms"),
            ("return-void",),
            ("label", "ca_sms"),
            ("move-exception", 1),
            ("return-void",),

            # 2. Check VOLUME_CHANGED_ACTION
            ("label", "check_vol_act"),
            ("const-string", 1, "android.media.VOLUME_CHANGED_ACTION"),
            ("invoke-virtual", [1, 0], m_str_equals),
            ("move-result", 2),
            ("if-eqz", 2, "done"),

            ("invoke-static", [8], m_ctrl_get_state),
            ("move-result", 2),
            ("const/4", 3, 1),
            ("if-ne", 2, 3, "done"),

            ("sget-wide", 0, f_ctrl_ring_start),
            ("const-wide/16", 2, 0),
            ("cmp-long", 4, 0, 2),
            ("if-lez", 4, "done"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 2),
            ("sub-long/2addr", 2, 0),
            ("const-wide/16", 0, 1500),
            ("cmp-long", 4, 2, 0),
            ("if-ltz", 4, "done"),

            ("sget-wide", 0, f_ctrl_last_tts_time),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 2),
            ("sub-long/2addr", 2, 0),
            ("const-wide/16", 0, 1200),
            ("cmp-long", 4, 2, 0),
            ("if-ltz", 4, "done"),

            ("const-string", 5, "android.media.EXTRA_VOLUME_STREAM_TYPE"),
            ("const/4", 6, -1),
            ("invoke-virtual", [9, 5, 6], m_intent_get_int),
            ("move-result", 4),
            # Accept ONLY STREAM_RING (2) and STREAM_VOICE_CALL (0) — never STREAM_ACCESSIBILITY (10)
            ("const/4", 5, 2),
            ("if-eq", 4, 5, "stream_ok"),
            ("if-nez", 4, "done"),

            ("label", "stream_ok"),
            ("const-string", 5, "android.media.EXTRA_VOLUME_STREAM_VALUE"),
            ("invoke-virtual", [9, 5, 6], m_intent_get_int),
            ("move-result", 2),
            ("const-string", 5, "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE"),
            ("invoke-virtual", [9, 5, 6], m_intent_get_int),
            ("move-result", 3),
            ("if-ltz", 2, "done"),
            ("if-ltz", 3, "done"),
            ("if-eq", 2, 3, "done"),

            ("if-gt", 2, 3, "vol_up_btn"),
            ("goto/16", "vol_dn_btn"),

            ("label", "vol_up_btn"),
            ("const/4", 4, 1),
            ("goto/16", "do_vol_trig"),

            ("label", "vol_dn_btn"),
            ("const/4", 4, 2),

            ("label", "do_vol_trig"),
            # Volume level changes are not evidence of a hardware key press.
            ("goto/16", "done"),

            ("label", "done"),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts_sms", "end_label": "te_sms", "handler_label": "ca_sms"}],
    }

    db.add_class(
        C_RCVR,
        C_BR,
        0x0001,
        direct_methods=[
            (
                m_rcvr_init,
                0x10001,
                {
                    "registers": 1, "ins": 1, "outs": 1,
                    "insns": [("invoke-direct", [0], m_br_init), ("return-void",)],
                },
            ),
        ],
        virtual_methods=[(m_rcvr_onrec, 0x0001, code_rcvr_onrec)],
    )

    # =========================================================================
    # CLASS 4: DelayedActionRunnable (Non-blocking Handler pulses)
    # Modes:
    # 1: answerCallPulse
    # 2: endCallPulse
    # 5: checkRingtoneStep
    # 6: confirmRingtoneSilenced
    # 7: checkDelayedCaller
    # 8: performDelayedSwipeUp
    # =========================================================================
    f_run_ctx = (C_RUN_ACT, "context", C_CTX)
    f_run_mode = (C_RUN_ACT, "mode", "I")
    m_run_act_run = (C_RUN_ACT, "run", ("V", ()))

    code_run_act_run = {
        "registers": 4, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("iget-object", 0, 3, f_run_ctx),
            ("iget", 1, 3, f_run_mode),
            ("const/4", 2, 1),
            ("if-eq", 1, 2, "m1"),
            ("const/4", 2, 2),
            ("if-eq", 1, 2, "m2"),
            ("const/4", 2, 5),
            ("if-eq", 1, 2, "m5"),
            ("const/4", 2, 6),
            ("if-eq", 1, 2, "m6"),
            ("const/4", 2, 7),
            ("if-eq", 1, 2, "m7"),
            ("const/16", 2, 8),
            ("if-eq", 1, 2, "m8"),
            ("return-void",),

            ("label", "m1"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_ctrl_ans_pulse),
            ("return-void",),

            ("label", "m2"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_ctrl_end_pulse),
            ("return-void",),

            ("label", "m5"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_ctrl_watch_step),
            ("return-void",),

            ("label", "m6"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_ctrl_confirm_sil),
            ("return-void",),

            ("label", "m7"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_ctrl_delayed_caller),
            ("return-void",),

            ("label", "m8"),
            ("if-eqz", 0, "done"),
            ("invoke-static", [0], m_acc_do_swipe_up),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    db.add_class(
        C_RUN_ACT,
        C_OBJ,
        0x0001,
        interfaces=(C_RUNNABLE,),
        instance_fields=[
            (f_run_ctx, 0x0002),
            (f_run_mode, 0x0002),
        ],
        direct_methods=[
            (
                m_run_act_init,
                0x10001,
                {
                    "registers": 3, "ins": 3, "outs": 1,
                    "insns": [
                        ("invoke-direct", [0], m_obj_init),
                        ("iput-object", 1, 0, f_run_ctx),
                        ("iput", 2, 0, f_run_mode),
                        ("return-void",),
                    ],
                },
            ),
        ],
        virtual_methods=[(m_run_act_run, 0x0001, code_run_act_run)],
    )

    # =========================================================================
    # CLASS 6: CallControlAccessibilityService
    # =========================================================================
    f_acc_rcvr = (C_ACC, "receiver", C_RCVR)
    m_acc_init = (C_ACC, "<init>", ("V", ()))
    m_acc_conn = (C_ACC, "onServiceConnected", ("V", ()))
    m_acc_event = (C_ACC, "onAccessibilityEvent", ("V", (C_ACCEV,)))
    m_acc_intr = (C_ACC, "onInterrupt", ("V", ()))
    m_acc_key = (C_ACC, "onKeyEvent", ("Z", (C_KE,)))
    m_acc_destroy = (C_ACC, "onDestroy", ("V", ()))
    m_acc_node_match = (C_ACC, "matchesNode", ("Z", (C_ACCNI, "Z")))
    m_acc_scan_tree = (C_ACC, "scanNodeTree", ("I", (C_ACCNI,)))
    m_acc_swipe_node = (C_ACC, "swipeNode", ("V", (C_ACCNI, "Z")))
    m_acc_click_rec = (C_ACC, "clickNodeTree", ("Z", (C_ACCNI, "Z")))

    # getActiveCapabilities() -> int
    code_acc_get_caps = {
        "registers": 3, "ins": 0, "outs": 1,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_acc_inst),
            ("if-eqz", 0, "ret_0"),
            ("invoke-virtual", [0], m_accs_get_info),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_0"),
            ("invoke-virtual", [0], m_accsi_get_caps),
            ("move-result", 1),
            ("label", "te"),
            ("return", 1),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "ret_0"),
            ("const/4", 1, 0),
            ("return", 1),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # matchesNode(AccessibilityNodeInfo v4, boolean v5_isAnswer) -> boolean
    code_node_match = {
        "registers": 6, "ins": 2, "outs": 2,
        "insns": [
            ("if-eqz", 4, "ret_f"),
            ("invoke-virtual", [4], m_accni_get_pkg),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_f"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_str_lower),
            ("move-result-object", 0),
            ("const-string", 1, "com.smartcall.ru"),
            ("invoke-virtual", [1, 0], m_str_equals),
            ("move-result", 1),
            ("if-nez", 1, "ret_f"),
            ("const-string", 1, "systemui"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "launcher"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "ret_f"),
            ("const-string", 1, "miui.home"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "ret_f"),

            # Allow dialer / incallui / telecom / phone packages
            ("const-string", 1, "dialer"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "incallui"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "telecom"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "phone"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),

            # For VoIP apps (whatsapp, telegram, nekogram, viber, imo), ONLY allow when voipIncoming or voipOngoing is active!
            ("sget-boolean", 1, f_ctrl_voip_inc),
            ("if-nez", 1, "check_voip_pkg"),
            ("sget-boolean", 1, f_ctrl_voip_ong),
            ("if-eqz", 1, "ret_f"),

            ("label", "check_voip_pkg"),
            ("const-string", 1, "whatsapp"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "telegram"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "nekogram"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "viber"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("const-string", 1, "imo"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "check_txt"),
            ("goto/16", "ret_f"),

            # 1. Check getText()
            ("label", "check_txt"),
            ("invoke-virtual", [4], m_accni_get_text),
            ("move-result-object", 0),
            ("if-eqz", 0, "check_desc"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("if-eqz", 5, "t_neg"),
            ("invoke-static", [0], m_notif_is_pos),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),
            ("goto/16", "check_desc"),
            ("label", "t_neg"),
            ("invoke-static", [0], m_notif_is_neg),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),

            # 2. Check getContentDescription()
            ("label", "check_desc"),
            ("invoke-virtual", [4], m_accni_get_desc),
            ("move-result-object", 0),
            ("if-eqz", 0, "check_vid"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("if-eqz", 5, "d_neg"),
            ("invoke-static", [0], m_notif_is_pos),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),
            ("goto/16", "check_vid"),
            ("label", "d_neg"),
            ("invoke-static", [0], m_notif_is_neg),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),

            # 3. Check getViewIdResourceName()
            ("label", "check_vid"),
            ("invoke-virtual", [4], m_accni_get_vid),
            ("move-result-object", 0),
            ("if-eqz", 0, "ret_f"),
            ("if-eqz", 5, "v_neg"),
            ("invoke-static", [0], m_notif_is_pos),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),
            ("goto/16", "ret_f"),
            ("label", "v_neg"),
            ("invoke-static", [0], m_notif_is_neg),
            ("move-result", 1),
            ("if-nez", 1, "ret_t"),

            ("label", "ret_f"),
            ("const/4", 1, 0),
            ("return", 1),
            ("label", "ret_t"),
            ("const/4", 1, 1),
            ("return", 1),
        ],
    }

    # scanNodeTree(AccessibilityNodeInfo v6) -> int (bitmask: 1=Answer button found, 2=End button found)
    code_scan_tree = {
        "registers": 7, "ins": 1, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("if-eqz", 6, "ret"),
            ("label", "ts"),
            ("invoke-virtual", [6], m_accni_get_pkg),
            ("move-result-object", 1),
            ("if-eqz", 1, "do_scan_m"),
            ("invoke-interface", [1], m_cs_tostr),
            ("move-result-object", 1),
            ("const-string", 2, "systemui"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 1),
            ("if-nez", 1, "ret"),
            ("label", "do_scan_m"),
            ("const/4", 1, 1),
            ("invoke-static", [6, 1], m_acc_node_match),
            ("move-result", 2),
            ("if-eqz", 2, "check_neg"),
            ("const/4", 2, 1),
            ("or-int/2addr", 0, 2),
            ("label", "check_neg"),
            ("const/4", 1, 0),
            ("invoke-static", [6, 1], m_acc_node_match),
            ("move-result", 2),
            ("if-eqz", 2, "children"),
            ("const/4", 2, 2),
            ("or-int/2addr", 0, 2),

            ("label", "children"),
            ("invoke-virtual", [6], m_accni_get_cnt),
            ("move-result", 3),
            ("const/4", 4, 0),
            ("label", "loop"),
            ("if-ge", 4, 3, "te"),
            ("invoke-virtual", [6, 4], m_accni_get_child),
            ("move-result-object", 5),
            ("if-eqz", 5, "next"),
            ("invoke-static", [5], m_acc_scan_tree),
            ("move-result", 2),
            ("or-int/2addr", 0, 2),
            ("and-int/lit8", 2, 0, 1),
            ("if-nez", 2, "te"),
            ("label", "next"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "loop"),
            ("label", "te"),
            ("label", "ret"),
            ("return", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # detectCallUiState() -> int (1=Answer button on screen -> INCOMING, 2=Only End button -> ONGOING, 0=none)
    code_detect_ui = {
        "registers": 7, "ins": 0, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("label", "ts"),
            ("sget-object", 1, f_acc_inst),
            ("if-eqz", 1, "te"),
            ("invoke-virtual", [1], m_accs_get_root),
            ("move-result-object", 2),
            ("if-eqz", 2, "check_wins"),
            ("invoke-static", [2], m_acc_scan_tree),
            ("move-result", 0),
            ("and-int/lit8", 2, 0, 1),
            ("if-nez", 2, "ret_1"),

            ("label", "check_wins"),
            ("invoke-virtual", [1], m_accs_get_wins),
            ("move-result-object", 2),
            ("if-eqz", 2, "eval_mask"),
            ("invoke-interface", [2], m_list_size),
            ("move-result", 3),
            ("const/4", 4, 0),
            ("label", "wloop"),
            ("if-ge", 4, 3, "eval_mask"),
            ("invoke-interface", [2, 4], m_list_get),
            ("move-result-object", 5),
            ("check-cast", 5, C_ACCWI),
            ("if-eqz", 5, "wnext"),
            ("invoke-virtual", [5], m_accwi_get_root),
            ("move-result-object", 5),
            ("if-eqz", 5, "wnext"),
            ("invoke-static", [5], m_acc_scan_tree),
            ("move-result", 6),
            ("or-int/2addr", 0, 6),
            ("and-int/lit8", 6, 0, 1),
            ("if-nez", 6, "ret_1"),
            ("label", "wnext"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "wloop"),

            ("label", "eval_mask"),
            ("and-int/lit8", 2, 0, 1),
            ("if-nez", 2, "ret_1"),
            ("sget-boolean", 2, f_ctrl_voip_inc),
            ("if-nez", 2, "ret_1"),
            ("and-int/lit8", 2, 0, 2),
            ("if-nez", 2, "ret_2"),
            ("label", "te"),
            ("const/4", 2, 0),
            ("return", 2),

            ("label", "ret_1"),
            ("const/4", 2, 1),
            ("return", 2),
            ("label", "ret_2"),
            ("const/4", 2, 2),
            ("return", 2),
            ("label", "ca"),
            ("move-exception", 1),
            ("const/4", 2, 0),
            ("return", 2),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # performDelayedSwipeUp(Context v7) -> void
    # Runs 170ms after the initial TAP on a full-screen incoming call Answer button.
    # If the call is STILL incoming (getCallState(v7) == 1), dispatches a 220ms SWIPE UP gesture
    # from (pendingSwipeX, pendingSwipeY) to (pendingSwipeX, pendingSwipeY - 480)!
    code_do_swipe_up = {
        "registers": 8, "ins": 1, "outs": 6,
        "insns": [
            ("if-eqz", 7, "done"),
            ("label", "ts"),
            ("invoke-static", [7], m_ctrl_get_state),
            ("move-result", 0),
            ("const/4", 1, 1),
            ("if-ne", 0, 1, "done"),
            ("sget-object", 6, f_acc_inst),
            ("if-eqz", 6, "done"),
            ("sget", 2, f_ctrl_swipe_x),
            ("sget", 3, f_ctrl_swipe_y),
            ("if-lez", 2, "done"),
            ("if-lez", 3, "done"),
            ("int-to-float", 2, 2),
            ("int-to-float", 4, 3),
            ("add-int/lit8", 3, 3, -120),
            ("add-int/lit8", 3, 3, -120),
            ("add-int/lit8", 3, 3, -120),
            ("add-int/lit8", 3, 3, -120),
            ("if-gtz", 3, "min_y"),
            ("const/16", 3, 100),
            ("label", "min_y"),
            ("int-to-float", 3, 3),
            ("new-instance", 1, C_PATH),
            ("invoke-direct", [1], m_path_init),
            ("invoke-virtual", [1, 2, 4], m_path_move),
            ("invoke-virtual", [1, 2, 3], m_path_line),
            ("new-instance", 0, C_GD_SD),
            ("const-wide/16", 2, 0),
            ("const-wide/16", 4, 220),
            ("invoke-direct/range", [0, 1, 2, 3, 4, 5], m_gdsd_init),
            ("new-instance", 1, C_GD_B),
            ("invoke-direct", [1], m_gdb_init),
            ("invoke-virtual", [1, 0], m_gdb_add),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_gdb_build),
            ("move-result-object", 1),
            ("const/4", 0, 0),
            ("invoke-virtual", [6, 1, 0, 0], m_accs_disp_gest),
            ("move-result", 2),
            ("const-string", 0, "Экран: свайп вверх по кнопке ответа"),
            ("invoke-static", [0], m_ctrl_log),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # swipeNode(AccessibilityNodeInfo v7, boolean v8_isAnswer) -> void
    # - For Answer (isAnswer==true):
    #   Always dispatches an immediate 55ms TAP at (cx, cy) (which answers both top banner AND full-screen 2-button layouts!),
    #   AND if cy >= 600 (full-screen UI), also schedules performDelayedSwipeUp at +170ms in case it's a vertical slider!
    # - For End/Decline (isAnswer==false):
    #   If dual puck (cy >= 600 and matchesNode(v7, true)), dispatches 220ms SWIPE DOWN (cy + 400);
    #   otherwise dispatches 55ms TAP at (cx, cy)!
    code_swipe_node = {
        "registers": 9, "ins": 2, "outs": 6,
        "insns": [
            ("label", "ts"),
            ("sget-object", 6, f_acc_inst),
            ("if-eqz", 6, "te"),
            ("if-eqz", 7, "te"),
            ("new-instance", 0, C_RECT),
            ("invoke-direct", [0], m_rect_init),
            ("invoke-virtual", [7, 0], m_accni_bounds),
            ("invoke-virtual", [0], m_rect_cx),
            ("move-result", 2),
            ("invoke-virtual", [0], m_rect_cy),
            ("move-result", 3),
            ("if-lez", 2, "te"),
            ("if-lez", 3, "te"),

            ("if-eqz", 8, "check_end_gest"),
            # Answer (isAnswer == true): save (cx, cy) and if cy >= 600, schedule delayed swipe up at +170ms!
            ("sput", 2, f_ctrl_swipe_x),
            ("sput", 3, f_ctrl_swipe_y),
            ("const/16", 5, 600),
            ("if-lt", 3, 5, "do_tap_now"),
            ("invoke-static", [], m_looper_main),
            ("move-result-object", 0),
            ("new-instance", 1, C_HANDLER),
            ("invoke-direct", [1, 0], m_handler_init),
            ("new-instance", 0, C_RUN_ACT),
            ("const/16", 5, 8),
            ("invoke-direct", [0, 6, 5], m_run_act_init),
            ("const-wide/16", 4, 170),
            ("invoke-virtual", [1, 0, 4, 5], m_handler_post_del),
            ("move-result", 5),
            ("goto/16", "do_tap_now"),

            ("label", "check_end_gest"),
            ("const/16", 5, 600),
            ("if-lt", 3, 5, "do_tap_now"),
            ("const/4", 5, 1),
            ("invoke-static", [7, 5], m_acc_node_match),
            ("move-result", 5),
            ("if-eqz", 5, "do_tap_now"),
            # Dual puck decline -> swipe DOWN 400px
            ("int-to-float", 2, 2),
            ("int-to-float", 4, 3),
            ("add-int/lit8", 3, 3, 100),
            ("add-int/lit8", 3, 3, 100),
            ("add-int/lit8", 3, 3, 100),
            ("add-int/lit8", 3, 3, 100),
            ("int-to-float", 3, 3),
            ("new-instance", 1, C_PATH),
            ("invoke-direct", [1], m_path_init),
            ("invoke-virtual", [1, 2, 4], m_path_move),
            ("invoke-virtual", [1, 2, 3], m_path_line),
            ("new-instance", 0, C_GD_SD),
            ("const-wide/16", 2, 0),
            ("const-wide/16", 4, 220),
            ("invoke-direct/range", [0, 1, 2, 3, 4, 5], m_gdsd_init),
            ("const/4", 8, 2),
            ("goto/16", "send_gest"),

            ("label", "do_tap_now"),
            ("const/4", 8, 0),
            ("int-to-float", 2, 2),
            ("int-to-float", 4, 3),
            ("int-to-float", 3, 3),
            ("new-instance", 1, C_PATH),
            ("invoke-direct", [1], m_path_init),
            ("invoke-virtual", [1, 2, 4], m_path_move),
            ("invoke-virtual", [1, 2, 3], m_path_line),
            ("new-instance", 0, C_GD_SD),
            ("const-wide/16", 2, 0),
            ("const-wide/16", 4, 55),
            ("invoke-direct/range", [0, 1, 2, 3, 4, 5], m_gdsd_init),

            ("label", "send_gest"),
            ("new-instance", 1, C_GD_B),
            ("invoke-direct", [1], m_gdb_init),
            ("invoke-virtual", [1, 0], m_gdb_add),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_gdb_build),
            ("move-result-object", 1),
            ("const/4", 0, 0),
            ("invoke-virtual", [6, 1, 0, 0], m_accs_disp_gest),
            ("move-result", 2),
            ("if-nez", 8, "log_down"),
            ("const-string", 0, "Экран: нажатие (TAP) по кнопке вызова"),
            ("invoke-static", [0], m_ctrl_log),
            ("goto/16", "te"),
            ("label", "log_down"),
            ("const-string", 0, "Экран: свайп вниз по кнопке отклонения"),
            ("invoke-static", [0], m_ctrl_log),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # clickNodeTree(AccessibilityNodeInfo v5, boolean v6_isAnswer) -> boolean
    code_click_rec = {
        "registers": 7, "ins": 2, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("if-eqz", 5, "ret_f"),
            ("invoke-static", [5, 6], m_acc_node_match),
            ("move-result", 0),
            ("if-eqz", 0, "children"),

            ("move-object", 1, 5),
            ("invoke-virtual", [1], m_accni_is_click),
            ("move-result", 0),
            ("if-nez", 0, "do_click"),
            ("invoke-virtual", [1], m_accni_get_parent),
            ("move-result-object", 1),
            ("if-eqz", 1, "click_self"),
            ("invoke-virtual", [1], m_accni_is_click),
            ("move-result", 0),
            ("if-nez", 0, "do_click"),
            ("invoke-virtual", [1], m_accni_get_parent),
            ("move-result-object", 1),
            ("if-eqz", 1, "click_self"),

            ("label", "do_click"),
            ("const/16", 0, 16),
            ("invoke-virtual", [1, 0], m_accni_perf_act),
            ("move-result", 0),
            ("if-nez", 0, "clicked_ok"),

            ("label", "click_self"),
            ("const/16", 0, 16),
            ("invoke-virtual", [5, 0], m_accni_perf_act),
            ("move-result", 0),
            ("if-nez", 0, "clicked_ok"),

            ("invoke-static", [5, 6], m_acc_swipe_node),
            ("const/4", 0, 1),
            ("return", 0),

            ("label", "clicked_ok"),
            ("const-string", 0, "Экран: нажата кнопка вызова (ACTION_CLICK)"),
            ("invoke-static", [0], m_ctrl_log),
            ("invoke-virtual", [5], m_accni_get_pkg),
            ("move-result-object", 0),
            ("if-eqz", 0, "check_sim_dir"),
            ("invoke-interface", [0], m_cs_tostr),
            ("move-result-object", 0),
            ("const-string", 1, "whatsapp"),
            ("invoke-virtual", [0, 1], m_str_contains),
            ("move-result", 0),
            ("if-nez", 0, "ret_clicked_1"),
            ("label", "check_sim_dir"),
            ("invoke-static", [5, 6], m_acc_swipe_node),
            ("label", "ret_clicked_1"),
            ("const/4", 0, 1),
            ("return", 0),

            ("label", "children"),
            ("invoke-virtual", [5], m_accni_get_cnt),
            ("move-result", 2),
            ("const/4", 3, 0),
            ("label", "loop"),
            ("if-ge", 3, 2, "ret_f"),
            ("invoke-virtual", [5, 3], m_accni_get_child),
            ("move-result-object", 4),
            ("if-eqz", 4, "next"),
            ("invoke-static", [4, 6], m_acc_click_rec),
            ("move-result", 0),
            ("if-nez", 0, "ret_t"),
            ("label", "next"),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "loop"),
            ("label", "te"),

            ("label", "ret_f"),
            ("const/4", 0, 0),
            ("return", 0),
            ("label", "ret_t"),
            ("const/4", 0, 1),
            ("return", 0),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 0, 0),
            ("return", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # clickCallButtonInUi(boolean v6_isAnswer) -> boolean
    code_acc_click_ui = {
        "registers": 7, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_acc_inst),
            ("if-eqz", 0, "ret_f"),
            ("invoke-virtual", [0], m_accs_get_root),
            ("move-result-object", 1),
            ("if-eqz", 1, "check_wins"),
            ("invoke-static", [1, 6], m_acc_click_rec),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),

            ("label", "check_wins"),
            ("invoke-virtual", [0], m_accs_get_wins),
            ("move-result-object", 1),
            ("if-eqz", 1, "ret_f"),
            ("invoke-interface", [1], m_list_size),
            ("move-result", 3),
            ("const/4", 4, 0),
            ("label", "wloop"),
            ("if-ge", 4, 3, "ret_f"),
            ("invoke-interface", [1, 4], m_list_get),
            ("move-result-object", 5),
            ("check-cast", 5, C_ACCWI),
            ("if-eqz", 5, "wnext"),
            ("invoke-virtual", [5], m_accwi_get_root),
            ("move-result-object", 5),
            ("if-eqz", 5, "wnext"),
            ("invoke-static", [5, 6], m_acc_click_rec),
            ("move-result", 2),
            ("if-nez", 2, "ret_t"),
            ("label", "wnext"),
            ("add-int/lit8", 4, 4, 1),
            ("goto/16", "wloop"),
            ("label", "te"),

            ("label", "ret_f"),
            ("const/4", 2, 0),
            ("return", 2),
            ("label", "ret_t"),
            ("const/4", 2, 1),
            ("return", 2),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 2, 0),
            ("return", 2),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # findCallerNodeRec(AccessibilityNodeInfo v5) -> String
    # Strictly ignores com.smartcall.ru, launcher, home, and systemui (status bar clock 13:50 / battery / network speed)!
    code_find_rec = {
        "registers": 6, "ins": 1, "outs": 2,
        "insns": [
            ("const/4", 0, 0),
            ("if-eqz", 5, "ret"),
            ("label", "ts"),
            ("invoke-virtual", [5], m_accni_get_pkg),
            ("move-result-object", 1),
            ("if-eqz", 1, "ret"),
            ("invoke-interface", [1], m_cs_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_str_lower),
            ("move-result-object", 1),
            ("const-string", 2, "com.smartcall.ru"),
            ("invoke-virtual", [2, 1], m_str_equals),
            ("move-result", 2),
            ("if-nez", 2, "ret"),
            ("const-string", 2, "launcher"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret"),
            ("const-string", 2, "systemui"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret"),
            ("const-string", 2, "miui.home"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "ret"),

            # Strictly require dialer / incallui / telecom / phone package!
            ("const-string", 2, "dialer"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "check_txt"),
            ("const-string", 2, "incallui"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "check_txt"),
            ("const-string", 2, "telecom"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "check_txt"),
            ("const-string", 2, "phone"),
            ("invoke-virtual", [1, 2], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "check_txt"),
            ("goto/16", "ret"),

            ("label", "check_txt"),
            ("invoke-virtual", [5], m_accni_get_text),
            ("move-result-object", 1),
            ("if-eqz", 1, "children"),
            ("invoke-interface", [1], m_cs_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_str_len),
            ("move-result", 2),
            ("const/4", 3, 2),
            ("if-le", 2, 3, "children"),
            ("const/16", 3, 45),
            ("if-ge", 2, 3, "children"),
            # Skip clock/battery/speed strings (":", "%", "кб/с") and button keywords
            ("const-string", 3, ":"),
            ("invoke-virtual", [1, 3], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "children"),
            ("const-string", 3, "%"),
            ("invoke-virtual", [1, 3], m_str_contains),
            ("move-result", 2),
            ("if-nez", 2, "children"),
            ("invoke-static", [1], m_notif_is_pos),
            ("move-result", 2),
            ("if-nez", 2, "children"),
            ("invoke-static", [1], m_notif_is_neg),
            ("move-result", 2),
            ("if-nez", 2, "children"),
            ("invoke-virtual", [1], m_str_lower),
            ("move-result-object", 2),
            ("invoke-static", [2], m_notif_is_excl),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("const-string", 3, "вызов"),
            ("invoke-virtual", [2, 3], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("const-string", 3, "звонок"),
            ("invoke-virtual", [2, 3], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("const-string", 3, "входящ"),
            ("invoke-virtual", [2, 3], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("const-string", 3, "sim"),
            ("invoke-virtual", [2, 3], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("const-string", 3, "кб/с"),
            ("invoke-virtual", [2, 3], m_str_contains),
            ("move-result", 3),
            ("if-nez", 3, "children"),
            ("return-object", 1),

            ("label", "children"),
            ("invoke-virtual", [5], m_accni_get_cnt),
            ("move-result", 2),
            ("const/4", 3, 0),
            ("label", "loop"),
            ("if-ge", 3, 2, "ret"),
            ("invoke-virtual", [5, 3], m_accni_get_child),
            ("move-result-object", 4),
            ("if-eqz", 4, "next"),
            ("invoke-static", [4], m_acc_find_rec),
            ("move-result-object", 1),
            ("if-eqz", 1, "next"),
            ("return-object", 1),
            ("label", "next"),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "loop"),
            ("label", "te"),
            ("label", "ret"),
            ("return-object", 0),
            ("label", "ca"),
            ("move-exception", 1),
            ("return-object", 0),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # findCallerNameInUi() -> String
    code_find_caller = {
        "registers": 5, "ins": 0, "outs": 2,
        "insns": [
            ("sget-object", 0, f_acc_inst),
            ("if-eqz", 0, "ret_null"),
            ("invoke-static", [0], m_features_find),
            ("move-result-object", 1),
            ("if-nez", 1, "ret_val"),

            # Fallback 1: scan getRootInActiveWindow()
            ("invoke-virtual", [0], m_accs_get_root),
            ("move-result-object", 4),
            ("if-eqz", 4, "scan_wins"),
            ("invoke-static", [4], m_acc_find_rec),
            ("move-result-object", 1),
            ("if-nez", 1, "ret_val"),

            # Fallback 2: scan getWindows()
            ("label", "scan_wins"),
            ("invoke-virtual", [0], m_accs_get_wins),
            ("move-result-object", 2),
            ("if-eqz", 2, "ret_null"),
            ("invoke-interface", [2], m_list_size),
            ("move-result", 3),
            ("const/4", 1, 0),
            ("label", "wloop"),
            ("if-ge", 1, 3, "ret_null"),
            ("invoke-interface", [2, 1], m_list_get),
            ("move-result-object", 4),
            ("check-cast", 4, C_ACCWI),
            ("if-eqz", 4, "wnext"),
            ("invoke-virtual", [4], m_accwi_get_root),
            ("move-result-object", 4),
            ("if-eqz", 4, "wnext"),
            ("invoke-static", [4], m_acc_find_rec),
            ("move-result-object", 4),
            ("if-nez", 4, "ret_w_val"),
            ("label", "wnext"),
            ("add-int/lit8", 1, 1, 1),
            ("goto/16", "wloop"),

            ("label", "ret_w_val"),
            ("return-object", 4),
            ("label", "ret_val"),
            ("return-object", 1),
            ("label", "ret_null"),
            ("const/4", 1, 0),
            ("return-object", 1),
        ],
    }

    # onServiceConnected()
    code_acc_conn = {
        "registers": 5, "ins": 1, "outs": 4,
        "insns": [
            ("sput-object", 4, f_acc_inst),
            ("invoke-static", [4], m_ctrl_bind_notif),
            ("label", "ts"),
            ("invoke-virtual", [4], m_accs_get_info),
            ("move-result-object", 0),
            ("if-eqz", 0, "reg_rcvr"),
            ("const/4", 1, -1),
            ("iput", 1, 0, f_accsi_events),
            ("iget", 1, 0, f_accsi_flags),
            ("const/16", 2, 0x73),
            ("or-int/2addr", 1, 2),
            ("iput", 1, 0, f_accsi_flags),
            ("invoke-virtual", [4, 0], m_accs_set_info),

            ("invoke-virtual", [0], m_accsi_get_caps),
            ("move-result", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "СпецВозм подключена: cap="),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_int),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-static", [1], m_ctrl_log),

            ("label", "reg_rcvr"),
            ("new-instance", 0, C_RCVR),
            ("invoke-direct", [0], m_rcvr_init),
            ("iput-object", 0, 4, f_acc_rcvr),
            ("new-instance", 1, C_IFILTER),
            ("invoke-direct", [1], m_ifilter_init),
            ("const-string", 2, "android.media.VOLUME_CHANGED_ACTION"),
            ("invoke-virtual", [1, 2], m_ifilter_add),
            ("sget", 2, f_sdk_int),
            ("add-int/lit8", 2, 2, -33),
            ("if-ltz", 2, "reg_legacy"),
            ("const/4", 2, 2),
            ("invoke-virtual", [4, 0, 1, 2], m_ctx_reg_rcvr_flg),
            ("move-result-object", 2),
            ("goto/16", "reg_ok"),
            ("label", "reg_legacy"),
            ("invoke-virtual", [4, 0, 1], m_ctx_reg_rcvr),
            ("move-result-object", 2),
            ("label", "reg_ok"),
            ("const/4", 2, 1),
            ("sput-boolean", 2, f_acc_receiver_ready),
            ("const-string", 1, "Приёмник кнопок громкости зарегистрирован"),
            ("invoke-static", [1], m_ctrl_log),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("const/4", 1, 0),
            ("sput-boolean", 1, f_acc_receiver_ready),
            ("const-string", 1, "Ошибка подключения службы/приёмника громкости:"),
            ("invoke-static", [1], m_ctrl_log),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # onKeyEvent(KeyEvent v7) -> boolean
    code_acc_key = {
        "registers": 8, "ins": 2, "outs": 2,
        "insns": [
            ("if-eqz", 7, "ret_f"),
            ("invoke-virtual", [7], m_ke_get_code),
            ("move-result", 0),
            ("invoke-virtual", [7], m_ke_get_act),
            ("move-result", 2),
            ("if-nez", 2, "key_up"),
            ("invoke-virtual", [7], m_ke_repeat),
            ("move-result", 2),
            ("if-nez", 2, "held_key"),
            ("const/16", 2, 24),
            ("const/4", 1, 1),
            ("if-eq", 0, 2, "check_intercept"),
            ("const/16", 2, 25),
            ("const/4", 1, 2),
            ("if-ne", 0, 2, "ret_f"),
            ("label", "check_intercept"),
            ("invoke-static", [6, 1], m_ctrl_should_key),
            ("move-result", 3),
            ("if-eqz", 3, "ret_f"),
            ("iput", 0, 6, f_acc_key),
            ("invoke-static", [6, 1], m_ctrl_handle_btn),
            ("move-result", 3),
            ("goto/16", "consume"),
            ("label", "key_up"),
            ("const/4", 3, 1),
            ("if-ne", 2, 3, "ret_f"),
            ("iget", 3, 6, f_acc_key),
            ("if-ne", 0, 3, "ret_f"),
            ("const/4", 3, 0),
            ("iput", 3, 6, f_acc_key),
            ("goto/16", "consume"),
            ("label", "held_key"),
            ("iget", 3, 6, f_acc_key),
            ("if-ne", 0, 3, "ret_f"),
            ("label", "consume"),
            ("const/4", 3, 1),
            ("return", 3),
            ("label", "ret_f"),
            ("const/4", 3, 0),
            ("return", 3),
        ],
    }

    # onDestroy()
    code_acc_destroy = {
        "registers": 3, "ins": 1, "outs": 2,
        "insns": [
            ("label", "ts"),
            ("iget-object", 0, 2, f_acc_rcvr),
            ("if-eqz", 0, "te"),
            ("invoke-virtual", [2, 0], m_ctx_unreg_rcvr),
            ("label", "te"),
            ("goto/16", "done"),
            ("label", "ca"),
            ("move-exception", 0),
            ("label", "done"),
            ("const/4", 0, 0),
            ("sput-object", 0, f_acc_inst),
            ("sput-boolean", 0, f_acc_receiver_ready),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    db.add_class(
        C_ACC,
        C_ACCS,
        0x0001,
        static_fields=[(f_acc_inst, 0x0009), (f_acc_receiver_ready, 0x0009)],
        instance_fields=[(f_acc_rcvr, 0x0002), (f_acc_key, 0x0002)],
        direct_methods=[
            (
                m_acc_init,
                0x10001,
                {
                    "registers": 1, "ins": 1, "outs": 1,
                    "insns": [("invoke-direct", [0], m_accs_init), ("return-void",)],
                },
            ),
            (m_acc_get_caps, 0x0009, code_acc_get_caps),
            (m_acc_node_match, 0x0009, code_node_match),
            (m_acc_scan_tree, 0x0009, code_scan_tree),
            (m_acc_detect_ui, 0x0009, code_detect_ui),
            (m_acc_do_swipe_up, 0x0009, code_do_swipe_up),
            (m_acc_swipe_node, 0x0009, code_swipe_node),
            (m_acc_click_rec, 0x0009, code_click_rec),
            (m_acc_click_ui, 0x0009, code_acc_click_ui),
            (m_acc_find_rec, 0x0009, code_find_rec),
            (m_acc_find_caller, 0x0009, code_find_caller),
        ],
        virtual_methods=[
            (m_acc_conn, 0x0004, code_acc_conn),
            (
                m_acc_event,
                0x0001,
                {
                    "registers": 2,
                    "ins": 2,
                    "outs": 1,
                    "insns": [
                        ("invoke-static", [0], m_ctrl_start_watch),
                        ("return-void",),
                    ],
                },
            ),
            (
                m_acc_intr,
                0x0001,
                {"registers": 1, "ins": 1, "outs": 0, "insns": [("return-void",)]},
            ),
            (m_acc_key, 0x0004, code_acc_key),
            (m_acc_destroy, 0x0001, code_acc_destroy),
        ],
    )

    # =========================================================================
    # CLASS 7: DialogClickListener (passes both mode and whichItem)
    # =========================================================================
    f_dlg_act = (C_DLG, "activity", C_MAIN)
    f_dlg_mode = (C_DLG, "mode", "I")
    m_dlg_init = (C_DLG, "<init>", ("V", (C_MAIN, "I")))
    m_dlg_click = (C_DLG, "onClick", ("V", (C_DLG_IF, "I")))
    m_main_handle_dlg = (C_MAIN, "onDialogPositiveAction", ("V", ("I", "I")))

    db.add_class(
        C_DLG,
        C_OBJ,
        0x0001,
        interfaces=(C_DLG_OCL,),
        instance_fields=[
            (f_dlg_act, 0x0002),
            (f_dlg_mode, 0x0002),
        ],
        direct_methods=[
            (
                m_dlg_init,
                0x10001,
                {
                    "registers": 3, "ins": 3, "outs": 1,
                    "insns": [
                        ("invoke-direct", [0], m_obj_init),
                        ("iput-object", 1, 0, f_dlg_act),
                        ("iput", 2, 0, f_dlg_mode),
                        ("return-void",),
                    ],
                },
            ),
        ],
        virtual_methods=[
            (
                m_dlg_click,
                0x0001,
                {
                    "registers": 5, "ins": 3, "outs": 3,
                    "insns": [
                        # v2 = this, v3 = DialogInterface, v4 = which
                        ("iget-object", 0, 2, f_dlg_act),
                        ("iget", 1, 2, f_dlg_mode),
                        ("invoke-virtual", [0, 1, 4], m_main_handle_dlg),
                        ("return-void",),
                    ],
                },
            ),
        ],
    )

    # =========================================================================
    # CLASS 8: MainActivity (v2.3.0)
    # =========================================================================
    f_main_tv_status = (C_MAIN, "statusTextView", C_TV)
    f_main_tv_diag = (C_MAIN, "diagTextView", C_TV)
    f_main_btn_rep = (C_MAIN, "btnTtsRepeat", C_BTN)
    f_main_btn_esim = (C_MAIN, "btnEngSim", C_BTN)
    f_main_btn_ewa = (C_MAIN, "btnEngWa", C_BTN)
    f_main_btn_etg = (C_MAIN, "btnEngTg", C_BTN)
    f_main_btn_eoth = (C_MAIN, "btnEngOther", C_BTN)
    f_main_btn_esms = (C_MAIN, "btnEngSms", C_BTN)
    f_main_btn_voice = (C_MAIN, "btnTtsVoice", C_BTN)
    f_main_btn_rsim = (C_MAIN, "btnRateSim", C_BTN)
    f_main_btn_rwa = (C_MAIN, "btnRateWa", C_BTN)
    f_main_btn_rtg = (C_MAIN, "btnRateTg", C_BTN)
    f_main_btn_roth = (C_MAIN, "btnRateOther", C_BTN)
    f_main_btn_rsms = (C_MAIN, "btnRateSms", C_BTN)
    f_main_btn_amode = (C_MAIN, "btnAudioMode", C_BTN)
    f_main_btn_cvol = (C_MAIN, "btnCustomVol", C_BTN)
    f_main_cb_ans_up = (C_MAIN, "cbAnsVolUp", C_CB)
    f_main_cb_ans_dn = (C_MAIN, "cbAnsVolDown", C_CB)
    f_main_cb_end_dn = (C_MAIN, "cbEndVolDown", C_CB)
    f_main_cb_end_up = (C_MAIN, "cbEndVolUp", C_CB)
    f_main_eng_pkgs = (C_MAIN, "dialogEnginePkgs", "[Ljava/lang/String;")
    f_main_check_launch = (C_MAIN, "checkPermissionsOnResume", "Z")

    m_main_init = (C_MAIN, "<init>", ("V", ()))
    m_main_oncreate = (C_MAIN, "onCreate", ("V", (C_BUNDLE,)))
    m_main_onstart = (C_MAIN, "onStart", ("V", ()))
    m_main_onresume = (C_MAIN, "onResume", ("V", ()))
    m_main_onperm = (C_MAIN, "onRequestPermissionsResult", ("V", ("I", "[Ljava/lang/String;", "[I")))
    m_main_onclick = (C_MAIN, "onClick", ("V", (C_VIEW,)))
    m_main_onchecked = (C_MAIN, "onCheckedChanged", ("V", (C_CMP_BTN, "Z")))
    m_main_refresh = (C_MAIN, "refreshStatusText", ("V", ()))
    m_main_req_phone = (C_MAIN, "requestPhonePermissionsNow", ("V", ("Z",)))
    m_main_open_set = (C_MAIN, "openSystemSetting", ("V", (C_STR, "Z")))
    m_main_check_svcs = (C_MAIN, "promptMissingServicesIfAny", ("V", ()))
    m_main_make_cb = (C_MAIN, "addCheckBox", ("V", (C_LL, C_STR, "I", C_STR)))
    m_main_make_btn = (C_MAIN, "addActionButton", (C_BTN, (C_LL, C_STR, "I", "I")))
    m_main_share_diag = (C_MAIN, "shareDiagReport", ("V", ()))
    m_main_show_eng_dlg = (C_MAIN, "showTtsEngineDialog", ("V", ("I", C_STR)))
    m_main_show_voice_dlg = (C_MAIN, "showTtsVoiceDialog", ("V", ()))
    m_main_show_rate_dlg = (C_MAIN, "showTtsRateDialog", ("V", ("I", C_STR)))
    m_main_show_amode_dlg = (C_MAIN, "showTtsAudioModeDialog", ("V", ()))
    m_main_show_cvol_dlg = (C_MAIN, "showTtsCustomVolDialog", ("V", ()))

    code_make_cb = {
        "registers": 8, "ins": 5, "outs": 5,
        "insns": [
            ("new-instance", 0, C_CB),
            ("invoke-direct", [0, 3], m_cb_init),
            ("invoke-virtual", [0, 5], m_cb_set_text),
            ("const", 1, 0x41780000),
            ("invoke-virtual", [0, 1], m_cb_set_size),
            ("const", 1, 0xFF111827),
            ("invoke-virtual", [0, 1], m_cb_set_color),
            ("const/16", 1, 18),
            ("invoke-virtual", [0, 1, 1, 1, 1], m_cb_set_pad),
            ("invoke-virtual", [0, 6], m_cb_set_id),
            ("const/4", 2, 0),
            ("const/16", 1, 200),
            ("if-eq", 6, 1, "def_true"),
            ("const/16", 1, 201),
            ("if-eq", 6, 1, "def_true"),
            ("const/16", 1, 205),
            ("if-eq", 6, 1, "def_true"),
            ("const/16", 1, 207),
            ("if-eq", 6, 1, "def_true"),
            ("const/16", 1, 210),
            ("if-lt", 6, 1, "read_pref"),
            ("const/16", 1, 217),
            ("if-gt", 6, 1, "def_true"),
            ("goto/16", "read_pref"),
            ("label", "def_true"),
            ("const/4", 2, 1),
            ("label", "read_pref"),
            ("invoke-static", [3, 7, 2], m_ctrl_is_pref),
            ("move-result", 2),
            ("invoke-virtual", [0, 2], m_cb_set_checked),
            ("invoke-virtual", [0, 3], m_cb_set_ocl),
            ("invoke-virtual", [4, 0], m_ll_add),
            ("const/16", 1, 201),
            ("if-ne", 6, 1, "chk_202"),
            ("iput-object", 0, 3, f_main_cb_ans_up),
            ("return-void",),
            ("label", "chk_202"),
            ("const/16", 1, 202),
            ("if-ne", 6, 1, "chk_205"),
            ("iput-object", 0, 3, f_main_cb_ans_dn),
            ("return-void",),
            ("label", "chk_205"),
            ("const/16", 1, 205),
            ("if-ne", 6, 1, "chk_206"),
            ("iput-object", 0, 3, f_main_cb_end_dn),
            ("return-void",),
            ("label", "chk_206"),
            ("const/16", 1, 206),
            ("if-ne", 6, 1, "done_cb"),
            ("iput-object", 0, 3, f_main_cb_end_up),
            ("label", "done_cb"),
            ("return-void",),
        ],
    }

    code_make_btn = {
        "registers": 9, "ins": 5, "outs": 5,
        "insns": [
            ("new-instance", 0, C_BTN),
            ("invoke-direct", [0, 4], m_btn_init),
            ("invoke-virtual", [0, 6], m_btn_set_text),
            ("const/4", 1, -1),
            ("invoke-virtual", [0, 1], m_btn_set_color),
            ("invoke-virtual", [0, 8], m_btn_set_bg),
            ("invoke-virtual", [0, 7], m_btn_set_id),
            ("invoke-virtual", [0, 4], m_btn_set_ocl),
            ("new-instance", 1, C_LL_LP),
            ("const/4", 2, -1),
            ("const/4", 3, -2),
            ("invoke-direct", [1, 2, 3], m_lllp_init),
            ("const/4", 2, 0),
            ("const/16", 3, 12),
            ("invoke-virtual", [1, 2, 2, 2, 3], m_lllp_margins),
            ("invoke-virtual", [5, 0, 1], m_ll_add_lp),
            ("return-object", 0),
        ],
    }

    code_show_eng_dlg = {
        "registers": 11, "ins": 3, "outs": 4,
        "insns": [
            ("label", "ts"),
            ("sget-object", 0, f_ctrl_tts),
            ("if-nez", 0, "has_t"),
            ("new-instance", 0, C_TTS),
            ("const/4", 1, 0),
            ("invoke-direct", [0, 8, 1], m_tts_init_2),
            ("label", "has_t"),
            ("invoke-virtual", [0], m_tts_engines),
            ("move-result-object", 1),
            ("const/4", 2, 0),
            ("if-eqz", 1, "alloc_arr"),
            ("invoke-interface", [1], m_list_size),
            ("move-result", 2),

            ("label", "alloc_arr"),
            ("add-int/lit8", 3, 2, 1),
            ("new-array", 4, 3, "[Ljava/lang/CharSequence;"),
            ("new-array", 5, 3, "[Ljava/lang/String;"),
            ("const/4", 6, 0),
            ("const-string", 7, "Системный движок (По умолчанию)"),
            ("aput-object", 7, 4, 6),
            ("const-string", 7, "default"),
            ("aput-object", 7, 5, 6),

            ("const/4", 6, 0),
            ("label", "loop"),
            ("if-ge", 6, 2, "show_d"),
            ("invoke-interface", [1, 6], m_list_get),
            ("move-result-object", 7),
            ("check-cast", 7, C_TTS_EI),
            ("add-int/lit8", 3, 6, 1),
            ("if-eqz", 7, "next"),
            ("iget-object", 0, 7, f_ttsei_name),
            ("iget-object", 7, 7, f_ttsei_label),
            ("if-nez", 7, "has_lbl"),
            ("move-object", 7, 0),
            ("label", "has_lbl"),
            ("aput-object", 0, 5, 3),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("invoke-virtual", [0, 7], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 7, " ["),
            ("invoke-virtual", [0, 7], m_sb_app_str),
            ("move-result-object", 0),
            ("aget-object", 7, 5, 3),
            ("invoke-virtual", [0, 7], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 7, "]"),
            ("invoke-virtual", [0, 7], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 7),
            ("aput-object", 7, 4, 3),

            ("label", "next"),
            ("add-int/lit8", 6, 6, 1),
            ("goto/16", "loop"),

            ("label", "show_d"),
            ("iput-object", 5, 8, f_main_eng_pkgs),
            ("new-instance", 0, C_AD_B),
            ("invoke-direct", [0, 8], m_adb_init),
            ("invoke-virtual", [0, 10], m_adb_title),
            ("move-result-object", 0),
            ("new-instance", 1, C_DLG),
            ("invoke-direct", [1, 8, 9], m_dlg_init),
            ("invoke-virtual", [0, 4, 1], m_adb_items),
            ("move-result-object", 0),
            ("const-string", 1, "Отмена"),
            ("const/4", 2, 0),
            ("invoke-virtual", [0, 1, 2], m_adb_neg),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_adb_show),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_show_voice_dlg = {
        "registers": 12, "ins": 1, "outs": 4,
        "insns": [
            ("const/4", 1, 0),
            ("label", "ts"),
            ("sget-object", 0, f_ctrl_tts),
            ("if-eqz", 0, "tv_e"),
            ("invoke-virtual", [0], m_tts_get_voices),
            ("move-result-object", 1),
            ("label", "tv_e"),
            ("goto/16", "check_set"),
            ("label", "cv"),
            ("move-exception", 2),
            ("const/4", 1, 0),

            ("label", "check_set"),
            ("label", "t2_s"),
            ("const/4", 2, 0),
            ("if-eqz", 1, "alloc_arr"),
            ("invoke-interface", [1], m_set_iter),
            ("move-result-object", 3),
            ("label", "cnt_loop"),
            ("invoke-interface", [3], m_iter_has_next),
            ("move-result", 4),
            ("if-eqz", 4, "alloc_arr"),
            ("invoke-interface", [3], m_iter_next),
            ("move-result-object", 7),
            ("check-cast", 7, C_VOICE),
            ("if-eqz", 7, "cnt_loop"),
            ("invoke-virtual", [7], m_voice_get_name),
            ("move-result-object", 8),
            ("if-eqz", 8, "cnt_loop"),
            ("add-int/lit8", 2, 2, 1),
            ("const/16", 4, 60),
            ("if-lt", 2, 4, "cnt_loop"),

            ("label", "alloc_arr"),
            ("add-int/lit8", 3, 2, 2),
            ("new-array", 4, 3, "[Ljava/lang/CharSequence;"),
            ("new-array", 5, 3, "[Ljava/lang/String;"),
            ("const/4", 6, 0),
            ("label", "prefill_loop"),
            ("if-ge", 6, 3, "prefill_done"),
            ("const-string", 7, "По умолчанию (Стандартный голос движка)"),
            ("aput-object", 7, 4, 6),
            ("const-string", 7, "default"),
            ("aput-object", 7, 5, 6),
            ("add-int/lit8", 6, 6, 1),
            ("goto/16", "prefill_loop"),

            ("label", "prefill_done"),
            ("const/4", 6, 1),
            ("if-eqz", 1, "set_last_item"),
            ("if-lez", 2, "set_last_item"),
            ("invoke-interface", [1], m_set_iter),
            ("move-result-object", 1),
            ("add-int/lit8", 10, 3, -1),
            ("label", "fill_loop"),
            ("if-ge", 6, 10, "set_last_item"),
            ("invoke-interface", [1], m_iter_has_next),
            ("move-result", 7),
            ("if-eqz", 7, "set_last_item"),
            ("invoke-interface", [1], m_iter_next),
            ("move-result-object", 7),
            ("check-cast", 7, C_VOICE),
            ("if-eqz", 7, "fill_loop"),
            ("invoke-virtual", [7], m_voice_get_name),
            ("move-result-object", 8),
            ("if-eqz", 8, "fill_loop"),
            ("aput-object", 8, 5, 6),

            ("invoke-virtual", [7], m_voice_get_loc),
            ("move-result-object", 9),
            ("const-string", 7, ""),
            ("if-eqz", 9, "build_lbl"),
            ("invoke-virtual", [9], m_loc_disp),
            ("move-result-object", 7),
            ("if-nez", 7, "build_lbl"),
            ("const-string", 7, ""),

            ("label", "build_lbl"),
            ("new-instance", 9, C_SB),
            ("invoke-direct", [9], m_sb_init),
            ("invoke-virtual", [9, 8], m_sb_app_str),
            ("move-result-object", 9),
            ("const-string", 8, " ("),
            ("invoke-virtual", [9, 8], m_sb_app_str),
            ("move-result-object", 9),
            ("invoke-virtual", [9, 7], m_sb_app_str),
            ("move-result-object", 9),
            ("const-string", 8, ")"),
            ("invoke-virtual", [9, 8], m_sb_app_str),
            ("move-result-object", 9),
            ("invoke-virtual", [9], m_sb_tostr),
            ("move-result-object", 9),
            ("aput-object", 9, 4, 6),
            ("add-int/lit8", 6, 6, 1),
            ("goto/16", "fill_loop"),

            ("label", "set_last_item"),
            ("add-int/lit8", 6, 3, -1),
            ("const-string", 7, "Системные настройки голосов TTS (Выбор диктора в системе)..."),
            ("aput-object", 7, 4, 6),
            ("const-string", 7, "open_tts_settings"),
            ("aput-object", 7, 5, 6),

            ("label", "show_d"),
            ("iput-object", 5, 11, f_main_eng_pkgs),
            ("new-instance", 0, C_AD_B),
            ("invoke-direct", [0, 11], m_adb_init),
            ("const-string", 1, "Выберите голос внутри движка TTS"),
            ("invoke-virtual", [0, 1], m_adb_title),
            ("move-result-object", 0),
            ("new-instance", 1, C_DLG),
            ("const/16", 2, 16),
            ("invoke-direct", [1, 11, 2], m_dlg_init),
            ("invoke-virtual", [0, 4, 1], m_adb_items),
            ("move-result-object", 0),
            ("const-string", 1, "Отмена"),
            ("const/4", 2, 0),
            ("invoke-virtual", [0, 1, 2], m_adb_neg),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_adb_show),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [
            {"start_label": "ts", "end_label": "tv_e", "handler_label": "cv"},
            {"start_label": "t2_s", "end_label": "te", "handler_label": "ca"},
        ],
    }

    # showTtsRateDialog(int v5_mode, String v6_title) -> void
    code_show_rate_dlg = {
        "registers": 7, "ins": 3, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("const/16", 0, 9),
            ("new-array", 1, 0, "[Ljava/lang/CharSequence;"),
            ("const/4", 2, 0),
            ("const-string", 3, "0.5x — Очень медленно (50%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 1),
            ("const-string", 3, "0.75x — Медленно (75%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 2),
            ("const-string", 3, "0.9x — Чуть медленнее (90%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 3),
            ("const-string", 3, "1.0x — Обычная скорость (100%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 4),
            ("const-string", 3, "1.15x — Чуть быстрее (115%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 5),
            ("const-string", 3, "1.25x — Быстро (125%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 6),
            ("const-string", 3, "1.5x — Очень быстро (150%)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 7),
            ("const-string", 3, "1.75x — Ускоренная (175%)"),
            ("aput-object", 3, 1, 2),
            ("const/16", 2, 8),
            ("const-string", 3, "2.0x — Максимальная скорость (200%)"),
            ("aput-object", 3, 1, 2),

            ("new-instance", 0, C_AD_B),
            ("invoke-direct", [0, 4], m_adb_init),
            ("invoke-virtual", [0, 6], m_adb_title),
            ("move-result-object", 0),
            ("new-instance", 2, C_DLG),
            ("invoke-direct", [2, 4, 5], m_dlg_init),
            ("invoke-virtual", [0, 1, 2], m_adb_items),
            ("move-result-object", 0),
            ("const-string", 2, "Отмена"),
            ("const/4", 3, 0),
            ("invoke-virtual", [0, 2, 3], m_adb_neg),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_adb_show),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # showTtsAudioModeDialog() -> void
    code_show_amode_dlg = {
        "registers": 5, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("const/4", 0, 4),
            ("new-array", 1, 0, "[Ljava/lang/CharSequence;"),
            ("const/4", 2, 0),
            ("const-string", 3, "1. Канал Специальные возможности (TalkBack / Accessibility)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 1),
            ("const-string", 3, "2. Канал Мультимедиа (Громкость музыки и медиа)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 2),
            ("const-string", 3, "3. Канал Звонка (Громкость мелодии вызова)"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 3),
            ("const-string", 3, "4. Собственная громкость (Регулируется отдельно в приложении)"),
            ("aput-object", 3, 1, 2),

            ("new-instance", 0, C_AD_B),
            ("invoke-direct", [0, 4], m_adb_init),
            ("const-string", 2, "Выберите аудиоканал озвучки (TTS)"),
            ("invoke-virtual", [0, 2], m_adb_title),
            ("move-result-object", 0),
            ("new-instance", 2, C_DLG),
            ("const/16", 3, 26),
            ("invoke-direct", [2, 4, 3], m_dlg_init),
            ("invoke-virtual", [0, 1, 2], m_adb_items),
            ("move-result-object", 0),
            ("const-string", 2, "Отмена"),
            ("const/4", 3, 0),
            ("invoke-virtual", [0, 2, 3], m_adb_neg),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_adb_show),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    # showTtsCustomVolDialog() -> void
    code_show_cvol_dlg = {
        "registers": 5, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("const/4", 0, 7),
            ("new-array", 1, 0, "[Ljava/lang/CharSequence;"),
            ("const/4", 2, 0),
            ("const-string", 3, "15% — Очень тихо"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 1),
            ("const-string", 3, "30% — Тихо"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 2),
            ("const-string", 3, "45% — Умеренно тихо"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 3),
            ("const-string", 3, "60% — Средняя громкость"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 4),
            ("const-string", 3, "75% — Комфортная громкость"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 5),
            ("const-string", 3, "90% — Громко"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 6),
            ("const-string", 3, "100% — Максимальная громкость"),
            ("aput-object", 3, 1, 2),

            ("new-instance", 0, C_AD_B),
            ("invoke-direct", [0, 4], m_adb_init),
            ("const-string", 2, "Собственная громкость озвучки TTS (отдельно)"),
            ("invoke-virtual", [0, 2], m_adb_title),
            ("move-result-object", 0),
            ("new-instance", 2, C_DLG),
            ("const/16", 3, 27),
            ("invoke-direct", [2, 4, 3], m_dlg_init),
            ("invoke-virtual", [0, 1, 2], m_adb_items),
            ("move-result-object", 0),
            ("const-string", 2, "Отмена"),
            ("const/4", 3, 0),
            ("invoke-virtual", [0, 2, 3], m_adb_neg),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_adb_show),
            ("move-result-object", 0),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_share_diag = {
        "registers": 5, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("invoke-static", [4], m_ctrl_get_log),
            ("move-result-object", 0),
            ("new-instance", 1, C_INTENT),
            ("const-string", 2, "android.intent.action.SEND"),
            ("invoke-direct", [1, 2], m_intent_init_act),
            ("const-string", 2, "text/plain"),
            ("invoke-virtual", [1, 2], m_intent_set_type),
            ("move-result-object", 1),
            ("const-string", 2, "android.intent.extra.TEXT"),
            ("invoke-virtual", [1, 2, 0], m_intent_put_str),
            ("move-result-object", 1),
            ("const-string", 2, "Отправить диагностику «Умный Вызов»"),
            ("invoke-static", [1, 2], m_intent_chooser),
            ("move-result-object", 1),
            ("invoke-virtual", [4, 1], m_ctx_start_act),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_open_set = {
        "registers": 6, "ins": 3, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("new-instance", 0, C_INTENT),
            ("invoke-direct", [0, 4], m_intent_init_act),
            ("if-eqz", 5, "launch"),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 2, "package:"),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [3], m_ctx_get_pkg),
            ("move-result-object", 2),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-static", [1], m_uri_parse),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_intent_set_data),
            ("move-result-object", 0),
            ("label", "launch"),
            ("const", 2, 0x10000000),
            ("invoke-virtual", [0, 2], m_intent_add_flags),
            ("move-result-object", 0),
            ("invoke-virtual", [3, 0], m_ctx_start_act),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_req_phone = {
        "registers": 7, "ins": 2, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("sget", 0, f_sdk_int),
            ("const/16", 1, 33),
            ("if-lt", 0, 1, "api_lt_33"),
            ("const/4", 0, 7),
            ("new-array", 1, 0, "[Ljava/lang/String;"),
            ("const/4", 2, 6),
            ("const-string", 3, "android.permission.POST_NOTIFICATIONS"),
            ("aput-object", 3, 1, 2),
            ("goto/16", "fill_common"),

            ("label", "api_lt_33"),
            ("const/4", 0, 6),
            ("new-array", 1, 0, "[Ljava/lang/String;"),

            ("label", "fill_common"),
            ("const/4", 2, 0),
            ("const-string", 3, "android.permission.READ_PHONE_STATE"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 1),
            ("const-string", 3, "android.permission.CALL_PHONE"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 2),
            ("const-string", 3, "android.permission.ANSWER_PHONE_CALLS"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 3),
            ("const-string", 3, "android.permission.READ_CONTACTS"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 4),
            ("const-string", 3, "android.permission.RECEIVE_SMS"),
            ("aput-object", 3, 1, 2),
            ("const/4", 2, 5),
            ("const-string", 3, "android.permission.READ_SMS"),
            ("aput-object", 3, 1, 2),

            ("if-eqz", 6, "do_req"),
            ("const-string", 3, "android.permission.READ_PHONE_STATE"),
            ("invoke-virtual", [5, 3], m_act_should_rat),
            ("move-result", 4),
            ("if-nez", 4, "do_req"),
            ("const/16", 2, 1001),
            ("invoke-virtual", [5, 1, 2], m_act_req_perms),
            ("const-string", 3, "android.settings.APPLICATION_DETAILS_SETTINGS"),
            ("const/4", 4, 1),
            ("invoke-virtual", [5, 3, 4], m_main_open_set),
            ("return-void",),

            ("label", "do_req"),
            ("const/16", 2, 1001),
            ("invoke-virtual", [5, 1, 2], m_act_req_perms),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_refresh = {
        "registers": 5, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("iget-object", 0, 4, f_main_tv_status),
            ("if-eqz", 0, "upd_btns"),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),

            ("invoke-static", [4], m_ctrl_has_phone),
            ("move-result", 2),
            ("if-nez", 2, "p1_ok"),
            ("const-string", 3, "✗ 1. Разрешения телефона/Контактов/SMS: НЕ ВСЕ ВЫДАНЫ\n"),
            ("goto/16", "p1_app"),
            ("label", "p1_ok"),
            ("const-string", 3, "✓ 1. Разрешения телефона: ВЫДАНЫ\n"),
            ("label", "p1_app"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),

            ("invoke-static", [4], m_ctrl_is_acc),
            ("move-result", 2),
            ("if-nez", 2, "p2_ok"),
            ("const-string", 3, "✗ 2. Спец. возможности (Кнопки и Датчик уха): ВЫКЛЮЧЕНО\n"),
            ("goto/16", "p2_app"),
            ("label", "p2_ok"),
            ("const-string", 3, "✓ 2. Спец. возможности (Кнопки и Датчик уха): ВКЛЮЧЕНО\n"),
            ("label", "p2_app"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),

            ("invoke-static", [4], m_ctrl_is_notif),
            ("move-result", 2),
            ("if-nez", 2, "p3_ok"),
            ("const-string", 3, "✗ 3. Доступ к уведомлениям (Мессенджеры/Озвучка): ВЫКЛЮЧЕНО\n"),
            ("goto/16", "p3_app"),
            ("label", "p3_ok"),
            ("const-string", 3, "✓ 3. Доступ к уведомлениям (Мессенджеры/Озвучка): ВКЛЮЧЕНО\n"),
            ("label", "p3_app"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),

            ("invoke-static", [4], m_ctrl_is_batt),
            ("move-result", 2),
            ("if-nez", 2, "p4_ok"),
            ("const-string", 3, "✗ 4. Работа в фоне без ограничений: ВЫКЛЮЧЕНО"),
            ("goto/16", "p4_app"),
            ("label", "p4_ok"),
            ("const-string", 3, "✓ 4. Работа в фоне без ограничений: АКТИВНО"),
            ("label", "p4_app"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),

            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 3),
            ("invoke-virtual", [0, 3], m_tv_set_text),

            ("invoke-static", [4], m_ctrl_all_perms),
            ("move-result", 2),
            ("if-nez", 2, "all_green"),
            ("const", 2, 0xFFFEF2F2),
            ("invoke-virtual", [0, 2], m_tv_set_bg),
            ("const", 2, 0xFF991B1B),
            ("invoke-virtual", [0, 2], m_tv_set_color),
            ("goto/16", "upd_btns"),

            ("label", "all_green"),
            ("const", 2, 0xFFECFDF5),
            ("invoke-virtual", [0, 2], m_tv_set_bg),
            ("const", 2, 0xFF065F46),
            ("invoke-virtual", [0, 2], m_tv_set_color),

            ("label", "upd_btns"),
            ("iget-object", 0, 4, f_main_btn_rep),
            ("if-eqz", 0, "upd_esim"),
            ("const-string", 1, "tts_repeat"),
            ("const/4", 2, 2),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Количество повторений имени: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_int),
            ("move-result-object", 1),
            ("const-string", 3, " раз(а) (Нажмите для смены)"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_esim"),
            ("iget-object", 0, 4, f_main_btn_esim),
            ("if-eqz", 0, "upd_ewa"),
            ("const-string", 1, "tts_eng_sim"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Движок TTS [Обычный звонок]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_ewa"),
            ("iget-object", 0, 4, f_main_btn_ewa),
            ("if-eqz", 0, "upd_etg"),
            ("const-string", 1, "tts_eng_wa"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Движок TTS [WhatsApp]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_etg"),
            ("iget-object", 0, 4, f_main_btn_etg),
            ("if-eqz", 0, "upd_eoth"),
            ("const-string", 1, "tts_eng_tg"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Движок TTS [Telegram]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_eoth"),
            ("iget-object", 0, 4, f_main_btn_eoth),
            ("if-eqz", 0, "upd_esms"),
            ("const-string", 1, "tts_eng_other"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Движок TTS [Viber / Imo / Другие]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_esms"),
            ("iget-object", 0, 4, f_main_btn_esms),
            ("if-eqz", 0, "upd_voice"),
            ("const-string", 1, "tts_eng_sms"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Движок TTS [Входящие SMS]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_voice"),
            ("iget-object", 0, 4, f_main_btn_rsim),
            ("if-eqz", 0, "upd_rwa"),
            ("const-string", 1, "tts_rate_sim"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_rate),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Скорость речи [Обычный звонок]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_rwa"),
            ("iget-object", 0, 4, f_main_btn_rwa),
            ("if-eqz", 0, "upd_rtg"),
            ("const-string", 1, "tts_rate_wa"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_rate),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Скорость речи [WhatsApp]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_rtg"),
            ("iget-object", 0, 4, f_main_btn_rtg),
            ("if-eqz", 0, "upd_roth"),
            ("const-string", 1, "tts_rate_tg"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_rate),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Скорость речи [Telegram]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_roth"),
            ("iget-object", 0, 4, f_main_btn_roth),
            ("if-eqz", 0, "upd_rsms"),
            ("const-string", 1, "tts_rate_other"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_rate),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Скорость речи [Viber / Imo / Другие]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_rsms"),
            ("iget-object", 0, 4, f_main_btn_rsms),
            ("if-eqz", 0, "upd_amode"),
            ("const-string", 1, "tts_rate_sms"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_rate),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Скорость речи [Входящие SMS]: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_amode"),
            ("iget-object", 0, 4, f_main_btn_amode),
            ("if-eqz", 0, "upd_cvol"),
            ("const-string", 1, "tts_audio_mode"),
            ("const/4", 2, 0),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("invoke-static", [2], m_ctrl_fmt_amode),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Аудиоканал озвучки (TTS): "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_cvol"),
            ("iget-object", 0, 4, f_main_btn_cvol),
            ("if-eqz", 0, "upd_legacy_v"),
            ("const-string", 1, "tts_custom_vol"),
            ("const/16", 2, 100),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Собственная громкость TTS (отдельно): "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_int),
            ("move-result-object", 1),
            ("const-string", 3, "%"),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "upd_legacy_v"),
            ("iget-object", 0, 4, f_main_btn_voice),
            ("if-eqz", 0, "update_diag"),
            ("const-string", 1, "tts_voice_name"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 1, C_SB),
            ("invoke-direct", [1], m_sb_init),
            ("const-string", 3, "Голос внутри движка TTS: "),
            ("invoke-virtual", [1, 3], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1, 2], m_sb_app_str),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_sb_tostr),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_btn_set_text),

            ("label", "update_diag"),
            ("iget-object", 0, 4, f_main_tv_diag),
            ("if-eqz", 0, "done"),
            ("invoke-static", [4], m_ctrl_get_log),
            ("move-result-object", 3),
            ("invoke-virtual", [0, 3], m_tv_set_text),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_check_svcs = {
        "registers": 5, "ins": 1, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("invoke-static", [4], m_ctrl_is_batt),
            ("move-result", 0),
            ("if-nez", 0, "check_notif"),
            ("new-instance", 1, C_AD_B),
            ("invoke-direct", [1, 4], m_adb_init),
            ("const-string", 2, "Разрешите работу в фоне"),
            ("invoke-virtual", [1, 2], m_adb_title),
            ("move-result-object", 1),
            ("const-string", 2, "Для стабильной работы на Samsung, Xiaomi и других телефонах разрешите работу в фоне без экономии батареи."),
            ("invoke-virtual", [1, 2], m_adb_msg),
            ("move-result-object", 1),
            ("new-instance", 3, C_DLG),
            ("const/4", 0, 4),
            ("invoke-direct", [3, 4, 0], m_dlg_init),
            ("const-string", 2, "Разрешить"),
            ("invoke-virtual", [1, 2, 3], m_adb_pos),
            ("move-result-object", 1),
            ("const-string", 2, "Позже"),
            ("const/4", 3, 0),
            ("invoke-virtual", [1, 2, 3], m_adb_neg),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_adb_show),
            ("move-result-object", 2),
            ("return-void",),

            ("label", "check_notif"),
            ("invoke-static", [4], m_ctrl_is_notif),
            ("move-result", 0),
            ("if-nez", 0, "check_acc"),
            ("new-instance", 1, C_AD_B),
            ("invoke-direct", [1, 4], m_adb_init),
            ("const-string", 2, "Доступ к звонкам и озвучке"),
            ("invoke-virtual", [1, 2], m_adb_title),
            ("move-result-object", 1),
            ("const-string", 2, "Включите «Умный Вызов» в списке доступа к уведомлениям, чтобы принимать и завершать звонки в WhatsApp, Telegram, Viber, Imo и озвучивать звонки и сообщения."),
            ("invoke-virtual", [1, 2], m_adb_msg),
            ("move-result-object", 1),
            ("new-instance", 3, C_DLG),
            ("const/4", 0, 3),
            ("invoke-direct", [3, 4, 0], m_dlg_init),
            ("const-string", 2, "Включить"),
            ("invoke-virtual", [1, 2, 3], m_adb_pos),
            ("move-result-object", 1),
            ("const-string", 2, "Позже"),
            ("const/4", 3, 0),
            ("invoke-virtual", [1, 2, 3], m_adb_neg),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_adb_show),
            ("move-result-object", 2),
            ("return-void",),

            ("label", "check_acc"),
            ("invoke-static", [4], m_ctrl_is_acc),
            ("move-result", 0),
            ("if-nez", 0, "done"),
            ("new-instance", 1, C_AD_B),
            ("invoke-direct", [1, 4], m_adb_init),
            ("const-string", 2, "Включите перехват кнопок"),
            ("invoke-virtual", [1, 2], m_adb_title),
            ("move-result-object", 1),
            ("const-string", 2, "Включите службу «Умный Вызов» в разделе Специальные возможности, чтобы кнопки громкости и датчик приближения могли поднимать и класть трубку."),
            ("invoke-virtual", [1, 2], m_adb_msg),
            ("move-result-object", 1),
            ("new-instance", 3, C_DLG),
            ("const/4", 0, 2),
            ("invoke-direct", [3, 4, 0], m_dlg_init),
            ("const-string", 2, "Включить"),
            ("invoke-virtual", [1, 2, 3], m_adb_pos),
            ("move-result-object", 1),
            ("const-string", 2, "Позже"),
            ("const/4", 3, 0),
            ("invoke-virtual", [1, 2, 3], m_adb_neg),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_adb_show),
            ("move-result-object", 2),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_handle_dlg = {
        "registers": 6, "ins": 3, "outs": 4,
        "insns": [
            ("label", "ts"),
            ("const/4", 0, 1),
            ("if-eq", 4, 0, "m1"),
            ("const/4", 0, 2),
            ("if-eq", 4, 0, "m2"),
            ("const/4", 0, 3),
            ("if-eq", 4, 0, "m3"),
            ("const/4", 0, 4),
            ("if-eq", 4, 0, "m4"),
            ("const/16", 0, 26),
            ("if-eq", 4, 0, "m26"),
            ("const/16", 0, 27),
            ("if-eq", 4, 0, "m27"),
            ("const/16", 0, 21),
            ("if-lt", 4, 0, "check_eng_arr"),
            ("const/16", 0, 25),
            ("if-gt", 4, 0, "check_eng_arr"),

            # Modes 21..25: Speed picker (v5 = 0..8 -> ratePct = 50,75,90,100,115,125,150,175,200)
            ("const/16", 2, 100),
            ("if-nez", 5, "rate_idx1"),
            ("const/16", 2, 50),
            ("goto/16", "rate_key"),
            ("label", "rate_idx1"),
            ("const/4", 0, 1),
            ("if-ne", 5, 0, "rate_idx2"),
            ("const/16", 2, 75),
            ("goto/16", "rate_key"),
            ("label", "rate_idx2"),
            ("const/4", 0, 2),
            ("if-ne", 5, 0, "rate_idx3"),
            ("const/16", 2, 90),
            ("goto/16", "rate_key"),
            ("label", "rate_idx3"),
            ("const/4", 0, 3),
            ("if-ne", 5, 0, "rate_idx4"),
            ("const/16", 2, 100),
            ("goto/16", "rate_key"),
            ("label", "rate_idx4"),
            ("const/4", 0, 4),
            ("if-ne", 5, 0, "rate_idx5"),
            ("const/16", 2, 115),
            ("goto/16", "rate_key"),
            ("label", "rate_idx5"),
            ("const/4", 0, 5),
            ("if-ne", 5, 0, "rate_idx6"),
            ("const/16", 2, 125),
            ("goto/16", "rate_key"),
            ("label", "rate_idx6"),
            ("const/4", 0, 6),
            ("if-ne", 5, 0, "rate_idx7"),
            ("const/16", 2, 150),
            ("goto/16", "rate_key"),
            ("label", "rate_idx7"),
            ("const/4", 0, 7),
            ("if-ne", 5, 0, "rate_idx8"),
            ("const/16", 2, 175),
            ("goto/16", "rate_key"),
            ("label", "rate_idx8"),
            ("const/16", 2, 200),

            ("label", "rate_key"),
            ("const/16", 0, 21),
            ("if-eq", 4, 0, "rk_sim"),
            ("const/16", 0, 22),
            ("if-eq", 4, 0, "rk_wa"),
            ("const/16", 0, 23),
            ("if-eq", 4, 0, "rk_tg"),
            ("const/16", 0, 24),
            ("if-eq", 4, 0, "rk_oth"),
            ("const-string", 1, "tts_rate_sms"),
            ("const-string", 5, "tts_eng_sms"),
            ("goto/16", "save_rate"),
            ("label", "rk_sim"),
            ("const-string", 1, "tts_rate_sim"),
            ("const-string", 5, "tts_eng_sim"),
            ("goto/16", "save_rate"),
            ("label", "rk_wa"),
            ("const-string", 1, "tts_rate_wa"),
            ("const-string", 5, "tts_eng_wa"),
            ("goto/16", "save_rate"),
            ("label", "rk_tg"),
            ("const-string", 1, "tts_rate_tg"),
            ("const-string", 5, "tts_eng_tg"),
            ("goto/16", "save_rate"),
            ("label", "rk_oth"),
            ("const-string", 1, "tts_rate_other"),
            ("const-string", 5, "tts_eng_other"),

            ("label", "save_rate"),
            ("invoke-static", [3, 1, 2], m_ctrl_set_int),
            ("invoke-virtual", [3], m_main_refresh),
            ("const-string", 0, "Проверка выбранной скорости речи"),
            ("const/4", 1, 1),
            ("invoke-static", [3, 0, 5, 1], m_features_speak),
            ("return-void",),

            ("label", "m26"),
            ("if-ltz", 5, "done"),
            ("const/4", 0, 3),
            ("if-gt", 5, 0, "done"),
            ("const-string", 1, "tts_audio_mode"),
            ("invoke-static", [3, 1, 5], m_ctrl_set_int),
            ("invoke-virtual", [3], m_main_refresh),
            ("const-string", 0, "Проверка выбранного аудиоканала"),
            ("const-string", 1, "tts_eng_sim"),
            ("const/4", 2, 1),
            ("invoke-static", [3, 0, 1, 2], m_features_speak),
            ("return-void",),

            ("label", "m27"),
            ("const/16", 2, 100),
            ("if-nez", 5, "cv_1"),
            ("const/16", 2, 15),
            ("goto/16", "save_cvol"),
            ("label", "cv_1"),
            ("const/4", 0, 1),
            ("if-ne", 5, 0, "cv_2"),
            ("const/16", 2, 30),
            ("goto/16", "save_cvol"),
            ("label", "cv_2"),
            ("const/4", 0, 2),
            ("if-ne", 5, 0, "cv_3"),
            ("const/16", 2, 45),
            ("goto/16", "save_cvol"),
            ("label", "cv_3"),
            ("const/4", 0, 3),
            ("if-ne", 5, 0, "cv_4"),
            ("const/16", 2, 60),
            ("goto/16", "save_cvol"),
            ("label", "cv_4"),
            ("const/4", 0, 4),
            ("if-ne", 5, 0, "cv_5"),
            ("const/16", 2, 75),
            ("goto/16", "save_cvol"),
            ("label", "cv_5"),
            ("const/4", 0, 5),
            ("if-ne", 5, 0, "save_cvol"),
            ("const/16", 2, 90),
            ("label", "save_cvol"),
            ("const-string", 1, "tts_custom_vol"),
            ("invoke-static", [3, 1, 2], m_ctrl_set_int),
            ("invoke-virtual", [3], m_main_refresh),
            ("const-string", 0, "Проверка собственной громкости озвучки"),
            ("const-string", 1, "tts_eng_sim"),
            ("const/4", 2, 1),
            ("invoke-static", [3, 0, 1, 2], m_features_speak),
            ("return-void",),

            ("label", "check_eng_arr"),
            ("iget-object", 0, 3, f_main_eng_pkgs),
            ("if-eqz", 0, "done"),
            ("if-ltz", 5, "done"),
            ("array-length", 1, 0),
            ("if-ge", 5, 1, "done"),
            ("aget-object", 2, 0, 5),
            ("if-eqz", 2, "done"),

            ("const-string", 0, "open_tts_settings"),
            ("invoke-virtual", [0, 2], m_str_equals),
            ("move-result", 0),
            ("if-eqz", 0, "check_mode_key"),
            ("const-string", 1, "com.android.settings.TTS_SETTINGS"),
            ("const/4", 2, 0),
            ("invoke-virtual", [3, 1, 2], m_main_open_set),
            ("return-void",),

            ("label", "check_mode_key"),
            ("const/16", 0, 11),
            ("if-eq", 4, 0, "e_sim"),
            ("const/16", 0, 12),
            ("if-eq", 4, 0, "e_wa"),
            ("const/16", 0, 13),
            ("if-eq", 4, 0, "e_tg"),
            ("const/16", 0, 14),
            ("if-eq", 4, 0, "e_oth"),
            ("const/16", 0, 15),
            ("if-eq", 4, 0, "e_sms"),
            ("const-string", 1, "tts_voice_name"),
            ("goto/16", "save_eng"),

            ("label", "e_sim"),
            ("const-string", 1, "tts_eng_sim"),
            ("goto/16", "save_eng"),
            ("label", "e_wa"),
            ("const-string", 1, "tts_eng_wa"),
            ("goto/16", "save_eng"),
            ("label", "e_tg"),
            ("const-string", 1, "tts_eng_tg"),
            ("goto/16", "save_eng"),
            ("label", "e_oth"),
            ("const-string", 1, "tts_eng_other"),
            ("goto/16", "save_eng"),
            ("label", "e_sms"),
            ("const-string", 1, "tts_eng_sms"),

            ("label", "save_eng"),
            ("invoke-static", [3, 1, 2], m_ctrl_set_str),
            ("const/16", 0, 16),
            ("if-eq", 4, 0, "log_sel"),
            ("invoke-static", [3, 1], m_features_engine_changed),
            ("invoke-static", [3, 2], m_ctrl_reinit_tts),

            ("label", "log_sel"),
            ("invoke-static", [2], m_ctrl_fmt_eng),
            ("move-result-object", 2),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("const-string", 4, "Сохранена настройка TTS ["),
            ("invoke-virtual", [0, 4], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("const-string", 4, "] = "),
            ("invoke-virtual", [0, 4], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0, 2], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("invoke-virtual", [3], m_main_refresh),
            ("goto/16", "done"),

            ("label", "m4"),
            ("const-string", 1, "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"),
            ("const/4", 2, 1),
            ("invoke-virtual", [3, 1, 2], m_main_open_set),
            ("goto/16", "done"),

            ("label", "m1"),
            ("const/4", 2, 1),
            ("invoke-virtual", [3, 2], m_main_req_phone),
            ("goto/16", "done"),

            ("label", "m2"),
            ("const-string", 1, "android.settings.ACCESSIBILITY_SETTINGS"),
            ("const/4", 2, 0),
            ("invoke-virtual", [3, 1, 2], m_main_open_set),
            ("goto/16", "done"),

            ("label", "m3"),
            ("const-string", 1, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
            ("const/4", 2, 0),
            ("invoke-virtual", [3, 1, 2], m_main_open_set),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_oncreate = {
        "registers": 10, "ins": 2, "outs": 5,
        "insns": [
            ("invoke-super", [8, 9], m_act_oncreate),
            ("label", "ts"),
            ("const/4", 0, 1),
            ("iput-boolean", 0, 8, f_main_check_launch),
            ("invoke-static", [8], m_ctrl_sanitize_prefs),
            ("const-string", 2, "Открыто приложение «Умный Вызов» v2.3.6"),
            ("invoke-static", [2], m_ctrl_log),
            ("invoke-static", [8], m_ctrl_bind_notif),

            ("new-instance", 0, C_SV),
            ("invoke-direct", [0, 8], m_sv_init),

            ("new-instance", 1, C_LL),
            ("invoke-direct", [1, 8], m_ll_init),
            ("const/4", 2, 1),
            ("invoke-virtual", [1, 2], m_ll_set_orient),
            ("const/16", 2, 36),
            ("invoke-virtual", [1, 2, 2, 2, 2], m_ll_set_pad),
            ("const", 2, 0xFFF8FAFC),
            ("invoke-virtual", [1, 2], m_ll_set_bg),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "Умный Вызов v2.3.6"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41B00000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF0F172A),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "Управление звонками кнопками громкости и датчиком у уха + Озвучка звонков, SMS и сообщений WhatsApp/Telegram"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41500000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF475569),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("const/4", 3, 0),
            ("const/16", 4, 24),
            ("invoke-virtual", [2, 3, 3, 3, 4], m_tv_set_pad),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const", 3, 0x41600000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const/16", 3, 28),
            ("invoke-virtual", [2, 3, 3, 3, 3], m_tv_set_pad),
            ("iput-object", 2, 8, f_main_tv_status),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("const-string", 2, "1. Выдать разрешения (Телефон / Контакты / SMS)"),
            ("const/16", 3, 101),
            ("const", 4, 0xFF2563EB),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("const-string", 2, "2. Включить Спец. возможности (Кнопки и Датчик уха)"),
            ("const/16", 3, 102),
            ("const", 4, 0xFF059669),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("const-string", 2, "3. Доступ к уведомлениям (Мессенджеры и Озвучка)"),
            ("const/16", 3, 103),
            ("const", 4, 0xFF7C3AED),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("const-string", 2, "4. Отключить экономию батареи (Samsung / Xiaomi)"),
            ("const/16", 3, 104),
            ("const", 4, 0xFFD97706),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),


            ("const-string", 2, "Включить управление звонками кнопками и датчиком"),
            ("const/16", 3, 200),
            ("const-string", 4, "enabled"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "\nПОДНЯТЬ ТРУБКУ (только ОДНА кнопка громкости: + или -):"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41880000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF047857),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("const-string", 2, "Поднять трубку при поднесении телефона к уху (Датчик приближения)"),
            ("const/16", 3, 207),
            ("const-string", 4, "ear_pickup"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Кнопка увеличения громкости (Громкость +)"),
            ("const/16", 3, 201),
            ("const-string", 4, "ans_vol_up"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Кнопка уменьшения громкости (Громкость -)"),
            ("const/16", 3, 202),
            ("const-string", 4, "ans_vol_down"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),


            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "\nЗАВЕРШИТЬ ЗВОНОК (только ОДНА кнопка громкости: - или +):"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41880000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFFB91C1C),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("const-string", 2, "Кнопка уменьшения громкости (Громкость -)"),
            ("const/16", 3, 205),
            ("const-string", 4, "end_vol_down"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Кнопка увеличения громкости (Громкость +)"),
            ("const/16", 3, 206),
            ("const-string", 4, "end_vol_up"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),


            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "\nГОЛОСОВОЕ ОЗВУЧИВАНИЕ ЗВОНКОВ И СООБЩЕНИЙ (TTS):"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41880000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF6D28D9),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("const-string", 2, "Включить голосовую озвучку звонящего и сообщений"),
            ("const/16", 3, 210),
            ("const-string", 4, "tts_enabled"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Читать номер, если он НЕ сохранён в контактах"),
            ("const/16", 3, 211),
            ("const-string", 4, "tts_read_unknown"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Озвучивать: Обычный звонок (SIM)"),
            ("const/16", 3, 212),
            ("const-string", 4, "tts_app_sim"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Озвучивать: WhatsApp (звонки и сообщения)"),
            ("const/16", 3, 213),
            ("const-string", 4, "tts_app_wa"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Озвучивать: Telegram (звонки и сообщения)"),
            ("const/16", 3, 214),
            ("const-string", 4, "tts_app_tg"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Озвучивать: Viber / Imo / Другие мессенджеры"),
            ("const/16", 3, 215),
            ("const-string", 4, "tts_app_other"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Озвучивать входящие сообщения (SMS / WhatsApp / Telegram)"),
            ("const/16", 3, 216),
            ("const-string", 4, "tts_app_sms"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Читать текст сообщений (SMS / WhatsApp / Telegram)"),
            ("const/16", 3, 217),
            ("const-string", 4, "tts_sms_text"),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_cb),

            ("const-string", 2, "Количество повторений имени: 2 раз(а)"),
            ("const/16", 3, 110),
            ("const", 4, 0xFF7C3AED),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_rep),

            ("const-string", 2, "Движок TTS [Обычный звонок]: По умолчанию"),
            ("const/16", 3, 111),
            ("const", 4, 0xFF0284C7),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_esim),

            ("const-string", 2, "Движок TTS [WhatsApp]: По умолчанию"),
            ("const/16", 3, 112),
            ("const", 4, 0xFF059669),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_ewa),

            ("const-string", 2, "Движок TTS [Telegram]: По умолчанию"),
            ("const/16", 3, 113),
            ("const", 4, 0xFF2563EB),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_etg),

            ("const-string", 2, "Движок TTS [Viber / Imo / Другие]: По умолчанию"),
            ("const/16", 3, 114),
            ("const", 4, 0xFF4F46E5),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_eoth),

            ("const-string", 2, "Движок TTS [Входящие SMS]: По умолчанию"),
            ("const/16", 3, 115),
            ("const", 4, 0xFF0D9488),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_esms),

            ("invoke-static", [8, 1], m_features_voice_buttons),

            ("const-string", 2, "Скорость речи [Обычный звонок]: 1.0x (Обычная)"),
            ("const/16", 3, 121),
            ("const", 4, 0xFF0369A1),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_rsim),

            ("const-string", 2, "Скорость речи [WhatsApp]: 1.0x (Обычная)"),
            ("const/16", 3, 122),
            ("const", 4, 0xFF047857),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_rwa),

            ("const-string", 2, "Скорость речи [Telegram]: 1.0x (Обычная)"),
            ("const/16", 3, 123),
            ("const", 4, 0xFF1D4ED8),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_rtg),

            ("const-string", 2, "Скорость речи [Viber / Imo / Другие]: 1.0x (Обычная)"),
            ("const/16", 3, 124),
            ("const", 4, 0xFF4338CA),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_roth),

            ("const-string", 2, "Скорость речи [Входящие SMS]: 1.0x (Обычная)"),
            ("const/16", 3, 125),
            ("const", 4, 0xFF0F766E),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_rsms),

            ("const-string", 2, "Аудиоканал озвучки (TTS): Канал Специальные возможности"),
            ("const/16", 3, 126),
            ("const", 4, 0xFF7E22CE),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_amode),

            ("const-string", 2, "Собственная громкость TTS (отдельно): 100%"),
            ("const/16", 3, 127),
            ("const", 4, 0xFFBE185D),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),
            ("iput-object", 5, 8, f_main_btn_cvol),

            ("const-string", 2, "Проверить озвучку сейчас (Тест голоса TTS)"),
            ("const/16", 3, 116),
            ("const", 4, 0xFF9333EA),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const-string", 3, "\nМАКСИМАЛЬНО ИНФОРМАТИВНАЯ ДИАГНОСТИКА:"),
            ("invoke-virtual", [2, 3], m_tv_set_text),
            ("const", 3, 0x41880000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF1E3A8A),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("const-string", 2, "Сохранить диагностику в папку Download"),
            ("const/16", 3, 105),
            ("const", 4, 0xFF0F766E),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("const-string", 2, "Отправить диагностику (Поделиться)"),
            ("const/16", 3, 106),
            ("const", 4, 0xFF4F46E5),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("const-string", 2, "Очистить журнал диагностики"),
            ("const/16", 3, 107),
            ("const", 4, 0xFF64748B),
            ("invoke-virtual", [8, 1, 2, 3, 4], m_main_make_btn),
            ("move-result-object", 5),

            ("new-instance", 2, C_TV),
            ("invoke-direct", [2, 8], m_tv_init),
            ("const", 3, 0x41380000),
            ("invoke-virtual", [2, 3], m_tv_set_size),
            ("const", 3, 0xFF1E293B),
            ("invoke-virtual", [2, 3], m_tv_set_color),
            ("const", 3, 0xFFE2E8F0),
            ("invoke-virtual", [2, 3], m_tv_set_bg),
            ("const/16", 3, 24),
            ("invoke-virtual", [2, 3, 3, 3, 3], m_tv_set_pad),
            ("iput-object", 2, 8, f_main_tv_diag),
            ("invoke-virtual", [1, 2], m_ll_add),

            ("invoke-virtual", [0, 1], m_sv_add),
            ("invoke-virtual", [8, 0], m_act_set_content),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_onstart = {
        "registers": 2, "ins": 1, "outs": 1,
        "insns": [
            ("invoke-super", [1], m_act_onstart),
            ("const/4", 0, 1),
            ("iput-boolean", 0, 1, f_main_check_launch),
            ("return-void",),
        ],
    }

    code_onresume = {
        "registers": 4, "ins": 1, "outs": 3,
        "insns": [
            ("invoke-super", [3], m_act_onresume),
            ("label", "ts"),
            ("invoke-static", [3], m_ctrl_bind_notif),
            ("sget-object", 0, f_ctrl_tts),
            ("if-nez", 0, "tts_ready"),
            ("const-string", 0, "tts_eng_sim"),
            ("const-string", 1, "default"),
            ("invoke-static", [3, 0, 1], m_ctrl_get_str),
            ("move-result-object", 0),
            ("invoke-static", [3, 0], m_ctrl_reinit_tts),
            ("label", "tts_ready"),
            ("invoke-virtual", [3], m_main_refresh),
            ("iget-boolean", 0, 3, f_main_check_launch),
            ("if-eqz", 0, "done"),
            ("const/4", 0, 0),
            ("iput-boolean", 0, 3, f_main_check_launch),

            ("invoke-static", [3], m_ctrl_has_phone),
            ("move-result", 1),
            ("if-nez", 1, "check_services"),
            ("const/4", 0, 0),
            ("invoke-virtual", [3, 0], m_main_req_phone),
            ("return-void",),

            ("label", "check_services"),
            ("invoke-virtual", [3], m_main_check_svcs),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_onperm = {
        "registers": 8, "ins": 4, "outs": 4,
        "insns": [
            ("invoke-super", [4, 5, 6, 7], m_act_onperm),
            ("label", "ts"),
            ("invoke-virtual", [4], m_main_refresh),
            ("invoke-static", [4], m_ctrl_has_phone),
            ("move-result", 0),
            ("if-nez", 0, "all_phone_ok"),
            ("new-instance", 1, C_AD_B),
            ("invoke-direct", [1, 4], m_adb_init),
            ("const-string", 2, "Необходимы разрешения"),
            ("invoke-virtual", [1, 2], m_adb_title),
            ("move-result-object", 1),
            ("const-string", 2, "Вы запретили одно или несколько разрешений. Для работы управления звонками и озвучивания контактов/SMS выдайте запрашиваемые разрешения."),
            ("invoke-virtual", [1, 2], m_adb_msg),
            ("move-result-object", 1),
            ("new-instance", 3, C_DLG),
            ("const/4", 0, 1),
            ("invoke-direct", [3, 4, 0], m_dlg_init),
            ("const-string", 2, "Выдать разрешения"),
            ("invoke-virtual", [1, 2, 3], m_adb_pos),
            ("move-result-object", 1),
            ("const-string", 2, "Закрыть"),
            ("const/4", 3, 0),
            ("invoke-virtual", [1, 2, 3], m_adb_neg),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_adb_show),
            ("move-result-object", 2),
            ("return-void",),

            ("label", "all_phone_ok"),
            ("invoke-virtual", [4], m_main_check_svcs),
            ("label", "te"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_onclick = {
        "registers": 6, "ins": 2, "outs": 4,
        "insns": [
            ("label", "ts"),
            ("if-eqz", 5, "done"),
            ("invoke-virtual", [5], m_view_get_id),
            ("move-result", 0),
            ("const/16", 1, 101),
            ("if-eq", 0, 1, "b101"),
            ("const/16", 1, 102),
            ("if-eq", 0, 1, "b102"),
            ("const/16", 1, 103),
            ("if-eq", 0, 1, "b103"),
            ("const/16", 1, 104),
            ("if-eq", 0, 1, "b104"),
            ("const/16", 1, 105),
            ("if-eq", 0, 1, "b105"),
            ("const/16", 1, 106),
            ("if-eq", 0, 1, "b106"),
            ("const/16", 1, 107),
            ("if-eq", 0, 1, "b107"),
            ("const/16", 1, 110),
            ("if-eq", 0, 1, "b110"),
            ("const/16", 1, 111),
            ("if-eq", 0, 1, "b111"),
            ("const/16", 1, 112),
            ("if-eq", 0, 1, "b112"),
            ("const/16", 1, 113),
            ("if-eq", 0, 1, "b113"),
            ("const/16", 1, 114),
            ("if-eq", 0, 1, "b114"),
            ("const/16", 1, 115),
            ("if-eq", 0, 1, "b115"),
            ("const/16", 1, 116),
            ("if-eq", 0, 1, "b116"),
            ("const/16", 1, 117),
            ("if-eq", 0, 1, "b117"),
            ("const/16", 1, 121),
            ("if-eq", 0, 1, "b121"),
            ("const/16", 1, 122),
            ("if-eq", 0, 1, "b122"),
            ("const/16", 1, 123),
            ("if-eq", 0, 1, "b123"),
            ("const/16", 1, 124),
            ("if-eq", 0, 1, "b124"),
            ("const/16", 1, 125),
            ("if-eq", 0, 1, "b125"),
            ("const/16", 1, 126),
            ("if-eq", 0, 1, "b126"),
            ("const/16", 1, 127),
            ("if-eq", 0, 1, "b127"),
            ("goto/16", "done"),
            ("goto/16", "done"),

            ("label", "b101"),
            ("const/4", 2, 1),
            ("invoke-virtual", [4, 2], m_main_req_phone),
            ("goto/16", "done"),

            ("label", "b102"),
            ("const-string", 1, "android.settings.ACCESSIBILITY_SETTINGS"),
            ("const/4", 2, 0),
            ("invoke-virtual", [4, 1, 2], m_main_open_set),
            ("goto/16", "done"),

            ("label", "b103"),
            ("const-string", 1, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
            ("const/4", 2, 0),
            ("invoke-virtual", [4, 1, 2], m_main_open_set),
            ("goto/16", "done"),

            ("label", "b104"),
            ("const-string", 1, "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"),
            ("const/4", 2, 1),
            ("invoke-virtual", [4, 1, 2], m_main_open_set),
            ("goto/16", "done"),

            ("label", "b105"),
            ("invoke-static", [4], m_ctrl_save_log),
            ("move-result-object", 1),
            ("new-instance", 2, C_AD_B),
            ("invoke-direct", [2, 4], m_adb_init),
            ("const-string", 3, "Диагностика сохранена"),
            ("invoke-virtual", [2, 3], m_adb_title),
            ("move-result-object", 2),
            ("invoke-virtual", [2, 1], m_adb_msg),
            ("move-result-object", 2),
            ("const-string", 3, "ОК"),
            ("const/4", 1, 0),
            ("invoke-virtual", [2, 3, 1], m_adb_neg),
            ("move-result-object", 2),
            ("invoke-virtual", [2], m_adb_show),
            ("move-result-object", 2),
            ("invoke-virtual", [4], m_main_refresh),
            ("goto/16", "done"),

            ("label", "b106"),
            ("invoke-virtual", [4], m_main_share_diag),
            ("goto/16", "done"),

            ("label", "b107"),
            ("invoke-static", [], m_ctrl_clear_log),
            ("invoke-virtual", [4], m_main_refresh),
            ("goto/16", "done"),

            ("label", "b110"),
            ("const-string", 1, "tts_repeat"),
            ("const/4", 2, 2),
            ("invoke-static", [4, 1, 2], m_ctrl_get_int),
            ("move-result", 2),
            ("const/4", 3, 1),
            ("if-ne", 2, 3, "r_2"),
            ("const/4", 2, 2),
            ("goto/16", "save_r"),
            ("label", "r_2"),
            ("const/4", 3, 2),
            ("if-ne", 2, 3, "r_3"),
            ("const/4", 2, 3),
            ("goto/16", "save_r"),
            ("label", "r_3"),
            ("const/4", 3, 3),
            ("if-ne", 2, 3, "r_1"),
            ("const/4", 2, 5),
            ("goto/16", "save_r"),
            ("label", "r_1"),
            ("const/4", 2, 1),
            ("label", "save_r"),
            ("invoke-static", [4, 1, 2], m_ctrl_set_int),
            ("invoke-virtual", [4], m_main_refresh),
            ("goto/16", "done"),

            ("label", "b111"),
            ("const/16", 1, 11),
            ("const-string", 2, "Выберите движок TTS для Обычных звонков (SIM)"),
            ("invoke-virtual", [4, 1, 2], m_main_show_eng_dlg),
            ("goto/16", "done"),

            ("label", "b112"),
            ("const/16", 1, 12),
            ("const-string", 2, "Выберите движок TTS для WhatsApp"),
            ("invoke-virtual", [4, 1, 2], m_main_show_eng_dlg),
            ("goto/16", "done"),

            ("label", "b113"),
            ("const/16", 1, 13),
            ("const-string", 2, "Выберите движок TTS для Telegram"),
            ("invoke-virtual", [4, 1, 2], m_main_show_eng_dlg),
            ("goto/16", "done"),

            ("label", "b114"),
            ("const/16", 1, 14),
            ("const-string", 2, "Выберите движок TTS для Viber / Imo / Других"),
            ("invoke-virtual", [4, 1, 2], m_main_show_eng_dlg),
            ("goto/16", "done"),

            ("label", "b115"),
            ("const/16", 1, 15),
            ("const-string", 2, "Выберите движок TTS для Входящих SMS"),
            ("invoke-virtual", [4, 1, 2], m_main_show_eng_dlg),
            ("goto/16", "done"),

            ("label", "b116"),
            ("const/4", 1, 0),
            ("sput", 1, f_ctrl_last_call_state),
            ("const-string", 1, "tts_eng_sim"),
            ("const-string", 2, "default"),
            ("invoke-static", [4, 1, 2], m_ctrl_get_str),
            ("move-result-object", 2),
            ("const-string", 1, "Проверка голосовой озвучки Умный Вызов. Звонит Абонент."),
            ("const/4", 3, 1),
            ("invoke-static", [4, 1, 2, 3], m_ctrl_speak),
            ("invoke-virtual", [4], m_main_refresh),
            ("goto/16", "done"),

            ("label", "b117"),
            ("invoke-virtual", [4], m_main_show_voice_dlg),
            ("goto/16", "done"),

            ("label", "b121"),
            ("const/16", 1, 21),
            ("const-string", 2, "Скорость речи: Обычный звонок (SIM)"),
            ("invoke-virtual", [4, 1, 2], m_main_show_rate_dlg),
            ("goto/16", "done"),

            ("label", "b122"),
            ("const/16", 1, 22),
            ("const-string", 2, "Скорость речи: WhatsApp"),
            ("invoke-virtual", [4, 1, 2], m_main_show_rate_dlg),
            ("goto/16", "done"),

            ("label", "b123"),
            ("const/16", 1, 23),
            ("const-string", 2, "Скорость речи: Telegram"),
            ("invoke-virtual", [4, 1, 2], m_main_show_rate_dlg),
            ("goto/16", "done"),

            ("label", "b124"),
            ("const/16", 1, 24),
            ("const-string", 2, "Скорость речи: Viber / Imo / Другие"),
            ("invoke-virtual", [4, 1, 2], m_main_show_rate_dlg),
            ("goto/16", "done"),

            ("label", "b125"),
            ("const/16", 1, 25),
            ("const-string", 2, "Скорость речи: Входящие SMS"),
            ("invoke-virtual", [4, 1, 2], m_main_show_rate_dlg),
            ("goto/16", "done"),

            ("label", "b126"),
            ("invoke-virtual", [4], m_main_show_amode_dlg),
            ("goto/16", "done"),

            ("label", "b127"),
            ("invoke-virtual", [4], m_main_show_cvol_dlg),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("invoke-virtual", [0], m_thr_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    code_onchecked = {
        "registers": 7, "ins": 3, "outs": 3,
        "insns": [
            ("label", "ts"),
            ("if-eqz", 5, "done"),
            ("invoke-virtual", [5], m_cmp_get_id),
            ("move-result", 0),
            ("const/16", 1, 200),
            ("if-eq", 0, 1, "c200"),
            ("const/16", 1, 201),
            ("if-eq", 0, 1, "c201"),
            ("const/16", 1, 202),
            ("if-eq", 0, 1, "c202"),
            ("const/16", 1, 205),
            ("if-eq", 0, 1, "c205"),
            ("const/16", 1, 206),
            ("if-eq", 0, 1, "c206"),
            ("const/16", 1, 207),
            ("if-eq", 0, 1, "c207"),
            ("const/16", 1, 210),
            ("if-eq", 0, 1, "c210"),
            ("const/16", 1, 211),
            ("if-eq", 0, 1, "c211"),
            ("const/16", 1, 212),
            ("if-eq", 0, 1, "c212"),
            ("const/16", 1, 213),
            ("if-eq", 0, 1, "c213"),
            ("const/16", 1, 214),
            ("if-eq", 0, 1, "c214"),
            ("const/16", 1, 215),
            ("if-eq", 0, 1, "c215"),
            ("const/16", 1, 216),
            ("if-eq", 0, 1, "c216"),
            ("const/16", 1, 217),
            ("if-eq", 0, 1, "c217"),
            ("goto/16", "done"),

            ("label", "c200"),
            ("const-string", 2, "enabled"),
            ("goto/16", "save"),
            ("label", "c201"),
            ("const-string", 2, "ans_vol_up"),
            ("if-eqz", 6, "save"),
            ("const-string", 0, "ans_vol_down"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_set_pref),
            ("iget-object", 0, 4, f_main_cb_ans_dn),
            ("if-eqz", 0, "save"),
            ("invoke-virtual", [0, 1], m_cb_set_checked),
            ("goto/16", "save"),

            ("label", "c202"),
            ("const-string", 2, "ans_vol_down"),
            ("if-eqz", 6, "save"),
            ("const-string", 0, "ans_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_set_pref),
            ("iget-object", 0, 4, f_main_cb_ans_up),
            ("if-eqz", 0, "save"),
            ("invoke-virtual", [0, 1], m_cb_set_checked),
            ("goto/16", "save"),

            ("label", "c205"),
            ("const-string", 2, "end_vol_down"),
            ("if-eqz", 6, "save"),
            ("const-string", 0, "end_vol_up"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_set_pref),
            ("iget-object", 0, 4, f_main_cb_end_up),
            ("if-eqz", 0, "save"),
            ("invoke-virtual", [0, 1], m_cb_set_checked),
            ("goto/16", "save"),

            ("label", "c206"),
            ("const-string", 2, "end_vol_up"),
            ("if-eqz", 6, "save"),
            ("const-string", 0, "end_vol_down"),
            ("const/4", 1, 0),
            ("invoke-static", [4, 0, 1], m_ctrl_set_pref),
            ("iget-object", 0, 4, f_main_cb_end_dn),
            ("if-eqz", 0, "save"),
            ("invoke-virtual", [0, 1], m_cb_set_checked),
            ("goto/16", "save"),
            ("label", "c207"),
            ("const-string", 2, "ear_pickup"),
            ("goto/16", "save"),
            ("label", "c210"),
            ("const-string", 2, "tts_enabled"),
            ("goto/16", "save"),
            ("label", "c211"),
            ("const-string", 2, "tts_read_unknown"),
            ("goto/16", "save"),
            ("label", "c212"),
            ("const-string", 2, "tts_app_sim"),
            ("goto/16", "save"),
            ("label", "c213"),
            ("const-string", 2, "tts_app_wa"),
            ("goto/16", "save"),
            ("label", "c214"),
            ("const-string", 2, "tts_app_tg"),
            ("goto/16", "save"),
            ("label", "c215"),
            ("const-string", 2, "tts_app_other"),
            ("goto/16", "save"),
            ("label", "c216"),
            ("const-string", 2, "tts_app_sms"),
            ("goto/16", "save"),
            ("label", "c217"),
            ("const-string", 2, "tts_sms_text"),

            ("label", "save"),
            ("invoke-static", [4, 2, 6], m_ctrl_set_pref),
            ("invoke-virtual", [4], m_main_refresh),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    db.add_class(
        C_MAIN,
        C_ACT,
        0x0001,
        interfaces=(C_VIEW_OCL, C_CMP_OCL),
        instance_fields=[
            (f_main_tv_status, 0x0002),
            (f_main_tv_diag, 0x0002),
            (f_main_btn_rep, 0x0002),
            (f_main_btn_esim, 0x0002),
            (f_main_btn_ewa, 0x0002),
            (f_main_btn_etg, 0x0002),
            (f_main_btn_eoth, 0x0002),
            (f_main_btn_esms, 0x0002),
            (f_main_btn_voice, 0x0002),
            (f_main_btn_rsim, 0x0002),
            (f_main_btn_rwa, 0x0002),
            (f_main_btn_rtg, 0x0002),
            (f_main_btn_roth, 0x0002),
            (f_main_btn_rsms, 0x0002),
            (f_main_btn_amode, 0x0002),
            (f_main_btn_cvol, 0x0002),
            (f_main_cb_ans_up, 0x0002),
            (f_main_cb_ans_dn, 0x0002),
            (f_main_cb_end_dn, 0x0002),
            (f_main_cb_end_up, 0x0002),
            (f_main_eng_pkgs, 0x0002),
            (f_main_check_launch, 0x0002),
        ],
        direct_methods=[
            (
                m_main_init,
                0x10001,
                {
                    "registers": 1, "ins": 1, "outs": 1,
                    "insns": [("invoke-direct", [0], m_act_init), ("return-void",)],
                },
            ),
        ],
        virtual_methods=[
            (m_main_make_cb, 0x0001, code_make_cb),
            (m_main_make_btn, 0x0001, code_make_btn),
            (m_main_show_eng_dlg, 0x0001, code_show_eng_dlg),
            (m_main_show_voice_dlg, 0x0001, code_show_voice_dlg),
            (m_main_show_rate_dlg, 0x0001, code_show_rate_dlg),
            (m_main_show_amode_dlg, 0x0001, code_show_amode_dlg),
            (m_main_show_cvol_dlg, 0x0001, code_show_cvol_dlg),
            (m_main_share_diag, 0x0001, code_share_diag),
            (m_main_open_set, 0x0001, code_open_set),
            (m_main_req_phone, 0x0001, code_req_phone),
            (m_main_refresh, 0x0001, code_refresh),
            (m_main_check_svcs, 0x0001, code_check_svcs),
            (m_main_handle_dlg, 0x0001, code_handle_dlg),
            (m_main_oncreate, 0x0004, code_oncreate),
            (m_main_onstart, 0x0004, code_onstart),
            (m_main_onresume, 0x0004, code_onresume),
            (m_main_onperm, 0x0001, code_onperm),
            (m_main_onclick, 0x0001, code_onclick),
            (m_main_onchecked, 0x0001, code_onchecked),
        ],
    )

    # =========================================================================
    # CLASS 9: TtsInitListener (implements TextToSpeech.OnInitListener)
    # =========================================================================
    f_ttsl_tts = (C_TTS_L, "tts", C_TTS)
    f_ttsl_text = (C_TTS_L, "text", C_STR)
    f_ttsl_rep = (C_TTS_L, "repeatCount", "I")
    f_ttsl_voice = (C_TTS_L, "voiceName", C_STR)
    m_ttsl_oninit = (C_TTS_L, "onInit", ("V", ("I",)))

    code_ttsl_oninit = {
        "registers": 11, "ins": 2, "outs": 5,
        "insns": [
            ("if-nez", 10, "init_err"),
            ("iget-object", 0, 9, f_ttsl_tts),
            ("if-nez", 0, "has_inst"),
            ("sget-object", 0, f_ctrl_tts),
            ("if-eqz", 0, "done"),
            ("label", "has_inst"),

            ("label", "tl_s"),
            ("invoke-static", [], m_loc_default),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_tts_set_lang),
            ("move-result", 2),
            ("label", "tl_e"),
            ("goto/16", "apply_voice"),
            ("label", "cl"),
            ("move-exception", 1),

            ("label", "apply_voice"),
            ("label", "tv_s"),
            ("const", 2, 0x3F800000),
            ("const", 3, 0x3F800000),
            ("iget-object", 1, 9, f_ttsl_voice),
            ("if-eqz", 1, "do_pitch_rate"),
            ("const-string", 4, "default"),
            ("invoke-virtual", [4, 1], m_str_equals),
            ("move-result", 4),
            ("if-nez", 4, "do_pitch_rate"),
            ("const-string", 4, "preset_"),
            ("invoke-virtual", [1, 4], m_str_contains),
            ("move-result", 4),
            ("if-nez", 4, "do_pitch_rate"),

            ("invoke-virtual", [0], m_tts_get_voices),
            ("move-result-object", 4),
            ("if-eqz", 4, "do_pitch_rate"),
            ("invoke-interface", [4], m_set_iter),
            ("move-result-object", 4),
            ("label", "v_loop"),
            ("invoke-interface", [4], m_iter_has_next),
            ("move-result", 5),
            ("if-eqz", 5, "do_pitch_rate"),
            ("invoke-interface", [4], m_iter_next),
            ("move-result-object", 5),
            ("check-cast", 5, C_VOICE),
            ("if-eqz", 5, "v_loop"),
            ("invoke-virtual", [5], m_voice_get_name),
            ("move-result-object", 6),
            ("if-eqz", 6, "v_loop"),
            ("invoke-virtual", [1, 6], m_str_equals),
            ("move-result", 6),
            ("if-eqz", 6, "v_loop"),
            ("invoke-virtual", [0, 5], m_tts_set_voice),
            ("move-result", 6),

            ("label", "do_pitch_rate"),
            ("invoke-virtual", [0, 2], m_tts_set_pitch),
            ("move-result", 4),
            ("invoke-virtual", [0, 3], m_tts_set_rate),
            ("move-result", 4),
            ("label", "tv_e"),
            ("goto/16", "set_aattr"),
            ("label", "cv"),
            ("move-exception", 1),

            ("label", "set_aattr"),
            ("iget-object", 1, 9, f_ttsl_text),
            ("if-eqz", 1, "done"),
            ("const/4", 7, 3),
            ("const/4", 8, 1),
            ("sget", 1, f_ctrl_last_call_state),
            ("const/4", 2, 1),
            ("if-ne", 1, 2, "use_stream"),
            ("const/4", 7, 2),
            ("const/4", 8, 6),

            ("label", "use_stream"),
            ("label", "ta_s"),
            ("new-instance", 1, C_AATTR_B),
            ("invoke-direct", [1], m_aattrb_init),
            ("invoke-virtual", [1, 8], m_aattrb_usage),
            ("move-result-object", 1),
            ("const/4", 2, 1),
            ("invoke-virtual", [1, 2], m_aattrb_ctype),
            ("move-result-object", 1),
            ("invoke-virtual", [1], m_aattrb_build),
            ("move-result-object", 1),
            ("invoke-virtual", [0, 1], m_tts_set_attr),
            ("move-result", 2),
            ("label", "ta_e"),
            ("goto/16", "make_b"),
            ("label", "ca_attr"),
            ("move-exception", 1),

            ("label", "make_b"),
            ("new-instance", 4, C_BUNDLE),
            ("invoke-direct", [4], m_bundle_init),
            ("const-string", 1, "streamType"),
            ("invoke-virtual", [4, 1, 7], m_bundle_put_int),
            ("const-string", 1, "volume"),
            ("const", 2, 0x3F800000),
            ("invoke-virtual", [4, 1, 2], m_bundle_put_flt),

            ("iget-object", 1, 9, f_ttsl_text),
            ("if-eqz", 1, "done"),
            ("iget", 2, 9, f_ttsl_rep),
            ("if-lez", 2, "def_1"),
            ("goto/16", "start_sp"),
            ("label", "def_1"),
            ("const/4", 2, 1),

            ("label", "start_sp"),
            ("const/4", 3, 0),
            ("const-string", 5, "smartcall_utt_0"),
            ("invoke-virtual", [0, 1, 3, 4, 5], m_tts_speak),
            ("move-result", 6),

            ("new-instance", 3, C_SB),
            ("invoke-direct", [3], m_sb_init),
            ("const-string", 5, "TTS: произнесение запущено (код="),
            ("invoke-virtual", [3, 5], m_sb_app_str),
            ("move-result-object", 3),
            ("invoke-virtual", [3, 6], m_sb_app_int),
            ("move-result-object", 3),
            ("const-string", 5, ", поток="),
            ("invoke-virtual", [3, 5], m_sb_app_str),
            ("move-result-object", 3),
            ("invoke-virtual", [3, 7], m_sb_app_int),
            ("move-result-object", 3),
            ("const-string", 5, ")"),
            ("invoke-virtual", [3, 5], m_sb_app_str),
            ("move-result-object", 3),
            ("invoke-virtual", [3], m_sb_tostr),
            ("move-result-object", 3),
            ("invoke-static", [3], m_ctrl_log),

            ("const/4", 3, 1),
            ("label", "rep_loop"),
            ("if-ge", 3, 2, "done"),
            ("new-instance", 5, C_SB),
            ("invoke-direct", [5], m_sb_init),
            ("const-string", 6, " "),
            ("invoke-virtual", [5, 6], m_sb_app_str),
            ("move-result-object", 5),
            ("invoke-virtual", [5, 1], m_sb_app_str),
            ("move-result-object", 5),
            ("invoke-virtual", [5], m_sb_tostr),
            ("move-result-object", 5),
            ("const/4", 6, 1),
            ("const-string", 7, "smartcall_utt_rep"),
            ("invoke-virtual", [0, 5, 6, 4, 7], m_tts_speak),
            ("move-result", 6),
            ("add-int/lit8", 3, 3, 1),
            ("goto/16", "rep_loop"),

            ("label", "init_err"),
            ("new-instance", 0, C_SB),
            ("invoke-direct", [0], m_sb_init),
            ("const-string", 1, "TTS Ошибка инициализации движка: status="),
            ("invoke-virtual", [0, 1], m_sb_app_str),
            ("move-result-object", 0),
            ("invoke-virtual", [0, 10], m_sb_app_int),
            ("move-result-object", 0),
            ("invoke-virtual", [0], m_sb_tostr),
            ("move-result-object", 0),
            ("invoke-static", [0], m_ctrl_log),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [
            {"start_label": "tl_s", "end_label": "tl_e", "handler_label": "cl"},
            {"start_label": "tv_s", "end_label": "tv_e", "handler_label": "cv"},
            {"start_label": "ta_s", "end_label": "ta_e", "handler_label": "ca_attr"},
            {"start_label": "make_b", "end_label": "te", "handler_label": "ca"},
        ],
    }

    db.add_class(
        C_TTS_L,
        C_OBJ,
        0x0001,
        interfaces=(C_TTS_OIL,),
        instance_fields=[
            (f_ttsl_tts, 0x0001),
            (f_ttsl_text, 0x0001),
            (f_ttsl_rep, 0x0001),
            (f_ttsl_voice, 0x0001),
        ],
        direct_methods=[
            (
                m_tts_l_init,
                0x10001,
                {
                    "registers": 5, "ins": 5, "outs": 1,
                    "insns": [
                        ("invoke-direct", [0], m_obj_init),
                        ("iput-object", 1, 0, f_ttsl_tts),
                        ("iput-object", 2, 0, f_ttsl_text),
                        ("iput", 3, 0, f_ttsl_rep),
                        ("iput-object", 4, 0, f_ttsl_voice),
                        ("return-void",),
                    ],
                },
            ),
        ],
        virtual_methods=[
            (m_ttsl_oninit, 0x0001, code_ttsl_oninit),
        ],
    )

    # =========================================================================
    # CLASS 10: ProximitySensorListener (implements SensorEventListener)
    # =========================================================================
    f_proxl_ctx = (C_PROX_L, "context", C_CTX)
    m_proxl_sensor = (C_PROX_L, "onSensorChanged", ("V", (C_SE,)))
    m_proxl_acc = (C_PROX_L, "onAccuracyChanged", ("V", (C_SENSOR, "I")))

    code_proxl_sensor = {
        "registers": 10, "ins": 2, "outs": 2,
        "insns": [
            ("if-eqz", 9, "done"),
            ("label", "ts"),
            ("iget-object", 4, 8, f_proxl_ctx),
            ("if-eqz", 4, "done"),

            ("sget", 0, f_ctrl_last_call_state),
            ("const/4", 1, 1),
            ("if-eq", 0, 1, "watch_ok"),
            ("sget-boolean", 0, f_ctrl_voip_inc),
            ("if-nez", 0, "watch_ok"),
            ("return-void",),

            ("label", "watch_ok"),
            ("iget-object", 0, 9, f_se_sensor),
            ("if-eqz", 0, "done"),
            ("invoke-virtual", [0], m_sensor_get_type),
            ("move-result", 6),
            ("iget-object", 0, 9, f_se_values),
            ("if-eqz", 0, "done"),
            ("array-length", 1, 0),
            ("if-lez", 1, "done"),

            ("const/16", 2, 8),
            ("if-ne", 6, 2, "done"),

            # --- TYPE_PROXIMITY (8) ONLY ---
            ("const/4", 1, 0),
            ("aget", 2, 0, 1),
            ("float-to-int", 2, 2),
            ("if-ltz", 2, "done"),
            ("if-eqz", 2, "prox_near"),
            # Value >= 1 means FAR (open air): record proxSawFar = true
            ("const/4", 0, 1),
            ("sput-boolean", 0, f_ctrl_prox_far),
            ("return-void",),

            ("label", "prox_near"),
            # Must have seen FAR (open air) first during this call!
            ("sget-boolean", 1, f_ctrl_prox_far),
            ("if-eqz", 1, "done"),

            # Must be >= 1200ms after callRingStartTime
            ("sget-wide", 0, f_ctrl_ring_start),
            ("const-wide/16", 2, 0),
            ("cmp-long", 5, 0, 2),
            ("if-lez", 5, "done"),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 2),
            ("sub-long/2addr", 2, 0),
            ("const-wide/16", 0, 1200),
            ("cmp-long", 5, 2, 0),
            ("if-ltz", 5, "done"),

            # Must be >= 800ms after proximity sensor registration
            ("sget-wide", 0, f_ctrl_prox_reg_time),
            ("invoke-static", [], m_sys_time),
            ("move-result-wide", 2),
            ("sub-long/2addr", 2, 0),
            ("const-wide/16", 0, 800),
            ("cmp-long", 5, 2, 0),
            ("if-ltz", 5, "done"),

            ("label", "trigger_ear"),
            ("invoke-static", [4], m_ctrl_unreg_prox),
            ("const-string", 0, "Датчик приближения (у уха): телефон поднесён к уху -> ПОДНЯТЬ ТРУБКУ"),
            ("invoke-static", [0], m_ctrl_log),
            ("invoke-static", [4], m_ctrl_ans),
            ("label", "te"),
            ("label", "done"),
            ("return-void",),
            ("label", "ca"),
            ("move-exception", 0),
            ("return-void",),
        ],
        "tries": [{"start_label": "ts", "end_label": "te", "handler_label": "ca"}],
    }

    db.add_class(
        C_PROX_L,
        C_OBJ,
        0x0001,
        interfaces=(C_SEL,),
        instance_fields=[
            (f_proxl_ctx, 0x0002),
        ],
        direct_methods=[
            (
                m_prox_l_init,
                0x10001,
                {
                    "registers": 2, "ins": 2, "outs": 1,
                    "insns": [
                        ("invoke-direct", [0], m_obj_init),
                        ("iput-object", 1, 0, f_proxl_ctx),
                        ("return-void",),
                    ],
                },
            ),
        ],
        virtual_methods=[
            (
                m_proxl_acc,
                0x0001,
                {"registers": 3, "ins": 3, "outs": 0, "insns": [("return-void",)]},
            ),
            (m_proxl_sensor, 0x0001, code_proxl_sensor),
        ],
    )

    return db.compile()


if __name__ == "__main__":
    dex_data = build_classes_dex()
    output = sys.argv[1] if len(sys.argv) > 1 else "classes.dex"
    with open(output, "wb") as f:
        f.write(dex_data)
    print(f"Successfully built classes.dex: {len(dex_data)} bytes")
