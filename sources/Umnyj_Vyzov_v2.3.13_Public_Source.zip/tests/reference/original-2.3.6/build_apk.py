#!/usr/bin/env python3
"""Единый скрипт сборки, верификации и подписи APK «Умный Вызов» v2.3.6."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    cmd = [
        sys.executable,
        str(ROOT / "build_release.py"),
        "--key", str(ROOT / "keystore/private_key.pem"),
        "--cert", str(ROOT / "previous_signing_certificate.pem"),
        "--output", str(ROOT / "dist/Umnyj_Vyzov_v2.3.6.apk"),
    ] + sys.argv[1:]
    subprocess.run(cmd, check=True)

if __name__ == "__main__":
    main()
