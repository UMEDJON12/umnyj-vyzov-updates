#!/usr/bin/env python3
"""
Verifies the generated classes.dex header, checksum, SHA-1, table sorting,
and runs a full control-flow & exact reference-class register-type verifier on all methods in build_dex.py.
"""
import hashlib
import struct
import zlib
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import build_dex

with open(sys.argv[1] if len(sys.argv) > 1 else "classes.dex", "rb") as f:
    dex = f.read()

magic = dex[:8]
assert magic in (b"dex\n035\x00", b"dex\n037\x00", b"dex\n038\x00", b"dex\n039\x00"), f"Bad magic: {magic}"
checksum = struct.unpack_from("<I", dex, 8)[0]
sig = dex[12:32]
calc_sig = hashlib.sha1(dex[32:]).digest()
assert sig == calc_sig, "SHA-1 mismatch!"
calc_checksum = zlib.adler32(dex[12:]) & 0xFFFFFFFF
assert checksum == calc_checksum, "Adler32 mismatch!"

file_size, header_size, endian = struct.unpack_from("<III", dex, 32)
assert file_size == len(dex), f"File size mismatch: {file_size} != {len(dex)}"
assert header_size == 112
assert endian == 0x12345678

print(f"DEX Header OK: size={file_size}, adler32={hex(checksum)}, sha1={sig.hex()[:16]}...")


SUPERTYPES = {
    "Lcom/smartcall/ru/MainActivity;": {"Landroid/app/Activity;", "Landroid/content/Context;", "Landroid/view/View$OnClickListener;", "Landroid/widget/CompoundButton$OnCheckedChangeListener;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/CallControlAccessibilityService;": {"Landroid/accessibilityservice/AccessibilityService;", "Landroid/app/Service;", "Landroid/content/Context;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/CallNotificationListenerService;": {"Landroid/service/notification/NotificationListenerService;", "Landroid/app/Service;", "Landroid/content/Context;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/ScreenAndVolumeReceiver;": {"Landroid/content/BroadcastReceiver;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/DelayedActionRunnable;": {"Ljava/lang/Runnable;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/DialogClickListener;": {"Landroid/content/DialogInterface$OnClickListener;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/TtsInitListener;": {"Landroid/speech/tts/TextToSpeech$OnInitListener;", "Ljava/lang/Object;"},
    "Lcom/smartcall/ru/ProximitySensorListener;": {"Landroid/hardware/SensorEventListener;", "Ljava/lang/Object;"},
    "Landroid/app/Activity;": {"Landroid/content/Context;", "Ljava/lang/Object;"},
    "Landroid/app/Service;": {"Landroid/content/Context;", "Ljava/lang/Object;"},
    "Landroid/accessibilityservice/AccessibilityService;": {"Landroid/app/Service;", "Landroid/content/Context;", "Ljava/lang/Object;"},
    "Landroid/service/notification/NotificationListenerService;": {"Landroid/app/Service;", "Landroid/content/Context;", "Ljava/lang/Object;"},
    "Landroid/widget/CheckBox;": {"Landroid/widget/CompoundButton;", "Landroid/widget/Button;", "Landroid/widget/TextView;", "Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/CompoundButton;": {"Landroid/widget/Button;", "Landroid/widget/TextView;", "Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/Button;": {"Landroid/widget/TextView;", "Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/TextView;": {"Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/LinearLayout;": {"Landroid/view/ViewGroup;", "Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/ScrollView;": {"Landroid/view/ViewGroup;", "Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/view/ViewGroup;": {"Landroid/view/View;", "Ljava/lang/Object;"},
    "Landroid/widget/LinearLayout$LayoutParams;": {"Landroid/view/ViewGroup$LayoutParams;", "Ljava/lang/Object;"},
    "Ljava/lang/String;": {"Ljava/lang/CharSequence;", "Ljava/lang/Object;"},
    "Ljava/lang/StringBuilder;": {"Ljava/lang/CharSequence;", "Ljava/lang/Object;"},
    "Ljava/lang/Exception;": {"Ljava/lang/Throwable;", "Ljava/lang/Object;"},
    "Ljava/lang/RuntimeException;": {"Ljava/lang/Exception;", "Ljava/lang/Throwable;", "Ljava/lang/Object;"},
}


def is_assignable(actual: str, expected: str) -> bool:
    if actual == "ZERO":
        return True
    if not actual.startswith("REF:") or not expected.startswith("REF:"):
        return False
    a_cls = actual[4:]
    e_cls = expected[4:]
    if a_cls == e_cls or e_cls == "Ljava/lang/Object;":
        return True
    if e_cls in SUPERTYPES.get(a_cls, set()):
        return True
    if a_cls.startswith("[") and e_cls.startswith("["):
        return is_assignable("REF:" + a_cls[1:], "REF:" + e_cls[1:])
    return False


def kind_of(t: str) -> str:
    if t == "J":
        return "LONG"
    if t == "F":
        return "FLOAT"
    if t in ("I", "Z", "B", "S", "C"):
        return "INT"
    if t.startswith("L") or t.startswith("["):
        return "REF:" + t
    return t


orig_compile = build_dex.DexBuilder.compile


def checked_compile(self):
    for c in self.classes:
        cls_name = c["cls_type"]
        for is_virtual, m_list in [(False, c["direct_methods"]), (True, c["virtual_methods"])]:
            for m_ref, acc, code in m_list:
                m_cls, m_name, (ret_t, params) = m_ref
                mname = f"{cls_name}.{m_name}"
                is_static = bool(acc & 0x0008)
                exp_ins = (0 if is_static else 1) + sum(2 if p in ("J", "D") else 1 for p in params)
                assert code["ins"] == exp_ins, f"{mname}: ins={code['ins']} != expected {exp_ins}"
                assert code["registers"] >= code["ins"], f"{mname}: registers < ins"

                max_outs = 0
                labels_cu = {}
                cu_pos = 0
                for ins in code["insns"]:
                    if ins[0] == "label":
                        labels_cu[ins[1]] = cu_pos
                    else:
                        cu_pos += self._insn_size_cu(ins[0])
                prev_try_end = 0
                for t in code.get("tries", []):
                    s_cu = labels_cu[t["start_label"]]
                    e_cu = labels_cu[t["end_label"]]
                    assert s_cu >= prev_try_end, f"{mname}: overlapping/unsorted try_item {s_cu} < {prev_try_end}"
                    assert e_cu > s_cu, f"{mname}: empty try_item"
                    prev_try_end = e_cu
                labels = set(labels_cu.keys())
                for ins in code["insns"]:
                    op = ins[0]
                    if op == "label":
                        continue
                    if op.startswith("invoke-"):
                        regs, target = ins[1], ins[2]
                        t_cls, t_name, (t_ret, t_params) = target
                        t_is_static = op in ("invoke-static", "invoke-static/range")
                        exp_arg_regs = (0 if t_is_static else 1) + sum(2 if p in ("J", "D") else 1 for p in t_params)
                        assert len(regs) == exp_arg_regs, (
                            f"{mname}: {op} {t_cls}.{t_name} passed {len(regs)} regs, expected {exp_arg_regs}"
                        )
                        for r in regs:
                            assert 0 <= r < code["registers"], f"{mname}: reg {r} out of range"
                        if len(regs) > max_outs:
                            max_outs = len(regs)
                    elif op in ("if-eqz", "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez"):
                        assert 0 <= ins[1] < code["registers"]
                        assert ins[2] in labels, f"Missing label {ins[2]} in {mname}"
                    elif op in ("if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le"):
                        assert 0 <= ins[1] < code["registers"] and 0 <= ins[2] < code["registers"]
                        assert ins[3] in labels, f"Missing label {ins[3]} in {mname}"
                    elif op == "goto/16":
                        assert ins[1] in labels, f"Missing label {ins[1]} in {mname}"
                assert code["outs"] >= max_outs, f"{mname}: outs={code['outs']} < max_outs={max_outs}"

                # Control-flow & exact reference-class register type verification
                regs_cnt = code["registers"]
                ins_cnt = code["ins"]
                insns = code["insns"]
                lbl_pc = {ins[1]: idx for idx, ins in enumerate(insns) if ins[0] == "label"}
                init_state = ["UNINIT"] * regs_cnt
                reg_p = regs_cnt - ins_cnt
                if not is_static:
                    init_state[reg_p] = "REF:" + cls_name
                    reg_p += 1
                for pt in params:
                    k = kind_of(pt)
                    if k == "LONG":
                        init_state[reg_p] = "LONG_LO"
                        init_state[reg_p + 1] = "LONG_HI"
                        reg_p += 2
                    else:
                        init_state[reg_p] = k
                        reg_p += 1
                states = {0: (tuple(init_state), "V")}
                queue = [0]
                while queue:
                    pc = queue.pop(0)
                    if pc >= len(insns):
                        continue
                    st_tuple, last_ret = states[pc]
                    st = list(st_tuple)
                    ins = insns[pc]
                    op = ins[0]
                    next_pcs = [pc + 1]

                    def set_reg(r, k):
                        assert 0 <= r < regs_cnt, f"{mname} pc={pc}: reg {r} out of bounds"
                        if r > 0 and st[r] == "LONG_HI":
                            st[r - 1] = "CONFLICT"
                        if r + 1 < regs_cnt and st[r] == "LONG_LO":
                            st[r + 1] = "CONFLICT"
                        st[r] = k

                    def set_wide(r):
                        assert 0 <= r and r + 1 < regs_cnt, f"{mname} pc={pc}: wide reg {r} out of bounds"
                        set_reg(r, "LONG_LO")
                        set_reg(r + 1, "LONG_HI")

                    def check_reg(r, allowed):
                        val = st[r]
                        if "REF_ANY" in allowed and (val.startswith("REF:") or val == "ZERO"):
                            return
                        for a in allowed:
                            if a.startswith("REF:") and is_assignable(val, a):
                                return
                        assert val in allowed, (
                            f"VerifyError in {mname} pc={pc} {ins}: reg v{r} has type {val}, expected {allowed}"
                        )

                    if op in ("label", "nop"):
                        pass
                    elif op in ("const/4", "const/16"):
                        set_reg(ins[1], "ZERO" if ins[2] == 0 else "INT")
                    elif op == "const":
                        set_reg(ins[1], "ZERO" if ins[2] == 0 else "INT_FLOAT")
                    elif op == "const-wide/16":
                        set_wide(ins[1])
                    elif op == "const-string":
                        set_reg(ins[1], "REF:Ljava/lang/String;")
                    elif op == "const-class":
                        set_reg(ins[1], "REF:Ljava/lang/Class;")
                    elif op == "new-instance":
                        set_reg(ins[1], "REF:" + ins[2])
                    elif op == "new-array":
                        set_reg(ins[1], "REF:" + ins[3])
                    elif op == "check-cast":
                        check_reg(ins[1], ("REF_ANY",))
                        set_reg(ins[1], "REF:" + ins[2])
                    elif op == "move":
                        check_reg(ins[2], ("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                        set_reg(ins[1], st[ins[2]])
                    elif op == "move-object":
                        check_reg(ins[2], ("REF_ANY",))
                        set_reg(ins[1], st[ins[2]])
                    elif op == "move-result":
                        set_reg(ins[1], "INT_FLOAT")
                    elif op == "move-result-wide":
                        set_wide(ins[1])
                    elif op == "move-result-object":
                        set_reg(ins[1], "REF:" + last_ret if last_ret.startswith("L") or last_ret.startswith("[") else "REF:Ljava/lang/Object;")
                    elif op == "move-exception":
                        set_reg(ins[1], "REF:Ljava/lang/Throwable;")
                    elif op == "return-void":
                        next_pcs = []
                    elif op == "return":
                        check_reg(ins[1], ("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                        next_pcs = []
                    elif op == "return-object":
                        check_reg(ins[1], ("REF:" + ret_t,))
                        next_pcs = []
                    elif op == "array-length":
                        check_reg(ins[2], ("REF_ANY",))
                        set_reg(ins[1], "INT")
                    elif op == "aget":
                        check_reg(ins[2], ("REF_ANY",))
                        check_reg(ins[3], ("INT", "INT_FLOAT", "ZERO"))
                        set_reg(ins[1], "INT_FLOAT")
                    elif op == "aget-object":
                        check_reg(ins[2], ("REF_ANY",))
                        check_reg(ins[3], ("INT", "INT_FLOAT", "ZERO"))
                        arr_t = st[ins[2]]
                        elem_t = "REF:" + arr_t[5:] if arr_t.startswith("REF:[") else "REF:Ljava/lang/Object;"
                        set_reg(ins[1], elem_t)
                    elif op == "aput-object":
                        check_reg(ins[1], ("REF_ANY",))
                        check_reg(ins[2], ("REF_ANY",))
                        check_reg(ins[3], ("INT", "INT_FLOAT", "ZERO"))
                    elif op in ("iget", "iget-boolean"):
                        check_reg(ins[2], ("REF:" + ins[3][0],))
                        set_reg(ins[1], "INT_FLOAT")
                    elif op == "iget-object":
                        check_reg(ins[2], ("REF:" + ins[3][0],))
                        set_reg(ins[1], "REF:" + ins[3][2])
                    elif op in ("iput", "iput-boolean"):
                        check_reg(ins[1], ("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                        check_reg(ins[2], ("REF:" + ins[3][0],))
                    elif op == "iput-object":
                        check_reg(ins[1], ("REF:" + ins[3][2],))
                        check_reg(ins[2], ("REF:" + ins[3][0],))
                    elif op in ("sget", "sget-boolean"):
                        set_reg(ins[1], "INT_FLOAT")
                    elif op == "sget-wide":
                        set_wide(ins[1])
                    elif op == "sget-object":
                        set_reg(ins[1], "REF:" + ins[2][2])
                    elif op in ("sput", "sput-boolean"):
                        check_reg(ins[1], ("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                    elif op == "sput-wide":
                        check_reg(ins[1], ("LONG_LO",))
                        check_reg(ins[1] + 1, ("LONG_HI",))
                    elif op == "sput-object":
                        check_reg(ins[1], ("REF:" + ins[2][2],))
                    elif op in ("add-int/lit8", "and-int/lit8", "and-int/2addr", "or-int/2addr"):
                        set_reg(ins[1], "INT")
                    elif op in ("int-to-float", "float-to-int"):
                        check_reg(ins[2], ("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                        set_reg(ins[1], "INT_FLOAT")
                    elif op == "int-to-long":
                        check_reg(ins[2], ("INT", "INT_FLOAT", "ZERO"))
                        set_wide(ins[1])
                    elif op in ("sub-long/2addr", "rem-long/2addr"):
                        check_reg(ins[1], ("LONG_LO",))
                        check_reg(ins[2], ("LONG_LO",))
                        set_wide(ins[1])
                    elif op == "cmp-long":
                        check_reg(ins[2], ("LONG_LO",))
                        check_reg(ins[3], ("LONG_LO",))
                        set_reg(ins[1], "INT")
                    elif op == "goto/16":
                        next_pcs = [lbl_pc[ins[1]]]
                    elif op.startswith("if-"):
                        if op.endswith("z"):
                            if op in ("if-eqz", "if-nez"):
                                check_reg(ins[1], ("INT", "INT_FLOAT", "REF_ANY", "ZERO"))
                            else:
                                check_reg(ins[1], ("INT", "INT_FLOAT", "ZERO"))
                            next_pcs = [pc + 1, lbl_pc[ins[2]]]
                        else:
                            if op in ("if-eq", "if-ne"):
                                check_reg(ins[1], ("INT", "INT_FLOAT", "REF_ANY", "ZERO"))
                                check_reg(ins[2], ("INT", "INT_FLOAT", "REF_ANY", "ZERO"))
                            else:
                                check_reg(ins[1], ("INT", "INT_FLOAT", "ZERO"))
                                check_reg(ins[2], ("INT", "INT_FLOAT", "ZERO"))
                            next_pcs = [pc + 1, lbl_pc[ins[3]]]
                    elif op.startswith("invoke-"):
                        regs_arg, mref = ins[1], ins[2]
                        t_cls, t_name, (t_ret, t_params) = mref
                        last_ret = t_ret
                        is_stat = "static" in op
                        expected = []
                        if not is_stat:
                            expected.append(("REF:" + t_cls,))
                        for pt in t_params:
                            k = kind_of(pt)
                            if k == "LONG":
                                expected.append(("LONG_LO",))
                                expected.append(("LONG_HI",))
                            elif k.startswith("REF:"):
                                expected.append((k,))
                            else:
                                expected.append(("INT", "FLOAT", "INT_FLOAT", "ZERO"))
                        for r_a, exp_a in zip(regs_arg, expected):
                            check_reg(r_a, exp_a)

                    for t in code.get("tries", []):
                        s_pc = lbl_pc[t["start_label"]]
                        e_pc = lbl_pc[t["end_label"]]
                        if s_pc <= pc < e_pc:
                            next_pcs.append(lbl_pc[t["handler_label"]])

                    def merge_reg(t1, t2):
                        if t1 == t2:
                            return t1
                        if t1 == "UNINIT" or t2 == "UNINIT":
                            return "CONFLICT"
                        if t1 == "ZERO" and t2.startswith("REF:"):
                            return t2
                        if t2 == "ZERO" and t1.startswith("REF:"):
                            return t1
                        if t1 == "ZERO" and t2 in ("INT", "FLOAT", "INT_FLOAT"):
                            return t2
                        if t2 == "ZERO" and t1 in ("INT", "FLOAT", "INT_FLOAT"):
                            return t1
                        if {t1, t2} <= {"INT", "FLOAT", "INT_FLOAT"}:
                            return "INT_FLOAT"
                        if t1.startswith("REF:") and t2.startswith("REF:"):
                            if is_assignable(t1, t2):
                                return t2
                            if is_assignable(t2, t1):
                                return t1
                            return "REF:Ljava/lang/Object;"
                        return "CONFLICT"

                    for npc in next_pcs:
                        if npc not in states:
                            states[npc] = (tuple(st), last_ret)
                            queue.append(npc)
                        else:
                            old_st, old_ret = states[npc]
                            merged = tuple(merge_reg(a, b) for a, b in zip(old_st, st))
                            merged_ret = old_ret if old_ret == last_ret else "Ljava/lang/Object;"
                            if (merged, merged_ret) != (old_st, old_ret):
                                states[npc] = (merged, merged_ret)
                                if npc not in queue:
                                    queue.append(npc)

    print(f"All {sum(len(c['direct_methods']) + len(c['virtual_methods']) for c in self.classes)} methods passed static & control-flow type verification!")
    return orig_compile(self)


build_dex.DexBuilder.compile = checked_compile
build_dex.build_classes_dex()
