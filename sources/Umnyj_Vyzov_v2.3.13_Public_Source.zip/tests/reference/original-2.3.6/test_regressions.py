"""Host-side execution of selected DEX IR paths. This is not an Android emulator."""
import unittest
from unittest.mock import patch

import build_dex


def capture_methods():
    captured = []
    with patch.object(build_dex.DexBuilder, "compile", lambda self: captured.extend(self.classes) or b""):
        build_dex.build_classes_dex()
    return {ref[1]: code for c in captured for ref, _, code in c["direct_methods"] + c["virtual_methods"]}


METHODS = capture_methods()


class Machine:
    def __init__(self, sdk=36, mocks=None, fields=None):
        self.sdk, self.mocks = sdk, mocks or {}
        self.fields = fields or {}
        self.calls = []

    def run(self, name, *args):
        code = METHODS[name]
        regs = [0] * code["registers"]
        regs[-len(args):] = args
        insns = code["insns"]
        labels = {ins[1]: i for i, ins in enumerate(insns) if ins[0] == "label"}
        pc, result, exception = 0, None, None
        for _ in range(5000):
            ins = insns[pc]
            op, vals = ins[0], ins[1:]
            current = pc
            pc += 1
            try:
                if op == "label" or op == "check-cast":
                    pass
                elif op.startswith("const"):
                    regs[vals[0]] = vals[1]
                elif op.startswith("move-result"):
                    regs[vals[0]] = result
                elif op == "move-exception":
                    regs[vals[0]] = exception
                elif op.startswith("move"):
                    regs[vals[0]] = regs[vals[1]]
                elif op.startswith("sget"):
                    regs[vals[0]] = self.sdk if vals[1][1] == "SDK_INT" else self.fields.get(vals[1][1], 0)
                elif op.startswith("sput"):
                    self.fields[vals[1][1]] = regs[vals[0]]
                elif op.startswith("iget"):
                    regs[vals[0]] = regs[vals[1]].get(vals[2][1], 0)
                elif op.startswith("iput"):
                    regs[vals[1]][vals[2][1]] = regs[vals[0]]
                elif op.startswith("invoke"):
                    target = vals[1]
                    mname = target[1]
                    argv = [regs[r] for r in vals[0]]
                    if op != "invoke-static":
                        argv = argv[1:]
                    self.calls.append(mname)
                    if mname in self.mocks:
                        mock = self.mocks[mname]
                        result = mock(*argv) if callable(mock) else mock
                    elif mname == "toString":
                        result = str(regs[vals[0][0]])
                    elif mname == "equals":
                        result = regs[vals[0][0]] == argv[0]
                    elif mname == "length":
                        result = len(regs[vals[0][0]])
                    elif mname == "toLowerCase":
                        result = str(regs[vals[0][0]]).lower()
                    elif mname == "contains":
                        result = str(argv[0]) in str(regs[vals[0][0]])
                    elif mname == "get":
                        result = regs[vals[0][0]].get(argv[0])
                    elif mname == "containsKey":
                        result = argv[0] in regs[vals[0][0]]
                    elif mname == "getInt":
                        result = regs[vals[0][0]].get(argv[0], argv[1])
                    elif mname == "getSystemService":
                        result = {}
                    elif mname == "elapsedRealtime":
                        result = 1000000
                    elif mname in ("log", "stopTts", "cancelAnswer"):
                        result = None
                    else:
                        raise AssertionError(f"Unmocked call: {mname}")
                elif op.startswith("if-"):
                    kind = op[3:]
                    a = regs[vals[0]]
                    if kind.endswith("z"):
                        b, label, kind = 0, vals[1], kind[:-1]
                    else:
                        b, label = regs[vals[1]], vals[2]
                    cond = {"eq": lambda: a == b, "ne": lambda: a != b,
                            "lt": lambda: a < b, "le": lambda: a <= b,
                            "gt": lambda: a > b, "ge": lambda: a >= b}[kind]()
                    if cond:
                        pc = labels[label]
                elif op.startswith("goto"):
                    pc = labels[vals[0]]
                elif op == "array-length":
                    regs[vals[0]] = len(regs[vals[1]])
                elif op in ("aget", "aget-object"):
                    regs[vals[0]] = regs[vals[1]][regs[vals[2]]]
                elif op == "float-to-int":
                    regs[vals[0]] = int(regs[vals[1]])
                elif op == "add-int/lit8":
                    regs[vals[0]] = regs[vals[1]] + vals[2]
                elif op == "and-int/lit8":
                    regs[vals[0]] = regs[vals[1]] & vals[2]
                elif op == "and-int/2addr":
                    regs[vals[0]] &= regs[vals[1]]
                elif op == "or-int/2addr":
                    regs[vals[0]] |= regs[vals[1]]
                elif op == "sub-long/2addr":
                    regs[vals[0]] -= regs[vals[1]]
                elif op == "cmp-long":
                    a, b = regs[vals[1]], regs[vals[2]]
                    regs[vals[0]] = (a > b) - (a < b)
                elif op == "return-void":
                    return None
                elif op.startswith("return"):
                    return regs[vals[0]]
                else:
                    raise AssertionError(f"Unsupported IR instruction: {ins}")
            except RuntimeError as error:
                for region in code.get("tries", []):
                    if labels[region["start_label"]] <= current < labels[region["end_label"]]:
                        exception = error
                        pc = labels[region["handler_label"]]
                        break
                else:
                    raise
        raise AssertionError("IR did not terminate")


class RegressionTests(unittest.TestCase):
    def test_end_stops_after_telecom_success(self):
        m = Machine(mocks={"endCall": True})
        m.run("endCallPulse", {})
        self.assertNotIn("triggerCallNotificationAction", m.calls)
        self.assertNotIn("clickCallButtonInUi", m.calls)
        self.assertNotIn("dispatchMediaKey", m.calls)

    def test_end_uses_one_successful_fallback(self):
        for notif, ui in [(True, False), (False, True), (False, False)]:
            with self.subTest(notif=notif, ui=ui):
                m = Machine(mocks={"endCall": False, "triggerCallNotificationAction": notif,
                                   "clickCallButtonInUi": ui, "dispatchMediaKey": None})
                m.run("endCallPulse", {})
                self.assertEqual("clickCallButtonInUi" in m.calls, not notif)
                self.assertEqual("dispatchMediaKey" in m.calls, not (notif or ui))

    def test_unsupported_telecom_api_not_called(self):
        m = Machine(sdk=24, mocks={"triggerCallNotificationAction": True})
        m.run("endCallPulse", {})
        self.assertNotIn("endCall", m.calls)

    def test_telecom_error_uses_fallback(self):
        def denied():
            raise RuntimeError("permission denied")
        m = Machine(mocks={"endCall": denied, "triggerCallNotificationAction": True})
        m.run("endCallPulse", {})
        self.assertIn("triggerCallNotificationAction", m.calls)
        self.assertNotIn("clickCallButtonInUi", m.calls)

    def test_answer_uses_confirmed_workflow_without_optimistic_connected_state(self):
        m = Machine(mocks={"answer": None, "canTriggerNow": True,
                           "unregisterProximitySensor": None})
        m.mocks["answerCallPulse"] = lambda context: m.run("answerCallPulse", context)
        m.run("answerCall", {})
        self.assertEqual(m.calls.count("answer"), 1)
        self.assertNotIn("recordActiveCallState", m.calls)

    def test_sms_wrapper_has_no_call_state_gate(self):
        for state in [0, 1, 2]:
            with self.subTest(state=state):
                received = []
                m = Machine(fields={"lastCallState": state, "lastSmsPackage": "com.whatsapp"},
                            mocks={"announceSms": lambda *args: received.append(args)})
                for ins in METHODS["announceIncomingSms"]["insns"]:
                    if ins[0] == "sget-object": m.fields[ins[2][1]] = "com.whatsapp"
                m.run("announceIncomingSms", {}, "Иван", "Привет")
                self.assertEqual(received, [({}, "com.whatsapp", "Иван", "Привет")])
                self.assertNotIn("getCallState", m.calls)

    def test_pending_intent_null_and_cancel_are_failures(self):
        def canceled(*args):
            raise RuntimeError("canceled PendingIntent")
        m = Machine(mocks={"send": canceled})
        self.assertFalse(m.run("sendPiWithBal", 0))
        m.sdk = 24
        self.assertFalse(m.run("sendPiWithBal", {}))
        m.mocks["send"] = None
        self.assertTrue(m.run("sendPiWithBal", {}))

    def test_one_notification_action_only(self):
        for answer in [False, True]:
            for success in [False, True]:
                with self.subTest(answer=answer, success=success):
                    notification = {"category": "call", "extras": {
                        "android.answerIntent": {"id": "a"}, "android.declineIntent": {"id": "d"},
                        "android.hangUpIntent": {"id": "h"}}, "actions": 0}
                    m = Machine(fields={"instance": {"service": True}}, mocks={
                        "getActiveNotifications": [{"n": notification}, {"n": notification}],
                        "getNotification": lambda: notification, "sendPiWithBal": success})
                    self.assertEqual(bool(m.run("triggerCallNotificationAction", answer)), success)
                    if success:
                        self.assertEqual(m.calls.count("sendPiWithBal"), 1)

    def test_held_key_and_up_do_not_repeat_or_need_active_call(self):
        service, event = {}, {"event": True}
        m = Machine(mocks={"getKeyCode": 24, "getAction": 0, "getRepeatCount": 0,
                           "shouldInterceptKey": True, "handleHardwareButton": True})
        self.assertTrue(m.run("onKeyEvent", service, event))
        m.mocks["getRepeatCount"] = 1
        self.assertTrue(m.run("onKeyEvent", service, event))
        m.mocks["getAction"] = 1
        m.mocks["shouldInterceptKey"] = False
        self.assertTrue(m.run("onKeyEvent", service, event))
        self.assertEqual(m.calls.count("handleHardwareButton"), 1)
        self.assertFalse(m.run("onKeyEvent", service, event))

    def test_power_key_and_screen_broadcasts_completely_ignored(self):
        service = {}
        m = Machine(mocks={"getKeyCode": 26, "getAction": 0, "getRepeatCount": 0,
                           "shouldInterceptKey": True, "handleHardwareButton": True})
        self.assertFalse(m.run("onKeyEvent", service, {"event": True}))
        self.assertNotIn("shouldInterceptKey", m.calls)
        self.assertNotIn("handleHardwareButton", m.calls)

        for state in [1, 2]:
            m_key = Machine(mocks={"isPrefEnabled": True, "getCallState": state})
            self.assertFalse(m_key.run("shouldInterceptKey", {}, 3))
            self.assertFalse(m_key.run("handleHardwareButton", {}, 3))

        for action in ["android.intent.action.SCREEN_OFF", "android.intent.action.SCREEN_ON"]:
            m_rcvr = Machine(mocks={"getAction": action})
            m_rcvr.run("onReceive", {}, {}, {"intent": True})
            self.assertNotIn("handleHardwareButton", m_rcvr.calls)
            self.assertNotIn("getCallState", m_rcvr.calls)

    def test_mutually_exclusive_volume_buttons(self):
        prefs = {"enabled": True, "ans_vol_up": True, "ans_vol_down": True,
                 "end_vol_down": True, "end_vol_up": True}
        m = Machine(mocks={
            "isPrefEnabled": lambda ctx, k, d: prefs.get(k, d),
            "setPrefEnabled": lambda ctx, k, v: prefs.__setitem__(k, bool(v)),
        })
        m.run("sanitizeButtonPrefs", {})
        self.assertTrue(prefs["ans_vol_up"])
        self.assertFalse(prefs["ans_vol_down"])
        self.assertTrue(prefs["end_vol_down"])
        self.assertFalse(prefs["end_vol_up"])

        # Even if both were true in prefs, VolDown cannot answer when ans_vol_up is true
        raw_prefs = {"enabled": True, "ans_vol_up": True, "ans_vol_down": True,
                     "end_vol_down": False, "end_vol_up": False}
        answered = []
        m2 = Machine(mocks={
            "isPrefEnabled": lambda ctx, k, d: raw_prefs.get(k, d),
            "getCallState": 1,
            "answerCall": lambda ctx: answered.append("ans"),
            "endCall": lambda ctx: answered.append("end"),
        })
        self.assertFalse(m2.run("shouldInterceptKey", {}, 2))
        self.assertFalse(m2.run("handleHardwareButton", {}, 2))
        self.assertTrue(m2.run("shouldInterceptKey", {}, 1))
        self.assertTrue(m2.run("handleHardwareButton", {}, 1))
        self.assertEqual(answered, ["ans"])

    def test_talkback_volume_up_and_ring_mask_incoming_state(self):
        # 1. STREAM_ACCESSIBILITY (10) in VOLUME_CHANGED_ACTION must be ignored so TTS startup never auto-answers!
        triggered = []
        intents = {
            "android.media.EXTRA_VOLUME_STREAM_TYPE": 10,
            "android.media.EXTRA_VOLUME_STREAM_VALUE": 8,
            "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE": 7,
        }
        m_vol10 = Machine(fields={"callRingStartTime": 990000, "lastTtsTime": 990000}, mocks={
            "getAction": "android.media.VOLUME_CHANGED_ACTION",
            "getCallState": 1,
            "getIntExtra": lambda k, d: intents.get(k, d),
            "handleHardwareButton": lambda ctx, key: triggered.append(key) or True,
        })
        m_vol10.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(triggered, [])

        # 2. VOLUME_CHANGED_ACTION within 1500ms of callRingStartTime or 1200ms of lastTtsTime is ignored
        intents["android.media.EXTRA_VOLUME_STREAM_TYPE"] = 2
        m_early = Machine(fields={"callRingStartTime": 999500, "lastTtsTime": 990000}, mocks={
            "getAction": "android.media.VOLUME_CHANGED_ACTION",
            "getCallState": 1,
            "getIntExtra": lambda k, d: intents.get(k, d),
            "handleHardwareButton": lambda ctx, key: triggered.append(key) or True,
        })
        m_early.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(triggered, [])

        # 3. Even after both time guards, a stream change is not a hardware key.
        m_ok = Machine(fields={"callRingStartTime": 990000, "lastTtsTime": 990000}, mocks={
            "getAction": "android.media.VOLUME_CHANGED_ACTION",
            "getCallState": 1,
            "getIntExtra": lambda k, d: intents.get(k, d),
            "handleHardwareButton": lambda ctx, key: triggered.append(key) or True,
        })
        m_ok.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(triggered, [])
        self.assertNotIn("handleHardwareButton", m_ok.calls)

    def test_audio_mask_drop_never_dispatches_hardware_action(self):
        for current_mask in (0, 1, 2):
            with self.subTest(current_mask=current_mask):
                m = Machine(fields={"callRingStartTime": 990000, "ringPeakMask": 3},
                            mocks={"getCallState": 1, "getRingtoneMask": current_mask,
                                   "startRingtoneWatcher": None})
                m.run("confirmRingtoneSilenced", {})
                self.assertNotIn("handleHardwareButton", m.calls)
                self.assertNotIn("answerCall", m.calls)
                self.assertNotIn("endCall", m.calls)
                self.assertNotIn("startRingtoneWatcher", m.calls)
                self.assertNotIn("postDelayed", m.calls)
        watcher = METHODS["checkRingtoneStep"]["insns"]
        self.assertNotIn(("const/4", 2, 6), watcher)  # no mode-6 confirmation callback
        self.assertFalse(any(i[0].startswith("invoke") and i[2][1] in
                             ("getRingtoneMask", "startRingtoneWatcher") for i in watcher))
        for name in ("checkRingtoneStep", "confirmRingtoneSilenced", "onReceive"):
            calls = [i[2][1] for i in METHODS[name]["insns"] if i[0].startswith("invoke")]
            self.assertNotIn("handleHardwareButton", calls, name)

    def test_disabled_message_checkboxes_suppress_all_messages(self):
        for disabled_key in ["tts_enabled", "tts_app_sms", "tts_sms_text"]:
            prefs = {"tts_enabled": True, "tts_app_sms": True, "tts_sms_text": True}
            prefs[disabled_key] = False
            m = Machine(mocks={
                "isPrefEnabled": lambda ctx, k, d: prefs.get(k, d),
                "handleMessageNotification": lambda *a: True,
                "refreshCallStatus": None,
            })
            m.run("onNotificationPosted", {}, 0)
            self.assertNotIn("handleMessageNotification", m.calls)

    def test_per_channel_tts_rate_and_audio_stream_helpers(self):
        m = Machine()
        self.assertEqual(m.run("pctToFloat", 50), 0x3F000000)
        self.assertEqual(m.run("pctToFloat", 100), 0x3F800000)
        self.assertEqual(m.run("pctToFloat", 150), 0x3FC00000)
        self.assertEqual(m.run("pctToFloat", 200), 0x40000000)
        self.assertIn("1.5x", m.run("formatRateLabel", 150))
        self.assertIn("Мультимедиа", m.run("formatAudioModeLabel", 1))
        self.assertIn("Звонка", m.run("formatAudioModeLabel", 2))
        self.assertIn("Собственная", m.run("formatAudioModeLabel", 3))

    def test_no_auto_answer_on_volume_duck_or_ringtone_silence(self):
        # 1. Volume ducking (newVal < prevVal or newVal == 0) with AnsUp=True, EndDn=False must NOT trigger VolUp (1)!
        for new_v, prev_v in [(5, 8), (0, 8)]:
            triggered = []
            intents = {
                "android.media.EXTRA_VOLUME_STREAM_TYPE": 2,
                "android.media.EXTRA_VOLUME_STREAM_VALUE": new_v,
                "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE": prev_v,
            }
            m_vol = Machine(fields={"callRingStartTime": 990000, "lastTtsTime": 990000}, mocks={
                "getAction": "android.media.VOLUME_CHANGED_ACTION",
                "getCallState": 1,
                "getIntExtra": lambda k, d: intents.get(k, d),
                "handleHardwareButton": lambda ctx, key: triggered.append(key) or False,
            })
            m_vol.run("onReceive", {}, {}, {"intent": True})
            self.assertEqual(triggered, [])
            self.assertNotIn("handleHardwareButton", m_vol.calls)

        # 2. confirmRingtoneSilenced ignores events within first 1500ms of ringing
        m_sil = Machine(fields={"callRingStartTime": 999500}, mocks={"getCallState": 1})
        m_sil.run("confirmRingtoneSilenced", {})
        self.assertNotIn("handleHardwareButton", m_sil.calls)

        # 3. Ongoing SIM call (TelephonyManager.getCallState()==2) is never overridden by voipIncoming
        m_st = Machine(fields={"lastActionTime": 0, "voipIncoming": 1}, mocks={
            "ensureNotificationListenerBound": None,
            "refreshCallStatus": None,
            "getCallState": 2,
            "recordActiveCallState": None,
        })
        self.assertEqual(m_st.run("getCallState", {}), 2)

    def test_phone_state_broadcast_and_call_state_detection(self):
        # 1. PHONE_STATE: RINGING triggers recordActiveCallState(1), startRingtoneWatcher, announceIncomingCall
        recorded = []
        announced = []
        extra_strings = {
            "state": "RINGING",
            "incoming_number": "+992900000000",
        }
        m_ring = Machine(mocks={
            "getAction": "android.intent.action.PHONE_STATE",
            "getStringExtra": lambda k: extra_strings.get(k),
            "recordActiveCallState": lambda st: recorded.append(st),
            "startRingtoneWatcher": None,
            "announceIncomingCall": lambda ctx, pkg, num: announced.append((pkg, num)),
        })
        m_ring.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(recorded, [1])
        self.assertIn("startRingtoneWatcher", m_ring.calls)
        self.assertEqual(announced, [("sim", "+992900000000")])

        # 2. PHONE_STATE: OFFHOOK triggers recordActiveCallState(2) and stopTts
        recorded.clear()
        extra_strings["state"] = "OFFHOOK"
        m_off = Machine(mocks={
            "getAction": "android.intent.action.PHONE_STATE",
            "getStringExtra": lambda k: extra_strings.get(k),
            "recordActiveCallState": lambda st: recorded.append(st),
            "stopTts": None,
        })
        m_off.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(recorded, [2])
        self.assertIn("stopTts", m_off.calls)

        # 3. PHONE_STATE: IDLE triggers recordActiveCallState(0) and stopTts
        recorded.clear()
        extra_strings["state"] = "IDLE"
        m_idle = Machine(mocks={
            "getAction": "android.intent.action.PHONE_STATE",
            "getStringExtra": lambda k: extra_strings.get(k),
            "recordActiveCallState": lambda st: recorded.append(st),
            "stopTts": None,
        })
        m_idle.run("onReceive", {}, {}, {"intent": True})
        self.assertEqual(recorded, [0])
        self.assertIn("stopTts", m_idle.calls)

        # 4. getCallState detects Answer button in UI when TelecomManager.isInCall() is true (even if TelephonyManager returns 0)
        m_ui_inc = Machine(fields={"lastActionTime": 0, "voipIncoming": 0, "simRinging": 0}, mocks={
            "ensureNotificationListenerBound": None,
            "refreshCallStatus": None,
            "getCallState": 0,
            "getRingtoneMask": 2,
            "isInCall": 1,
            "detectCallUiState": 1,
            "recordActiveCallState": None,
        })
        self.assertEqual(m_ui_inc.run("getCallState", {}), 1)

        # 5. getCallState detects ringtone playback configuration (mask & 4 != 0) when UI is not scanned yet
        m_mask_inc = Machine(fields={"lastActionTime": 0, "voipIncoming": 0, "simRinging": 0}, mocks={
            "ensureNotificationListenerBound": None,
            "refreshCallStatus": None,
            "getCallState": 0,
            "getRingtoneMask": 6,
            "recordActiveCallState": None,
        })
        self.assertEqual(m_mask_inc.run("getCallState", {}), 1)

        # 6. getCallState detects End button in UI (detectCallUiState==2) when isInCall() is true
        m_ui_ong = Machine(fields={"lastActionTime": 0, "voipIncoming": 0, "simRinging": 0}, mocks={
            "ensureNotificationListenerBound": None,
            "refreshCallStatus": None,
            "getCallState": 0,
            "getRingtoneMask": 2,
            "isInCall": 1,
            "detectCallUiState": 2,
            "recordActiveCallState": None,
        })
        self.assertEqual(m_ui_ong.run("getCallState", {}), 2)

        # 7. getCallState returns 0 (IDLE) when listening to WhatsApp voice message (AudioManager mode==3, voipOngoing==0)
        m_wa_voice = Machine(fields={"lastActionTime": 0, "voipIncoming": 0, "voipOngoing": 0, "simRinging": 0}, mocks={
            "ensureNotificationListenerBound": None,
            "refreshCallStatus": None,
            "getCallState": 0,
            "getRingtoneMask": 2,
            "isInCall": 0,
            "getMode": 3,
        })
        self.assertEqual(m_wa_voice.run("getCallState", {}), 0)

    def test_whatsapp_group_and_media_notifications_ignored(self):
        # 1. matchesNode rejects com.whatsapp when voipIncoming=0 and voipOngoing=0 (even if text is 'Ответить')
        m_wa_node = Machine(fields={"voipIncoming": 0, "voipOngoing": 0}, mocks={
            "getPackageName": "com.whatsapp",
            "getText": "Ответить",
        })
        self.assertEqual(m_wa_node.run("matchesNode", {}, 1), 0)

        # 2. matchesNode accepts com.google.android.dialer when text is 'Ответить'
        m_dial_node = Machine(fields={"voipIncoming": 0, "voipOngoing": 0}, mocks={
            "getPackageName": "com.google.android.dialer",
            "getText": "Ответить",
            "isPositiveText": 1,
        })
        self.assertEqual(m_dial_node.run("matchesNode", {}, 1), 1)

        # 3. findCallerNodeRec rejects com.whatsapp group title ('Sitoraboron') so it is never read as SIM call
        m_wa_caller = Machine(mocks={
            "getPackageName": "com.whatsapp",
            "getText": "Sitoraboron",
        })
        self.assertEqual(m_wa_caller.run("findCallerNodeRec", {}), 0)

        # 4. isMediaOrOngoingNotification filters out voice message / music notifications
        # 4a: FLAG_ONGOING_EVENT (0x02) -> True (filtered)
        m_ongoing = Machine(mocks={
            "getNotification": {"category": "msg", "flags": 2, "extras": {}, "actions": None},
        })
        self.assertEqual(m_ongoing.run("isMediaOrOngoingNotification", {}), 1)

        # 4b: android.mediaSession present -> True (filtered)
        m_session = Machine(mocks={
            "getNotification": {"category": "msg", "flags": 0, "extras": {"android.mediaSession": True}, "actions": None},
        })
        self.assertEqual(m_session.run("isMediaOrOngoingNotification", {}), 1)

        # 4c: Pause action button on notification -> True (filtered)
        m_pause = Machine(mocks={
            "getNotification": {"category": "msg", "flags": 0, "extras": {}, "actions": [{"title": "Пауза"}]},
        })
        self.assertEqual(m_pause.run("isMediaOrOngoingNotification", {}), 1)

        # 4d: Voice message text ('🎤 Голосовое сообщение (0:47)') -> True (filtered)
        m_voice_txt = Machine(mocks={
            "getNotification": {"category": "msg", "flags": 16, "extras": {"android.title": "Фируз", "android.text": "🎤 Голосовое сообщение (0:47)"}, "actions": None},
        })
        self.assertEqual(m_voice_txt.run("isMediaOrOngoingNotification", {}), 1)

        # 4e: Real incoming WhatsApp message notification -> False (allowed!)
        m_real = Machine(fields={"voipOngoing": 0, "instance": {}}, mocks={
            "getNotification": {"category": "msg", "flags": 16, "extras": {"android.title": "Иван", "android.text": "Привет!"}, "actions": [{"title": "Ответить"}]},
            "getMode": 0,
        })
        self.assertEqual(m_real.run("isMediaOrOngoingNotification", {}), 0)

    def test_proximity_sensor_requires_far_then_near_and_ignores_accelerometer(self):
        # 1. Accelerometer (type 1) never triggers answerCall
        m_acc = Machine(fields={"lastCallState": 1, "callRingStartTime": 990000, "proxRegTime": 990000, "proxSawFar": 1}, mocks={
            "getType": 1,
            "answerCall": None,
        })
        m_acc.run("onSensorChanged", {"context": {}}, {"sensor": {}, "values": [0, 9, 0]})
        self.assertNotIn("answerCall", m_acc.calls)

        # 2. Proximity NEAR (0) without prior FAR (proxSawFar==0) never triggers answerCall
        m_no_far = Machine(fields={"lastCallState": 1, "callRingStartTime": 990000, "proxRegTime": 990000, "proxSawFar": 0}, mocks={
            "getType": 8,
            "answerCall": None,
        })
        m_no_far.run("onSensorChanged", {"context": {}}, {"sensor": {}, "values": [0]})
        self.assertNotIn("answerCall", m_no_far.calls)

        # 3. Proximity FAR (5) sets proxSawFar=1, and subsequent NEAR (0) after 1200ms ringing and 800ms reg triggers answerCall
        m_prox = Machine(fields={"lastCallState": 1, "callRingStartTime": 990000, "proxRegTime": 990000, "proxSawFar": 0}, mocks={
            "getType": 8,
            "unregisterProximitySensor": None,
            "answerCall": None,
        })
        m_prox.run("onSensorChanged", {"context": {}}, {"sensor": {}, "values": [5]})
        self.assertEqual(m_prox.fields["proxSawFar"], 1)
        m_prox.run("onSensorChanged", {"context": {}}, {"sensor": {}, "values": [0]})
        self.assertIn("answerCall", m_prox.calls)

        # 4. checkDelayedCaller aborts within 4500ms after answerCall (lastActionTime)
        m_dc = Machine(fields={"lastActionTime": 998000}, mocks={
            "getCallState": 1,
            "findActiveCallTitle": "Махина",
            "announceIncomingCall": None,
        })
        m_dc.run("checkDelayedCaller", {})
        self.assertNotIn("announceIncomingCall", m_dc.calls)

    def test_wrong_signing_identity_rejected(self):
        import tempfile
        from pathlib import Path
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from build_release import check_identity, ROOT
        with tempfile.TemporaryDirectory() as directory:
            key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
            path = Path(directory) / "wrong-key.pem"
            path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
                                              serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
            with self.assertRaisesRegex(ValueError, "Закрытый ключ"):
                check_identity(path, ROOT / "previous_signing_certificate.pem")


if __name__ == "__main__":
    unittest.main(verbosity=2)
