#!/usr/bin/env python3
"""
Clean, spec-compliant Dalvik Executable (DEX 035) Assembler & Verifier.
Strictly follows AOSP art/libdexfile/dex/dex_file_verifier.cc section alignment rules.
"""
import hashlib
import struct
import zlib


def uleb128(val: int) -> bytes:
    if val < 0:
        raise ValueError(f"uleb128 requires non-negative int, got {val}")
    out = bytearray()
    while True:
        byte = val & 0x7F
        val >>= 7
        if val != 0:
            out.append(byte | 0x80)
        else:
            out.append(byte)
            break
    return bytes(out)


def sleb128(val: int) -> bytes:
    out = bytearray()
    more = True
    while more:
        byte = val & 0x7F
        val >>= 7
        if (val == 0 and (byte & 0x40) == 0) or (val == -1 and (byte & 0x40) != 0):
            more = False
        else:
            byte |= 0x80
        out.append(byte)
    return bytes(out)


def encode_mutf8(s: str) -> tuple[int, bytes]:
    u16 = s.encode("utf-16le")
    utf16_len = len(u16) // 2
    out = bytearray()
    for i in range(utf16_len):
        cu = struct.unpack_from("<H", u16, i * 2)[0]
        if cu == 0:
            out.extend(b"\xc0\x80")
        elif cu < 0x80:
            out.append(cu)
        elif cu < 0x800:
            out.append(0xC0 | (cu >> 6))
            out.append(0x80 | (cu & 0x3F))
        else:
            out.append(0xE0 | (cu >> 12))
            out.append(0x80 | ((cu >> 6) & 0x3F))
            out.append(0x80 | (cu & 0x3F))
    return utf16_len, bytes(out)


def shorty_for_type(t: str) -> str:
    if t.startswith("[") or t.startswith("L"):
        return "L"
    return t


class DexBuilder:
    def __init__(self):
        self.strings = set()
        self.types = set()
        self.protos = set()
        self.fields = set()
        self.methods = set()
        self.classes = []

    def add_string(self, s: str):
        self.strings.add(s)

    def add_type(self, t: str):
        self.types.add(t)
        self.add_string(t)

    def add_proto(self, ret_type: str, param_types: tuple[str, ...] = ()):
        param_types = tuple(param_types)
        self.add_type(ret_type)
        for pt in param_types:
            self.add_type(pt)
        shorty = shorty_for_type(ret_type) + "".join(shorty_for_type(pt) for pt in param_types)
        self.add_string(shorty)
        self.protos.add((ret_type, param_types))
        return (ret_type, param_types)

    def add_field(self, cls: str, name: str, ftype: str):
        self.add_type(cls)
        self.add_string(name)
        self.add_type(ftype)
        self.fields.add((cls, name, ftype))
        return (cls, name, ftype)

    def add_method(self, cls: str, name: str, ret_type: str, param_types: list[str] | tuple[str, ...] = ()):
        proto = self.add_proto(ret_type, tuple(param_types))
        self.add_type(cls)
        self.add_string(name)
        m = (cls, name, proto)
        self.methods.add(m)
        return m

    def add_class(
        self,
        cls_type: str,
        super_type: str = "Ljava/lang/Object;",
        access_flags: int = 0x0001,
        interfaces: tuple[str, ...] = (),
        static_fields: list[tuple[tuple, int]] = None,
        instance_fields: list[tuple[tuple, int]] = None,
        direct_methods: list[tuple[tuple, int, dict]] = None,
        virtual_methods: list[tuple[tuple, int, dict]] = None,
    ):
        self.add_type(cls_type)
        self.add_type(super_type)
        for iface in interfaces:
            self.add_type(iface)
        self.classes.append({
            "cls_type": cls_type,
            "super_type": super_type,
            "access_flags": access_flags,
            "interfaces": tuple(interfaces),
            "static_fields": static_fields or [],
            "instance_fields": instance_fields or [],
            "direct_methods": direct_methods or [],
            "virtual_methods": virtual_methods or [],
        })

    def compile(self) -> bytes:
        for c in self.classes:
            for f_ref, _ in c["static_fields"] + c["instance_fields"]:
                self.add_field(*f_ref)
            for m_ref, _, code in c["direct_methods"] + c["virtual_methods"]:
                self.add_method(m_ref[0], m_ref[1], m_ref[2][0], m_ref[2][1])
                if code:
                    for ins in code["insns"]:
                        op = ins[0]
                        if op == "const-string":
                            self.add_string(ins[2])
                        elif op in ("const-class", "check-cast", "new-instance", "new-array", "filled-new-array"):
                            self.add_type(ins[-1])
                        elif op.startswith("iget") or op.startswith("iput") or op.startswith("sget") or op.startswith("sput"):
                            self.add_field(*ins[-1])
                        elif op.startswith("invoke-"):
                            m = ins[-1]
                            self.add_method(m[0], m[1], m[2][0], m[2][1])
                    for t in code.get("tries", []):
                        if t.get("catch_type"):
                            self.add_type(t["catch_type"])

        sorted_strings = sorted(self.strings, key=lambda s: encode_mutf8(s)[1])
        str_idx = {s: i for i, s in enumerate(sorted_strings)}

        sorted_types = sorted(self.types, key=lambda t: str_idx[t])
        type_idx = {t: i for i, t in enumerate(sorted_types)}

        sorted_protos = sorted(
            self.protos,
            key=lambda p: (type_idx[p[0]], tuple(type_idx[pt] for pt in p[1]))
        )
        proto_idx = {p: i for i, p in enumerate(sorted_protos)}

        sorted_fields = sorted(
            self.fields,
            key=lambda f: (type_idx[f[0]], str_idx[f[1]], type_idx[f[2]])
        )
        field_idx = {f: i for i, f in enumerate(sorted_fields)}

        sorted_methods = sorted(
            self.methods,
            key=lambda m: (type_idx[m[0]], str_idx[m[1]], proto_idx[m[2]])
        )
        method_idx = {m: i for i, m in enumerate(sorted_methods)}

        def assemble_code(code_spec: dict) -> bytes:
            regs = code_spec["registers"]
            ins_count = code_spec["ins"]
            outs_count = code_spec["outs"]
            insns = code_spec["insns"]
            tries_spec = code_spec.get("tries", [])

            labels = {}
            cu_offset = 0
            for item in insns:
                if item[0] == "label":
                    labels[item[1]] = cu_offset
                else:
                    cu_offset += self._insn_size_cu(item[0])

            raw_insns = bytearray()
            cur_cu = 0
            for item in insns:
                op = item[0]
                if op == "label":
                    continue
                encoded = self._encode_insn(item, cur_cu, labels, str_idx, type_idx, field_idx, method_idx)
                assert len(encoded) == self._insn_size_cu(op) * 2
                raw_insns.extend(encoded)
                cur_cu += self._insn_size_cu(op)

            insns_size_cu = cur_cu
            tries_size = len(tries_spec)

            header = struct.pack(
                "<HHHHII",
                regs,
                ins_count,
                outs_count,
                tries_size,
                0,
                insns_size_cu,
            )

            if tries_size == 0:
                return header + bytes(raw_insns)

            padding = b"\x00\x00" if (insns_size_cu % 2 == 1) else b""

            handlers_list = []
            handler_key_to_idx = {}
            for t in tries_spec:
                key = (t.get("catch_type"), t["handler_label"])
                if key not in handler_key_to_idx:
                    handler_key_to_idx[key] = len(handlers_list)
                    handlers_list.append(key)

            handlers_buf = bytearray(uleb128(len(handlers_list)))
            handler_byte_offsets = {}
            for idx, (c_type, h_label) in enumerate(handlers_list):
                handler_byte_offsets[idx] = len(handlers_buf)
                h_addr = labels[h_label]
                if c_type is None:
                    handlers_buf.extend(sleb128(0))
                    handlers_buf.extend(uleb128(h_addr))
                else:
                    handlers_buf.extend(sleb128(1))
                    handlers_buf.extend(uleb128(type_idx[c_type]))
                    handlers_buf.extend(uleb128(h_addr))

            try_items_buf = bytearray()
            for t in tries_spec:
                start_cu = labels[t["start_label"]]
                end_cu = labels[t["end_label"]]
                insn_count = end_cu - start_cu
                assert insn_count > 0
                key = (t.get("catch_type"), t["handler_label"])
                h_off = handler_byte_offsets[handler_key_to_idx[key]]
                try_items_buf.extend(struct.pack("<IHH", start_cu, insn_count, h_off))

            return header + bytes(raw_insns) + padding + bytes(try_items_buf) + bytes(handlers_buf)

        num_strings = len(sorted_strings)
        num_types = len(sorted_types)
        num_protos = len(sorted_protos)
        num_fields = len(sorted_fields)
        num_methods = len(sorted_methods)
        num_classes = len(self.classes)

        header_off = 0
        header_size = 112
        string_ids_off = header_size
        type_ids_off = string_ids_off + num_strings * 4
        proto_ids_off = type_ids_off + num_types * 4
        field_ids_off = proto_ids_off + num_protos * 12
        method_ids_off = field_ids_off + num_fields * 8
        class_defs_off = method_ids_off + num_methods * 8
        data_off = class_defs_off + num_classes * 32

        data_buf = bytearray()

        def align_data_4():
            rem = (data_off + len(data_buf)) % 4
            if rem:
                data_buf.extend(b"\x00" * (4 - rem))

        # Section A in data: type_list items (4-byte aligned before each item, NO trailing align_data_4)
        type_lists_needed = []
        type_list_set = set()
        for p in sorted_protos:
            if p[1] and p[1] not in type_list_set:
                type_list_set.add(p[1])
                type_lists_needed.append(p[1])
        for c in self.classes:
            if c["interfaces"] and c["interfaces"] not in type_list_set:
                type_list_set.add(c["interfaces"])
                type_lists_needed.append(c["interfaces"])

        type_list_off_map = {}
        type_lists_section_off = 0
        for idx_tl, tl in enumerate(type_lists_needed):
            align_data_4()
            if idx_tl == 0:
                type_lists_section_off = data_off + len(data_buf)
            type_list_off_map[tl] = data_off + len(data_buf)
            data_buf.extend(struct.pack("<I", len(tl)))
            for t in tl:
                data_buf.extend(struct.pack("<H", type_idx[t]))

        # Section B in data: code_item items (4-byte aligned before each item, NO trailing align_data_4
        # because the following section 0x2002 string_data_item is 1-byte aligned in DexFileVerifier!)
        code_items_section_off = 0
        num_code_items = 0
        method_code_off = {}
        for c in self.classes:
            dm = sorted(c["direct_methods"], key=lambda x: method_idx[x[0]])
            vm = sorted(c["virtual_methods"], key=lambda x: method_idx[x[0]])
            for m_ref, access, code in dm + vm:
                if code is not None:
                    align_data_4()
                    if num_code_items == 0:
                        code_items_section_off = data_off + len(data_buf)
                    num_code_items += 1
                    method_code_off[(c["cls_type"], m_ref)] = data_off + len(data_buf)
                    data_buf.extend(assemble_code(code))

        # Section C in data: string_data_item items (1-byte aligned — starts immediately!)
        string_data_section_off = data_off + len(data_buf)
        string_data_offsets = []
        for s in sorted_strings:
            string_data_offsets.append(data_off + len(data_buf))
            u16_len, mutf8_bytes = encode_mutf8(s)
            data_buf.extend(uleb128(u16_len))
            data_buf.extend(mutf8_bytes)
            data_buf.append(0)

        # Section D in data: class_data_item items (1-byte aligned — starts immediately!)
        class_data_section_off = data_off + len(data_buf)
        class_data_offsets = []
        for c in self.classes:
            class_data_offsets.append(data_off + len(data_buf))
            sf = sorted(c["static_fields"], key=lambda x: field_idx[x[0]])
            inf = sorted(c["instance_fields"], key=lambda x: field_idx[x[0]])
            dm = sorted(c["direct_methods"], key=lambda x: method_idx[x[0]])
            vm = sorted(c["virtual_methods"], key=lambda x: method_idx[x[0]])

            data_buf.extend(uleb128(len(sf)))
            data_buf.extend(uleb128(len(inf)))
            data_buf.extend(uleb128(len(dm)))
            data_buf.extend(uleb128(len(vm)))

            prev = 0
            for f_ref, acc in sf:
                idx = field_idx[f_ref]
                data_buf.extend(uleb128(idx - prev))
                data_buf.extend(uleb128(acc))
                prev = idx

            prev = 0
            for f_ref, acc in inf:
                idx = field_idx[f_ref]
                data_buf.extend(uleb128(idx - prev))
                data_buf.extend(uleb128(acc))
                prev = idx

            prev = 0
            for m_ref, acc, code in dm:
                idx = method_idx[m_ref]
                c_off = method_code_off.get((c["cls_type"], m_ref), 0)
                data_buf.extend(uleb128(idx - prev))
                data_buf.extend(uleb128(acc))
                data_buf.extend(uleb128(c_off))
                prev = idx

            prev = 0
            for m_ref, acc, code in vm:
                idx = method_idx[m_ref]
                c_off = method_code_off.get((c["cls_type"], m_ref), 0)
                data_buf.extend(uleb128(idx - prev))
                data_buf.extend(uleb128(acc))
                data_buf.extend(uleb128(c_off))
                prev = idx

        # Section E in data: map_list (4-byte aligned)
        align_data_4()
        map_off = data_off + len(data_buf)

        map_entries = [
            (0x0000, 1, header_off),
            (0x0001, num_strings, string_ids_off),
            (0x0002, num_types, type_ids_off),
            (0x0003, num_protos, proto_ids_off),
            (0x0004, num_fields, field_ids_off),
            (0x0005, num_methods, method_ids_off),
            (0x0006, num_classes, class_defs_off),
        ]
        if type_lists_needed:
            map_entries.append((0x1001, len(type_lists_needed), type_lists_section_off))
        if num_code_items > 0:
            map_entries.append((0x2001, num_code_items, code_items_section_off))
        map_entries.append((0x2002, num_strings, string_data_section_off))
        map_entries.append((0x2000, num_classes, class_data_section_off))
        map_entries.append((0x1000, 1, map_off))

        data_buf.extend(struct.pack("<I", len(map_entries)))
        for m_type, m_size, m_offset in map_entries:
            data_buf.extend(struct.pack("<HHII", m_type, 0, m_size, m_offset))

        align_data_4()
        data_size = len(data_buf)
        file_size = data_off + data_size

        string_ids_buf = b"".join(struct.pack("<I", off) for off in string_data_offsets)
        type_ids_buf = b"".join(struct.pack("<I", str_idx[t]) for t in sorted_types)

        proto_ids_buf = bytearray()
        for ret_t, params in sorted_protos:
            shorty = shorty_for_type(ret_t) + "".join(shorty_for_type(pt) for pt in params)
            p_off = type_list_off_map[params] if params else 0
            proto_ids_buf.extend(struct.pack("<III", str_idx[shorty], type_idx[ret_t], p_off))

        field_ids_buf = bytearray()
        for cls_t, name, ft in sorted_fields:
            field_ids_buf.extend(struct.pack("<HHI", type_idx[cls_t], type_idx[ft], str_idx[name]))

        method_ids_buf = bytearray()
        for cls_t, name, proto in sorted_methods:
            method_ids_buf.extend(struct.pack("<HHI", type_idx[cls_t], proto_idx[proto], str_idx[name]))

        class_defs_buf = bytearray()
        for idx, c in enumerate(self.classes):
            if_off = type_list_off_map[c["interfaces"]] if c["interfaces"] else 0
            class_defs_buf.extend(
                struct.pack(
                    "<IIIIIIII",
                    type_idx[c["cls_type"]],
                    c["access_flags"],
                    type_idx[c["super_type"]],
                    if_off,
                    0xFFFFFFFF,
                    0,
                    class_data_offsets[idx],
                    0,
                )
            )

        header_prefix = b"dex\n035\x00"
        header_tail = struct.pack(
            "<IIIIIIIIIIIIIIIIIIII",
            file_size,
            112,
            0x12345678,
            0,
            0,
            map_off,
            num_strings,
            string_ids_off,
            num_types,
            type_ids_off,
            num_protos,
            proto_ids_off,
            num_fields,
            field_ids_off,
            num_methods,
            method_ids_off,
            num_classes,
            class_defs_off,
            data_size,
            data_off,
        )

        body_after_sig = (
            header_tail
            + string_ids_buf
            + type_ids_buf
            + bytes(proto_ids_buf)
            + bytes(field_ids_buf)
            + bytes(method_ids_buf)
            + bytes(class_defs_buf)
            + bytes(data_buf)
        )
        sha1_digest = hashlib.sha1(body_after_sig).digest()
        adler_val = zlib.adler32(sha1_digest + body_after_sig) & 0xFFFFFFFF

        full_dex = header_prefix + struct.pack("<I", adler_val) + sha1_digest + body_after_sig
        assert len(full_dex) == file_size
        return full_dex

    def _insn_size_cu(self, op: str) -> int:
        if op in (
            "nop", "move", "move-object", "move-result", "move-result-wide",
            "move-result-object", "move-exception", "return-void", "return",
            "return-object", "const/4", "array-length", "and-int/2addr", "or-int/2addr", "sub-long/2addr", "rem-long/2addr", "int-to-long", "int-to-float", "float-to-int",
            "move-wide", "monitor-enter", "monitor-exit", "throw", "goto",
            "sub-int/2addr", "add-long/2addr"
        ):
            return 1
        if op in (
            "const/16", "const-wide/16", "const-string", "const-class",
            "check-cast", "new-instance", "new-array", "goto/16",
            "if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le",
            "if-eqz", "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez",
            "aget", "aget-object", "aput-object",
            "iget", "iget-object", "iget-boolean",
            "iput", "iput-object", "iput-boolean",
            "sget", "sget-wide", "sget-object", "sget-boolean",
            "sput", "sput-wide", "sput-object", "sput-boolean",
            "add-int/lit8", "and-int/lit8", "cmp-long",
            "move/from16", "move-object/from16", "aget-boolean", "aput-boolean",
            "iget-wide", "iput-wide", "and-int/lit16", "mul-int/lit8", "xor-int/lit8"
        ):
            return 2
        if op in (
            "const", "invoke-virtual", "invoke-super", "invoke-direct",
            "invoke-static", "invoke-interface",
            "invoke-virtual/range", "invoke-super/range", "invoke-direct/range",
            "invoke-static/range", "invoke-interface/range",
            "const-wide/32", "filled-new-array"
        ):
            return 3
        raise ValueError(f"Unknown opcode: {op}")

    def _encode_insn(self, item, cur_cu, labels, str_idx, type_idx, field_idx, method_idx) -> bytes:
        op = item[0]
        if op == "nop":
            return b"\x00\x00"
        if op == "return-void":
            return b"\x0e\x00"
        if op in ("move-result", "move-result-wide", "move-result-object", "move-exception", "return", "return-object", "monitor-enter", "monitor-exit", "throw"):
            opc = {
                "move-result": 0x0A,
                "move-result-wide": 0x0B,
                "move-result-object": 0x0C,
                "move-exception": 0x0D,
                "return": 0x0F,
                "return-object": 0x11,
                "monitor-enter": 0x1D,
                "monitor-exit": 0x1E,
                "throw": 0x27,
            }[op]
            return struct.pack("<BB", opc, item[1])
        if op in ("move", "move-object", "array-length", "and-int/2addr", "or-int/2addr", "sub-long/2addr", "rem-long/2addr", "int-to-long", "int-to-float", "float-to-int", "move-wide", "sub-int/2addr", "add-long/2addr"):
            opc = {
                "move": 0x01,
                "move-object": 0x07,
                "array-length": 0x21,
                "and-int/2addr": 0xB5,
                "or-int/2addr": 0xB6,
                "sub-long/2addr": 0xBC,
                "rem-long/2addr": 0xBF,
                "int-to-long": 0x81,
                "int-to-float": 0x82,
                "float-to-int": 0x87,
                "move-wide": 0x04,
                "sub-int/2addr": 0xB1,
                "add-long/2addr": 0xBB,
            }[op]
            va, vb = item[1], item[2]
            assert 0 <= va <= 15 and 0 <= vb <= 15
            return struct.pack("<BB", opc, (vb << 4) | va)
        if op == "const/4":
            va, val = item[1], item[2]
            assert 0 <= va <= 15 and -8 <= val <= 7
            return struct.pack("<BB", 0x12, ((val & 0xF) << 4) | va)
        if op in ("const/16", "const-wide/16"):
            opc = 0x13 if op == "const/16" else 0x16
            va, val = item[1], item[2]
            return struct.pack("<BBh", opc, va, val)
        if op == "const":
            va, val = item[1], item[2]
            return struct.pack("<BBI", 0x14, va, val & 0xFFFFFFFF)
        if op == "const-string":
            va, s = item[1], item[2]
            return struct.pack("<BBH", 0x1A, va, str_idx[s])
        if op in ("const-class", "check-cast", "new-instance"):
            opc = {"const-class": 0x1C, "check-cast": 0x1F, "new-instance": 0x22}[op]
            va, t = item[1], item[2]
            return struct.pack("<BBH", opc, va, type_idx[t])
        if op == "new-array":
            va, vb, t = item[1], item[2], item[3]
            assert 0 <= va <= 15 and 0 <= vb <= 15
            return struct.pack("<BBH", 0x23, (vb << 4) | va, type_idx[t])
        if op == "goto/16":
            target = labels[item[1]]
            rel = target - cur_cu
            assert rel != 0
            return struct.pack("<BBh", 0x29, 0, rel)
        if op in ("if-eqz", "if-nez", "if-ltz", "if-gez", "if-gtz", "if-lez"):
            opc = {
                "if-eqz": 0x38, "if-nez": 0x39, "if-ltz": 0x3A,
                "if-gez": 0x3B, "if-gtz": 0x3C, "if-lez": 0x3D,
            }[op]
            va, lbl = item[1], item[2]
            rel = labels[lbl] - cur_cu
            return struct.pack("<BBh", opc, va, rel)
        if op in ("if-eq", "if-ne", "if-lt", "if-ge", "if-gt", "if-le"):
            opc = {
                "if-eq": 0x32, "if-ne": 0x33, "if-lt": 0x34,
                "if-ge": 0x35, "if-gt": 0x36, "if-le": 0x37,
            }[op]
            va, vb, lbl = item[1], item[2], item[3]
            assert 0 <= va <= 15 and 0 <= vb <= 15
            rel = labels[lbl] - cur_cu
            return struct.pack("<BBh", opc, (vb << 4) | va, rel)
        if op in ("aget", "aget-object", "aget-boolean", "aput-object", "aput-boolean", "cmp-long"):
            opc = {"aget": 0x44, "aget-object": 0x46, "aget-boolean": 0x47, "aput-object": 0x4D, "aput-boolean": 0x4E, "cmp-long": 0x31}[op]
            return struct.pack("<BBBB", opc, item[1], item[2], item[3])
        if op in ("add-int/lit8", "and-int/lit8"):
            opc = 0xD8 if op == "add-int/lit8" else 0xDD
            return struct.pack("<BBBb", opc, item[1], item[2], item[3])
        if op in ("iget", "iget-wide", "iget-object", "iget-boolean", "iput", "iput-wide", "iput-object", "iput-boolean"):
            opc = {
                "iget": 0x52, "iget-wide": 0x53, "iget-object": 0x54, "iget-boolean": 0x55,
                "iput": 0x59, "iput-wide": 0x5A, "iput-object": 0x5B, "iput-boolean": 0x5C,
            }[op]
            va, vb, f_ref = item[1], item[2], item[3]
            assert 0 <= va <= 15 and 0 <= vb <= 15
            return struct.pack("<BBH", opc, (vb << 4) | va, field_idx[f_ref])
        if op in ("sget", "sget-wide", "sget-object", "sget-boolean", "sput", "sput-wide", "sput-object", "sput-boolean"):
            opc = {
                "sget": 0x60, "sget-wide": 0x61, "sget-object": 0x62, "sget-boolean": 0x63,
                "sput": 0x67, "sput-wide": 0x68, "sput-object": 0x69, "sput-boolean": 0x6A,
            }[op]
            va, f_ref = item[1], item[2]
            return struct.pack("<BBH", opc, va, field_idx[f_ref])
        if op in ("invoke-virtual", "invoke-super", "invoke-direct", "invoke-static", "invoke-interface"):
            opc = {
                "invoke-virtual": 0x6E,
                "invoke-super": 0x6F,
                "invoke-direct": 0x70,
                "invoke-static": 0x71,
                "invoke-interface": 0x72,
            }[op]
            reg_list, m_ref = item[1], item[2]
            cnt = len(reg_list)
            assert 0 <= cnt <= 5
            for r in reg_list:
                assert 0 <= r <= 15
            regs_padded = list(reg_list) + [0] * (5 - cnt)
            c, d, e, f, g = regs_padded
            b1 = (cnt << 4) | g
            b4 = (d << 4) | c
            b5 = (f << 4) | e
            return struct.pack("<BBHBB", opc, b1, method_idx[m_ref], b4, b5)
        if op in ("invoke-virtual/range", "invoke-super/range", "invoke-direct/range", "invoke-static/range", "invoke-interface/range"):
            opc = {
                "invoke-virtual/range": 0x74,
                "invoke-super/range": 0x75,
                "invoke-direct/range": 0x76,
                "invoke-static/range": 0x77,
                "invoke-interface/range": 0x78,
            }[op]
            reg_list, m_ref = item[1], item[2]
            cnt = len(reg_list)
            assert cnt >= 1
            for idx_r in range(cnt - 1):
                assert reg_list[idx_r + 1] == reg_list[idx_r] + 1, f"Non-contiguous range registers: {reg_list}"
            return struct.pack("<BBHH", opc, cnt, method_idx[m_ref], reg_list[0])
        if op in ("move/from16", "move-object/from16"):
            opc = 0x02 if op == "move/from16" else 0x08
            return struct.pack("<BBH", opc, item[1], item[2])
        if op == "const-wide/32":
            return struct.pack("<BBI", 0x17, item[1], item[2] & 0xFFFFFFFF)
        if op == "goto":
            target = labels[item[1]]
            rel = target - cur_cu
            assert -128 <= rel <= 127 and rel != 0, f"goto out of 8-bit range: {rel}"
            return struct.pack("<Bb", 0x28, rel)
        if op == "filled-new-array":
            reg_list, t = item[1], item[2]
            cnt = len(reg_list)
            assert 0 <= cnt <= 5
            regs_padded = list(reg_list) + [0] * (5 - cnt)
            c, d, e, f, g = regs_padded
            b1 = (cnt << 4) | g
            b4 = (d << 4) | c
            b5 = (f << 4) | e
            return struct.pack("<BBHBB", 0x24, b1, type_idx[t], b4, b5)
        if op == "and-int/lit16":
            va, vb, lit = item[1], item[2], item[3]
            assert 0 <= va <= 15 and 0 <= vb <= 15
            return struct.pack("<BBh", 0xD5, (vb << 4) | va, lit)
        if op in ("mul-int/lit8", "xor-int/lit8"):
            opc = 0xDA if op == "mul-int/lit8" else 0xDF
            return struct.pack("<BBBb", opc, item[1], item[2], item[3])
        raise ValueError(f"Unhandled instruction: {item}")
