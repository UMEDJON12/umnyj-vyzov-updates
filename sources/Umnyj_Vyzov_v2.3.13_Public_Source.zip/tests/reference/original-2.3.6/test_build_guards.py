import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import build_release


class FeatureBuildGuards(unittest.TestCase):
    def test_modified_java_never_silently_uses_assembler(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'assets').mkdir()
            (root / 'java').mkdir()
            (root / 'assets/features.dex').write_bytes(b'dex')
            (root / 'java/Feature.java').write_bytes(b'modified')
            meta = {'dex_sha256': hashlib.sha256(b'dex').hexdigest(),
                    'sources': {'java/Feature.java': hashlib.sha256(b'original').hexdigest()}}
            (root / 'assets/features-build.json').write_text(json.dumps(meta))
            with patch.object(build_release, 'ROOT', root), \
                 patch.object(build_release, 'update_features_dex_file') as assemble:
                with self.assertRaisesRegex(RuntimeError, 'НЕ компилирует'):
                    build_release.ensure_features_dex()
                assemble.assert_not_called()

    def test_force_rebuild_cannot_hide_logic_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(build_release, 'ROOT', Path(directory)), \
                 patch.object(build_release, 'update_features_dex_file') as assemble:
                with self.assertRaisesRegex(RuntimeError, 'отключена'):
                    build_release.ensure_features_dex(force_rebuild=True)
                assemble.assert_not_called()


if __name__ == '__main__':
    unittest.main()
