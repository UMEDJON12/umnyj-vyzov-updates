#!/usr/bin/env python3
"""
APK Packager (with 4-byte zipalign) + Dual Signer:
- JAR Signature Scheme v1 (META-INF/MANIFEST.MF, CERT.SF, CERT.RSA via PKCS7SignatureBuilder)
- APK Signature Scheme v2 (APK Sig Block 42, ID 0x7109871a, RSA-2048 PKCS#1 v1.5 with SHA-256)
Minimum Android 7.0 (API 24), target SDK 28. OEM/device validation is required.
"""
import base64
import hashlib
import struct
import zlib
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import pkcs7


def lp(data: bytes) -> bytes:
    return struct.pack("<I", len(data)) + data


def make_v1_signature_files(
    entries: list[tuple[str, bytes, bool]],
    key_pem_path: str,
    cert_pem_path: str,
) -> list[tuple[str, bytes, bool]]:
    with open(key_pem_path, "rb") as f:
        priv_key = serialization.load_pem_private_key(f.read(), password=None)
    with open(cert_pem_path, "rb") as f:
        cert_obj = x509.load_pem_x509_certificate(f.read())

    manifest_lines = [
        "Manifest-Version: 1.0",
        "Created-By: 1.0 (Android)",
        "",
    ]
    sf_entry_blocks = []

    for name, raw_bytes, _ in entries:
        sha256_b64 = base64.b64encode(hashlib.sha256(raw_bytes).digest()).decode("ascii")
        entry_chunk = f"Name: {name}\r\nSHA-256-Digest: {sha256_b64}\r\n\r\n"
        manifest_lines.append(f"Name: {name}")
        manifest_lines.append(f"SHA-256-Digest: {sha256_b64}")
        manifest_lines.append("")

        chunk_sha256_b64 = base64.b64encode(
            hashlib.sha256(entry_chunk.encode("utf-8")).digest()
        ).decode("ascii")
        sf_entry_blocks.append(f"Name: {name}\r\nSHA-256-Digest: {chunk_sha256_b64}\r\n\r\n")

    manifest_bytes = ("\r\n".join(manifest_lines) + "\r\n").encode("utf-8")
    manifest_sha256_b64 = base64.b64encode(hashlib.sha256(manifest_bytes).digest()).decode("ascii")

    sf_header = (
        "Signature-Version: 1.0\r\n"
        "Created-By: 1.0 (Android)\r\n"
        f"SHA-256-Digest-Manifest: {manifest_sha256_b64}\r\n"
        "X-Android-APK-Signed: 2\r\n\r\n"
    )
    sf_bytes = (sf_header + "".join(sf_entry_blocks)).encode("utf-8")

    rsa_bytes = (
        pkcs7.PKCS7SignatureBuilder()
        .set_data(sf_bytes)
        .add_signer(cert_obj, priv_key, hashes.SHA256())
        .sign(
            serialization.Encoding.DER,
            [
                pkcs7.PKCS7Options.DetachedSignature,
                pkcs7.PKCS7Options.Binary,
                pkcs7.PKCS7Options.NoAttributes,
            ],
        )
    )

    return [
        ("META-INF/MANIFEST.MF", manifest_bytes, True),
        ("META-INF/CERT.SF", sf_bytes, True),
        ("META-INF/CERT.RSA", rsa_bytes, True),
    ]


def build_aligned_zip_sections(
    all_entries: list[tuple[str, bytes, bool]]
) -> tuple[bytes, bytes, bytes]:
    contents = bytearray()
    cd_records = bytearray()

    for name, raw_bytes, compress in all_entries:
        name_bytes = name.encode("utf-8")
        crc = zlib.crc32(raw_bytes) & 0xFFFFFFFF
        uncomp_size = len(raw_bytes)

        if compress:
            comp_obj = zlib.compressobj(9, zlib.DEFLATED, -zlib.MAX_WBITS)
            comp_bytes = comp_obj.compress(raw_bytes) + comp_obj.flush()
            method = 8
        else:
            comp_bytes = raw_bytes
            method = 0

        comp_size = len(comp_bytes)
        local_header_off = len(contents)

        extra_bytes = b""
        if not compress:
            data_start_without_extra = local_header_off + 30 + len(name_bytes)
            rem = data_start_without_extra % 4
            if rem != 0:
                pad_len = 4 - rem
                extra_bytes = b"\x00" * pad_len

        dos_time = 0x0000
        dos_date = 0x5421

        local_header = struct.pack(
            "<IHHHHHIIIHH",
            0x04034B50,
            20,
            0,
            method,
            dos_time,
            dos_date,
            crc,
            comp_size,
            uncomp_size,
            len(name_bytes),
            len(extra_bytes),
        )
        contents.extend(local_header)
        contents.extend(name_bytes)
        contents.extend(extra_bytes)
        if not compress:
            assert len(contents) % 4 == 0, f"Unaligned stored entry {name}"
        contents.extend(comp_bytes)

        cd_record = struct.pack(
            "<IHHHHHHIIIHHHHHII",
            0x02014B50,
            20,
            20,
            0,
            method,
            dos_time,
            dos_date,
            crc,
            comp_size,
            uncomp_size,
            len(name_bytes),
            0,
            0,
            0,
            0,
            0,
            local_header_off,
        )
        cd_records.extend(cd_record)
        cd_records.extend(name_bytes)

    cd_offset = len(contents)
    cd_size = len(cd_records)
    num_entries = len(all_entries)

    eocd = struct.pack(
        "<IHHHHIIH",
        0x06054B50,
        0,
        0,
        num_entries,
        num_entries,
        cd_size,
        cd_offset,
        0,
    )
    return bytes(contents), bytes(cd_records), eocd


def compute_v2_content_digest(contents: bytes, cd: bytes, eocd_with_sigblock_off: bytes) -> bytes:
    chunk_size = 1048576
    chunk_digests = []

    for section in (contents, cd, eocd_with_sigblock_off):
        pos = 0
        sec_len = len(section)
        while pos < sec_len:
            chunk = section[pos : pos + chunk_size]
            h = hashlib.sha256()
            h.update(b"\xa5")
            h.update(struct.pack("<I", len(chunk)))
            h.update(chunk)
            chunk_digests.append(h.digest())
            pos += chunk_size

    top = hashlib.sha256()
    top.update(b"\x5a")
    top.update(struct.pack("<I", len(chunk_digests)))
    for d in chunk_digests:
        top.update(d)
    return top.digest()


def build_v2_signing_block(
    contents: bytes,
    cd: bytes,
    eocd: bytes,
    key_pem_path: str,
    cert_der_path: str,
) -> bytes:
    with open(key_pem_path, "rb") as f:
        priv_key = serialization.load_pem_private_key(f.read(), password=None)
    with open(cert_der_path, "rb") as f:
        cert_der = f.read()

    cert_obj = x509.load_der_x509_certificate(cert_der)
    spki_der = cert_obj.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    eocd_for_digest = eocd[:16] + struct.pack("<I", len(contents)) + eocd[20:]
    top_digest = compute_v2_content_digest(contents, cd, eocd_for_digest)

    alg_id = 0x0103
    digest_entry = lp(struct.pack("<I", alg_id) + lp(top_digest))
    digests = lp(digest_entry)
    certs = lp(lp(cert_der))
    additional_attrs = struct.pack("<I", 0)

    signed_data = digests + certs + additional_attrs
    signature_bytes = priv_key.sign(
        signed_data,
        padding.PKCS1v15(),
        hashes.SHA256(),
    )

    sig_entry = lp(struct.pack("<I", alg_id) + lp(signature_bytes))
    signatures = lp(sig_entry)
    public_key = lp(spki_der)

    signer = lp(signed_data) + signatures + public_key
    signers = lp(lp(signer))

    v2_pair_body = struct.pack("<I", 0x7109871A) + signers
    v2_pair = struct.pack("<Q", len(v2_pair_body)) + v2_pair_body

    size_of_block = len(v2_pair) + 24
    sig_block = (
        struct.pack("<Q", size_of_block)
        + v2_pair
        + struct.pack("<Q", size_of_block)
        + b"APK Sig Block 42"
    )
    return sig_block


def package_and_sign_apk(
    app_entries: list[tuple[str, bytes, bool]],
    key_pem_path: str,
    cert_pem_path: str,
    cert_der_path: str,
    output_apk_path: str,
):
    v1_entries = make_v1_signature_files(app_entries, key_pem_path, cert_pem_path)
    all_entries = app_entries + v1_entries

    contents, cd, eocd = build_aligned_zip_sections(all_entries)
    sig_block = build_v2_signing_block(contents, cd, eocd, key_pem_path, cert_der_path)

    new_cd_offset = len(contents) + len(sig_block)
    final_eocd = eocd[:16] + struct.pack("<I", new_cd_offset) + eocd[20:]

    final_apk = contents + sig_block + cd + final_eocd
    with open(output_apk_path, "wb") as f:
        f.write(final_apk)
    return len(final_apk)
