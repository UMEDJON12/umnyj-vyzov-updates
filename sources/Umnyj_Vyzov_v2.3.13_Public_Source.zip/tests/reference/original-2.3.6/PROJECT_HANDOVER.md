# PROJECT HANDOVER: «Умный Вызов» (`com.smartcall.ru`) — версия 2.3.6

Полная техническая документация для нового разработчика по устройству, редактированию, сборке, цифровой подписи и выпуску обновлений приложения «Умный Вызов».

---

## 1. Название и назначение приложения
- **Название**: «Умный Вызов»
- **Назначение**: Доступное приложение для Android (особенно адаптированное для незрячих и слабовидящих пользователей, использующих скринридеры TalkBack и Jieshuo), обеспечивающее:
  1. Ответ на входящие звонки (обычные SIM-вызовы, WhatsApp, Telegram и другие мессенджеры) и сброс вызовов физическими кнопками громкости («Громкость +» / «Громкость -»).
  2. Ответ на входящий звонок при поднесении телефона к уху (по датчику приближения `TYPE_PROXIMITY` с двухфазной защитой `FAR -> NEAR`).
  3. Многодвижковую голосовую озвучку (TTS) имени звонящего, входящих SMS и уведомлений мессенджеров с индивидуальным выбором TTS-движка, голоса, скорости речи, аудиоканала, собственной громкости и числа повторений для каждого профиля (`sim`, `wa`, `tg`, `other`, `sms`).
  4. Встроенную систему самодиагностики и журналирования событий для быстрой отладки на прошивках Xiaomi HyperOS / MIUI, Samsung OneUI и Realme UI (Android 8–16, включая SDK 36).

---

## 2. Точный `packageName`, `versionName` и `versionCode`
- **Идентификатор пакета (`packageName`)**: `com.smartcall.ru`
- **Текущая версия (`versionName`)**: `"2.3.6"`
- **Текущий код версии (`versionCode`)**: `29` (предыдущие выпуски: `2.3.5` = `28`, `2.3.4` = `27`, `2.3.0` = `23`)
- **Параметры SDK в манифесте**: `minSdkVersion = 21`, `targetSdkVersion = 28` (обеспечивает полную совместимость с системным `TelecomManager` и `AccessibilityService` на Android 8–16).

---

## 3. Структура исходного проекта
```text
Umnyj_Vyzov_v2.3.6/
├── PROJECT_HANDOVER.md                 # Настоящая документация для нового разработчика
├── SIGNING_CREDENTIALS.txt             # Полные реквизиты цифровой подписи, пароли, алиасы и SHA-256
├── README_RU.md                        # Сводка исправлений версии 2.3.6
├── RELEASE_INFO.json                   # Паспорт текущего релиза и контрольные суммы
├── requirements.txt                    # Python-зависимости (cryptography>=41.0.0)
├── build_apk.py                        # Скрипт полной сборки, проверки и подписи APK одной командой
├── build_release.py                    # Главный сборщик релиза (генерация AXML/ARSC/DEX, верификация, подпись)
├── build_dex.py                        # Редактируемый генератор первого модуля classes.dex (8168 строк, 9 классов)
├── build_features_dex.py               # Редактируемый генератор второго модуля assets/features.dex (9009 строк, 27 классов)
├── dex_assembler.py                    # Спецификационный ассемблер Dalvik DEX (формат 035, поддержка всех 71 опкодов)
├── axml_arsc_gen.py                    # Генератор бинарного AndroidManifest.xml, accessibility_config.xml и resources.arsc
├── apk_signer.py                       # Упаковщик ZIP с выравниванием 4 байта (zipalign) и подписью JAR v1 + APK Scheme v2
├── patch_features.py                   # Детерминированный патчер эталонного assets/features.dex из assets/features.dex.orig
├── compile_features.py                 # Альтернативный компилятор java/*.java -> assets/features.dex через Android SDK (javac+d8)
├── verify_dex.py                       # Статический и потоковый (control-flow) верификатор байткода DEX (защита от ART VerifyError)
├── verify_apk_links.py                 # Верификатор межклассовых ссылок (36 классов, 387 ссылок) и границ инструкций/try-блоков
├── test_regressions.py                 # Набор из 19 автоматических регрессионных тестов логики и байткода
├── run_host_tests.py                   # Запуск регрессионных тестов + компиляция Java-тестов при наличии JDK
├── previous_signing_certificate.pem    # Сертификат разработчика X.509 (PEM) для проверки идентичности ключа
├── assets/
│   ├── features.dex                    # Второй DEX-модуль (упаковывается в APK как classes2.dex)
│   ├── features.dex.orig               # Базовый эталон features.dex для patch_features.py
│   ├── features-build.json             # Контрольные суммы исходников и текущего features.dex
│   ├── java-strings-baseline.json      # Базовые строки java/*.java для автоматической синхронизации с build_features_dex.py
│   └── ic_launcher.png                 # Иконка приложения (PNG)
├── java/com/smartcall/ru/              # Редактируемые Java-исходники второго модуля (classes2.dex):
│   ├── SmartCallFeatures.java          # Экран настроек TTS/голосов, обработка уведомлений сообщений, ответ на вызов, отчёт
│   ├── AnswerFlow.java                 # Многоступенчатый конечный автомат ответа на звонок (250 мс / 450 мс)
│   └── SpeechPolicy.java               # Политика дедупликации сообщений и очистки имени звонящего
├── java-stubs/                         # Стабы классов из classes.dex для раздельной компиляции java/ через compile_features.py
├── java-tests/com/smartcall/ru/
│   └── FeatureTests.java               # Модульные тесты AnswerFlow и SpeechPolicy на Java
├── keystore/                           # Полный комплект ключей цифровой подписи:
│   ├── SIGNING_CREDENTIALS.txt         # Копия файла с паролями и параметрами подписи
│   ├── README_KEYSTORE.txt             # Справка по хранилищу ключей
│   ├── release.keystore                # Хранилище PKCS#12 (storePassword=android, keyAlias=smartcall, keyPassword=android)
│   ├── release_android.p12             # Хранилище PKCS#12 (storePassword=android, keyAlias=smartcall, keyPassword=android)
│   ├── release.p12                     # Хранилище PKCS#12 (storePassword=android, keyAlias=smartcall, keyPassword=android)
│   ├── private_key.pem                 # Закрытый ключ RSA-2048 (PEM, без пароля)
│   ├── private_key_pkcs8.pem           # Чистый закрытый ключ RSA-2048 PKCS#8 (PEM, без пароля)
│   ├── cert.pem                        # Сертификат X.509 (PEM)
│   └── cert.der                        # Сертификат X.509 (DER)
└── dist/
    └── Umnyj_Vyzov_v2.3.6.apk          # Оригинальный проверенный установочный APK версии 2.3.6
```

---

## 4. Описание основных компонентов приложения
Приложение состоит из **2 DEX-модулей** (`classes.dex` и `classes2.dex`), включающих в сумме **36 классов**:

### Модуль 1: `classes.dex` (9 классов, исходник: `build_dex.py`)
1. **`com.smartcall.ru.CallController`**:
   - Центральный менеджер состояния звонков (`lastCallState`, `callRingStartTime`, `simRinging`, `voipIncoming`, `voipOngoing`).
   - Обработка физических кнопок громкости (`shouldInterceptKey`, `handleHardwareButton`): взаимное исключение конфликтующих настроек, защита от повторного срабатывания при удержании кнопки, мгновенный ответ или сброс вызова.
   - Управление датчиком приближения (`registerProximitySensor`, `unregisterProximitySensor`): регистрация строго `Sensor.TYPE_PROXIMITY` (акселерометр отключён), двухфазный фильтр `proxSawFar == true`, защитные окна `1200 мс` от начала вызова и `800 мс` от регистрации датчика.
   - Защита от повторной озвучки имени звонящего после ответа (`4500 мс` блокировки `lastActionTime` в `checkDelayedCaller` и `startRingtoneWatcher`).
   - Расширенные настройки TTS (`applyTtsSettings`, `configureAndSpeakActiveJob`, `addExtraTtsControls`, `buildProfileSummary`): применение скорости речи (`tts_rate_<channel>`), аудиоканала (`tts_stream_mode`: Специальные возможности / Мультимедиа / Звонок / Голосовой вызов) и собственной громкости (`tts_custom_vol`).
   - Фильтрация уведомлений голосовых сообщений и медиа (`isMediaOrOngoingNotification`: отсечение `голосовое сообщ`, `voice message`, `🎤`, `🎵`, `🎧` и режима `MODE_IN_COMMUNICATION`).
2. **`com.smartcall.ru.CallControlAccessibilityService`**:
   - Системная служба `AccessibilityService`: перехватывает `onKeyEvent`, анализирует окна (`scanNodeTree`, `detectCallUiState`, `clickCallButtonInUi`, `clickNodeTree`, `swipeNode`), умеет нажимать кнопку ответа как в полноэкранном интерфейсе звонилки, так и во всплывающем уведомлении `com.android.systemui`.
3. **`com.smartcall.ru.CallNotificationListenerService`**:
   - Системная служба `NotificationListenerService`: отслеживает уведомления звонков и мессенджеров, выполняет `PendingIntent` ответа/отклонения (`triggerCallNotificationAction`).
4. **`com.smartcall.ru.ProximitySensorListener`**:
   - Слушатель `SensorEventListener` для ответа при поднесении телефона к уху.
5. **`com.smartcall.ru.ScreenAndVolumeReceiver`**:
   - `BroadcastReceiver` для событий `PHONE_STATE` и `SMS_RECEIVED`.
6. **`com.smartcall.ru.DelayedActionRunnable`**:
   - Выполнение отложенных задач в главном потоке (`Looper.getMainLooper()`): отложенное чтение имени звонящего, проверка мелодии звонка, свайп ответа.
7. **`com.smartcall.ru.TtsInitListener`**:
   - Слушатель инициализации `TextToSpeech`.
8. **`com.smartcall.ru.MainActivity`**:
   - Главная `Activity` приложения: строит весь основной интерфейс, переключатели разрешений, настроек кнопок, датчика приближения, TTS и блок диагностики, вызывая расширения из `SmartCallFeatures` и `CallController`.
9. **`com.smartcall.ru.DialogClickListener`**:
   - Обработчик диалоговых окон выбора движка, голоса, скорости речи и аудиоканала.

### Модуль 2: `classes2.dex` / `assets/features.dex` (27 классов, исходники: `build_features_dex.py` и `java/com/smartcall/ru/*.java`)
1. **`com.smartcall.ru.SmartCallFeatures`** (и его вложенные классы `SpeechJob`, `ExternalTtsSpeaker`, лямбды `ExternalSyntheticLambda0..21`):
   - Добавляет кнопки выбора голоса для каждого из 5 профилей (`addVoiceButtons`), управляет очередью озвучки `QUEUE`, создаёт экземпляры `TextToSpeech` с нужным движком, разбивает длинные тексты на части, обрабатывает уведомления мессенджеров (`handleMessageNotification`, `announceMessage`), координирует ответ (`answer`, `answerUi`, `readLiveState`, `phoneState`).
2. **`com.smartcall.ru.AnswerFlow`**:
   - Конечный автомат гарантированного ответа на вызов (стадия 0: `TelecomManager.acceptRingingCall()`, стадия 1 через 250 мс: `PendingIntent` уведомления, стадия 2 через 250 мс: клик/жест в UI, стадия 3 через 450 мс: повторный клик/жест в UI, стадия 4 через 450 мс: финальная проверка состояния).
3. **`com.smartcall.ru.SpeechPolicy`** и **`SpeechPolicy$Dedup`**:
   - Определение профиля приложения по имени пакета (`wa`, `tg`, `sms`, `other`), очистка имени звонящего от служебных слов и защита от повторного чтения одинаковых сообщений в течение окна дедупликации.

---

## 5. Используемые языки, инструменты и версии SDK
- **Языки**: Python 3.9+ (рекомендуется Python 3.11) и Java 8 (байткод совместим с Dalvik DEX 035, Android 5.0–16.0).
- **Ассемблер и упаковщик**: собственные модули `dex_assembler.py`, `axml_arsc_gen.py`, `apk_signer.py` на базе стандартной библиотеки Python и пакета `cryptography`.
- **Верификаторы**: `verify_dex.py` (статический и потоковый анализатор типов регистров Dalvik, моделирующий проверки верификатора Android ART на Android 14–16) и `verify_apk_links.py` (проверка целостности таблиц классов/методов/полей, выравнивания инструкций и границ `try_item` во всех DEX-файлах).

---

## 6. Способ сборки всех программных модулей (`classes.dex` и `features.dex`)

### 6.1. Сборка первого модуля (`classes.dex`)
Модуль `classes.dex` всегда собирается напрямую из редактируемого файла `build_dex.py` при вызове `build_release.py` (функция `build_classes_dex()`).

### 6.2. Сборка и модификация второго модуля (`assets/features.dex` / `classes2.dex`)
В проекте предусмотрены **три полноценных способа** изменения и пересборки `assets/features.dex`:

1. **Способ 1 (Автономный, без Android SDK — через `build_features_dex.py` и `java/*.java`)**:
   - Файл `build_features_dex.py` содержит полное символьное описание всех 27 классов и 112 методов второго DEX-модуля в формате `DexBuilder`.
   - Вы можете редактировать любые строки, константы или инструкции напрямую в `build_features_dex.py`, либо изменять строковые литералы в `java/com/smartcall/ru/{SmartCallFeatures.java, AnswerFlow.java, SpeechPolicy.java}` (функция `_sync_from_java_sources` в `build_features_dex.py` автоматически переносит изменённые строки из `.java` файлов в символьное дерево DEX).
   - Для пересборки `assets/features.dex` с нуля выполните:
     ```bash
     python3 build_features_dex.py
     ```
   - При запуске `python3 build_release.py` (или `python3 build_apk.py`), если вы изменили `java/com/smartcall/ru/*.java`, удалили `assets/features.dex` или передали флаг `--rebuild-features`, сборщик автоматически вызовет `build_features_dex.py` и соберёт новый `assets/features.dex`.

2. **Способ 2 (Восстановление побайтового эталона v2.3.6 — через `patch_features.py`)**:
   - Если нужно восстановить точный побайтовый эталон `assets/features.dex` версии 2.3.6 (`33 688` байт, `SHA-256: 82af4812f820565c42aadf3330c904e839646d9040637214aca9365153dc680e`) из `assets/features.dex.orig`, выполните:
     ```bash
     python3 patch_features.py
     ```

3. **Способ 3 (Компиляция Java с нуля через Android SDK — `compile_features.py`)**:
   - При наличии установленного Android SDK (`android.jar` API 35+ и `d8.jar` из Android Build-Tools) и JDK (`javac` или `ecj.jar`):
     ```bash
     python3 compile_features.py --android-jar /path/to/android.jar --d8-jar /path/to/d8.jar
     ```

---

## 7. Инструкция по сборке APK с нуля
1. Убедитесь, что установлен Python 3.9+ и библиотека `cryptography`:
   ```bash
   pip install -r requirements.txt
   ```
2. Запустите регрессионные тесты:
   ```bash
   python3 test_regressions.py
   ```
3. Соберите и подпишите релизный APK одной командой:
   ```bash
   python3 build_apk.py
   ```
   Готовый подписанный файл появится по пути `dist/Umnyj_Vyzov_v2.3.6.apk`.

---

## 8. Инструкция по цифровой подписи
Все ключи и пароли подробно описаны в файле `SIGNING_CREDENTIALS.txt` (в корне проекта и в `keystore/SIGNING_CREDENTIALS.txt`):
- **Пароль хранилища (`storePassword`)**: `android`
- **Псевдоним ключа (`keyAlias`)**: `smartcall`
- **Пароль ключа (`keyPassword`)**: `android`
- **Отпечаток сертификата (SHA-256)**: `baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01`

Подпись выполняется автоматически при вызове `python3 build_apk.py` или:
```bash
python3 build_release.py \
    --key keystore/private_key.pem \
    --cert previous_signing_certificate.pem \
    --output dist/Umnyj_Vyzov_v2.3.6.apk
```
Скрипт `apk_signer.py` формирует как **JAR Signing (v1)** (`META-INF/MANIFEST.MF`, `CERT.SF`, `CERT.RSA`), так и блок **APK Signature Scheme v2** (`ID 0x7109871a` перед Central Directory), выравнивая несжатые ресурсы на границу 4 байт (`zipalign`).

---

## 9. Инструкция по увеличению номера версии и порядок создания следующего обновления
Для выпуска следующей версии (например, `2.3.7` с `versionCode = 30`), которая установится поверх существующей `2.3.6` (`versionCode = 29`) без удаления приложения и с сохранением всех настроек пользователя:

1. **Внесите изменения в исходный код**:
   - Для первого DEX-модуля (`classes.dex`): отредактируйте `build_dex.py` (при смене номера версии обновите также строку заголовка диагностики `"=== ДИАГНОСТИКА «УМНЫЙ ВЫЗОВ» v2.3.7 ===\n\n"` в `build_dex.py`).
   - Для второго DEX-модуля (`classes2.dex` / `assets/features.dex`): отредактируйте `build_features_dex.py` или `java/com/smartcall/ru/*.java` и выполните `python3 build_features_dex.py`.
2. **Увеличьте `versionCode` и `versionName`**:
   - Либо обновите константы `VERSION_NAME = "2.3.7"` и `VERSION_CODE = 30` в начале файла `build_release.py`,
   - Либо передайте их аргументами командной строки:
     ```bash
     python3 build_release.py \
         --key keystore/private_key.pem \
         --cert previous_signing_certificate.pem \
         --version-name 2.3.7 \
         --version-code 30 \
         --output dist/Umnyj_Vyzov_v2.3.7.apk
     ```
3. **Запустите проверки**:
   - Во время сборки `build_release.py` автоматически проверит оба DEX-модуля через `verify_dex.py`, проверит все межклассовые ссылки через `verify_apk_links.py` и сверит отпечаток сертификата подписи (`SHA-256: baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01`).

---

## 10. Способ проверки совместимости подписи
Чтобы убедиться, что собранный APK подписан тем же сертификатом и установится поверх существующего приложения:
1. Встроенная проверка в `build_release.py`: функция `check_identity()` автоматически проверяет, что SHA-256 сертификата равен `baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01`, а публичный ключ в сертификате математически совпадает с закрытым ключом.
2. Проверка через `openssl` / `keytool`:
   ```bash
   keytool -printcert -jarfile dist/Umnyj_Vyzov_v2.3.6.apk
   ```
   В строке `SHA256:` должно быть:
   `BA:ED:B1:A7:7A:F5:B2:A9:A0:F3:4D:E7:2E:7F:88:52:6E:0E:82:C5:08:EB:07:FE:E8:B0:4C:E2:CF:02:3C:01`.

---

## 11. Список зависимостей и их источников
- **Стандартная библиотека Python 3.9+**: `struct`, `zlib`, `hashlib`, `zipfile`, `json`, `unittest`, `argparse`, `tempfile`, `pathlib`.
- **Пакет `cryptography` (`>= 41.0.0`)**: стандартный пакет из PyPI (`pip install cryptography`), указан в `requirements.txt`.
- Никаких закрытых, проприетарных или внешних сетевых зависимостей проект не имеет.

---

## 12. Описание возможных ограничений проекта
1. **Правила верификатора байткода Android ART (Android 14–16)**:
   - При редактировании инструкций Dalvik в `build_dex.py` или `build_features_dex.py` никогда не применяйте `if-eqz` / `if-nez` напрямую к 64-битным регистрам `long` (`J`), так как в Dalvik `long` занимает пару регистров (`vX, vX+1`) и требует `const-wide/16` + `cmp-long` + `if-eqz/if-nez`.
   - Следите за тем, чтобы тип регистра `this` в `invoke-virtual` / `invoke-interface` точно соответствовал классу вызываемого метода. Скрипт `verify_dex.py` автоматически проверяет оба этих правила при каждой сборке.
2. **Системные ограничения Android на целевых устройствах**:
   - Для работы перехвата кнопок громкости и определения экранов вызовов на Xiaomi HyperOS / MIUI пользователю необходимо включить службу «Умный Вызов» в «Специальных возможностях» и предоставить доступ к уведомлениям.
