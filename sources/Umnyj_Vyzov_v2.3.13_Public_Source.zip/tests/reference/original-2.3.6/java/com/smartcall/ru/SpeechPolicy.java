package com.smartcall.ru;

import java.util.Locale;
import java.util.LinkedHashMap;

/** Pure policies, tested on the host JVM without Android. */
public final class SpeechPolicy {
    private SpeechPolicy() {}
    public static String channel(String pkg) {
        String p = pkg == null ? "sim" : pkg.toLowerCase(Locale.ROOT);
        if (p.contains("whatsapp")) return "wa";
        if (p.contains("telegram") || p.contains("nekogram") || p.contains("challegram")) return "tg";
        if (p.equals("sim") || p.equals("sms") || p.contains("messaging") || p.contains("mms")) return "sms";
        return "other";
    }
    public static String cleanCaller(String input) {
        if (input == null) return "";
        String s = input.trim();
        String lower = s.toLowerCase(Locale.ROOT);
        if (lower.equals("whatsapp") || lower.equals("telegram") || lower.equals("телефон") || lower.equals("входящий вызов") || lower.equals("incoming call")) return "";
        if (lower.contains("meta ai") || lower.contains("для поиска") || lower.contains("поиск")
                || lower.contains("search") || lower.contains("ask meta") || lower.contains("запрос для")) return "";
        s = s.replaceFirst("(?iu)^(звонит|позвонить|входящий вызов от|звонок ватсап от|звонок телеграм от|звонок от|звонок)\\s+", "");
        return s.replaceAll("[\\s\\p{Punct}…。，،]+$", "").trim();
    }
    public static boolean callerNode(String id, String text, boolean editable) {
        if (editable || cleanCaller(text).isEmpty() || id == null) return false;
        String p = id.toLowerCase(Locale.ROOT);
        return p.contains("caller_name") || p.contains("contact_name") || p.contains("call_name")
                || p.contains("calling_name") || p.contains("voip_name") || p.contains("peer_name");
    }
    public static String voiceKey(String channel) { return "tts_voice_" + channel; }
    public static String engineKey(String channel) { return "tts_eng_" + channel; }

    public static final class Dedup {
        private final LinkedHashMap<String,String> seen = new LinkedHashMap<String,String>();
        public synchronized boolean accept(String key, String signature) {
            if (signature.equals(seen.get(key))) return false;
            seen.put(key, signature);
            if (seen.size() > 128) seen.remove(seen.keySet().iterator().next());
            return true;
        }
    }
}
