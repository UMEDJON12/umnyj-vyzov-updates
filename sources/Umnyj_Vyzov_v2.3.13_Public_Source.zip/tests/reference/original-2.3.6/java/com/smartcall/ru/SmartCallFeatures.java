package com.smartcall.ru;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Android bridge for answer confirmation, notification messages, and speech profiles. */
public final class SmartCallFeatures {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final SpeechPolicy.Dedup MESSAGES = new SpeechPolicy.Dedup();
    private static final ArrayDeque<SpeechJob> QUEUE = new ArrayDeque<SpeechJob>();
    public static SpeechJob active;
    private static long speechSequence;
    private static long messageSequence;
    private static AnswerFlow answerFlow;
    private static long answerGeneration;
    private SmartCallFeatures() {}
    private static void log(String message) { CallController.log(message); }
    private static SharedPreferences prefs(Context context) { return context.getSharedPreferences("call_prefs", 0); }
    public static String cleanCaller(String value) { return SpeechPolicy.cleanCaller(value); }
    public static void showPowerHelp(final Activity activity) {
        int behavior = android.provider.Settings.Secure.getInt(activity.getContentResolver(), "incall_power_button_behavior", 1);
        String status = (behavior & 2) != 0 ? "включено" : "выключено";
        new AlertDialog.Builder(activity).setTitle("Кнопка питания и блокировка экрана")
            .setMessage("Системное завершение разговора питанием: " + status + ". Для уже принятого обычного разговора включите настройку Android «Кнопка питания завершает вызов». Для входящего вызова система может заглушить звонок и выключить экран до получения события приложением. Обычное приложение не может гарантированно запретить эту блокировку. Резервный сброс по SCREEN_OFF сохранён; для сброса без гашения экрана можно выбрать кнопку громкости. Снятие PIN/пароля приложение не выполняет.")
            .setPositiveButton("Открыть специальные возможности", (dialog, which) -> activity.startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)))
            .setNegativeButton("Закрыть", null).show();
    }

    public static String profileSummary(Context context) {
        SharedPreferences p = prefs(context);
        StringBuilder out = new StringBuilder("Голоса: ");
        for (String c : new String[]{"sim", "wa", "tg", "other", "sms"}) {
            out.append(c).append('=').append(p.getString(SpeechPolicy.voiceKey(c), c.equals("sim") ? p.getString("tts_voice_name", "default") : "default")).append("; ");
        }
        return out.toString();
    }
    public static void onEngineChanged(Context context, String engineKey) {
        if (engineKey != null && engineKey.startsWith("tts_eng_")) {
            String c = engineKey.substring(8);
            prefs(context).edit().putString(SpeechPolicy.voiceKey(c), "default").apply();
        }
    }
    public static void addVoiceButtons(final Activity activity, LinearLayout layout) {
        final String[] channels = {"sim", "wa", "tg", "other", "sms"};
        final String[] titles = {"Голос SIM-звонков", "Голос WhatsApp", "Голос Telegram", "Голос других приложений", "Голос входящих SMS"};
        for (int i = 0; i < channels.length; i++) {
            final String channel = channels[i];
            final String title = titles[i];
            final Button button = new Button(activity);
            updateVoiceButton(activity, button, channel, title);
            button.setOnClickListener(view -> showVoicePicker(activity, channel, title, button));
            layout.addView(button);
        }
    }
    private static void updateVoiceButton(Activity a, Button b, String channel, String title) {
        String voice = prefs(a).getString(SpeechPolicy.voiceKey(channel), channel.equals("sim") ? prefs(a).getString("tts_voice_name", "default") : "default");
        b.setText(title + ": " + ("default".equals(voice) ? "По умолчанию" : voice));
    }
    private static void showVoicePicker(final Activity a, final String channel, final String title, final Button button) {
        final String engine = prefs(a).getString(SpeechPolicy.engineKey(channel), "default");
        final TextToSpeech[] loader = new TextToSpeech[1];
        final AlertDialog loading = new AlertDialog.Builder(a).setMessage("Загружаются голоса выбранного синтезатора…").setNegativeButton("Отмена", null).create();
        final boolean[] closed = {false};
        loading.setOnDismissListener(dialog -> { closed[0] = true; if (loader[0] != null) loader[0].shutdown(); });
        loading.show();
        TextToSpeech.OnInitListener init = status -> MAIN.post(() -> {
            if (closed[0] || a.isFinishing()) { if (loader[0] != null) loader[0].shutdown(); return; }
            if (status != TextToSpeech.SUCCESS || loader[0] == null) {
                loading.dismiss();
                new AlertDialog.Builder(a).setMessage("Синтезатор не загрузился. Проверьте выбранный движок и его голоса.").setPositiveButton("Закрыть", null).show();
                return;
            }
            try {
                Set<Voice> voices = loader[0].getVoices();
                final ArrayList<Voice> sorted = new ArrayList<Voice>();
                if (voices != null) sorted.addAll(voices);
                Collections.sort(sorted, Comparator.comparing(Voice::getName));
                final String[] names = new String[sorted.size() + 1];
                names[0] = "По умолчанию (голос выбранного движка)";
                for (int j = 0; j < sorted.size(); j++) {
                    Voice voice = sorted.get(j);
                    names[j + 1] = voice.getName() + " — " + voice.getLocale().getDisplayName() + (voice.isNetworkConnectionRequired() ? " (нужен интернет)" : "");
                }
                loading.dismiss();
                new AlertDialog.Builder(a).setTitle(title + "; " + engine).setItems(names, (dialog, which) -> {
                    String selected = which == 0 ? "default" : sorted.get(which - 1).getName();
                    prefs(a).edit().putString(SpeechPolicy.voiceKey(channel), selected).apply();
                    updateVoiceButton(a, button, channel, title);
                    log("Голос сохранён: " + channel + "=" + selected);
                    speak(a, "Проверка выбранного голоса", SpeechPolicy.engineKey(channel), 1);
                }).setNegativeButton("Отмена", null).show();
            } catch (RuntimeException ex) { loading.dismiss(); log("Ошибка списка голосов: " + ex); }
        });
        loader[0] = "default".equals(engine) ? new TextToSpeech(a, init) : new TextToSpeech(a, init, engine);
        MAIN.postDelayed(() -> { if (!closed[0]) { loading.dismiss(); log("Голоса: истекло ожидание инициализации синтезатора"); } }, 15000);
    }

    public static void speak(Context context, String text, String enginePreferenceKey, int repeat) {
        String channel = enginePreferenceKey != null && enginePreferenceKey.startsWith("tts_eng_") ? enginePreferenceKey.substring(8) : "sim";
        enqueue(context, SpeechPolicy.cleanCaller(text), channel, repeat, !channel.equals("sms"), null);
    }
    public static void speakLegacy(Context context, String text, String engine, int repeat) {
        enqueue(context, text, "sim", repeat, true, engine);
    }
    private static void enqueue(Context context, String text, String channel, int repeat, boolean call, String explicitEngine) {
        if (context == null || text == null || text.trim().isEmpty()) return;
        final SpeechJob job = new SpeechJob(context.getApplicationContext(), text.trim(), channel, Math.max(1, Math.min(5, repeat)), call, explicitEngine);
        MAIN.post(() -> {
            if (QUEUE.size() >= 32) { log("TTS: очередь переполнена; сообщение не добавлено"); return; }
            QUEUE.add(job);
            pump();
        });
    }
    /** Stops caller announcements; queued message jobs remain available. */
    public static void stopSpeech() {
        MAIN.post(() -> {
            ArrayList<SpeechJob> saved = new ArrayList<SpeechJob>();
            while (!QUEUE.isEmpty()) { SpeechJob j = QUEUE.remove(); if (!j.call) saved.add(j); }
            QUEUE.addAll(saved);
            if (active != null && active.call) finish(active);
        });
    }
    private static void pump() {
        if (active != null || QUEUE.isEmpty()) return;
        final SpeechJob job = QUEUE.remove();
        active = job;
        SharedPreferences p = prefs(job.context);
        String engine = job.explicitEngine != null ? job.explicitEngine : p.getString(SpeechPolicy.engineKey(job.channel), "default");
        job.voice = p.getString(SpeechPolicy.voiceKey(job.channel), job.channel.equals("sim") ? p.getString("tts_voice_name", "default") : "default");
        log("TTS профиль=" + job.channel + ", движок=" + engine + ", голос=" + job.voice + ", текст=" + job.text);
        TextToSpeech.OnInitListener listener = status -> MAIN.post(() -> {
            if (active != job) return;
            if (status != TextToSpeech.SUCCESS || job.tts == null) { log("TTS: ошибка инициализации " + status); finish(job); return; }
            try {
                if (!"default".equals(job.voice)) {
                    boolean found = false;
                    Set<Voice> voices = job.tts.getVoices();
                    if (voices != null) for (Voice v : voices) if (job.voice.equals(v.getName())) {
                        int result = job.tts.setVoice(v); found = result == TextToSpeech.SUCCESS;
                        log("TTS: setVoice=" + v.getName() + ", результат=" + result); break;
                    }
                    if (!found) log("TTS: выбранный голос отсутствует/не принят, используется стандартный голос этого движка");
                }
                job.tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                job.tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    public void onStart(String id) {}
                    public void onDone(String id) { if (id.equals(job.lastId)) MAIN.post(() -> finish(job)); }
                    public void onError(String id) { MAIN.post(() -> { log("TTS: ошибка произнесения " + id); finish(job); }); }
                });
                int limit = Math.max(128, TextToSpeech.getMaxSpeechInputLength() - 8);
                ArrayList<String> chunks = new ArrayList<String>();
                for (int start = 0; start < job.text.length(); start += limit) chunks.add(job.text.substring(start, Math.min(start + limit, job.text.length())));
                long sequence = ++speechSequence;
                int total = chunks.size() * job.repeat;
                int index = 0;
                job.lastId = "sc_" + sequence + "_" + (total - 1);
                for (int i = 0; i < job.repeat; i++) for (String chunk : chunks) {
                    String id = "sc_" + sequence + "_" + index;
                    int result = job.tts.speak(chunk, index == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, new Bundle(), id);
                    if (result != TextToSpeech.SUCCESS) { log("TTS: speak отклонён, код=" + result); finish(job); return; }
                    index++;
                }
                log("TTS: отправлено частей=" + total + "; без добавленной пунктуации");
            } catch (RuntimeException ex) { log("TTS: " + ex); finish(job); }
        });
        try { job.tts = "default".equals(engine) ? new TextToSpeech(job.context, listener) : new TextToSpeech(job.context, listener, engine); }
        catch (RuntimeException ex) { log("TTS: " + ex); finish(job); }
        MAIN.postDelayed(() -> { if (active == job) { log("TTS: истекло ожидание завершения"); finish(job); } }, 120000);
    }
    private static void finish(SpeechJob job) {
        if (active != job) return;
        if (job.tts != null) { try { job.tts.stop(); job.tts.shutdown(); } catch (RuntimeException ignored) {} }
        active = null;
        pump();
    }
    private static final class SpeechJob {
        final Context context; final String text, channel, explicitEngine; final int repeat; final boolean call;
        TextToSpeech tts; String voice, lastId;
        SpeechJob(Context c, String t, String channel, int r, boolean call, String engine) { context=c; text=t; this.channel=channel; repeat=r; this.call=call; explicitEngine=engine; }
    }

    public static void announceSms(Context context, String pkg, String sender, String body) {
        String channel = SpeechPolicy.channel(pkg);
        announceMessage(context, channel, sender, body, "sms:" + pkg + ":" + sender, (body == null ? "" : body) + ":" + (++messageSequence));
    }
    private static void announceMessage(Context context, String channel, String sender, String body, String key, String signature) {
        SharedPreferences p = prefs(context);
        if (!p.getBoolean("tts_enabled", true) || !p.getBoolean("tts_app_" + channel, true)) return;
        if (sender == null) sender = "";
        if (body == null) body = "";
        if (sender.isEmpty() && body.isEmpty()) return;
        if (!MESSAGES.accept(key, signature)) return;
        if (!sender.matches(".*[\\p{L}].*")) {
            try { String contact = CallController.lookupContactName(context, sender); if (contact != null && !contact.isEmpty()) sender = contact; } catch (RuntimeException ignored) {}
        }
        String label = channel.equals("wa") ? "WhatsApp " : channel.equals("tg") ? "Telegram " : channel.equals("sms") ? "СМС " : "Сообщение ";
        String text = label + sender;
        if (p.getBoolean("tts_sms_text", true) && !body.isEmpty()) text += "\n" + body;
        log("Получено сообщение: профиль=" + channel + ", отправитель=" + sender);
        enqueue(context, text, channel, 1, false, null);
    }
    /** Returns true for message packages even if muted/summary, preventing old duplicate handling. */
    public static boolean handleMessageNotification(Context context, StatusBarNotification sbn) {
        if (sbn == null) return false;
        String pkg = sbn.getPackageName();
        String channel = SpeechPolicy.channel(pkg);
        if (!(channel.equals("wa") || channel.equals("tg") || channel.equals("sms") || pkg.contains("viber") || pkg.contains("imo"))) return false;
        Notification n = sbn.getNotification();
        if (n == null || Notification.CATEGORY_CALL.equals(n.category)) return false;
        if (n.extras != null && (n.extras.get("android.answerIntent") != null || n.extras.getInt("android.callType", 0) != 0)) return false;
        // SMS_RECEIVED owns ordinary SIM texts whenever that permission is granted.
        // Do not announce the same SIM text again from the SMS app's notification.
        if (channel.equals("sms") && context.checkSelfPermission("android.permission.RECEIVE_SMS") == 0) return true;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return true;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 && !Notification.CATEGORY_MESSAGE.equals(n.category)
                && (n.extras == null || !n.extras.containsKey(Notification.EXTRA_MESSAGES))) return true;
        try {
            Bundle b = n.extras;
            if (b == null) return true;
            String sender = string(b.getCharSequence(Notification.EXTRA_TITLE));
            String body = string(b.getCharSequence(Notification.EXTRA_BIG_TEXT));
            if (body.isEmpty()) body = string(b.getCharSequence(Notification.EXTRA_TEXT));
            long timestamp = 0;
            android.os.Parcelable[] bundled = b.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (bundled != null && Build.VERSION.SDK_INT >= 30) {
                List<Notification.MessagingStyle.Message> messages = Notification.MessagingStyle.Message.getMessagesFromBundleArray(bundled);
                if (messages != null && !messages.isEmpty()) {
                    Notification.MessagingStyle.Message message = messages.get(messages.size() - 1);
                    if (message.getSender() != null) sender = message.getSender().toString();
                    body = string(message.getText()); timestamp = message.getTimestamp();
                }
            }
            if (body.isEmpty()) {
                CharSequence[] lines = b.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
                if (lines != null && lines.length > 0) body = string(lines[lines.length - 1]);
            }
            if (body.isEmpty()) { log("Сообщение: уведомление без доступного текста, пакет=" + pkg); return true; }
            if (timestamp == 0) timestamp = n.when;
            announceMessage(context, channel, sender, body, sbn.getKey(), sender + "\n" + body + "\n" + timestamp);
        } catch (RuntimeException ex) { log("Ошибка чтения уведомления сообщения: " + ex); }
        return true;
    }
    private static String string(CharSequence s) { return s == null ? "" : s.toString().trim(); }

    public static String findCallerName(AccessibilityService service) {
        if (service == null) return null;
        try {
            String found = findCaller(service, service.getRootInActiveWindow(), 0);
            if (found != null) return found;
            List<AccessibilityWindowInfo> windows = service.getWindows();
            if (windows != null) for (AccessibilityWindowInfo w : windows) { found = findCaller(service, w.getRoot(), 0); if (found != null) return found; }
        } catch (RuntimeException ex) { log("Имя из окна: " + ex); }
        return null;
    }
    private static String findCaller(Context context, AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 24) return null;
        String pkg = string(node.getPackageName());
        if (pkg.equals("com.smartcall.ru") || pkg.contains("launcher") || pkg.contains("systemui") || !callPackage(context, pkg)) return null;
        String text = string(node.getText());
        if (node.isVisibleToUser() && SpeechPolicy.callerNode(node.getViewIdResourceName(), text, node.isEditable())) return SpeechPolicy.cleanCaller(text);
        for (int i = 0; i < Math.min(node.getChildCount(), 100); i++) { String value = findCaller(context, node.getChild(i), depth+1); if (value != null) return value; }
        return null;
    }

    public static void cancelAnswer() {
        answerGeneration++;
        if (answerFlow != null) answerFlow.cancel();
        answerFlow = null;
    }
    public static void answer(final Context context) {
        final long generation = ++answerGeneration;
        MAIN.post(() -> {
            if (generation != answerGeneration) return;
            if (answerFlow != null) answerFlow.cancel();
            CallController.stopTts();
            final long epoch = CallController.callRingStartTime;
            answerFlow = new AnswerFlow(new AnswerFlow.Actions() {
                public int liveState() {
                    if (epoch != 0 && CallController.callRingStartTime != 0 && CallController.callRingStartTime != epoch) return 0;
                    return readLiveState(context);
                }
                public void telecom() {
                    if (Build.VERSION.SDK_INT >= 26) {
                        TelecomManager manager = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                        if (manager != null) { manager.acceptRingingCall(); log("Ответ: запрос acceptRingingCall отправлен; ожидаем реальное состояние"); }
                    }
                }
                public void notification() { boolean sent = CallNotificationListenerService.triggerCallNotificationAction(true); log("Ответ: действие уведомления отправлено=" + sent); }
                public void ui() { log("Ответ: кнопка/жест интерфейса отправлены=" + answerUi(context)); }
                public void completed(int observed) { CallController.recordActiveCallState(observed); }
                public void log(String message) { SmartCallFeatures.log(message); }
            }, (callback, millis) -> MAIN.postDelayed(callback, millis));
            answerFlow.start();
        });
    }
    private static int phoneState(Context context) {
        try { TelephonyManager manager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE); return manager == null ? 0 : manager.getCallState(); }
        catch (RuntimeException ex) { return 0; }
    }
    private static int readLiveState(Context context) {
        int phone = phoneState(context);
        if (phone == TelephonyManager.CALL_STATE_RINGING) return 1;
        if (phone == TelephonyManager.CALL_STATE_OFFHOOK) return 2;
        boolean incoming = false, ongoing = false;
        try {
            CallNotificationListenerService service = CallNotificationListenerService.instance;
            StatusBarNotification[] all = service == null ? null : service.getActiveNotifications();
            if (all != null) for (StatusBarNotification sbn : all) {
                Notification n = sbn.getNotification();
                if (n == null || !Notification.CATEGORY_CALL.equals(n.category) || sbn.getPackageName().equals("com.smartcall.ru")) continue;
                Bundle b = n.extras;
                if (b != null) {
                    int type = b.getInt("android.callType", 0);
                    incoming |= type == 1 || b.get("android.answerIntent") != null;
                    ongoing |= type == 2 || b.get("android.hangUpIntent") != null;
                }
            }
            int ui = CallControlAccessibilityService.detectCallUiState();
            if (incoming || ui == 1) return 1;
            if (ongoing || ui == 2) return 2;
        } catch (RuntimeException ex) { log("Ответ: проверка уведомлений/окна: " + ex); }
        return 0;
    }
    private static boolean callPackage(Context context, String pkg) {
        if (pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom") || pkg.contains("contacts")) return phoneState(context) == 1;
        try {
            CallNotificationListenerService s = CallNotificationListenerService.instance;
            if (s != null) for (StatusBarNotification n : s.getActiveNotifications()) if (pkg.equals(n.getPackageName()) && Notification.CATEGORY_CALL.equals(n.getNotification().category)) return true;
        } catch (RuntimeException ignored) {}
        return false;
    }
    private static boolean answerUi(Context context) {
        AccessibilityService service = CallControlAccessibilityService.instance;
        if (service == null || readLiveState(context) != 1) return false;
        try {
            CallController.recordActiveCallState(98);
            return true;
        } catch (RuntimeException ex) { log("Ответ: ошибка интерфейса " + ex); }
        return false;
    }
    private static boolean answerNode(Context context, AccessibilityService service, AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 24 || !callPackage(context, string(node.getPackageName()))) return false;
        String text = (string(node.getText()) + " " + string(node.getContentDescription()) + " " + node.getViewIdResourceName()).toLowerCase(Locale.ROOT);
        boolean positive = text.contains("ответить") || text.contains("принять") || text.contains("answer") || text.contains("accept_call") || text.contains("answer_call");
        boolean excluded = text.contains("перезвон") || text.contains("callback") || text.contains("call_back") || text.contains("reject") || text.contains("decline");
        if (positive && !excluded && node.isVisibleToUser() && node.isEnabled()) {
            AccessibilityNodeInfo target = node;
            for (int parent = 0; parent < 3 && target != null; parent++, target = target.getParent()) if (target.isClickable() && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            Rect r = new Rect(); node.getBoundsInScreen(r);
            if (r.width() > 0 && r.height() > 0 && readLiveState(context) == 1) {
                Path path = new Path(); path.moveTo(r.centerX(), r.centerY()); path.lineTo(r.centerX(), Math.max(1, r.centerY() - Math.max(160, r.height()*2)));
                return service.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0, 280)).build(), null, null);
            }
        }
        for (int i = 0; i < Math.min(node.getChildCount(), 100); i++) if (answerNode(context, service, node.getChild(i), depth+1)) return true;
        return false;
    }
}
