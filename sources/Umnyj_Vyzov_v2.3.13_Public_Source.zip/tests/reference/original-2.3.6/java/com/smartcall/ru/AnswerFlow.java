package com.smartcall.ru;

/** Bounded answer fallbacks; a dispatched command never implies a connected call. */
public final class AnswerFlow {
    public interface Actions {
        int liveState(); // 0 idle/unknown, 1 incoming, 2 connected
        void telecom();
        void notification();
        void ui();
        void completed(int observed);
        void log(String text);
    }
    public interface Scheduler { void later(Runnable callback, long millis); }
    private final Actions actions;
    private final Scheduler scheduler;
    private boolean canceled;
    public AnswerFlow(Actions actions, Scheduler scheduler) { this.actions = actions; this.scheduler = scheduler; }
    public void cancel() { canceled = true; }
    public void start() { step(0); }
    private void step(final int stage) {
        if (canceled) return;
        int state = actions.liveState();
        if (state != 1) {
            actions.log(state == 2 ? "Ответ: принятый звонок подтверждён состоянием Android" : "Ответ: входящий звонок больше не подтверждается");
            actions.completed(state);
            return;
        }
        if (stage == 3) {
            actions.log("Ответ: после резервных способов звонок всё ещё входящий");
            actions.completed(1);
            return;
        }
        try {
            if (stage == 0) actions.telecom();
            else if (stage == 1) actions.notification();
            else actions.ui();
        } catch (RuntimeException ex) { actions.log("Ответ: ошибка способа " + stage + " " + ex); }
        scheduler.later(new Runnable() { public void run() { step(stage + 1); } }, stage == 0 ? 250 : 450);
    }
}
