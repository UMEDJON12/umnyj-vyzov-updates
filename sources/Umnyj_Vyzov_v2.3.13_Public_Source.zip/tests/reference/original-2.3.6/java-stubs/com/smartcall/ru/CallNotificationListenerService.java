package com.smartcall.ru;
import android.service.notification.NotificationListenerService;
public class CallNotificationListenerService extends NotificationListenerService {
 public static CallNotificationListenerService instance;
 public static boolean triggerCallNotificationAction(boolean answer) { return false; }
}
