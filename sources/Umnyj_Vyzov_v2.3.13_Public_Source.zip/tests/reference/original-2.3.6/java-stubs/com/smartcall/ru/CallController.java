package com.smartcall.ru;
import android.content.Context;
public class CallController {
 public static long callRingStartTime;
 public static boolean voipIncoming, voipOngoing;
 public static void log(String value) {}
 public static void stopTts() {}
 public static void recordActiveCallState(int state) {}
 public static String lookupContactName(Context context, String number) { return null; }
}
