package com.smartcall.ru;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
public class CallControlAccessibilityService extends AccessibilityService {
 public static CallControlAccessibilityService instance;
 public static int detectCallUiState() { return 0; }
 public void onAccessibilityEvent(AccessibilityEvent event) {}
 public void onInterrupt() {}
}
