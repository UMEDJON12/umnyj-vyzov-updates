#!/usr/bin/env python3
"""Validate app-owned method/field references across all APK DEX files."""
import hashlib
import zlib
import struct
import sys
import zipfile

PREFIX = 'Lcom/smartcall/ru/'
def uleb(b, p):
    value, shift = 0, 0
    while True:
        part = b[p]; p += 1
        value |= (part & 127) << shift
        if not part & 128: return value, p
        shift += 7

def parse(b):
    assert b[:4] == b'dex\n'
    assert b[12:32] == hashlib.sha1(b[32:]).digest(), 'DEX SHA1 mismatch'
    assert struct.unpack_from('<I', b, 8)[0] == zlib.adler32(b[12:]) & 0xffffffff, 'DEX checksum mismatch'
    assert struct.unpack_from('<I', b, 32)[0] == len(b), 'DEX size mismatch'
    def word(p): return struct.unpack_from('<I', b, p)[0]
    strings = []
    for i in range(word(56)):
        p = word(word(60) + i*4)
        _, p = uleb(b, p)
        strings.append(b[p:b.index(b'\0', p)].decode('utf-8', 'replace'))
    types = [strings[word(word(68) + i*4)] for i in range(word(64))]
    protos = []
    for i in range(word(72)):
        p = word(76) + i*12
        ret = types[word(p+4)]; params_off = word(p+8)
        params = [] if not params_off else [types[struct.unpack_from('<H', b, params_off+4+j*2)[0]] for j in range(word(params_off))]
        protos.append((ret, tuple(params)))
    methods = []
    for i in range(word(88)):
        c, p, n = struct.unpack_from('<HHI', b, word(92) + i*8)
        methods.append((types[c], strings[n], protos[p]))
    fields = []
    for i in range(word(80)):
        c, t, n = struct.unpack_from('<HHI', b, word(84) + i*8)
        fields.append((types[c], strings[n], types[t]))
    classes = {}
    for i in range(word(96)):
        p = word(100)+i*32
        cls = types[word(p)]; sup_idx = word(p+8)
        parent = None if sup_idx == 0xffffffff else types[sup_idx]
        declared_methods, declared_fields = set(), set()
        data = word(p+24)
        if data:
            sizes = []
            for _ in range(4):
                size, data = uleb(b, data); sizes.append(size)
            for count in sizes[:2]:
                index = 0
                for _ in range(count):
                    delta, data = uleb(b, data); index += delta
                    _, data = uleb(b, data)
                    declared_fields.add(fields[index][1:])
            SZ = {op: 1 for op in [0x00, 0x01, 0x04, 0x07, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x1d, 0x1e, 0x21, 0x27, 0x28, 0x73, *range(0x7b, 0x90), *range(0xb0, 0xd0)]}
            SZ.update({op: 2 for op in [0x02, 0x05, 0x08, 0x13, 0x15, 0x16, 0x19, 0x1a, 0x1c, 0x1f, 0x20, 0x22, 0x23, 0x29, 0x2d, 0x2e, 0x2f, 0x30, 0x31, *range(0x32, 0x3e), *range(0x44, 0x6e), *range(0x90, 0xb0), *range(0xd0, 0xe3), 0xfe, 0xff]})
            SZ.update({op: 3 for op in [0x03, 0x06, 0x09, 0x14, 0x17, 0x1b, 0x24, 0x25, 0x26, 0x2a, 0x2b, 0x2c, *range(0x6e, 0x73), *range(0x74, 0x79), 0xfc, 0xfd]})
            SZ.update({0xfa: 4, 0xfb: 4, 0x18: 5})
            for count in sizes[2:]:
                index = 0
                for _ in range(count):
                    delta, data = uleb(b, data); index += delta
                    _, data = uleb(b, data); code_off, data = uleb(b, data)
                    declared_methods.add(methods[index][1:])
                    if code_off:
                        _, _, _, tries = struct.unpack_from('<HHHH', b, code_off)
                        _, insns_size = struct.unpack_from('<II', b, code_off + 8)
                        pc, boundaries = 0, set()
                        while pc < insns_size:
                            boundaries.add(pc)
                            w = struct.unpack_from('<H', b, code_off + 16 + pc*2)[0]
                            if w == 0x0100: pc += struct.unpack_from('<H', b, code_off + 16 + (pc+1)*2)[0] * 2 + 4
                            elif w == 0x0200: pc += struct.unpack_from('<H', b, code_off + 16 + (pc+1)*2)[0] * 4 + 2
                            elif w == 0x0300:
                                ew = struct.unpack_from('<H', b, code_off + 16 + (pc+1)*2)[0]
                                es = struct.unpack_from('<I', b, code_off + 16 + (pc+2)*2)[0]
                                pc += (es * ew + 1) // 2 + 4
                            else: pc += SZ[w & 0xff]
                        assert pc == insns_size, f'{methods[index]}: instruction boundary overflow'
                        boundaries.add(insns_size)
                        if tries > 0:
                            t_off = code_off + 16 + insns_size * 2 + (2 if insns_size % 2 else 0)
                            for t_i in range(tries):
                                s_addr, i_cnt, _ = struct.unpack_from('<IHH', b, t_off + t_i * 8)
                                assert s_addr in boundaries and (s_addr + i_cnt) in boundaries, f'{methods[index]}: invalid try block boundary' 
        classes[cls] = (parent, declared_methods, declared_fields)
    return classes, methods, fields

def verify(path):
    classes, methods, fields = {}, [], []
    with zipfile.ZipFile(path) as z:
        dex_names = [n for n in z.namelist() if n.startswith('classes') and n.endswith('.dex')]
        for name in dex_names:
            cs, ms, fs = parse(z.read(name))
            assert not (classes.keys() & cs.keys()), 'Duplicate DEX class'
            classes.update(cs); methods += ms; fields += fs
    checked = 0
    for refs, member_index in [(methods, 1), (fields, 2)]:
        for owner, *member in refs:
            if not owner.startswith(PREFIX): continue
            parent = owner
            while parent and parent.startswith(PREFIX):
                assert parent in classes, f'Missing application class: {parent}'
                info = classes[parent]
                if tuple(member) in info[member_index]: break
                parent = info[0]
            else:
                assert parent and parent.startswith('Landroid/') and member[0] in ('getActiveNotifications',), f'Missing application member: {owner} {member}'
            checked += 1
    assert 'Lcom/smartcall/ru/SmartCallFeatures;' in classes, 'Missing features DEX'
    print(f'PASS: {len(dex_names)} DEX files, {len(classes)} classes, {checked} application member references')
if __name__ == '__main__': verify(sys.argv[1])
