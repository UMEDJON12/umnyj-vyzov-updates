#!/usr/bin/env python3
"""
Generator for Android Binary XML (AXML), Resource Table (resources.arsc),
and App Icon (ic_launcher.png) for «Умный Вызов» v2.0.0 (com.smartcall.ru).
Minimum Android 7.0 (API 24), target SDK 28. OEM/device validation is required.
All android.R.attr hex IDs verified against AOSP core/res/res/values/public.xml:
  - showWhenLocked = 0x01010569
  - turnScreenOn   = 0x0101056A
"""
import struct
from PIL import Image, ImageDraw

RES_DRAWABLE_IC_LAUNCHER = 0x7F010000
RES_XML_ACCESSIBILITY_CONFIG = 0x7F020000
RES_STRING_APP_NAME = 0x7F030000
RES_STRING_ACC_DESC = 0x7F030001
RES_STRING_ACC_LABEL = 0x7F030002
RES_STRING_NOTIF_LABEL = 0x7F030003

APP_TITLE_RU = "Умный Вызов"
ACC_LABEL_RU = "Умный Вызов — Кнопки ответа и сброса"
NOTIF_LABEL_RU = "Умный Вызов — Звонки и озвучка"
ACC_DESC_RU = (
    "Позволяет принимать и завершать любые звонки (обычные вызовы, WhatsApp, "
    "Telegram, Viber, Imo и др.) кнопками громкости и датчиком приближения "
    "(поднесением к уху), а также озвучивать имя звонящего и входящие сообщения."
)

ANDROID_NS_URI = "http://schemas.android.com/apk/res/android"
ANDROID_NS_PREFIX = "android"

# Exact attribute resource IDs from AOSP core/res/res/values/public.xml
ATTR_IDS = {
    "theme": 0x01010000,
    "label": 0x01010001,
    "icon": 0x01010002,
    "name": 0x01010003,
    "permission": 0x01010006,
    "enabled": 0x0101000E,
    "exported": 0x01010010,
    "taskAffinity": 0x01010012,
    "stateNotNeeded": 0x01010016,
    "excludeFromRecents": 0x01010017,
    "launchMode": 0x0101001D,
    "configChanges": 0x0101001F,
    "description": 0x01010020,
    "resource": 0x01010025,
    "minSdkVersion": 0x0101020C,
    "versionCode": 0x0101021B,
    "versionName": 0x0101021C,
    "settingsActivity": 0x01010225,
    "noHistory": 0x0101022D,
    "targetSdkVersion": 0x01010270,
    "allowBackup": 0x01010280,
    "accessibilityEventTypes": 0x01010380,
    "accessibilityFeedbackType": 0x01010382,
    "notificationTimeout": 0x01010383,
    "accessibilityFlags": 0x01010384,
    "canRetrieveWindowContent": 0x01010385,
    "showOnLockScreen": 0x010103C9,
    "canRequestFilterKeyEvents": 0x010103D9,
    "canPerformGestures": 0x0101050D,
    "showWhenLocked": 0x01010569,
    "turnScreenOn": 0x0101056A,
}

TYPE_REFERENCE = 0x01
TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_HEX = 0x11
TYPE_INT_BOOLEAN = 0x12


def align4(data: bytes) -> bytes:
    rem = len(data) % 4
    if rem:
        return data + b"\x00" * (4 - rem)
    return data


def build_utf16_string_pool(strings: list[str]) -> bytes:
    count = len(strings)
    offsets = []
    encoded_blobs = bytearray()
    for s in strings:
        offsets.append(len(encoded_blobs))
        u16 = s.encode("utf-16le")
        char_len = len(u16) // 2
        encoded_blobs += struct.pack("<H", char_len) + u16 + b"\x00\x00"

    encoded_blobs = bytearray(align4(bytes(encoded_blobs)))
    header_size = 28
    strings_start = header_size + count * 4
    total_size = strings_start + len(encoded_blobs)

    header = struct.pack(
        "<HHIIIIII",
        0x0001,
        header_size,
        total_size,
        count,
        0,
        0,
        strings_start,
        0,
    )
    offset_table = b"".join(struct.pack("<I", off) for off in offsets)
    return header + offset_table + bytes(encoded_blobs)


class AxmlBuilder:
    def __init__(self, used_attr_names: list[str], other_strings: list[str]):
        self.sorted_attrs = sorted(used_attr_names, key=lambda n: ATTR_IDS[n])
        self.attr_res_ids = [ATTR_IDS[n] for n in self.sorted_attrs]

        self.strings = list(self.sorted_attrs)
        for s in other_strings:
            if s not in self.strings:
                self.strings.append(s)
        self.str_idx = {s: i for i, s in enumerate(self.strings)}
        self.chunks = bytearray()
        self._tag_stack = []

    def s(self, val: str) -> int:
        if val not in self.str_idx:
            self.str_idx[val] = len(self.strings)
            self.strings.append(val)
        return self.str_idx[val]

    def start_namespace(self, prefix: str, uri: str, line: int = 1):
        p_idx = self.s(prefix)
        u_idx = self.s(uri)
        self.chunks += struct.pack(
            "<HHIIIII",
            0x0100, 16, 24, line, 0xFFFFFFFF, p_idx, u_idx
        )

    def end_namespace(self, prefix: str, uri: str, line: int = 1):
        assert len(self._tag_stack) == 0, f"Unclosed tags remaining: {self._tag_stack}"
        p_idx = self.s(prefix)
        u_idx = self.s(uri)
        self.chunks += struct.pack(
            "<HHIIIII",
            0x0101, 16, 24, line, 0xFFFFFFFF, p_idx, u_idx
        )

    def start_element(self, tag: str, attrs: list[tuple], line: int = 1):
        self._tag_stack.append(tag)
        tag_idx = self.s(tag)

        processed_attrs = []
        for ns, name, dtype, val in attrs:
            ns_idx = self.s(ns) if ns else 0xFFFFFFFF
            name_idx = self.s(name)
            if dtype == TYPE_STRING:
                v_idx = self.s(str(val))
                raw_val = v_idx
                t_data = v_idx
            elif dtype == TYPE_INT_BOOLEAN:
                raw_val = 0xFFFFFFFF
                t_data = 0xFFFFFFFF if val else 0
            else:
                raw_val = 0xFFFFFFFF
                t_data = int(val) & 0xFFFFFFFF
            processed_attrs.append((ns_idx, name_idx, raw_val, dtype, t_data))

        processed_attrs.sort(
            key=lambda x: (0 if x[1] < len(self.sorted_attrs) else 1, x[1])
        )

        num_attrs = len(processed_attrs)
        chunk_size = 36 + 20 * num_attrs
        header = struct.pack(
            "<HHIIIIIHHHHHH",
            0x0102,
            16,
            chunk_size,
            line,
            0xFFFFFFFF,
            0xFFFFFFFF,
            tag_idx,
            20,
            20,
            num_attrs,
            0,
            0,
            0,
        )
        assert len(header) == 36

        attr_bytes = bytearray()
        for ns_idx, name_idx, raw_val, dtype, t_data in processed_attrs:
            attr_bytes += struct.pack(
                "<IIIHBBI",
                ns_idx,
                name_idx,
                raw_val,
                8,
                0,
                dtype,
                t_data,
            )
        self.chunks += header + attr_bytes

    def end_element(self, tag: str, line: int = 1):
        assert self._tag_stack and self._tag_stack[-1] == tag, (
            f"Tag mismatch: closing </{tag}> but top of stack is {self._tag_stack}"
        )
        self._tag_stack.pop()
        tag_idx = self.s(tag)
        self.chunks += struct.pack(
            "<HHIIIII",
            0x0103, 16, 24, line, 0xFFFFFFFF, 0xFFFFFFFF, tag_idx
        )

    def build(self) -> bytes:
        assert len(self._tag_stack) == 0, f"Unclosed tags: {self._tag_stack}"
        string_pool = build_utf16_string_pool(self.strings)
        res_map_size = 8 + 4 * len(self.attr_res_ids)
        res_map = struct.pack("<HHI", 0x0180, 8, res_map_size) + b"".join(
            struct.pack("<I", rid) for rid in self.attr_res_ids
        )
        body = string_pool + res_map + bytes(self.chunks)
        total_size = 8 + len(body)
        return struct.pack("<HHI", 0x0003, 8, total_size) + body


def build_manifest_axml(
    package_name: str = "com.smartcall.ru",
    version_code: int = 29,
    version_name: str = "2.3.6",
    min_sdk: int = 24,
    target_sdk: int = 28,
) -> bytes:
    used_attrs = [
        "theme",
        "label",
        "icon",
        "name",
        "permission",
        "enabled",
        "exported",
        "taskAffinity",
        "stateNotNeeded",
        "excludeFromRecents",
        "launchMode",
        "configChanges",
        "resource",
        "minSdkVersion",
        "versionCode",
        "versionName",
        "noHistory",
        "targetSdkVersion",
        "allowBackup",
        "showOnLockScreen",
        "showWhenLocked",
        "turnScreenOn",
    ]
    b = AxmlBuilder(used_attrs, [ANDROID_NS_PREFIX, ANDROID_NS_URI, "package", package_name])
    ns = ANDROID_NS_URI

    b.start_namespace(ANDROID_NS_PREFIX, ANDROID_NS_URI, 2)

    b.start_element(
        "manifest",
        [
            (ns, "versionCode", TYPE_INT_DEC, version_code),
            (ns, "versionName", TYPE_STRING, version_name),
            (None, "package", TYPE_STRING, package_name),
        ],
        2,
    )

    b.start_element(
        "uses-sdk",
        [
            (ns, "minSdkVersion", TYPE_INT_DEC, min_sdk),
            (ns, "targetSdkVersion", TYPE_INT_DEC, target_sdk),
        ],
        4,
    )
    b.end_element("uses-sdk", 4)

    permissions = [
        "android.permission.READ_PHONE_STATE",
        "android.permission.ANSWER_PHONE_CALLS",
        "android.permission.CALL_PHONE",
        "android.permission.READ_CALL_LOG",
        "android.permission.READ_CONTACTS",
        "android.permission.RECEIVE_SMS",
        "android.permission.READ_SMS",
        "android.permission.QUERY_ALL_PACKAGES",
        "android.permission.MODIFY_AUDIO_SETTINGS",
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
        "android.permission.FOREGROUND_SERVICE",
        "android.permission.VIBRATE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
    ]
    line = 6
    for perm in permissions:
        b.start_element("uses-permission", [(ns, "name", TYPE_STRING, perm)], line)
        b.end_element("uses-permission", line)
        line += 1

    # Add <queries> for TTS engines on Android 11-17
    b.start_element("queries", [], line)
    b.start_element("intent", [], line + 1)
    b.start_element(
        "action",
        [(ns, "name", TYPE_STRING, "android.intent.action.TTS_SERVICE")],
        line + 2,
    )
    b.end_element("action", line + 2)
    b.end_element("intent", line + 3)
    b.end_element("queries", line + 4)
    line += 5

    b.start_element(
        "application",
        [
            (ns, "theme", TYPE_REFERENCE, 0x0103000C),
            (ns, "label", TYPE_STRING, APP_TITLE_RU),
            (ns, "icon", TYPE_REFERENCE, RES_DRAWABLE_IC_LAUNCHER),
            (ns, "allowBackup", TYPE_INT_BOOLEAN, True),
        ],
        line,
    )
    line += 1

    # 1. MainActivity
    b.start_element(
        "activity",
        [
            (ns, "label", TYPE_STRING, APP_TITLE_RU),
            (ns, "name", TYPE_STRING, f"{package_name}.MainActivity"),
            (ns, "exported", TYPE_INT_BOOLEAN, True),
            (ns, "launchMode", TYPE_INT_DEC, 1),
            (ns, "configChanges", TYPE_INT_HEX, 0x000004A0),
        ],
        line,
    )
    b.start_element("intent-filter", [], line + 1)
    b.start_element("action", [(ns, "name", TYPE_STRING, "android.intent.action.MAIN")], line + 2)
    b.end_element("action", line + 2)
    b.start_element("category", [(ns, "name", TYPE_STRING, "android.intent.category.LAUNCHER")], line + 3)
    b.end_element("category", line + 3)
    b.end_element("intent-filter", line + 4)
    b.end_element("activity", line + 5)
    line += 6

    # 2. CallControlAccessibilityService
    b.start_element(
        "service",
        [
            (ns, "label", TYPE_STRING, ACC_LABEL_RU),
            (ns, "name", TYPE_STRING, f"{package_name}.CallControlAccessibilityService"),
            (ns, "permission", TYPE_STRING, "android.permission.BIND_ACCESSIBILITY_SERVICE"),
            (ns, "enabled", TYPE_INT_BOOLEAN, True),
            (ns, "exported", TYPE_INT_BOOLEAN, True),
        ],
        line,
    )
    b.start_element("intent-filter", [], line + 1)
    b.start_element(
        "action",
        [(ns, "name", TYPE_STRING, "android.accessibilityservice.AccessibilityService")],
        line + 2,
    )
    b.end_element("action", line + 2)
    b.end_element("intent-filter", line + 3)
    b.start_element(
        "meta-data",
        [
            (ns, "name", TYPE_STRING, "android.accessibilityservice"),
            (ns, "resource", TYPE_REFERENCE, RES_XML_ACCESSIBILITY_CONFIG),
        ],
        line + 4,
    )
    b.end_element("meta-data", line + 4)
    b.end_element("service", line + 5)
    line += 6

    # 3. CallNotificationListenerService
    b.start_element(
        "service",
        [
            (ns, "label", TYPE_STRING, NOTIF_LABEL_RU),
            (ns, "name", TYPE_STRING, f"{package_name}.CallNotificationListenerService"),
            (ns, "permission", TYPE_STRING, "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"),
            (ns, "enabled", TYPE_INT_BOOLEAN, True),
            (ns, "exported", TYPE_INT_BOOLEAN, True),
        ],
        line,
    )
    b.start_element("intent-filter", [], line + 1)
    b.start_element(
        "action",
        [(ns, "name", TYPE_STRING, "android.service.notification.NotificationListenerService")],
        line + 2,
    )
    b.end_element("action", line + 2)
    b.end_element("intent-filter", line + 3)
    b.end_element("service", line + 4)
    line += 5

    # 4. ScreenAndVolumeReceiver (Static BroadcastReceiver for SMS_RECEIVED and PHONE_STATE)
    b.start_element(
        "receiver",
        [
            (ns, "name", TYPE_STRING, f"{package_name}.ScreenAndVolumeReceiver"),
            (ns, "enabled", TYPE_INT_BOOLEAN, True),
            (ns, "exported", TYPE_INT_BOOLEAN, True),
        ],
        line,
    )
    b.start_element("intent-filter", [], line + 1)
    b.start_element(
        "action",
        [(ns, "name", TYPE_STRING, "android.provider.Telephony.SMS_RECEIVED")],
        line + 2,
    )
    b.end_element("action", line + 2)
    b.start_element(
        "action",
        [(ns, "name", TYPE_STRING, "android.intent.action.PHONE_STATE")],
        line + 3,
    )
    b.end_element("action", line + 3)
    b.end_element("intent-filter", line + 4)
    b.end_element("receiver", line + 5)
    line += 6

    b.end_element("application", line)
    b.end_element("manifest", line + 1)
    b.end_namespace(ANDROID_NS_PREFIX, ANDROID_NS_URI, line + 1)

    return b.build()


def build_accessibility_config_axml(package_name: str = "com.smartcall.ru") -> bytes:
    used_attrs = [
        "description",
        "settingsActivity",
        "accessibilityEventTypes",
        "accessibilityFeedbackType",
        "notificationTimeout",
        "accessibilityFlags",
        "canRetrieveWindowContent",
        "canRequestFilterKeyEvents",
        "canPerformGestures",
    ]
    b = AxmlBuilder(used_attrs, [ANDROID_NS_PREFIX, ANDROID_NS_URI])
    ns = ANDROID_NS_URI

    b.start_namespace(ANDROID_NS_PREFIX, ANDROID_NS_URI, 2)
    b.start_element(
        "accessibility-service",
        [
            (ns, "description", TYPE_REFERENCE, RES_STRING_ACC_DESC),
            (ns, "settingsActivity", TYPE_STRING, f"{package_name}.MainActivity"),
            (ns, "accessibilityEventTypes", TYPE_INT_HEX, 0xFFFFFFFF),
            (ns, "accessibilityFeedbackType", TYPE_INT_HEX, 0x00000010),
            (ns, "notificationTimeout", TYPE_INT_DEC, 50),
            (ns, "accessibilityFlags", TYPE_INT_HEX, 0x00000073),
            (ns, "canRetrieveWindowContent", TYPE_INT_BOOLEAN, True),
            (ns, "canRequestFilterKeyEvents", TYPE_INT_BOOLEAN, True),
            (ns, "canPerformGestures", TYPE_INT_BOOLEAN, True),
        ],
        2,
    )
    b.end_element("accessibility-service", 3)
    b.end_namespace(ANDROID_NS_PREFIX, ANDROID_NS_URI, 3)
    return b.build()


def build_resources_arsc(package_name: str = "com.smartcall.ru") -> bytes:
    global_strings = [
        "res/drawable/ic_launcher.png",
        "res/xml/accessibility_config.xml",
        APP_TITLE_RU,
        ACC_DESC_RU,
        ACC_LABEL_RU,
        NOTIF_LABEL_RU,
    ]
    global_pool = build_utf16_string_pool(global_strings)

    type_strings = ["drawable", "xml", "string"]
    type_pool = build_utf16_string_pool(type_strings)

    key_strings = [
        "ic_launcher",
        "accessibility_service_config",
        "app_name",
        "accessibility_service_description",
        "accessibility_service_label",
        "notification_listener_label",
    ]
    key_pool = build_utf16_string_pool(key_strings)

    def make_type_chunks(type_id: int, entries: list[tuple[int, int]]) -> bytes:
        count = len(entries)
        spec_size = 16 + count * 4
        spec_chunk = struct.pack(
            "<HHIBBHI",
            0x0202,
            16,
            spec_size,
            type_id,
            0,
            0,
            count,
        ) + (struct.pack("<I", 0) * count)

        config_size = 64
        config_bytes = struct.pack("<I", config_size) + (b"\x00" * (config_size - 4))
        header_size = 20 + config_size
        entries_start = header_size + count * 4
        entry_blobs = bytearray()
        offsets = []
        for key_idx, val_idx in entries:
            offsets.append(len(entry_blobs))
            entry_blobs += struct.pack(
                "<HHIHBBI",
                8,
                0,
                key_idx,
                8,
                0,
                TYPE_STRING,
                val_idx,
            )
        type_size = entries_start + len(entry_blobs)
        type_header = (
            struct.pack(
                "<HHIBBHII",
                0x0201,
                header_size,
                type_size,
                type_id,
                0,
                0,
                count,
                entries_start,
            )
            + config_bytes
        )
        offset_bytes = b"".join(struct.pack("<I", off) for off in offsets)
        return spec_chunk + type_header + offset_bytes + bytes(entry_blobs)

    t1 = make_type_chunks(1, [(0, 0)])
    t2 = make_type_chunks(2, [(1, 1)])
    t3 = make_type_chunks(3, [(2, 2), (3, 3), (4, 4), (5, 5)])

    pkg_header_size = 288
    type_strings_off = pkg_header_size
    key_strings_off = pkg_header_size + len(type_pool)
    pkg_body = type_pool + key_pool + t1 + t2 + t3
    pkg_total_size = pkg_header_size + len(pkg_body)

    pkg_name_u16 = package_name.encode("utf-16le")
    pkg_name_padded = pkg_name_u16 + b"\x00" * (256 - len(pkg_name_u16))

    pkg_header = (
        struct.pack("<HHII", 0x0200, pkg_header_size, pkg_total_size, 0x7F)
        + pkg_name_padded
        + struct.pack(
            "<IIIII",
            type_strings_off,
            len(type_strings),
            key_strings_off,
            len(key_strings),
            0,
        )
    )
    assert len(pkg_header) == 288

    pkg_chunk = pkg_header + pkg_body
    total_arsc_size = 12 + len(global_pool) + len(pkg_chunk)
    table_header = struct.pack("<HHII", 0x0002, 12, total_arsc_size, 1)
    return table_header + global_pool + pkg_chunk


def build_icon_png(output_path: str):
    size = 192
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    draw.rounded_rectangle([8, 8, size - 8, size - 8], radius=42, fill=(16, 137, 62, 255))
    draw.rounded_rectangle([14, 14, size - 14, size - 14], radius=38, fill=(22, 163, 74, 255))

    draw.rounded_rectangle([152, 46, 166, 82], radius=6, fill=(255, 255, 255, 235))
    draw.rounded_rectangle([152, 96, 166, 132], radius=6, fill=(255, 215, 64, 245))

    draw.ellipse([36, 36, 144, 144], fill=(255, 255, 255, 35))

    draw.rounded_rectangle([54, 52, 82, 84], radius=10, fill=(255, 255, 255, 255))
    draw.rounded_rectangle([98, 96, 126, 128], radius=10, fill=(255, 255, 255, 255))
    draw.polygon([(58, 76), (78, 62), (118, 102), (104, 122)], fill=(255, 255, 255, 255))

    img.save(output_path, "PNG")
