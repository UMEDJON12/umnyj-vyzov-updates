#!/usr/bin/env python3
"""Run IR regressions plus pure Java policy/answer-flow tests on a host JVM."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile
ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--ecj-jar', default=os.environ.get('ECJ_JAR'))
a = p.parse_args()
subprocess.run([sys.executable, str(ROOT / 'test_regressions.py')], check=True)
subprocess.run([sys.executable, '-m', 'unittest', '-v', 'test_build_guards', 'test_control_flow'], cwd=ROOT, check=True)
with tempfile.TemporaryDirectory() as t:
    sources = [ROOT / 'java/com/smartcall/ru/SpeechPolicy.java', ROOT / 'java/com/smartcall/ru/AnswerFlow.java', ROOT / 'java-tests/com/smartcall/ru/FeatureTests.java']
    compiler = ['java', '-jar', a.ecj_jar, '-8', '-proc:none'] if a.ecj_jar else ['javac', '-source', '8', '-target', '8']
    subprocess.run(compiler + ['-d', t] + [str(x) for x in sources], check=True)
    subprocess.run(['java', '-cp', t, 'com.smartcall.ru.FeatureTests'], check=True)
