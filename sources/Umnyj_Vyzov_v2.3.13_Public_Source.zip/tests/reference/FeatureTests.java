package com.smartcall.ru;
import java.util.ArrayDeque;

public class FeatureTests {
 private static int assertions;
 private static void check(boolean value, String message) { assertions++; if (!value) throw new AssertionError(message); }
 private static final class Fake implements AnswerFlow.Actions, AnswerFlow.Scheduler {
  int state=1, telecom, notifications, ui, completed=-1;
  boolean throwTelecom;
  ArrayDeque<Runnable> queue=new ArrayDeque<Runnable>();
  public int liveState(){return state;}
  public void telecom(){telecom++;if(throwTelecom)throw new RuntimeException("denied");}
  public void notification(){notifications++;}
  public void ui(){ui++;}
  public void completed(int observed){completed=observed;}
  public void log(String s){}
  public void later(Runnable r,long millis){check(millis>0,"retries must be asynchronous");queue.add(r);}
  void next(){queue.remove().run();}
 }
 public static void main(String[] args) {
  check(SpeechPolicy.cleanCaller("Звонит Иван.").equals("Иван"),"pure caller name");
  check(SpeechPolicy.cleanCaller("Позвонить Иван... ").equals("Иван"),"no spoken period");
  check(SpeechPolicy.cleanCaller("Звонок Ватсап от Мохшариф").equals("Мохшариф"),"no call prefix");
  check(SpeechPolicy.cleanCaller("Запрос для Meta AI или поиска").isEmpty(),"Meta AI must not be a caller");
  check(!SpeechPolicy.callerNode("com.whatsapp:id/search", "Иван", true),"editable field rejected");
  check(!SpeechPolicy.callerNode("com.whatsapp:id/search", "Поиск", false),"search rejected");
  check(!SpeechPolicy.callerNode("com.whatsapp:id/name", "Текст чата", false),"generic node rejected");
  check(SpeechPolicy.callerNode("com.android.incallui:id/contact_name", "Иван", false),"known caller node accepted");
  check(SpeechPolicy.channel("com.whatsapp.w4b").equals("wa"),"business WhatsApp profile");
  check(SpeechPolicy.channel("org.telegram.plus").equals("tg"),"Plus Messenger profile");
  check(SpeechPolicy.channel("org.thunderdog.challegram").equals("tg"),"Telegram X profile");
  check(SpeechPolicy.channel("sim").equals("sms"),"SIM SMS profile");
  check(!SpeechPolicy.voiceKey("wa").equals(SpeechPolicy.voiceKey("sim")),"independent voice preferences");
  SpeechPolicy.Dedup d=new SpeechPolicy.Dedup();
  check(d.accept("wa:1","Иван:привет:100"),"first message");
  check(!d.accept("wa:1","Иван:привет:100"),"same update not repeated");
  check(d.accept("wa:1","Иван:второе сообщение:101"),"new message within same notification");
  check(d.accept("tg:2","Иван:привет:100"),"other app independent");
  Fake f=new Fake();AnswerFlow flow=new AnswerFlow(f,f);flow.start();
  check(f.telecom==1 && f.completed==-1,"void Telecom success is not connected");
  f.next();check(f.notifications==1,"still incoming uses notification fallback");
  f.next();check(f.ui==1,"still incoming uses UI fallback");
  f.next();check(f.completed==1 && f.queue.isEmpty(),"bounded retries leave real incoming state");
  f=new Fake();flow=new AnswerFlow(f,f);flow.start();f.state=2;f.next();
  check(f.completed==2 && f.notifications==0 && f.ui==0,"confirmed answer prevents second action");
  f=new Fake();flow=new AnswerFlow(f,f);flow.start();f.state=0;f.next();
  check(f.completed==0 && f.notifications==0,"remote hangup stops fallback");
  f=new Fake();flow=new AnswerFlow(f,f);flow.start();flow.cancel();f.next();
  check(f.notifications==0,"explicit cancel prevents delayed answer");
  f=new Fake();f.throwTelecom=true;flow=new AnswerFlow(f,f);flow.start();f.next();
  check(f.notifications==1,"Telecom denial still tries notification");
  f=new Fake();f.state=2;flow=new AnswerFlow(f,f);flow.start();
  check(f.telecom==0 && f.ui==0,"already accepted call never gets another answer");
  System.out.println("PASS: " + assertions + " host JVM assertions");
 }
}
