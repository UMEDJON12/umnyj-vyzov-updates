package com.smartcall.ru;

import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Host-only tests: real android.content.SharedPreferences interface, fake store. */
public class SettingsMigrationTest {
    static int checks;

    static void check(boolean ok, String msg) {
        checks++;
        if (!ok) throw new AssertionError(msg);
    }

    static final class FakePrefs implements SharedPreferences {
        final Map<String, Object> data = new HashMap<>();
        boolean failCommit;

        FakePrefs put(String k, Object v) { data.put(k, v); return this; }

        public Map<String, ?> getAll() { return new HashMap<>(data); }
        public String getString(String k, String d) {
            Object v = data.get(k); return v instanceof String ? (String) v : d;
        }
        @SuppressWarnings("unchecked")
        public Set<String> getStringSet(String k, Set<String> d) {
            Object v = data.get(k); return v instanceof Set ? (Set<String>) v : d;
        }
        public int getInt(String k, int d) { Object v = data.get(k); return v instanceof Integer ? (Integer) v : d; }
        public long getLong(String k, long d) { Object v = data.get(k); return v instanceof Long ? (Long) v : d; }
        public float getFloat(String k, float d) { Object v = data.get(k); return v instanceof Float ? (Float) v : d; }
        public boolean getBoolean(String k, boolean d) { Object v = data.get(k); return v instanceof Boolean ? (Boolean) v : d; }
        public boolean contains(String k) { return data.containsKey(k); }
        public Editor edit() { return new Ed(); }
        public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) {}
        public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) {}

        final class Ed implements Editor {
            final Map<String, Object> pending = new HashMap<>();
            final Set<String> removals = new HashSet<>();
            boolean clear;
            public Editor putString(String k, String v) { pending.put(k, v); return this; }
            public Editor putStringSet(String k, Set<String> v) { pending.put(k, v); return this; }
            public Editor putInt(String k, int v) { pending.put(k, v); return this; }
            public Editor putLong(String k, long v) { pending.put(k, v); return this; }
            public Editor putFloat(String k, float v) { pending.put(k, v); return this; }
            public Editor putBoolean(String k, boolean v) { pending.put(k, v); return this; }
            public Editor remove(String k) { removals.add(k); return this; }
            public Editor clear() { clear = true; return this; }
            public boolean commit() {
                if (failCommit) return false;
                if (clear) data.clear();
                for (String k : removals) data.remove(k);
                data.putAll(pending);
                return true;
            }
            public void apply() { commit(); }
        }
    }

    public static void main(String[] args) {
        emptyInstallUsesSafeDefaults();
        explicitDisableIsNeverReenabled();
        legacySplitIntoThreeProfiles();
        repeatsAndVoicesAreCopied();
        migrationIsIdempotent();
        unknownKeysSurvive();
        failedCommitRetries();
        textSwitchBlocksMessageReading();

        System.out.println("PASS: " + checks + " SettingsMigration assertions");
    }

    static void emptyInstallUsesSafeDefaults() {
        FakePrefs p = new FakePrefs();
        check(SettingsMigration.migrate(p), "first run migrates");
        check(p.getInt(SettingsMigration.KEY_SCHEMA, 0) == 2, "schema written");
        check(p.getBoolean("call_enabled_sim", false), "SIM calls keep runtime default");
        check(p.getBoolean("msg_enabled_sms", false), "SMS messages keep runtime default");
        check(p.getInt("msg_lock_mode_sms", -1) == 0, "locked screen default is silent");
        check(p.getInt("call_delay_sms", -1) == 0, "delay starts at zero");
        check(p.getInt("call_repeat_wa", -1) == 2, "legacy default repeat copied");
    }

    static void explicitDisableIsNeverReenabled() {
        FakePrefs p = new FakePrefs()
                .put("tts_enabled", true)
                .put("tts_app_wa", false)
                .put("tts_sms_text", false);
        SettingsMigration.migrate(p);
        check(!p.getBoolean("call_enabled_wa", true), "explicitly disabled WA stays off");
        check(!p.getBoolean("msg_enabled_wa", true), "WA messages stay off");
        check(!p.getBoolean("msg_enabled_sms", true), "text switch off blocks SMS");
        check(!p.getBoolean("msg_read_text_sms", true), "text reading stays off");
        check(p.getBoolean("call_enabled_tg", false), "untouched TG keeps default");
    }

    static void legacySplitIntoThreeProfiles() {
        FakePrefs p = new FakePrefs().put("tts_app_other", false);
        SettingsMigration.migrate(p);
        for (String c : new String[]{"other", "viber", "imo"}) {
            check(!p.getBoolean("call_enabled_" + c, true), c + " call inherits disabled other");
            check(!p.getBoolean("msg_enabled_" + c, true), c + " messages inherit disabled other");
        }
        // Independent afterwards: writing one profile must not move another.
        p.edit().putBoolean("call_enabled_viber", true).commit();
        check(!p.getBoolean("call_enabled_other", true), "other unchanged");
        check(!p.getBoolean("call_enabled_imo", true), "imo unchanged");
    }

    static void repeatsAndVoicesAreCopied() {
        FakePrefs p = new FakePrefs()
                .put("tts_repeat", 5)
                .put("tts_eng_tg", "ru-ru-engine")
                .put("tts_voice_tg", "alice")
                .put("tts_voice_name", "legacy-voice")
                .put("tts_rate_tg", 150);
        SettingsMigration.migrate(p);
        for (String c : SettingsMigration.CALL_CHANNELS) {
            check(p.getInt("call_repeat_" + c, -1) == 5, c + " repeat");
        }
        check("ru-ru-engine".equals(p.getString("call_eng_tg", null)), "engine copied");
        check("alice".equals(p.getString("call_voice_tg", null)), "voice copied");
        check(150 == p.getInt("call_rate_tg", -1), "rate copied");
        check("legacy-voice".equals(p.getString("call_voice_sim", null)), "SIM voice fallback");
        check("default".equals(p.getString("call_voice_viber", null)), "split voice default");
        check(150 == p.getInt("msg_rate_tg", -1), "message rate copied");
    }

    static void migrationIsIdempotent() {
        FakePrefs p = new FakePrefs().put("tts_repeat", 3);
        check(SettingsMigration.migrate(p), "first run");
        p.edit().putInt("call_repeat_sim", 4).commit();
        check(!SettingsMigration.migrate(p), "second run is a no-op");
        check(p.getInt("call_repeat_sim", -1) == 4, "user change survives re-run");
    }

    static void unknownKeysSurvive() {
        FakePrefs p = new FakePrefs().put("future_key", "keep-me").put("tts_repeat", 2);
        SettingsMigration.migrate(p);
        check("keep-me".equals(p.getString("future_key", null)), "unknown key kept");
    }

    static void failedCommitRetries() {
        FakePrefs p = new FakePrefs();
        p.failCommit = true;
        check(!SettingsMigration.migrate(p), "failed commit reported");
        check(p.getInt(SettingsMigration.KEY_SCHEMA, 0) == 0, "no marker after failure");
        p.failCommit = false;
        check(SettingsMigration.migrate(p), "retry succeeds");
        check(p.getInt(SettingsMigration.KEY_SCHEMA, 0) == 2, "marker after retry");
    }

    static void textSwitchBlocksMessageReading() {
        FakePrefs p = new FakePrefs().put("tts_sms_text", false).put("tts_app_sms", true);
        SettingsMigration.migrate(p);
        check(!p.getBoolean("msg_enabled_sms", true), "no message speech");
        check(p.getInt("msg_lock_mode_sms", -1) == 0, "lock mode silent");
    }
}
