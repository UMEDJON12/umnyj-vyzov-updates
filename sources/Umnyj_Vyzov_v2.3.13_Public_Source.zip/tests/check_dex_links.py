#!/usr/bin/env python3
"""Check app-owned DEX references; inherited platform members are explicitly deferred.

Uses the original project's parser for DEX checksums/instruction/try boundaries.
Does NOT check Android, Java or interface member availability, access flags or ART.
"""
import argparse
import importlib.util
from pathlib import Path
from zipfile import ZipFile

parser_file = Path(__file__).resolve().parent / 'reference' / 'original-2.3.6' / 'verify_apk_links.py'
if not parser_file.exists():  # fallback for the original workspace layout
    parser_file = Path('/root/workspace/smartcall-work/Umnyj_Vyzov_v2.3.6/verify_apk_links.py')
spec = importlib.util.spec_from_file_location('original_dex_parser', parser_file)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    arg = argparse.ArgumentParser(description=__doc__)
    arg.add_argument('apk', type=Path)
    a = arg.parse_args()
    with ZipFile(a.apk) as z:
        assert z.testzip() is None, 'invalid ZIP CRC'
        names = [n for n in z.namelist() if n.startswith('classes') and n.endswith('.dex')]
        assert names == ['classes.dex'], f'expected one DEX, got {names}'
        classes, methods, fields = module.parse(z.read(names[0]))
    checked = 0
    deferred = set()
    for refs, index in ((methods, 1), (fields, 2)):
        for owner, *member in refs:
            if not owner.startswith(module.PREFIX):
                continue
            current = owner
            seen = set()
            while current and current.startswith(module.PREFIX):
                assert current not in seen, f'application superclass cycle: {current}'
                seen.add(current)
                assert current in classes, f'missing application class: {current}'
                info = classes[current]
                if tuple(member) in info[index]:
                    checked += 1
                    break
                current = info[0]
            else:
                assert current, f'unresolved application member: {owner}, {member}'
                deferred.add((current, owner, repr(member)))
    print(f'PASS bounded checks: {len(names)} DEX, {len(classes)} classes, {checked} app-owned member references resolved')
    print(f'DEFERRED {len(deferred)} app-owner references potentially inherited from non-app superclasses:')
    for item in sorted(deferred): print('  ', *item)
    print('External APIs, inheritance via interfaces, access flags, verifier and behavior not validated.')

if __name__ == '__main__':
    main()
