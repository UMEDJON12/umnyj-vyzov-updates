package com.smartcall.ru.update.test.fake;

import com.smartcall.ru.update.HttpTransport;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fake HTTP-транспорт для host-тестов: скриптованные ответы по URL,
 * включая редиректы, сетевые исключения и обрыв тела после N байт.
 * Реальной сети здесь нет и не нужно.
 */
public final class FakeTransport implements HttpTransport {

    /** Один скриптованный ответ. */
    public static final class Script {
        public int status = 200;
        public String location;
        public long contentLength = -1;
        public byte[] body = new byte[0];
        /** Тело оборвётся с IOException после этого числа байт (-1 — нет). */
        public int failAfterBytes = -1;
        /** execute() бросит это исключение вместо ответа. */
        public IOException openError;
        /** Сколько раз скрипт уже отдан (для последовательностей). */
        int uses;

        public Script(int status, byte[] body) {
            this.status = status;
            this.body = body == null ? new byte[0] : body;
            this.contentLength = this.body.length;
        }

        public static Script json(int status, String body) {
            return new Script(status, body.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }

        public static Script ok(String body) {
            return json(200, body);
        }

        public static Script okBytes(byte[] body) {
            return new Script(200, body);
        }

        public static Script redirect(String location) {
            Script s = new Script(302, new byte[0]);
            s.location = location;
            s.contentLength = -1;
            return s;
        }

        public static Script httpError(int status) {
            return new Script(status, new byte[0]);
        }

        public static Script networkError(IOException e) {
            Script s = new Script(200, new byte[0]);
            s.openError = e;
            return s;
        }

        /** Обрыв соединения после failAfter байт (тело объявлено длиной declared). */
        public static Script brokenStream(long declared, int failAfter) {
            Script s = new Script(200, new byte[0]);
            s.body = new byte[(int) Math.max(declared, 0)];
            for (int i = 0; i < s.body.length; i++) {
                s.body[i] = (byte) (i * 31 + 7);
            }
            s.contentLength = declared;
            s.failAfterBytes = failAfter;
            return s;
        }

        /** Объявить длину независимо от фактического тела. */
        public Script declaredLength(long len) {
            this.contentLength = len;
            return this;
        }
    }

    private final Map<String, List<Script>> scripts = new HashMap<String, List<Script>>();
    private final Map<String, Integer> calls = new HashMap<String, Integer>();
    private final List<String> requestLog = new ArrayList<String>();

    /** Один и тот же ответ на каждый запрос URL. */
    public FakeTransport on(String url, Script script) {
        List<Script> list = new ArrayList<Script>();
        list.add(script);
        scripts.put(url, list);
        return this;
    }

    /** Последовательность ответов (по одному на каждый запрос). */
    public FakeTransport sequence(String url, Script... seq) {
        List<Script> list = new ArrayList<Script>();
        for (Script s : seq) {
            list.add(s);
        }
        scripts.put(url, list);
        return this;
    }

    public int calls(String url) {
        Integer c = calls.get(url);
        return c == null ? 0 : c;
    }

    public List<String> requestLog() {
        return requestLog;
    }

    @Override
    public Reply execute(String url, int connectTimeoutMs, int readTimeoutMs) throws IOException {
        requestLog.add(url);
        Integer c = calls.get(url);
        calls.put(url, c == null ? 1 : c + 1);

        List<Script> list = scripts.get(url);
        if (list == null || list.isEmpty()) {
            throw new java.net.UnknownHostException("нет скрипта для " + url);
        }
        Script s = list.get(0);
        if (list.size() > 1) {
            int idx = Math.min(s.uses, list.size() - 1);
            s = list.get(idx);
        }
        s.uses++;
        if (s.openError != null) {
            throw s.openError;
        }
        InputStream body = s.body.length == 0 && s.failAfterBytes < 0
                ? new ByteArrayInputStream(new byte[0])
                : new FlakyStream(s.body, s.failAfterBytes);
        return new Reply(s.status, s.location, s.contentLength, body);
    }

    /** Поток, который после N байт бросает IOException (обрыв соединения). */
    private static final class FlakyStream extends InputStream {
        private final byte[] data;
        private final int failAfter;
        private int pos;

        FlakyStream(byte[] data, int failAfter) {
            this.data = data;
            this.failAfter = failAfter;
        }

        @Override
        public int read() throws IOException {
            if (failAfter >= 0 && pos >= failAfter) {
                throw new EOFException("connection reset by peer (fake)");
            }
            if (pos >= data.length) {
                if (failAfter >= 0) {
                    throw new EOFException("connection reset by peer (fake)");
                }
                return -1;
            }
            return data[pos++] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (failAfter >= 0 && pos >= failAfter) {
                throw new EOFException("connection reset by peer (fake)");
            }
            if (pos >= data.length) {
                if (failAfter >= 0) {
                    throw new EOFException("connection reset by peer (fake)");
                }
                return -1;
            }
            int n = Math.min(len, data.length - pos);
            if (failAfter >= 0) {
                n = Math.min(n, failAfter - pos);
                if (n <= 0) {
                    throw new EOFException("connection reset by peer (fake)");
                }
            }
            System.arraycopy(data, pos, b, off, n);
            pos += n;
            return n;
        }
    }
}
