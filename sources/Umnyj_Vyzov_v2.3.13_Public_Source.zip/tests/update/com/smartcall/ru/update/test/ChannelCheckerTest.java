package com.smartcall.ru.update.test;

import com.smartcall.ru.update.ChannelChecker;
import com.smartcall.ru.update.ReleaseManifest;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateConfig;
import com.smartcall.ru.update.UpdateException;
import com.smartcall.ru.update.test.fake.FakeTransport.Script;

import java.io.IOException;

/** Host-тесты проверки стабильного канала: черновики, откат, повреждённые данные. */
public final class ChannelCheckerTest {

    private ChannelCheckerTest() {
    }

    private static ChannelChecker checker(FakeHolder holder) {
        return new ChannelChecker(UpdateConfig.defaults(), holder.transport, 35);
    }

    /** Простой контейнер, чтобы лямбды тестов могли менять транспорт. */
    private static final class FakeHolder {
        final com.smartcall.ru.update.test.fake.FakeTransport transport =
                new com.smartcall.ru.update.test.fake.FakeTransport();
    }

    private static void scriptOk(FakeHolder h) {
        h.transport.on(Fixtures.STABLE_URL,
                com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.stableJson()));
        h.transport.on(Fixtures.RELEASE_URL,
                com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.releaseJson()));
    }

    private static void publicRepo(FakeHolder h) {
        h.transport.on(UpdateConfig.REPOSITORY_API_URL, Script.ok(
                "{\"name\":\"umnyj-vyzov-updates\",\"private\":false,"
                        + "\"owner\":{\"login\":\"UMEDJON12\"}}"));
    }

    public static void run() {
        T.suite("ChannelChecker");

        T.test("both 404 with public repository mean no published updates", () -> {
            FakeHolder h = new FakeHolder();
            publicRepo(h);
            h.transport.on(Fixtures.STABLE_URL, Script.httpError(404));
            h.transport.on(Fixtures.RELEASE_URL, Script.httpError(404));
            UpdateException e = T.assertStatus(StatusCode.NO_PUBLISHED_UPDATES,
                    () -> checker(h).check(29, 29));
            T.assertEquals("Опубликованных обновлений пока нет", e.userMessage());
            T.assertFalse(e.status().isFailure(), "должен быть информационный статус");
        });

        T.test("repository must exist and identify the public pinned repository", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL, Script.httpError(404));
            h.transport.on(Fixtures.RELEASE_URL, Script.httpError(404));
            h.transport.on(UpdateConfig.REPOSITORY_API_URL, Script.httpError(404));
            T.assertStatus(StatusCode.CHANNEL_INVALID, () -> checker(h).check(29, 29));
            String[] invalid = {
                "{\"name\":\"umnyj-vyzov-updates\",\"private\":true,\"owner\":{\"login\":\"UMEDJON12\"}}",
                "{\"name\":\"other\",\"private\":false,\"owner\":{\"login\":\"UMEDJON12\"}}",
                "{\"name\":\"umnyj-vyzov-updates\",\"private\":false,\"owner\":{\"login\":\"other\"}}",
                "{\"name\":\"umnyj-vyzov-updates\",\"owner\":{\"login\":\"UMEDJON12\"}}",
                "not json",
                "{\"name\":\"umnyj-vyzov-updates\",\"private\":false,\"owner\":{\"login\":\"UMEDJON12\"}} garbage"
            };
            for (String json : invalid) {
                h.transport.on(UpdateConfig.REPOSITORY_API_URL, Script.ok(json));
                T.assertStatus(StatusCode.CHANNEL_INVALID, () -> checker(h).check(29, 29));
            }
        });

        T.test("repository network and HTTP errors remain errors", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL, Script.httpError(404));
            h.transport.on(Fixtures.RELEASE_URL, Script.httpError(404));
            h.transport.on(UpdateConfig.REPOSITORY_API_URL,
                    Script.networkError(new java.net.SocketTimeoutException()));
            T.assertStatus(StatusCode.TIMEOUT, () -> checker(h).check(29, 29));
            h.transport.on(UpdateConfig.REPOSITORY_API_URL, Script.httpError(403));
            T.assertStatus(StatusCode.HTTP, () -> checker(h).check(29, 29));
            h.transport.on(UpdateConfig.REPOSITORY_API_URL, Script.redirect("https://evil.example/repo"));
            T.assertStatus(StatusCode.BAD_URL, () -> checker(h).check(29, 29));
        });

        T.test("one 404 is invalid channel in either direction", () -> {
            for (boolean stableMissing : new boolean[] { true, false }) {
                FakeHolder h = new FakeHolder();
                scriptOk(h);
                h.transport.on(stableMissing ? Fixtures.STABLE_URL : Fixtures.RELEASE_URL,
                        Script.httpError(404));
                T.assertStatus(StatusCode.CHANNEL_INVALID, () -> checker(h).check(30, 30));
            }
        });

        T.test("404 and network or HTTP error are not masked", () -> {
            for (boolean stableMissing : new boolean[] { true, false }) {
                FakeHolder h = new FakeHolder();
                String missing = stableMissing ? Fixtures.STABLE_URL : Fixtures.RELEASE_URL;
                String failed = stableMissing ? Fixtures.RELEASE_URL : Fixtures.STABLE_URL;
                h.transport.on(missing, Script.httpError(404));
                h.transport.on(failed, Script.networkError(new java.net.SocketTimeoutException()));
                T.assertStatus(StatusCode.TIMEOUT, () -> checker(h).check(29, 29));
                h.transport.on(failed, Script.httpError(403));
                T.assertStatus(StatusCode.HTTP, () -> checker(h).check(29, 29));
            }
        });

        T.test("redirect to 404 is checked and unsafe redirect rejected", () -> {
            FakeHolder h = new FakeHolder();
            publicRepo(h);
            String target = "https://api.github.com/missing";
            h.transport.on(Fixtures.STABLE_URL, Script.redirect(target));
            h.transport.on(target, Script.httpError(404));
            h.transport.on(Fixtures.RELEASE_URL, Script.httpError(404));
            T.assertStatus(StatusCode.NO_PUBLISHED_UPDATES, () -> checker(h).check(29, 29));
            h.transport.on(Fixtures.STABLE_URL, Script.redirect("https://evil.example/missing"));
            T.assertStatus(StatusCode.BAD_URL, () -> checker(h).check(29, 29));
            T.assertEquals(0, h.transport.calls("https://evil.example/missing"));
            h.transport.on(Fixtures.STABLE_URL, Script.redirect("http://api.github.com/missing"));
            T.assertStatus(StatusCode.BAD_URL, () -> checker(h).check(29, 29));
        });

        T.test("response read failure and redirect loop remain errors", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL, Script.httpError(404));
            h.transport.on(Fixtures.RELEASE_URL, Script.brokenStream(10, 0));
            T.assertStatus(StatusCode.NETWORK, () -> checker(h).check(29, 29));
            h.transport.on(Fixtures.STABLE_URL, Script.redirect(Fixtures.STABLE_URL));
            T.assertStatus(StatusCode.BAD_RESPONSE, () -> checker(h).check(29, 29));
        });

        T.test("valid public release is accepted", () -> {
            FakeHolder h = new FakeHolder();
            scriptOk(h);
            ReleaseManifest m = checker(h).check(29, 29);
            T.assertEquals(Fixtures.FIXTURE_VERSION_CODE, m.versionCode);
            T.assertEquals(Fixtures.FIXTURE_VERSION_NAME, m.versionName);
            T.assertEquals(Fixtures.FIXTURE_PACKAGE, m.packageName);
        });

        T.test("same version is NOT_NEWER", () -> {
            FakeHolder h = new FakeHolder();
            scriptOk(h);
            T.assertStatus(StatusCode.NOT_NEWER, () -> checker(h).check(30, 30));
        });

        T.test("lower channel version is ROLLBACK", () -> {
            FakeHolder h = new FakeHolder();
            scriptOk(h);
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(
                            Fixtures.stableJson(28, "2.3.5")));
            T.assertStatus(StatusCode.ROLLBACK, () -> checker(h).check(27, 30));
        });

        T.test("draft release is rejected", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.stableJson()));
            h.transport.on(Fixtures.RELEASE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.releaseJson(true, false)));
            T.assertStatus(StatusCode.DRAFT, () -> checker(h).check(29, 29));
        });

        T.test("prerelease is rejected", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.stableJson()));
            h.transport.on(Fixtures.RELEASE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.releaseJson(false, true)));
            T.assertStatus(StatusCode.PRERELEASE, () -> checker(h).check(29, 29));
        });

        T.test("foreign package is rejected", () -> {
            FakeHolder h = new FakeHolder();
            scriptOk(h);
            String json = Fixtures.stableJson().replace(
                    "\"packageName\": \"com.smartcall.ru\"",
                    "\"packageName\": \"org.example.other\"");
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(json));
            T.assertStatus(StatusCode.WRONG_PACKAGE, () -> checker(h).check(29, 29));
        });

        T.test("broken JSON is rejected", () -> {
            FakeHolder h = new FakeHolder();
            scriptOk(h);
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok("{not json"));
            T.assertAnyStatus(() -> checker(h).check(29, 29));
        });

        T.test("network failure is reported, never crashes", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.networkError(
                            new IOException("offline")));
            T.assertAnyStatus(() -> checker(h).check(29, 29));
        });

        T.test("mismatched release asset is rejected", () -> {
            FakeHolder h = new FakeHolder();
            h.transport.on(Fixtures.STABLE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(Fixtures.stableJson()));
            String release = Fixtures.releaseJson().replace(Fixtures.APK_NAME, "other.apk");
            h.transport.on(Fixtures.RELEASE_URL,
                    com.smartcall.ru.update.test.fake.FakeTransport.Script.ok(release));
            T.assertAnyStatus(() -> checker(h).check(29, 29));
        });
    }
}
