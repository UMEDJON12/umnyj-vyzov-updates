package com.smartcall.ru.update.test;

/** Единая точка запуска host-тестов модуля обновлений. */
public final class UpdateTestsRunner {
    public static void main(String[] args) {
        ApprovedReleaseTest.run();
        ChannelCheckerTest.run();
        ApkVerifierTest.run();
        DownloaderTest.run();
        UpdateEngineTest.run();
        StatePersistenceTest.run();
        System.out.println(T.summary());
        if (T.failedCount() > 0) {
            System.exit(1);
        }
    }
}
