package com.smartcall.ru.update.test;

import com.smartcall.ru.update.FileKeyValueStore;
import com.smartcall.ru.update.UpdateConfig;
import com.smartcall.ru.update.UpdateState;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Properties;

public final class StatePersistenceTest {
    private static final String HASH = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

    public static void run() {
        T.suite("StatePersistence");
        T.test("legacy migration retains all values", () -> {
            File dir = Files.createTempDirectory("state-legacy").toFile();
            File file = new File(dir, "state");
            Properties p = new Properties();
            p.setProperty(UpdateConfig.KEY_KNOWN_VERSION, "500");
            p.setProperty(UpdateConfig.KEY_AUTO_CHECK, "false");
            p.setProperty("unknown_legacy_key", "preserved");
            try (FileOutputStream out = new FileOutputStream(file)) { p.store(out, "smartcall update state"); }
            FileKeyValueStore store = new FileKeyValueStore(file);
            UpdateState state = new UpdateState(store);
            T.assertEquals(500, state.knownVersionCode());
            T.assertFalse(state.isAutoCheckEnabled(), "legacy boolean");
            state.saveDownloaded(400, "4", HASH, 123, "app.apk");
            FileKeyValueStore reread = new FileKeyValueStore(file);
            T.assertEquals("preserved", reread.getString("unknown_legacy_key", null));
            T.assertEquals(500, new UpdateState(reread).knownVersionCode());
            T.assertEquals(400, new UpdateState(reread).downloaded().versionCode);
            T.assertEquals(0, Files.readAllBytes(file.toPath())[0]);
        });
        T.test("download batch persists and clears without lowering known", () -> {
            File file = new File(Files.createTempDirectory("state-batch").toFile(), "state");
            UpdateState state = new UpdateState(new FileKeyValueStore(file));
            state.saveDownloaded(90, "v90", HASH, 7, "x.apk");
            UpdateState reopened = new UpdateState(new FileKeyValueStore(file));
            T.assertEquals(90, reopened.knownVersionCode());
            T.assertEquals("v90", reopened.downloaded().versionName);
            reopened.clearDownloaded();
            reopened = new UpdateState(new FileKeyValueStore(file));
            T.assertEquals(null, reopened.downloaded());
            T.assertEquals(90, reopened.knownVersionCode());
        });
        T.test("corruption fails closed and cannot be overwritten", () -> {
            File file = new File(Files.createTempDirectory("state-bad").toFile(), "state");
            FileKeyValueStore store = new FileKeyValueStore(file);
            store.putLong(UpdateConfig.KEY_KNOWN_VERSION, 200);
            byte[] bytes = Files.readAllBytes(file.toPath());
            bytes[bytes.length - 1] ^= 1;
            Files.write(file.toPath(), bytes);
            expectFailure(() -> store.getLong(UpdateConfig.KEY_KNOWN_VERSION, 0));
            expectFailure(() -> new UpdateState(store).clearDownloaded());
            T.assertTrue(Arrays.equals(bytes, Files.readAllBytes(file.toPath())), "corrupt file changed");
            Files.write(file.toPath(), Arrays.copyOf(bytes, 3));
            expectFailure(() -> new FileKeyValueStore(file).getLong(UpdateConfig.KEY_KNOWN_VERSION, 0));
        });
        T.test("lost file during lifetime fails closed", () -> {
            File file = new File(Files.createTempDirectory("state-lost").toFile(), "state");
            FileKeyValueStore store = new FileKeyValueStore(file);
            store.putLong(UpdateConfig.KEY_KNOWN_VERSION, 200);
            Files.delete(file.toPath());
            expectFailure(() -> store.getLong(UpdateConfig.KEY_KNOWN_VERSION, 0));
            expectFailure(() -> store.putLong(UpdateConfig.KEY_KNOWN_VERSION, 300));
            T.assertFalse(file.exists(), "lost file recreated");
        });
        T.test("failed write preserves previous batch", () -> {
            File file = new File(Files.createTempDirectory("state-fail").toFile(), "state");
            UpdateState state = new UpdateState(new FileKeyValueStore(file));
            state.saveDownloaded(20, "old", HASH, 10, "old.apk");
            byte[] before = Files.readAllBytes(file.toPath());
            char[] huge = new char[1024 * 1024];
            Arrays.fill(huge, 'x');
            expectFailure(() -> state.saveDownloaded(30, new String(huge), HASH, 20, "new.apk"));
            T.assertTrue(Arrays.equals(before, Files.readAllBytes(file.toPath())), "previous state changed");
            UpdateState reopened = new UpdateState(new FileKeyValueStore(file));
            T.assertEquals(20, reopened.knownVersionCode());
            T.assertEquals("old", reopened.downloaded().versionName);
        });
    }
    private static void expectFailure(T.Body body) throws Exception {
        try { body.run(); } catch (IllegalStateException expected) { return; }
        T.fail("expected IllegalStateException");
    }
}
