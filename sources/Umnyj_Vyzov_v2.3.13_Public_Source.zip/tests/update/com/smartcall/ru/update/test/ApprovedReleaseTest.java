package com.smartcall.ru.update.test;

import com.smartcall.ru.update.ApprovedRelease;
import com.smartcall.ru.update.ReleaseManifest;
import com.smartcall.ru.update.UpdateConfig;
import java.lang.reflect.Constructor;

/** Host tests for the identity of the release approved by the user. */
public final class ApprovedReleaseTest {
    private ApprovedReleaseTest() { }

    private static ReleaseManifest parse(String json) throws Exception {
        return ReleaseManifest.parseAndValidate(Fixtures.utf8(json), UpdateConfig.defaults(), 35);
    }

    private static void changed(String field, ReleaseManifest base, ReleaseManifest other) {
        T.assertEquals(base.versionCode, other.versionCode);
        T.assertFalse(ApprovedRelease.fingerprint(base).equals(ApprovedRelease.fingerprint(other)),
                field + " must change fingerprint");
        T.assertFalse(ApprovedRelease.matches(other, ApprovedRelease.fingerprint(base)),
                field + " must invalidate approval");
    }

    // A canonical URL is a function of tag and filename, so validation cannot produce
    // manifests differing only in any one of these three fields. Isolate each field
    // with the private constructor in addition to testing valid, coupled changes below.
    private static ReleaseManifest withLocation(ReleaseManifest m, String tag, String file, String url)
            throws Exception {
        Constructor<ReleaseManifest> ctor = ReleaseManifest.class.getDeclaredConstructor(
                int.class, String.class, String.class, boolean.class, long.class, String.class,
                long.class, String.class, long.class, String.class, String.class, String.class,
                String.class, boolean.class, String.class, String.class);
        ctor.setAccessible(true);
        return ctor.newInstance(m.schemaVersion, m.packageName, m.variant, m.testOnly,
                m.versionCode, m.versionName, m.minSdk, m.signingCertificateSha256,
                m.sizeBytes, m.sha256, file, url, m.releaseNotes, m.ready, tag, m.publishedAt);
    }

    public static void run() {
        T.suite("ApprovedRelease");
        T.test("identical manifests have identical fingerprint and match approval", () -> {
            ReleaseManifest a = parse(Fixtures.stableJson());
            ReleaseManifest b = parse(Fixtures.stableJson());
            String fingerprint = ApprovedRelease.fingerprint(a);
            T.assertEquals(fingerprint, ApprovedRelease.fingerprint(b));
            T.assertTrue(ApprovedRelease.matches(b, fingerprint), "same release must match");
            T.assertFalse(ApprovedRelease.matches(b, null), "null approval must not match");
            T.assertFalse(ApprovedRelease.matches(b,
                    "0000000000000000000000000000000000000000000000000000000000000000"),
                    "foreign approval must not match");
        });
        T.test("each independent manifest field changes fingerprint", () -> {
            String json = Fixtures.stableJson();
            ReleaseManifest base = parse(json);
            changed("versionName", base, parse(json.replace("\"versionName\": \"2.3.7\"", "\"versionName\": \"2.3.8\"")));
            changed("size", base, parse(json.replace("\"sizeBytes\": 207113", "\"sizeBytes\": 207114")));
            changed("sha256", base, parse(json.replace(Fixtures.FIXTURE_SHA256,
                    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")));
            changed("releaseNotes", base, parse(json.replace("Тестовое описание обновления", "Другое описание")));
            changed("minSdk", base, parse(json.replace("\"minSdk\": 24", "\"minSdk\": 25")));
        });
        T.test("tag, filename and URL each contribute independently", () -> {
            ReleaseManifest base = parse(Fixtures.stableJson());
            String tag = "v2.3.8";
            String file = "SmartCall-2.3.8.apk";
            String tagUrl = UpdateConfig.defaults().canonicalApkUrl(tag, base.apkFileName);
            String fileUrl = UpdateConfig.defaults().canonicalApkUrl(base.tagName, file);
            changed("tag", base, withLocation(base, tag, base.apkFileName, base.apkUrl));
            changed("filename", base, withLocation(base, base.tagName, file, base.apkUrl));
            changed("URL", base, withLocation(base, base.tagName, base.apkFileName, tagUrl));
            // These pairs also pass all real URL and filename validation.
            String json = Fixtures.stableJson();
            changed("valid tag and URL", base, parse(json.replace(Fixtures.APK_URL, tagUrl)
                    .replace("\"tagName\": \"" + Fixtures.TAG + "\"", "\"tagName\": \"" + tag + "\"")));
            changed("valid filename and URL", base, parse(json.replace(Fixtures.APK_URL, fileUrl)
                    .replace("\"apkFileName\": \"" + Fixtures.APK_NAME + "\"", "\"apkFileName\": \"" + file + "\"")));
        });
    }
}
