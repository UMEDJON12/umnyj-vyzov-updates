package com.smartcall.ru.update.test;

import com.smartcall.ru.update.ApkVerifier;
import com.smartcall.ru.update.UpdateConfig;
import java.io.File;

/** Verify the actual built APK, not only the retained 2.3.7 fixture. */
public final class VerifyCandidate {
    public static void main(String[] args) throws Exception {
        if (args.length != 5) throw new IllegalArgumentException("apk size sha256 versionCode versionName");
        ApkVerifier.Expectations expected = new ApkVerifier.Expectations(
                Long.parseLong(args[1]), args[2], Long.parseLong(args[3]), args[4]);
        ApkVerifier.Result result = ApkVerifier.verify(new File(args[0]), expected, UpdateConfig.defaults());
        System.out.println("PASS: candidate package=" + result.packageName + " code=" + result.versionCode
                + " signer=" + result.certSha256s);
    }
}
