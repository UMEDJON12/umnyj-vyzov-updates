package com.smartcall.ru.update.test;

import com.smartcall.ru.update.*;
import com.smartcall.ru.update.test.fake.FakeTransport;
import com.smartcall.ru.update.test.fake.FakeTransport.Script;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

/** Синхронные host-тесты без сети: bytes read — источник истины для прогресса. */
public final class DownloaderTest {
    private static final byte[] OLD = Fixtures.utf8("previous APK must survive");
    private static ReleaseManifest manifest() throws Exception {
        return ReleaseManifest.parseAndValidate(Fixtures.utf8(Fixtures.stableJson()), UpdateConfig.defaults(), 35);
    }
    private static File temp() throws IOException { return Files.createTempDirectory("update-downloader-").toFile(); }
    private static void clean(File dir) throws IOException {
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) Files.deleteIfExists(f.toPath());
        Files.deleteIfExists(dir.toPath());
    }
    private static File old(File dir) throws IOException {
        File file = new File(dir, Fixtures.APK_NAME);
        Files.write(file.toPath(), OLD);
        return file;
    }
    private static void unchanged(File dir, File target) throws IOException {
        T.assertTrue(target.isFile(), "старый APK исчез");
        T.assertTrue(Arrays.equals(OLD, Files.readAllBytes(target.toPath())), "старый APK изменился");
        T.assertFalse(new File(dir, Fixtures.APK_NAME + ".part").exists(), "остался .part");
    }
    private static Downloader downloader(FakeTransport fake) { return new Downloader(UpdateConfig.defaults(), fake); }

    /** Ограничаем каждый read фиксированным чанком, считая фактически прочитанное. */
    private static final class CountingTransport implements HttpTransport {
        final FakeTransport fake;
        long read;
        int reads;
        CountingTransport(FakeTransport fake) { this.fake = fake; }
        public Reply execute(String url, int connect, int timeout) throws IOException {
            Reply r = fake.execute(url, connect, timeout);
            InputStream body = new FilterInputStream(r.body) {
                @Override public int read(byte[] b, int off, int len) throws IOException {
                    int n = in.read(b, off, Math.min(len, 16384));
                    if (n > 0) { read += n; reads++; }
                    return n;
                }
            };
            return new Reply(r.status, r.location, r.contentLength, body);
        }
    }
    public static void run() {
        T.suite("Downloader");
        T.test("real chunk progress, zero, intermediate, 100 and remaining", () -> {
            File dir = temp();
            try {
                byte[] data = Fixtures.readFixtureApk();
                CountingTransport transport = new CountingTransport(new FakeTransport().on(Fixtures.APK_URL, Script.okBytes(data)));
                List<Long> events = new ArrayList<Long>();
                File result = new Downloader(UpdateConfig.defaults(), transport).download(manifest(), dir,
                    (done, total, percent, remaining) -> {
                        T.assertEquals(transport.read, done); // никакой имитации / забегания вперёд
                        T.assertEquals(data.length, total);
                        T.assertEquals((int)(done * 100 / total), percent);
                        T.assertEquals(total - done, remaining);
                        events.add(done);
                    }, Downloader.NEVER_CANCELLED);
                T.assertEquals(0L, events.get(0).longValue());
                T.assertTrue(transport.reads > 1, "нужны несколько чанков");
                T.assertTrue(events.size() >= transport.reads + 1, "нет события на каждый чанк");
                for (int i = 1; i <= transport.reads; i++)
                    T.assertEquals(Math.min((long)i * 16384, data.length), events.get(i).longValue());
                T.assertEquals(data.length, events.get(events.size()-1).longValue());
                T.assertTrue(Arrays.equals(data, Files.readAllBytes(result.toPath())), "неверное тело");
                T.assertFalse(new File(dir, Fixtures.APK_NAME + ".part").exists(), "остался .part");
            } finally { clean(dir); }
        });
        T.test("cancel mid-transfer preserves old APK and cleans part", () -> {
            File dir = temp();
            try {
                File target = old(dir);
                FakeTransport fake = new FakeTransport().on(Fixtures.APK_URL, Script.okBytes(Fixtures.readFixtureApk()));
                final boolean[] cancel = {false}; final long[] progress = {0};
                T.assertStatus(StatusCode.CANCELLED, () -> downloader(fake).download(manifest(), dir,
                    (done, total, percent, remaining) -> { progress[0] = done; if (done > 0) cancel[0] = true; },
                    () -> cancel[0]));
                T.assertTrue(progress[0] > 0 && progress[0] < Fixtures.FIXTURE_SIZE, "отмена не во время скачивания");
                unchanged(dir, target);
            } finally { clean(dir); }
        });
        T.test("broken stream preserves old APK and cleans part", () -> {
            File dir = temp();
            try {
                File target = old(dir);
                FakeTransport fake = new FakeTransport().on(Fixtures.APK_URL, Script.brokenStream(Fixtures.FIXTURE_SIZE, 70000));
                T.assertStatus(StatusCode.INTERRUPTED, () -> downloader(fake).download(manifest(), dir, null, Downloader.NEVER_CANCELLED));
                unchanged(dir, target);
            } finally { clean(dir); }
        });
        T.test("premature EOF preserves old APK and cleans part", () -> {
            File dir = temp();
            try {
                File target = old(dir);
                FakeTransport fake = new FakeTransport().on(Fixtures.APK_URL,
                    Script.okBytes(Arrays.copyOf(Fixtures.readFixtureApk(), 70000)).declaredLength(Fixtures.FIXTURE_SIZE));
                T.assertStatus(StatusCode.INTERRUPTED, () -> downloader(fake).download(manifest(), dir, null, Downloader.NEVER_CANCELLED));
                unchanged(dir, target);
            } finally { clean(dir); }
        });
        T.test("declared length mismatch preserves old APK and cleans stale part", () -> {
            File dir = temp();
            try {
                File target = old(dir);
                Files.write(new File(dir, Fixtures.APK_NAME + ".part").toPath(), OLD);
                FakeTransport fake = new FakeTransport().on(Fixtures.APK_URL, Script.okBytes(Fixtures.readFixtureApk()).declaredLength(Fixtures.FIXTURE_SIZE + 1));
                T.assertStatus(StatusCode.SIZE_MISMATCH, () -> downloader(fake).download(manifest(), dir, null, Downloader.NEVER_CANCELLED));
                unchanged(dir, target);
            } finally { clean(dir); }
        });
        T.test("oversized body with unknown length preserves old APK and cleans part", () -> {
            File dir = temp();
            try {
                File target = old(dir);
                byte[] extra = Arrays.copyOf(Fixtures.readFixtureApk(), (int)Fixtures.FIXTURE_SIZE + 1);
                FakeTransport fake = new FakeTransport().on(Fixtures.APK_URL, Script.okBytes(extra).declaredLength(-1));
                T.assertStatus(StatusCode.SIZE_MISMATCH, () -> downloader(fake).download(manifest(), dir, null, Downloader.NEVER_CANCELLED));
                unchanged(dir, target);
            } finally { clean(dir); }
        });
    }
}
