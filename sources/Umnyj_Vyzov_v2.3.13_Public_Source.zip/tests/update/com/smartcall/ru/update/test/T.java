package com.smartcall.ru.update.test;

import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateException;

/**
 * Мини-фреймворк для host-тестов (без JUnit — без внешних зависимостей).
 * Каждый тест — lambda; неожиданный исход падает с понятной ссылкой.
 */
public final class T {

    public interface Body {
        void run() throws Exception;
    }

    private static int passed;
    private static int failed;
    private static String currentSuite = "";

    private T() {
    }

    public static void suite(String name) {
        currentSuite = name;
        System.out.println("== " + name);
    }

    public static void test(String name, Body body) {
        String full = currentSuite + "." + name;
        try {
            body.run();
            passed++;
            System.out.println("  [OK]   " + name);
        } catch (Throwable t) {
            failed++;
            System.out.println("  [FAIL] " + name + " -> " + t);
            t.printStackTrace(System.out);
        }
    }

    // ---- утверждения ----------------------------------------------------

    public static void assertTrue(boolean cond, String msg) {
        if (!cond) {
            throw new AssertionError(msg);
        }
    }

    public static void assertFalse(boolean cond, String msg) {
        if (cond) {
            throw new AssertionError(msg);
        }
    }

    public static void assertEquals(Object expected, Object actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError("ожидалось <" + expected + ">, получено <" + actual + ">");
        }
    }

    public static void assertEquals(long expected, long actual) {
        if (expected != actual) {
            throw new AssertionError("ожидалось " + expected + ", получено " + actual);
        }
    }

    public static void fail(String msg) {
        throw new AssertionError(msg);
    }

    /** Ожидаемый UpdateException с конкретным статусом. */
    public static UpdateException assertStatus(StatusCode expected, Body body) {
        try {
            body.run();
        } catch (UpdateException e) {
            if (e.status() != expected) {
                throw new AssertionError("ожидался статус " + expected
                        + ", получен " + e.status() + " (" + e.userMessage() + ")");
            }
            return e;
        } catch (Throwable t) {
            throw new AssertionError("ожидался UpdateException(" + expected
                    + "), получен " + t, t);
        }
        throw new AssertionError("ожидался UpdateException(" + expected + "), но исхода не было");
    }

    /** Ожидается UpdateException ЛЮБОГО статуса (возвращается для деталей). */
    public static UpdateException assertAnyStatus(Body body) {
        try {
            body.run();
        } catch (UpdateException e) {
            return e;
        } catch (Throwable t) {
            throw new AssertionError("ожидался UpdateException, получен " + t, t);
        }
        throw new AssertionError("ожидался UpdateException, но исхода не было");
    }

    // ---- итог -----------------------------------------------------------

    public static int failedCount() {
        return failed;
    }

    public static int passedCount() {
        return passed;
    }

    public static String summary() {
        return "Итого: пройдено " + passed + ", провалено " + failed
                + " (всего " + (passed + failed) + ")";
    }
}
