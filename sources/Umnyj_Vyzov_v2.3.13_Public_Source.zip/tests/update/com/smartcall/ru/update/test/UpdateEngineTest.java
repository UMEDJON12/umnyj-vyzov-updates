package com.smartcall.ru.update.test;

import com.smartcall.ru.update.*;
import com.smartcall.ru.update.test.fake.FakeTransport;
import com.smartcall.ru.update.test.fake.FakeTransport.Script;
import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;

public final class UpdateEngineTest {
    private static ReleaseManifest candidate(long version) throws Exception {
        return ReleaseManifest.parseAndValidate(Fixtures.utf8(Fixtures.stableJson(version, "2.3." + version)), UpdateConfig.defaults(), 35);
    }
    private static void clean(File f) throws Exception {
        if (f.isDirectory()) {
            File[] files = f.listFiles();
            if (files != null) for (File child : files) clean(child);
        }
        Files.deleteIfExists(f.toPath());
    }
    private static void noParts(File f) {
        T.assertFalse(f.getName().endsWith(".part"), "остался .part: " + f);
        File[] files = f.listFiles();
        if (files != null) for (File child : files) noParts(child);
    }
    public static void run() {
        T.suite("UpdateEngine");
        T.test("installed 31 and channel 31 produce NOT_NEWER", () -> {
            File dir = Files.createTempDirectory("update-current-").toFile();
            try {
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.STABLE_URL, Script.ok(Fixtures.stableJson(31, "2.3.8")))
                    .on(Fixtures.RELEASE_URL, Script.ok(Fixtures.releaseJson()));
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake,
                        new UpdateState(new FileKeyValueStore(new File(dir, "state"))), dir, 35, null);
                T.assertStatus(StatusCode.NOT_NEWER, () -> engine.check(31));
            } finally { clean(dir); }
        });
        T.test("installed 31 offers 32; postpone only auto same version; manual and 33 visible", () -> {
            File dir = Files.createTempDirectory("update-offer-").toFile();
            try {
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.STABLE_URL, Script.ok(Fixtures.stableJson(32, "2.3.32")))
                    .on(Fixtures.RELEASE_URL, Script.ok(Fixtures.releaseJson()));
                UpdateState state = new UpdateState(new FileKeyValueStore(new File(dir, "state")));
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake, state, dir, 35, null);
                ReleaseManifest v32 = engine.check(31);
                T.assertEquals(32, v32.versionCode);
                T.assertTrue(engine.shouldOffer(v32, false), "32 должна предлагаться после 31");
                engine.postpone(32);
                T.assertFalse(engine.shouldOffer(v32, false), "отложенная 32 показана автоматически");
                T.assertTrue(engine.shouldOffer(v32, true), "ручная проверка скрыта");
                T.assertTrue(engine.shouldOffer(candidate(33), false), "следующая версия скрыта");
            } finally { clean(dir); }
        });
        T.test("verified download survives restart and revalidates before installation", () -> {
            File dir = Files.createTempDirectory("update-restart-").toFile();
            try {
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.APK_URL, Script.okBytes(Fixtures.readFixtureApk()))
                    .on(Fixtures.STABLE_URL, Script.ok(Fixtures.stableJson()))
                    .on(Fixtures.RELEASE_URL, Script.ok(Fixtures.releaseJson()));
                File stateFile = new File(dir, "state");
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake,
                        new UpdateState(new FileKeyValueStore(stateFile)), dir, 35, null);
                ReleaseManifest manifest = ReleaseManifest.parseAndValidate(Fixtures.utf8(Fixtures.stableJson()), UpdateConfig.defaults(), 35);
                ApkVerifier.Result result = engine.download(29, manifest, null, Downloader.NEVER_CANCELLED);
                T.assertEquals(30, result.versionCode);
                UpdateEngine restarted = new UpdateEngine(UpdateConfig.defaults(), fake,
                        new UpdateState(new FileKeyValueStore(stateFile)), dir, 35, null);
                ApkVerifier.Result reverified = restarted.verifyDownloaded(29);
                T.assertTrue(restarted.downloadedFile(reverified).isFile(), "проверенный файл не восстановлен");
                T.assertTrue(restarted.downloadedFile(null) == null, "путь не должен выдаваться без проверки");
                ApkVerifier.Result wrong = new ApkVerifier.Result(reverified.packageName, reverified.versionCode,
                        reverified.versionName, reverified.sizeBytes, "0" + reverified.sha256.substring(1), reverified.certSha256s);
                if (wrong.sha256.equals(reverified.sha256)) wrong = new ApkVerifier.Result(reverified.packageName,
                        reverified.versionCode, reverified.versionName, reverified.sizeBytes,
                        "1" + reverified.sha256.substring(1), reverified.certSha256s);
                T.assertTrue(restarted.downloadedFile(wrong) == null, "путь не должен выдаваться для другого хеша");
                T.assertStatus(StatusCode.UP_TO_DATE, () -> restarted.verifyDownloaded(30));
                T.assertTrue(restarted.state().downloaded() != null, "метаданные не должны удаляться после проверки равной версии");
                noParts(dir);
            } finally { clean(dir); }
        });
        T.test("cleanup removes only owned orphan work files", () -> {
            File dir = Files.createTempDirectory("update-cleanup-").toFile();
            try {
                File stage = new File(dir, "work-12345678-abcd-4abc-8abc-1234567890ab");
                T.assertTrue(stage.mkdir(), "создание тестового каталога");
                File part = new File(stage, "update.apk.part"); Files.write(part.toPath(), new byte[]{1});
                File keep = new File(dir, "user.apk"); Files.write(keep.toPath(), new byte[]{2});
                File orphan = new File(dir, "work-install-12345.tmp"); Files.write(orphan.toPath(), new byte[]{3});
                File protectedDir = new File(dir, "protected"); T.assertTrue(protectedDir.mkdir(), "protected directory");
                File protectedFile = new File(protectedDir, "important.apk"); Files.write(protectedFile.toPath(), new byte[]{4});
                File symlink = new File(dir, "work-abcdef12-abcd-4abc-8abc-1234567890ab");
                Files.createSymbolicLink(symlink.toPath(), protectedDir.toPath());
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), new FakeTransport(),
                        new UpdateState(new FileKeyValueStore(new File(dir, "state"))), dir, 35, null);
                engine.cleanupStaleWork();
                T.assertFalse(part.exists(), "временный part не удалён");
                T.assertFalse(stage.exists(), "пустой каталог не удалён");
                T.assertFalse(orphan.exists(), "временный snapshot не удалён");
                T.assertTrue(keep.isFile() && Files.readAllBytes(keep.toPath())[0] == 2, "чужой файл изменён");
                T.assertTrue(protectedFile.isFile() && Files.readAllBytes(protectedFile.toPath())[0] == 4, "очистка не должна проходить по ссылкам");
                Files.delete(symlink.toPath());
            } finally { clean(dir); }
        });
        T.test("known 33 rejects saved 32 on installed 31", () -> {
            File dir = Files.createTempDirectory("update-rollback-install-").toFile();
            try {
                UpdateState state = new UpdateState(new FileKeyValueStore(new File(dir, "state")));
                state.saveDownloaded(32, "2.3.9", Fixtures.FIXTURE_SHA256, Fixtures.FIXTURE_SIZE, "saved.apk");
                state.noteKnownVersion(33);
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), new FakeTransport(), state, dir, 35, null);
                T.assertStatus(StatusCode.ROLLBACK, () -> engine.verifyDownloaded(31));
                T.assertEquals(32, state.downloaded().versionCode);
            } finally { clean(dir); }
        });
        T.test("verification failure retains metadata for a later retry", () -> {
            File dir = Files.createTempDirectory("update-missing-").toFile();
            try {
                UpdateState state = new UpdateState(new FileKeyValueStore(new File(dir, "state")));
                state.saveDownloaded(30, "2.3.7", Fixtures.FIXTURE_SHA256, Fixtures.FIXTURE_SIZE, "missing.apk");
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), new FakeTransport(), state, dir, 35, null);
                T.assertAnyStatus(() -> engine.verifyDownloaded(29));
                T.assertTrue(state.downloaded() != null, "ошибка чтения не должна удалять метаданные");
            } finally { clean(dir); }
        });
        T.test("failed recheck does not replace or delete old APK", () -> {
            File dir = Files.createTempDirectory("update-engine-").toFile();
            try {
                byte[] old = Fixtures.utf8("trusted old APK");
                File target = new File(dir, Fixtures.APK_NAME);
                Files.write(target.toPath(), old);
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.APK_URL, Script.okBytes(Fixtures.readFixtureApk()))
                    .on(Fixtures.STABLE_URL, Script.httpError(503));
                UpdateState state = new UpdateState(new FileKeyValueStore(new File(dir, "state")));
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake, state, dir, 35, null);
                T.assertAnyStatus(() -> engine.download(29, candidate(30), null, Downloader.NEVER_CANCELLED));
                T.assertTrue(target.isFile(), "старый APK удалён после ошибки проверки канала");
                T.assertTrue(Arrays.equals(old, Files.readAllBytes(target.toPath())), "старый APK заменён после ошибки");
                noParts(dir);
            } finally { clean(dir); }
        });
        T.test("release notes changed after approval refuse download result", () -> {
            File dir = Files.createTempDirectory("update-release-change-").toFile();
            try {
                String initial = Fixtures.stableJson();
                String changed = initial.replace("Тестовое описание обновления", "Изменённое описание обновления");
                T.assertTrue(!initial.equals(changed), "fixture must change");
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.APK_URL, Script.okBytes(Fixtures.readFixtureApk()))
                    .on(Fixtures.STABLE_URL, Script.ok(changed))
                    .on(Fixtures.RELEASE_URL, Script.ok(Fixtures.releaseJson()));
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake,
                        new UpdateState(new FileKeyValueStore(new File(dir, "state"))), dir, 35, null);
                ReleaseManifest approved = ReleaseManifest.parseAndValidate(Fixtures.utf8(initial), UpdateConfig.defaults(), 35);
                T.assertStatus(StatusCode.RELEASE_CHANGED, () -> engine.download(29, approved, null, Downloader.NEVER_CANCELLED));
                T.assertTrue(engine.state().downloaded() == null, "изменённый релиз не должен сохраняться как готовый");
                noParts(dir);
            } finally { clean(dir); }
        });
        T.test("hash verification failure preserves old APK and removes staging parts", () -> {
            File dir = Files.createTempDirectory("update-engine-hash-").toFile();
            try {
                byte[] old = Fixtures.utf8("trusted old APK");
                File target = new File(dir, Fixtures.APK_NAME);
                Files.write(target.toPath(), old);
                byte[] corrupt = Fixtures.readFixtureApk();
                corrupt[corrupt.length / 2] ^= 1;
                FakeTransport fake = new FakeTransport()
                    .on(Fixtures.APK_URL, Script.okBytes(corrupt))
                    .on(Fixtures.STABLE_URL, Script.ok(Fixtures.stableJson()))
                    .on(Fixtures.RELEASE_URL, Script.ok(Fixtures.releaseJson()));
                UpdateState state = new UpdateState(new FileKeyValueStore(new File(dir, "state")));
                UpdateEngine engine = new UpdateEngine(UpdateConfig.defaults(), fake, state, dir, 35, null);
                ReleaseManifest m = ReleaseManifest.parseAndValidate(Fixtures.utf8(Fixtures.stableJson()), UpdateConfig.defaults(), 35);
                T.assertStatus(StatusCode.HASH_MISMATCH, () -> engine.download(29, m, null, Downloader.NEVER_CANCELLED));
                T.assertTrue(target.isFile(), "старый APK удалён после ошибки хеша");
                T.assertTrue(Arrays.equals(old, Files.readAllBytes(target.toPath())), "старый APK заменён после ошибки хеша");
                noParts(dir);
            } finally { clean(dir); }
        });
    }
}
