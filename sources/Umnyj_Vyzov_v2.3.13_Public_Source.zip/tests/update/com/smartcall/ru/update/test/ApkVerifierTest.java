package com.smartcall.ru.update.test;

import com.smartcall.ru.update.ApkVerifier;
import com.smartcall.ru.update.AxmlManifestParser;
import com.smartcall.ru.update.SigningBlockCerts;
import com.smartcall.ru.update.Sha256;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateConfig;
import com.smartcall.ru.update.UpdateException;
import com.smartcall.ru.update.test.T.Body;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Проверка APK на host-JVM против РЕАЛЬНОГО подписанного APK-фикстуры
 * (com.smartcall.ru 2.3.7, подпись v1+v2, сертификат baedb1a7…).
 */
public final class ApkVerifierTest {

    public static void run() {
        T.suite("ApkVerifier");

        T.test("fixturePassesAllChecks", () -> {
            File apk = Fixtures.FIXTURE_APK;
            ApkVerifier.Result r = ApkVerifier.verify(apk, expectations(), UpdateConfig.defaults());
            assertEquals(Fixtures.FIXTURE_PACKAGE, r.packageName);
            assertEquals(Fixtures.FIXTURE_VERSION_CODE, r.versionCode);
            assertEquals(Fixtures.FIXTURE_VERSION_NAME, r.versionName);
            assertEquals(Fixtures.FIXTURE_SIZE, r.sizeBytes);
            assertEquals(Fixtures.FIXTURE_SHA256, r.sha256);
            assertTrue(r.certSha256s.contains(Fixtures.FIXTURE_CERT_SHA256),
                    "ожидался отпечаток фикстуры среди " + r.certSha256s);
        });

        T.test("missingFileRejected", () -> {
            T.assertStatus(StatusCode.NO_FILE, new Body() {
                @Override
                public void run() throws Exception {
                    ApkVerifier.verify(new File("test/fixtures/нет-такого.apk"),
                            expectations(), UpdateConfig.defaults());
                }
            });
        });

        T.test("versionCodeMismatchRejected", () -> {
            T.assertStatus(StatusCode.VERSION_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK,
                            new ApkVerifier.Expectations(Fixtures.FIXTURE_SIZE,
                                    Fixtures.FIXTURE_SHA256, 31, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
        });

        T.test("versionNameMismatchRejected", () -> {
            T.assertStatus(StatusCode.VERSION_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK,
                            new ApkVerifier.Expectations(Fixtures.FIXTURE_SIZE,
                                    Fixtures.FIXTURE_SHA256, Fixtures.FIXTURE_VERSION_CODE, "9.9.9"),
                            UpdateConfig.defaults()));
        });

        T.test("hashMismatchRejected", () -> {
            T.assertStatus(StatusCode.HASH_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK,
                            new ApkVerifier.Expectations(Fixtures.FIXTURE_SIZE,
                                    Sha256.ofBytes(new byte[32]),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
        });

        T.test("sizeMismatchRejected", () -> {
            T.assertStatus(StatusCode.SIZE_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK,
                            new ApkVerifier.Expectations(Fixtures.FIXTURE_SIZE - 1,
                                    Fixtures.FIXTURE_SHA256,
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
        });

        T.test("overLimitRejected", () -> {
            UpdateConfig tiny = UpdateConfig.builder().maxApkBytes(1000).build();
            T.assertStatus(StatusCode.TOO_LARGE, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK, expectations(), tiny));
        });

        T.test("wrongPackageRejected", () -> {
            UpdateConfig other = UpdateConfig.builder().packageName("ru.other.app").build();
            T.assertStatus(StatusCode.PACKAGE_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK, expectations(), other));
        });

        T.test("wrongSigningCertRejected", () -> {
            UpdateConfig other = UpdateConfig.builder()
                    .expectedCertSha256(Sha256.ofBytes("чужой сертификат".getBytes("UTF-8")))
                    .build();
            T.assertStatus(StatusCode.CERT_MISMATCH, () ->
                    ApkVerifier.verify(Fixtures.FIXTURE_APK, expectations(), other));
        });

        T.test("emptyFileRejected", () -> {
            File tmp = tempFile("empty");
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(0, Sha256.ofBytes(new byte[0]),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("randomBytesRejectedAsBrokenArchive", () -> {
            byte[] junk = new byte[4096];
            for (int i = 0; i < junk.length; i++) {
                junk[i] = (byte) (i * 17 + 3);
            }
            File tmp = writeTemp("junk", junk);
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(junk.length, Sha256.ofBytes(junk),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("truncatedFileWithMatchingExpectationsRejected", () -> {
            byte[] full = Fixtures.readFixtureApk();
            byte[] half = new byte[full.length / 2];
            System.arraycopy(full, 0, half, 0, half.length);
            File tmp = writeTemp("truncated", half);
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(half.length, Sha256.ofBytes(half),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("truncatedFileAgainstRealExpectationsRejected", () -> {
            byte[] full = Fixtures.readFixtureApk();
            byte[] half = new byte[full.length / 2];
            System.arraycopy(full, 0, half, 0, half.length);
            File tmp = writeTemp("truncated2", half);
            T.assertStatus(StatusCode.SIZE_MISMATCH, () ->
                    ApkVerifier.verify(tmp, expectations(), UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("missingV1SignatureRejectedEvenWithPinnedV2Certificate", () -> {
            byte[] data = Fixtures.readFixtureApk();
            byte[] oldName = "META-INF/CERT.SF".getBytes("US-ASCII");
            byte[] newName = "META-INF/CERT.XX".getBytes("US-ASCII");
            int local = indexOf(data, oldName);
            int central = findCentralEntry(data, "META-INF/CERT.SF");
            assertTrue(local >= 0 && central >= 0, "нет файла v1 подписи");
            System.arraycopy(newName, 0, data, local, newName.length);
            System.arraycopy(newName, 0, data, central + 46, newName.length);
            File tmp = writeTemp("missing-v1", data);
            try {
                T.assertStatus(StatusCode.CERT_MISMATCH, () -> ApkVerifier.verify(tmp,
                        new ApkVerifier.Expectations(data.length, Sha256.ofBytes(data),
                                Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                        UpdateConfig.defaults()));
            } finally { tmp.delete(); }
        });

        T.test("unsignedExtraEntryRejected", () -> {
            File tmp = copyZipWithExtraEntry();
            try {
                T.assertStatus(StatusCode.CERT_MISMATCH, () -> ApkVerifier.verify(tmp,
                        new ApkVerifier.Expectations(tmp.length(), Sha256.ofFile(tmp),
                                Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                        UpdateConfig.defaults()));
            } finally { tmp.delete(); }
        });

        T.test("contentTamperedCrcCaughtByZipIntegrity", () -> {
            byte[] tampered = tamperDexWithoutPatchingCrc();
            File tmp = writeTemp("tampered-crc", tampered);
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(tampered.length, Sha256.ofBytes(tampered),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("contentTamperedWithPatchedCrcCaughtByJarSignature", () -> {
            // Взломщик пересчитал CRC в заголовках, но v1-подпись (SHA-256-Digest)
            // содержимого должна его выдать.
            byte[] tampered = tamperDexWithPatchedCrc();
            File tmp = writeTemp("tampered-sig", tampered);
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(tampered.length, Sha256.ofBytes(tampered),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });

        T.test("axmlManifestParsedFromFixture", () -> {
            byte[] manifest = readZipEntry(Fixtures.FIXTURE_APK, "AndroidManifest.xml");
            AxmlManifestParser.Info info = AxmlManifestParser.parse(manifest);
            assertEquals(Fixtures.FIXTURE_PACKAGE, info.packageName);
            assertEquals(Fixtures.FIXTURE_VERSION_CODE, info.versionCode);
            assertEquals(Fixtures.FIXTURE_VERSION_NAME, info.versionName);
        });

        T.test("axmlGarbageRejected", () -> {
            byte[] garbage = "это не манифест".getBytes("UTF-8");
            T.assertStatus(StatusCode.APK_INVALID, () -> AxmlManifestParser.parse(garbage));
        });

        T.test("axmlTruncatedRejected", () -> {
            byte[] manifest = readZipEntry(Fixtures.FIXTURE_APK, "AndroidManifest.xml");
            byte[] cut = new byte[manifest.length / 3];
            System.arraycopy(manifest, 0, cut, 0, cut.length);
            T.assertStatus(StatusCode.APK_INVALID, () -> AxmlManifestParser.parse(cut));
        });

        T.test("signingBlockV2CertMatchesExpectedFingerprint", () -> {
            List<byte[]> certs = SigningBlockCerts.read(Fixtures.FIXTURE_APK);
            assertTrue(!certs.isEmpty(), "в фикстуре должен быть блок подписи v2");
            boolean found = false;
            for (byte[] der : certs) {
                if (Fixtures.FIXTURE_CERT_SHA256.equals(Sha256.ofBytes(der))) {
                    found = true;
                }
            }
            assertTrue(found, "отпечаток v2-сертификата не совпал с ожидаемым");
        });

        T.test("signingBlockCorruptedStructureRejected", () -> {
            // Меняем длину пары в Signing Block — структура становится невалидной.
            byte[] data = Fixtures.readFixtureApk();
            int magic = indexOf(data, "APK Sig Block 42".getBytes("US-ASCII"));
            assertTrue(magic > 32, "магия Signing Block не найдена");
            // Первая пара начинается на blockStart+8; blockStart = magic+16-24-size.
            int sizeAtEnd = readIntLE(data, magic - 8);
            int blockStart = magic + 16 - 24 - sizeAtEnd;
            int pairLenOff = blockStart + 8;
            // Увеличиваем длину пары так, чтобы она вышла за пределы блока.
            writeIntLE(data, pairLenOff, sizeAtEnd + 64);
            File tmp = writeTemp("broken-sigblock", data);
            T.assertStatus(StatusCode.APK_INVALID, () ->
                    ApkVerifier.verify(tmp,
                            new ApkVerifier.Expectations(data.length, Sha256.ofBytes(data),
                                    Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME),
                            UpdateConfig.defaults()));
            tmp.delete();
        });
    }

    // ---- помощники ------------------------------------------------------

    static ApkVerifier.Expectations expectations() {
        return new ApkVerifier.Expectations(Fixtures.FIXTURE_SIZE, Fixtures.FIXTURE_SHA256,
                Fixtures.FIXTURE_VERSION_CODE, Fixtures.FIXTURE_VERSION_NAME);
    }

    static void assertTrue(boolean b, String msg) {
        T.assertTrue(b, msg);
    }

    static void assertEquals(Object e, Object a) {
        T.assertEquals(e, a);
    }

    static void assertEquals(long e, long a) {
        T.assertEquals(e, a);
    }

    static File tempFile(String prefix) {
        try {
            return File.createTempFile(prefix, ".tmp");
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    static File writeTemp(String prefix, byte[] data) {
        try {
            File f = File.createTempFile(prefix, ".apk");
            Files.write(f.toPath(), data);
            return f;
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    static File copyZipWithExtraEntry() throws IOException {
        File result = tempFile("unsigned-extra");
        try (ZipFile zip = new ZipFile(Fixtures.FIXTURE_APK);
             java.util.zip.ZipOutputStream out = new java.util.zip.ZipOutputStream(new FileOutputStream(result))) {
            java.util.Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                out.putNextEntry(new ZipEntry(entry.getName()));
                try (InputStream in = zip.getInputStream(entry)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                out.closeEntry();
            }
            out.putNextEntry(new ZipEntry("assets/injected.txt"));
            out.write(1);
            out.closeEntry();
        }
        return result;
    }

    static byte[] readZipEntry(File apk, String name) throws IOException {
        ZipFile zf = new ZipFile(apk);
        try {
            ZipEntry e = zf.getEntry(name);
            if (e == null) {
                throw new IOException("нет записи " + name);
            }
            InputStream in = zf.getInputStream(e);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            try {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    bos.write(buf, 0, n);
                }
            } finally {
                in.close();
            }
            return bos.toByteArray();
        } finally {
            zf.close();
        }
    }

    /** Найти local header ZIP с указанным именем → [offset, dataOffset]. */
    static int[] findLocalHeader(byte[] data, String entryName) {
        byte[] want = entryName.getBytes(StandardCharsetsHolder.US_ASCII);
        for (int i = 0; i + 30 < data.length; i++) {
            if (data[i] == 0x50 && data[i + 1] == 0x4B && data[i + 2] == 0x03 && data[i + 3] == 0x04) {
                int nameLen = readU16LE(data, i + 26);
                int extraLen = readU16LE(data, i + 28);
                if (i + 30 + nameLen <= data.length && nameLen == want.length) {
                    boolean match = true;
                    for (int k = 0; k < nameLen; k++) {
                        if (data[i + 30 + k] != want[k]) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        return new int[]{i, i + 30 + nameLen + extraLen};
                    }
                }
            }
        }
        return null;
    }

    /** Найти central directory entry с именем → offset. */
    static int findCentralEntry(byte[] data, String entryName) {
        byte[] want = entryName.getBytes(StandardCharsetsHolder.US_ASCII);
        for (int i = 0; i + 46 < data.length; i++) {
            if (data[i] == 0x50 && data[i + 1] == 0x4B && data[i + 2] == 0x01 && data[i + 3] == 0x02) {
                int nameLen = readU16LE(data, i + 28);
                if (i + 46 + nameLen <= data.length && nameLen == want.length) {
                    boolean match = true;
                    for (int k = 0; k < nameLen; k++) {
                        if (data[i + 46 + k] != want[k]) {
                            match = false;
                            break;
                        }
                    }
                    if (match) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }

    /** Взлом: байт внутри classes.dex изменён, CRC в заголовках НЕ тронут. */
    static byte[] tamperDexWithoutPatchingCrc() {
        byte[] data = Fixtures.readFixtureApk();
        int[] lh = findLocalHeader(data, "classes.dex");
        assertTrue(lh != null, "classes.dex не найден в фикстуре");
        data[lh[1] + 128] ^= 0x5A;
        return data;
    }

    /** Взлом: байт изменён, CRC32 в local+central пересчитаны (читается как валидный ZIP). */
    static byte[] tamperDexWithPatchedCrc() {
        byte[] data = Fixtures.readFixtureApk();
        int[] lh = findLocalHeader(data, "classes.dex");
        assertTrue(lh != null, "classes.dex не найден в фикстуре");
        int method = readIntLE(data, lh[0] + 8);
        assertTrue(method == 0, "ожидался stored-entry для classes.dex, method=" + method);
        int size = readIntLE(data, lh[0] + 18);
        data[lh[1] + 128] ^= 0x5A;

        CRC32 crc = new CRC32();
        crc.update(data, lh[1], size);
        int crcValue = (int) crc.getValue();
        writeIntLE(data, lh[0] + 14, crcValue);           // local header
        int cd = findCentralEntry(data, "classes.dex");
        assertTrue(cd >= 0, "central entry для classes.dex не найден");
        writeIntLE(data, cd + 16, crcValue);              // central directory
        return data;
    }

    static int indexOf(byte[] hay, byte[] needle) {
        outer:
        for (int i = 0; i + needle.length <= hay.length; i++) {
            for (int k = 0; k < needle.length; k++) {
                if (hay[i + k] != needle[k]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }

    static int readIntLE(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8)
                | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
    }

    /** 16-битное поле заголовка ZIP (nameLen/extraLen — ровно 2 байта). */
    static int readU16LE(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
    }

    static void writeIntLE(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >> 8) & 0xFF);
        b[off + 2] = (byte) ((v >> 16) & 0xFF);
        b[off + 3] = (byte) ((v >> 24) & 0xFF);
    }

    private static final class StandardCharsetsHolder {
        static final java.nio.charset.Charset US_ASCII = java.nio.charset.StandardCharsets.US_ASCII;
    }
}
