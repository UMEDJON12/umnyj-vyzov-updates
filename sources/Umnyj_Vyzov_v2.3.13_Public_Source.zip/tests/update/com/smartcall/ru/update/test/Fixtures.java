package com.smartcall.ru.update.test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Общие фикстуры тестов: реальный APK «Умный Вызов» 2.3.7 (скопирован из
 * smartcall-project/dist только для чтения), его эталонные значения, и генераторы
 * stable.json / release JSON для fake-транспорта.
 */
public final class Fixtures {

    public static final File FIXTURE_APK =
            resolveFixture();

    /** SHA-256 файла (получен внешним инструментом — не нашим кодом). */
    public static final String FIXTURE_SHA256 =
            "5e8b27bc72ea024da86ff9e48ec56e956e3499ab2e921ee70006d52890f6ff8d";
    public static final long FIXTURE_SIZE = 207113L;
    public static final long FIXTURE_VERSION_CODE = 30L;
    public static final String FIXTURE_VERSION_NAME = "2.3.7";
    public static final String FIXTURE_PACKAGE = "com.smartcall.ru";
    public static final String FIXTURE_CERT_SHA256 =
            "baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01";

    public static final String STABLE_URL =
            "https://raw.githubusercontent.com/UMEDJON12/umnyj-vyzov-updates/main/updates/stable.json";
    public static final String RELEASE_URL =
            "https://api.github.com/repos/UMEDJON12/umnyj-vyzov-updates/releases/latest";
    public static final String TAG = "v2.3.7";
    public static final String APK_NAME = "SmartCall-2.3.7.apk";
    public static final String APK_URL =
            "https://github.com/UMEDJON12/umnyj-vyzov-updates/releases/download/v2.3.7/SmartCall-2.3.7.apk";
    /** Куда github.com редиректит скачивание ассета (белый список *.githubusercontent.com). */
    public static final String CDN_URL =
            "https://objects.githubusercontent.com/github-production-release-asset-2e65be/"
                    + "12345678/SmartCall-2.3.7.apk?token=NOT-A-SECRET-FOR-TESTS";

    private Fixtures() {
    }

    /** Ищет фикстуру относительно каталога классов и корня проекта. */
    private static File resolveFixture() {
        String[] candidates = {
            "tests/update/fixtures/SmartCall-2.3.7-fixture.apk",
            "test/fixtures/SmartCall-2.3.7-fixture.apk",
            "fixtures/SmartCall-2.3.7-fixture.apk",
        };
        for (String c : candidates) {
            File f = new File(c);
            if (f.isFile()) return f;
        }
        try {
            File here = new File(Fixtures.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            File dir = here.isDirectory() ? here : here.getParentFile();
            for (int i = 0; i < 6 && dir != null; i++, dir = dir.getParentFile()) {
                File f = new File(dir, "fixtures/SmartCall-2.3.7-fixture.apk");
                if (f.isFile()) return f;
                f = new File(dir, "tests/update/fixtures/SmartCall-2.3.7-fixture.apk");
                if (f.isFile()) return f;
            }
        } catch (Exception ignored) {
        }
        return new File(candidates[0]);
    }

    public static byte[] readFixtureApk() {
        try {
            return Files.readAllBytes(FIXTURE_APK.toPath());
        } catch (IOException e) {
            throw new IllegalStateException("нет фикстуры " + FIXTURE_APK, e);
        }
    }

    /** Валидный stable.json (по образцу канала calculator-umedjon-updates). */
    public static String stableJson() {
        return stableJson(FIXTURE_VERSION_CODE, FIXTURE_VERSION_NAME);
    }

    public static String stableJson(long versionCode, String versionName) {
        return "{\n"
                + "  \"schemaVersion\": 1,\n"
                + "  \"packageName\": \"com.smartcall.ru\",\n"
                + "  \"variant\": \"standard\",\n"
                + "  \"testOnly\": false,\n"
                + "  \"versionCode\": " + versionCode + ",\n"
                + "  \"versionName\": \"" + versionName + "\",\n"
                + "  \"minSdk\": 24,\n"
                + "  \"signingCertificateSha256\": \"" + FIXTURE_CERT_SHA256 + "\",\n"
                + "  \"sizeBytes\": " + FIXTURE_SIZE + ",\n"
                + "  \"sha256\": \"" + FIXTURE_SHA256 + "\",\n"
                + "  \"apkFileName\": \"" + APK_NAME + "\",\n"
                + "  \"apkUrl\": \"" + APK_URL + "\",\n"
                + "  \"releaseNotes\": \"Тестовое описание обновления\",\n"
                + "  \"ready\": true,\n"
                + "  \"tagName\": \"" + TAG + "\",\n"
                + "  \"publishedAt\": \"2026-11-11T00:00:00Z\"\n"
                + "}";
    }

    /** JSON публичного релиза GitHub, согласованный со stable.json. */
    public static String releaseJson() {
        return releaseJson(false, false);
    }

    public static String releaseJson(boolean draft, boolean prerelease) {
        return "{\n"
                + "  \"tag_name\": \"" + TAG + "\",\n"
                + "  \"name\": \"Умный Вызов " + FIXTURE_VERSION_NAME + "\",\n"
                + "  \"draft\": " + draft + ",\n"
                + "  \"prerelease\": " + prerelease + ",\n"
                + "  \"assets\": [\n"
                + "    {\"name\": \"" + APK_NAME + "\", \"size\": " + FIXTURE_SIZE
                + ", \"browser_download_url\": \"" + APK_URL + "\",\n"
                + "     \"content_type\": \"application/vnd.android.package-archive\"}\n"
                + "  ]\n"
                + "}";
    }

    public static byte[] utf8(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }
}
