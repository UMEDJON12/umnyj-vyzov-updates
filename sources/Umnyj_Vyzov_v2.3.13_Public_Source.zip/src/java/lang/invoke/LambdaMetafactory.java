package java.lang.invoke;
/** Compile-only: D8 desugars all lambdas at minimum API24; this stub is not packaged. */
public class LambdaMetafactory {
 public static CallSite metafactory(MethodHandles.Lookup caller, String name, MethodType type,
    MethodType sam, MethodHandle impl, MethodType instantiated) throws LambdaConversionException { return null; }
 public static CallSite altMetafactory(MethodHandles.Lookup caller, String name, MethodType type,
    Object... args) throws LambdaConversionException { return null; }
}
