package com.smartcall.ru;

/** Single-use, short-lived proof of a permitted physical user gesture.
 * No background callback, notification, ringtone or delayed job may grant it.
 */
public final class HangupPermit {
    private int key;
    private long issued;
    private boolean issuedValid;
    public synchronized boolean grant(int physicalKey, int state, boolean enabled, long nowMs) {
        issuedValid = false;
        if (!enabled || state != 1 && state != 2 || physicalKey != 1 && physicalKey != 2) return false;
        key = physicalKey;
        issued = nowMs;
        issuedValid = true;
        return true;
    }
    public synchronized boolean claim(int physicalKey, long nowMs) {
        boolean valid = issuedValid && key == physicalKey && nowMs >= issued && nowMs-issued <= 750;
        issuedValid = false;
        return valid;
    }
    public synchronized void revoke() { issuedValid = false; }
}
