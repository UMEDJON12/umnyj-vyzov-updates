package com.smartcall.ru;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.smartcall.ru.update.ReleaseManifest;
import com.smartcall.ru.update.ApprovedRelease;

/** Download progress shown as a modal dialog over the original activity.
 *  UpdateService remains the single owner of background network work.
 */
public final class UpdateDownloadDialog implements UpdateProgress.Listener, DialogInterface.OnDismissListener {
    private final Activity activity;
    private final ReleaseManifest release;
    private AlertDialog dialog;
    private TextView state, details;
    private ProgressBar progress;
    private Button left, right;
    private UpdateProgress.Phase lastPhase;
    private boolean listening;

    private UpdateDownloadDialog(Activity activity, ReleaseManifest release) {
        this.activity = activity;
        this.release = release;
    }

    public static void open(Activity activity, ReleaseManifest release) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        // API 24..29 still need a runtime storage permission flow for public Download.
        // Keep the established permission Activity on those devices.
        if (Build.VERSION.SDK_INT < 30) {
            UpdateProgressActivity.startDownload(activity, release);
            return;
        }
        new UpdateDownloadDialog(activity, release).show();
    }

    private int dp(int n) {
        return Math.round(n * activity.getResources().getDisplayMetrics().density);
    }
    private TextView text(LinearLayout parent, int size) {
        TextView t = new TextView(activity);
        t.setTextColor(UiTheme.onSurface(activity));
        t.setTextSize(size);
        t.setPadding(0, dp(5), 0, dp(5));
        parent.addView(t, new LinearLayout.LayoutParams(-1, -2));
        return t;
    }
    private Button button(LinearLayout parent, String label) {
        Button b = new Button(activity);
        b.setText(label);
        b.setAllCaps(false);
        b.setMinHeight(dp(48));
        parent.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        return b;
    }
    private void show() {
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(12), dp(20), dp(12));
        state = text(root, 17);
        state.setText("Подключение…");
        state.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
        details = text(root, 16);
        details.setText("Ожидание загрузки…");
        details.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
        progress = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(24)));
        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams buttonsMargin = new LinearLayout.LayoutParams(-1, -2);
        buttonsMargin.topMargin = dp(12);
        root.addView(actions, buttonsMargin);
        left = button(actions, "Скрыть");
        right = button(actions, "Отменить");
        dialog = new AlertDialog.Builder(activity)
                .setTitle("Загрузка обновления " + release.versionName)
                .setView(root)
                .create();
        dialog.setOnDismissListener(this);
        left.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (UpdateProgress.current().phase == UpdateProgress.Phase.READY)
                    UpdatesController.postponeDownloaded(activity);
                dialog.dismiss(); // does not cancel background download
            }
        });
        right.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                UpdateProgress.Phase phase = UpdateProgress.current().phase;
                if (phase == UpdateProgress.Phase.READY) {
                    UpdatesController.installDownloaded(activity);
                    dialog.dismiss();
                } else if (phase == UpdateProgress.Phase.ERROR || phase == UpdateProgress.Phase.CANCELLED) {
                    UpdateService.startDownload(activity, release.versionName, release.versionCode,
                            ApprovedRelease.fingerprint(release));
                } else if (phase == UpdateProgress.Phase.RECHECK) {
                    dialog.dismiss();
                    UpdatesController.checkManually(activity);
                } else if (phase == UpdateProgress.Phase.STORAGE_PERMISSION) {
                    dialog.dismiss();
                    UpdateProgressActivity.startDownload(activity, release);
                } else {
                    UpdateService.cancel(activity);
                }
            }
        });
        dialog.show();
        listening = true;
        UpdateProgress.listen(this);
        if (!UpdateProgress.current().running() &&
                (UpdateProgress.current().phase != UpdateProgress.Phase.READY
                 || !release.versionName.equals(UpdateProgress.current().version))) {
            UpdateService.startDownload(activity, release.versionName, release.versionCode,
                    ApprovedRelease.fingerprint(release));
        }
    }

    @Override public void onUpdate(UpdateProgress.Snapshot snapshot) {
        if (!listening || dialog == null || !dialog.isShowing()
                || activity.isFinishing() || activity.isDestroyed()) return;
        switch (snapshot.phase) {
            case CONNECTING: state.setText("Подключение к серверу…"); break;
            case DOWNLOADING: state.setText("Скачивание APK…"); break;
            case VERIFYING: state.setText("Проверка загруженного файла…"); break;
            case SAVING: state.setText("Сохранение проверенного APK…"); break;
            case READY: state.setText("APK скачан и проверен"); break;
            case CANCELLED: state.setText("Скачивание отменено"); break;
            case RECHECK: state.setText("Версия изменилась, требуется новая проверка"); break;
            case STORAGE_PERMISSION: state.setText("Нужно разрешение на сохранение файла"); break;
            case ERROR: state.setText("Ошибка загрузки: " + snapshot.message); break;
            default: state.setText(snapshot.message.isEmpty() ? "Ожидание…" : snapshot.message);
        }
        // Show manifest-verified total before first bytes arrive, not invented progress.
        long total = snapshot.total > 0 ? snapshot.total : release.sizeBytes;
        details.setText(UpdateProgressText.progress(snapshot.downloaded, total));
        int percent = UpdateProgressText.percent(snapshot.downloaded, total);
        progress.setIndeterminate(snapshot.phase == UpdateProgress.Phase.CONNECTING || total <= 0);
        if (total > 0) progress.setProgress(percent);
        boolean ready = snapshot.phase == UpdateProgress.Phase.READY;
        boolean retry = snapshot.phase == UpdateProgress.Phase.ERROR
                || snapshot.phase == UpdateProgress.Phase.CANCELLED
                || snapshot.phase == UpdateProgress.Phase.RECHECK
                || snapshot.phase == UpdateProgress.Phase.STORAGE_PERMISSION;
        left.setText(ready ? "Позже" : "Скрыть");
        right.setText(ready ? "Установить" : retry
                ? (snapshot.phase == UpdateProgress.Phase.RECHECK ? "Проверить снова" : "Повторить")
                : "Отменить");
        if (lastPhase != snapshot.phase && lastPhase != null) {
            state.announceForAccessibility(state.getText());
        }
        lastPhase = snapshot.phase;
    }

    @Override public void onDismiss(DialogInterface ignored) {
        if (listening) UpdateProgress.unlisten(this);
        listening = false;
        dialog = null;
    }
}
