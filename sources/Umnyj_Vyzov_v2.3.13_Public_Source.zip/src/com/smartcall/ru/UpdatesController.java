package com.smartcall.ru;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import com.smartcall.ru.update.FileKeyValueStore;
import com.smartcall.ru.update.ReleaseManifest;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateEngine;
import com.smartcall.ru.update.UpdateException;
import com.smartcall.ru.update.UpdateState;
import com.smartcall.ru.update.UrlConnectionTransport;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Тонкая обвязка модуля обновлений над UI приложения.
 *
 * Все сетевые и криптографические проверки выполняет {@link UpdateEngine};
 * здесь — потоки, диалоги и запуск системного установщика. Никаких секретов
 * и токенов: канал публичный, проверяется сертификат подписи установленного
 * приложения, размер, SHA-256, пакет и версия.
 */
public final class UpdatesController {
    public static final int CURRENT_VERSION_CODE = 34;
    public static final String CURRENT_VERSION_NAME = "2.3.11";

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static UpdateEngine engine;
    private static final java.util.concurrent.atomic.AtomicBoolean busy = new java.util.concurrent.atomic.AtomicBoolean();
    private static java.lang.ref.WeakReference<Activity> foreground = new java.lang.ref.WeakReference<>(null);

    private UpdatesController() {}

    public static synchronized void onActivityResumed(Activity activity) {
        foreground = new java.lang.ref.WeakReference<>(activity);
    }
    public static synchronized void onActivityPaused(Activity activity) {
        if (foreground.get() == activity) foreground.clear();
    }
    private static synchronized Activity activeActivity() {
        Activity a = foreground.get();
        return a == null || a.isFinishing() || a.isDestroyed() ? null : a;
    }

    public static long installedVersionCode(Context context) {
        long code = AppVersion.code(context);
        return code > 0 ? code : CURRENT_VERSION_CODE;
    }

    public static synchronized UpdateEngine engine(Context context) {
        if (engine == null) {
            Context app = context.getApplicationContext();
            File files = app.getFilesDir();
            UpdateState state = new UpdateState(new FileKeyValueStore(new File(files, "update_state")));
            UpdateEngine candidate = new UpdateEngine(
                    com.smartcall.ru.update.UpdateConfig.defaults(),
                    new UrlConnectionTransport(),
                    state,
                    new File(files, "updates"),
                    Build.VERSION.SDK_INT,
                    new UpdateEngine.Logger() {
                        @Override // UpdateEngine.Logger
                        public void log(String message) {
                            CallController.log("Обновления: " + message);
                        }
                    });
            candidate.noteInstalled(installedVersionCode(context));
            engine = candidate; // publish only after state was successfully validated
        }
        return engine;
    }

    public static boolean isAutoCheckEnabled(Context context) {
        try {
            return engine(context).state().isAutoCheckEnabled();
        } catch (RuntimeException e) {
            return true;
        }
    }

    public static void setAutoCheckEnabled(Context context, boolean enabled) {
        try {
            engine(context).state().setAutoCheckEnabled(enabled);
        } catch (RuntimeException e) {
            CallController.log("Обновления: не удалось сохранить настройку проверки");
        }
    }

    /** MainActivity invokes this once per opening; «Позже» is evaluated by UpdateEngine. */
    public static void autoCheck(final Activity activity) {
        if (activity == null || !isAutoCheckEnabled(activity)) return;
        runCheck(activity, false);
    }

    /** Ручная проверка из настроек. */
    public static void checkManually(final Activity activity) {
        runCheck(activity, true);
    }

    /** «Позже» after download keeps the file and suppresses the same version automatically. */
    public static void postponeDownloaded(Context context) {
        final Context app = context.getApplicationContext();
        final DownloadStore.Record record = DownloadStore.read(app);
        if (record == null) return;
        IO.execute(new Runnable() { public void run() {
            try { engine(app).postpone(record.versionCode); }
            catch (RuntimeException e) { CallController.log("Обновления: не удалось запомнить «Позже» для скачанного APK"); }
        }});
    }

    private static void runCheck(final Activity activity, final boolean manual) {
        if (!busy.compareAndSet(false, true)) {
            if (manual) showStatus(activity, "Обновление", "Проверка обновления уже выполняется.");
            return;
        }
        IO.execute(new Runnable() {
            @Override // java.lang.Runnable
            public void run() {
                try {
                    final UpdateEngine e = engine(activity);
                    final ReleaseManifest m = e.check(installedVersionCode(activity));
                    if (!e.shouldOffer(m, manual)) {
                        // «Позже» is deliberately silent on automatic checks.
                        busy.set(false);
                        return;
                    }
                    MAIN.post(new Runnable() {
                        @Override // java.lang.Runnable
                        public void run() {
                            busy.set(false);
                            Activity target = activeActivity();
                            if (target != null) offer(target, m);
                            else CallController.log("Обновления: новая версия обнаружена, экран приложения закрыт");
                        }
                    });
                } catch (UpdateException ex) {
                    StatusCode status = ex.status();
                    if (!UpdateNoticePolicy.shouldShow(manual, status)) {
                        // Background informational outcomes and errors never block startup.
                        if (status.isFailure()) CallController.log("Обновления: " + ex.userMessage());
                        busy.set(false);
                        return;
                    }
                    final String text = status.isFailure() ? "Не удалось проверить обновления: " + ex.userMessage() : status.text();
                    finish(activity, "Обновление", text);
                } catch (RuntimeException ex) {
                    CallController.log("Обновления: ошибка проверки " + ex.getClass().getSimpleName());
                    if (manual) finish(activity, "Обновление", ex instanceof IllegalStateException
                            ? "Не удалось проверить обновления: состояние обновлений повреждено или недоступно."
                            : "Не удалось проверить обновления: " + ex.getClass().getSimpleName());
                    else busy.set(false);
                }
            }
        });
    }

    private static void finish(final Activity activity, final String title, final String message) {
        MAIN.post(new Runnable() {
            @Override // java.lang.Runnable
            public void run() {
                busy.set(false);
                Activity target = activeActivity();
                if (target != null) showStatus(target, title, message);
                else CallController.log("Обновления: результат проверки доступен при следующем запросе");
            }
        });
    }

    private static void showStatus(Activity activity, String title, String message) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) return;
        try {
            new AlertDialog.Builder(activity).setTitle(title).setMessage(message)
                    .setNegativeButton("ОК", null).show();
        } catch (RuntimeException ignored) {
        }
    }

    /** Диалог «Доступно обновление» с кнопками «Позже» и «Скачать». */
    private static void offer(final Activity activity, final ReleaseManifest m) {
        try {
            String size = m.sizeBytes >= 1024 * 1024
                    ? String.format(java.util.Locale.US, "%.1f МБ", m.sizeBytes / (1024.0 * 1024.0))
                    : (m.sizeBytes / 1024) + " КБ";
            StringBuilder msg = new StringBuilder();
            msg.append("Версия ").append(m.versionName).append(" (код ").append(m.versionCode).append(")\n");
            msg.append("Размер: ").append(size).append('\n');
            if (m.releaseNotes != null && !m.releaseNotes.trim().isEmpty()) {
                msg.append("\n").append(UpdateNoteSummary.summarize(m.releaseNotes));
            }
            final android.widget.LinearLayout panel = new android.widget.LinearLayout(activity);
            panel.setOrientation(android.widget.LinearLayout.VERTICAL);
            int pad = Math.round(20 * activity.getResources().getDisplayMetrics().density);
            panel.setPadding(pad, pad / 2, pad, pad / 2);
            android.widget.TextView summary = new android.widget.TextView(activity);
            summary.setText(msg.toString());
            summary.setTextSize(16);
            summary.setTextColor(UiTheme.onSurface(activity));
            panel.addView(summary, new android.widget.LinearLayout.LayoutParams(-1, -2));
            android.widget.LinearLayout actions = new android.widget.LinearLayout(activity);
            actions.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            // Physical order: left «Позже», right «Скачать» (including RTL device layouts).
            actions.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
            android.widget.LinearLayout.LayoutParams actionsLp = new android.widget.LinearLayout.LayoutParams(-1, -2);
            actionsLp.topMargin = pad;
            panel.addView(actions, actionsLp);
            android.widget.Button postpone = new android.widget.Button(activity);
            postpone.setText("Позже");
            postpone.setAllCaps(false);
            postpone.setMinHeight(pad * 2);
            actions.addView(postpone, new android.widget.LinearLayout.LayoutParams(0, -2, 1));
            android.widget.Button download = new android.widget.Button(activity);
            download.setText("Скачать");
            download.setAllCaps(false);
            download.setMinHeight(pad * 2);
            actions.addView(download, new android.widget.LinearLayout.LayoutParams(0, -2, 1));
            final AlertDialog offerDialog = new AlertDialog.Builder(activity)
                    .setTitle("Доступно новое обновление")
                    .setView(panel).create();
            postpone.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    offerDialog.dismiss();
                    IO.execute(new Runnable() {
                        @Override public void run() {
                            try {
                                engine(activity).postpone(m.versionCode);
                                CallController.log("Обновление " + m.versionName + " отложено");
                            } catch (RuntimeException ex) {
                                CallController.log("Обновления: не удалось сохранить «Позже»");
                                MAIN.post(new Runnable() { @Override public void run() {
                                    Activity target = activeActivity();
                                    if (target != null) showStatus(target, "Обновление", "Не удалось запомнить «Позже».");
                                }});
                            }
                        }
                    });
                }
            });
            download.setOnClickListener(new android.view.View.OnClickListener() {
                @Override public void onClick(android.view.View v) {
                    offerDialog.dismiss();
                    UpdateDownloadDialog.open(activity, m);
                }
            });
            offerDialog.show();
        } catch (RuntimeException ignored) {
        }
    }

    private static final int REQUEST_INSTALL_SOURCE = 4213;

    /** Re-read the saved public copy, then verify a private snapshot before granting it. */
    public static void installDownloaded(final Context context) {
        final Activity activity = asActivity(context);
        if (activity == null) {
            CallController.log("Обновления: установка требует открытого экрана приложения");
            return;
        }
        if (!busy.compareAndSet(false, true)) {
            showStatus(activity, "Установка", "Другая операция обновления ещё выполняется.");
            return;
        }
        IO.execute(new Runnable() { public void run() {
            try {
                final UpdateEngine e = engine(context);
                final DownloadStore.Record record = DownloadStore.read(context);
                if (record == null) {
                    com.smartcall.ru.update.UpdateState.Downloaded old = e.state().downloaded();
                    MAIN.post(new Runnable() { public void run() {
                        busy.set(false);
                        Activity target = activeActivity();
                        if (target == null) return;
                        if (old != null && old.versionCode > installedVersionCode(target)) {
                            // A 2.3.8 private download can be exported without downloading again.
                            UpdateProgressActivity.startExportExisting(target);
                        } else {
                            showInstallProblem(target, old == null ? "Скачанный APK не найден. Проверьте наличие обновлений."
                                    : "Установлена такая же или более новая версия.");
                        }
                    }});
                    return;
                }
                final File snapshot;
                synchronized (e) {
                    long installed = installedVersionCode(context);
                    StatusCode status = com.smartcall.ru.update.InstallVersionPolicy.status(
                            installed, e.state().knownVersionCode(), record.versionCode);
                    if (status != StatusCode.OK) {
                        throw new UpdateException(status, "сохранённая версия не может быть установлена поверх текущей");
                    }
                    snapshot = DownloadStore.snapshotForInstall(context, record, installed);
                }
                MAIN.post(new Runnable() { public void run() {
                    busy.set(false);
                    Activity target = activeActivity();
                    if (target != null) launchInstaller(target, snapshot, record);
                    else CallController.log("Обновления: APK проверен; для установки откройте приложение снова");
                }});
            } catch (UpdateException ex) {
                CallController.log("Обновления, проверка перед установкой: " + ex.userMessage());
                final String message = ex.status() == StatusCode.UP_TO_DATE
                        ? "Установлена такая же или более новая версия."
                        : ex.status() == StatusCode.NO_FILE
                        ? "Сохранённый APK не найден или недоступен. Проверьте папку Download."
                        : ex.status() == StatusCode.STORAGE
                        ? "Не удалось подготовить APK: " + ex.userMessage() + ". Проверьте доступное место и повторите."
                        : "APK не прошёл проверку: " + ex.userMessage() + ". Проверьте обновления для повторного скачивания.";
                MAIN.post(new Runnable() { public void run() { busy.set(false); Activity target = activeActivity(); if (target != null) showInstallProblem(target, message); }});
            } catch (RuntimeException ex) {
                CallController.log("Обновления, установка: " + ex.getClass().getSimpleName());
                MAIN.post(new Runnable() { public void run() { busy.set(false); Activity target = activeActivity(); if (target != null) showInstallProblem(target, "Не удалось подготовить APK к установке."); }});
            }
        }});
    }

    private static Activity asActivity(Context context) {
        return context instanceof Activity ? (Activity) context : null;
    }

    private static void launchInstaller(final Activity activity, File file, DownloadStore.Record record) {
        if (Build.VERSION.SDK_INT >= 26 && !activity.getPackageManager().canRequestPackageInstalls()) {
            try {
            new AlertDialog.Builder(activity).setTitle("Разрешение на установку")
                    .setMessage("Чтобы открыть системный установщик, разрешите установку из этого приложения в настройках Android. Это действие выполняете вы; сохранённый APK останется в Download.")
                    .setPositiveButton("Открыть настройки", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            try {
                                Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + activity.getPackageName()));
                                activity.startActivityForResult(i, REQUEST_INSTALL_SOURCE);
                            } catch (RuntimeException e) {
                                showInstallProblem(activity, "Не удалось открыть настройки разрешения. Откройте APK из Download вручную.");
                            }
                        }
                    }).setNegativeButton("Позже", null).show();
            } catch (RuntimeException e) {
                CallController.log("Обновления: экран разрешения установки недоступен");
            }
            return;
        }
        try {
            Uri uri = UpdateInstallProvider.authorizeSnapshot(activity, file, record.name);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.setClipData(android.content.ClipData.newRawUri(record.name, uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(intent);
            CallController.log("Обновления: открыт системный установщик (установка не подтверждена)");
        } catch (java.io.IOException | RuntimeException ex) {
            CallController.log("Обновления: установщик недоступен (" + ex.getClass().getSimpleName() + ")");
            showInstallProblem(activity, "Не удалось открыть системный установщик. Откройте сохранённый APK в папке Download вручную.");
        }
    }

    public static void onInstallPermissionResult(Activity activity, int requestCode) {
        if (requestCode != REQUEST_INSTALL_SOURCE) return;
        if (Build.VERSION.SDK_INT < 26 || activity.getPackageManager().canRequestPackageInstalls()) installDownloaded(activity);
        else showInstallProblem(activity, "Разрешение на установку не выдано. Файл сохранён в Download.");
    }

    private static void showInstallProblem(final Activity activity, String message) {
        if (activity == null || activity.isFinishing()) return;
        new AlertDialog.Builder(activity).setTitle("Установка обновления").setMessage(message)
                .setPositiveButton("Открыть Download", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { openDownloads(activity); }
                }).setNeutralButton("Проверить обновления", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { checkManually(activity); }
                }).setNegativeButton("Закрыть", null).show();
    }

    public static void openDownloads(Activity activity) {
        try { activity.startActivity(new Intent("android.intent.action.VIEW_DOWNLOADS")); }
        catch (RuntimeException ex) {
            try {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                activity.startActivity(i);
            } catch (RuntimeException ignored) { showStatus(activity, "Download", "Откройте папку Download в файловом менеджере."); }
        }
    }

    public static boolean hasDownloaded(Context context) {
        try { return DownloadStore.read(context) != null || engine(context).state().downloaded() != null; }
        catch (RuntimeException e) { return false; }
    }
}
