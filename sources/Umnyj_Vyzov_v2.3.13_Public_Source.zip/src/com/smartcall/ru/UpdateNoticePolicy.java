package com.smartcall.ru;

import com.smartcall.ru.update.StatusCode;

/** Presentation policy only; the channel checker still validates all responses. */
public final class UpdateNoticePolicy {
    private UpdateNoticePolicy() { }

    public static boolean shouldShow(boolean manual, StatusCode status) {
        return manual;
    }
}
