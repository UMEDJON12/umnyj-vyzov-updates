package com.smartcall.ru;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;

/** Sources are tagged; no contact names or numbers are stored. */
public final class SimCallMonitor {
    private static final SimCallEvidence EVIDENCE = new SimCallEvidence();
    private static volatile String lastSource = "нет";
    private static volatile int lastState = -1;
    private static volatile long lastEventMs;
    private static final String PREF = "smartcall_last_sim_call";
    private static final int LIMIT = 14000;
    private SimCallMonitor() { }

    public static void event(Context ctx, int subscription, int state, String source) {
        long now=SystemClock.elapsedRealtime();
        EVIDENCE.event(subscription,state,now,source);
        lastSource=source; lastState=state; lastEventMs=now;
        CallController.log("SIM: " + source + " sub=" + subscription + " state=" + state + " @" + now);
        if (ctx != null) {
            synchronized (SimCallMonitor.class) {
                SharedPreferences prefs=ctx.getApplicationContext().getSharedPreferences(PREF,0);
                String previous=prefs.getString("events", "");
                if (state==1 && (previous.isEmpty() || !previous.contains("RINGING") || previous.contains("\nEND"))) previous="";
                String type=state==1?"RINGING":state==2?"OFFHOOK":"IDLE";
                String row="\n" + System.currentTimeMillis() + " / +" + now + "ms " + type
                    + " source=" + source + " sim=" + subscription;
                String merged=(previous+row);
                if (merged.length()>LIMIT) merged=merged.substring(merged.length()-LIMIT);
                prefs.edit().putString("events", merged + (state==0?"\nEND (причина системой не раскрыта)":"")).apply();
            }
        }
        // Only a positive or explicit end telephony state can update the ringing indicator.
        if (state==1) {
            CallController.simRinging=true;
            CallController.recordActiveCallState(1);
        } else if (state==2) {
            CallController.recordActiveCallState(2);
        } else if (EVIDENCE.authoritative(now,60000)!=1) {
            CallController.simRinging=false;
            CallController.recordActiveCallState(0);
        }
    }

    public static int hardwareState(Context context) {
        long now=SystemClock.elapsedRealtime();
        int observed=0;
        try {
            TelephonyManager tm=(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm!=null) observed=tm.getCallState();
        } catch (RuntimeException e) { CallController.log("SIM опрос: " + e.getClass().getSimpleName()); }
        EVIDENCE.observed(observed,now);
        if (observed==1 || observed==2) return observed;
        // Keep a recent explicit RINGING transition through transient aggregate IDLE.
        boolean inCall=false;
        try { TelecomManager telecom=(TelecomManager)context.getSystemService(Context.TELECOM_SERVICE);
              inCall=telecom!=null && telecom.isInCall(); }
        catch (RuntimeException e) { CallController.log("Telecom.isInCall: " + e.getClass().getSimpleName()); }
        int trusted=EVIDENCE.authoritative(now,inCall?60000:3000);
        if (trusted==1 && !inCall) CallController.log("SIM: недавний RINGING при агрегатном IDLE; окно не более 3с");
        return trusted;
    }
    public static int phoneObserved(Context ctx) {
        try { TelephonyManager tm=(TelephonyManager)ctx.getSystemService(Context.TELEPHONY_SERVICE);
              return tm!=null?tm.getCallState():-1; }
        catch (RuntimeException e) { return -1; }
    }
    public static String diagnostic(Context ctx) {
        return "Последний входящий SIM-звонок (без номера):\n"+
          ctx.getApplicationContext().getSharedPreferences(PREF,0).getString("events","нет записей")
          +"\nИсточники состояний: "+EVIDENCE.snapshot(SystemClock.elapsedRealtime())
          +"\nПоследнее событие="+lastState+" от "+lastSource+" @"+lastEventMs;
    }
    public static void note(Context ctx,String action) {
        if (ctx==null) return;
        synchronized (SimCallMonitor.class) {
            SharedPreferences p=ctx.getApplicationContext().getSharedPreferences(PREF,0);
            String current=p.getString("events","");
            String sanitized=action.replaceAll("[\r\n]", " ");
            if (sanitized.length()>240) sanitized=sanitized.substring(0,240);
            current += "\n"+System.currentTimeMillis()+" / +"+SystemClock.elapsedRealtime()+"ms "+sanitized;
            if(current.length()>LIMIT)current=current.substring(current.length()-LIMIT);
            p.edit().putString("events",current).apply();
        }
    }
}
