package com.smartcall.ru;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.smartcall.ru.update.ReleaseManifest;

/** Accessible progress screen; the service owns the operation and continues when this closes. */
public final class UpdateProgressActivity extends Activity implements UpdateProgress.Listener {
    private static final int REQUEST_STORAGE = 4212;
    private static final String EXTRA_START = "start_operation";
    private static final String EXTRA_EXISTING = "export_existing";
    private static final String EXTRA_VERSION = "version";
    private static final String EXTRA_CODE = "version_code";
    private static final String EXTRA_APPROVAL = "release_fingerprint";
    private TextView title, version, state, details;
    private ProgressBar bar;
    private Button cancel, retry, install, openDownloads, later;
    private boolean existing;
    private String expectedVersion = "";
    private long expectedCode;
    private String approvedFingerprint;
    private boolean startPending;
    private boolean permissionInFlight;
    private UpdateProgress.Phase lastAnnouncedPhase;

    public static void startDownload(Activity activity, ReleaseManifest manifest) {
        Intent i = new Intent(activity, UpdateProgressActivity.class);
        i.putExtra(EXTRA_START, true); i.putExtra(EXTRA_VERSION, manifest.versionName);
        i.putExtra(EXTRA_CODE, manifest.versionCode);
        i.putExtra(EXTRA_APPROVAL, com.smartcall.ru.update.ApprovedRelease.fingerprint(manifest));
        activity.startActivity(i);
    }
    public static void startExportExisting(Activity activity) {
        Intent i = new Intent(activity, UpdateProgressActivity.class);
        i.putExtra(EXTRA_START, true); i.putExtra(EXTRA_EXISTING, true);
        activity.startActivity(i);
    }
    public static Intent openIntent(android.content.Context context) {
        return new Intent(context, UpdateProgressActivity.class).setAction("com.smartcall.ru.action.UPDATE_PROGRESS");
    }

    @Override protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(MainActivity.applyThemeMode(base));
    }
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        existing = savedInstanceState != null ? savedInstanceState.getBoolean("export_existing", false)
                : intent != null && intent.getBooleanExtra(EXTRA_EXISTING, false);
        expectedVersion = intent == null ? "" : intent.getStringExtra(EXTRA_VERSION);
        if (expectedVersion == null) expectedVersion = "";
        expectedCode = intent == null ? 0 : intent.getLongExtra(EXTRA_CODE, 0);
        approvedFingerprint = intent == null ? null : intent.getStringExtra(EXTRA_APPROVAL);
        buildScreen();
        startPending = savedInstanceState != null ? savedInstanceState.getBoolean("pending_start", false)
                : intent != null && intent.getBooleanExtra(EXTRA_START, false);
        permissionInFlight = savedInstanceState != null && savedInstanceState.getBoolean("permission_in_flight", false);
        if (UpdateProgress.current().running()) startPending = false;
        if (startPending && !permissionInFlight) askStorageOrStart();
    }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView label(LinearLayout parent, float size) {
        TextView v = new TextView(this); v.setTextSize(size); v.setTextColor(UiTheme.onSurface(this));
        v.setPadding(0, dp(8), 0, dp(8)); parent.addView(v); return v;
    }
    private Button button(LinearLayout parent, String text, int color) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(16);
        b.setMinHeight(dp(48)); b.setTextColor(UiTheme.onSurface(this));
        b.setBackground(UiTheme.rounded(this, color, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0,dp(6),0,dp(6));
        parent.addView(b,lp); return b;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(24),dp(20),dp(24)); root.setBackgroundColor(UiTheme.window(this));
        scroll.addView(root); setContentView(scroll);
        title = label(root,24); title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setText("Обновление «Умный Вызов»");
        if (Build.VERSION.SDK_INT >= 28) title.setAccessibilityHeading(true);
        version = label(root,18); state = label(root,17); details = label(root,16);
        state.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
        details.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setContentDescription("Прогресс скачивания APK");
        bar.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_NONE);
        // The adjacent text exposes the same real percentage without progress-bar event spam.
        bar.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(24)));
        cancel = button(root,"Отменить скачивание",UiTheme.errorContainer(this));
        retry = button(root,"Повторить",UiTheme.primaryContainer(this));
        install = button(root,"Установить",UiTheme.primaryContainer(this));
        openDownloads = button(root,"Открыть папку Download",UiTheme.secondaryContainer(this));
        later = button(root,"Позже",UiTheme.surfaceVariant(this));
        cancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { UpdateService.cancel(UpdateProgressActivity.this); } });
        retry.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            if (UpdateProgress.current().phase == UpdateProgress.Phase.RECHECK) {
                UpdatesController.checkManually(UpdateProgressActivity.this);
                return;
            }
            try {
                com.smartcall.ru.update.UpdateState.Downloaded cached = UpdatesController.engine(UpdateProgressActivity.this).state().downloaded();
                if (cached != null && expectedCode > 0 && cached.versionCode == expectedCode) existing = true;
            } catch (RuntimeException ignored) { }
            if (!existing && expectedCode <= 0) UpdatesController.checkManually(UpdateProgressActivity.this);
            else askStorageOrStart();
        } });
        install.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { UpdatesController.installDownloaded(UpdateProgressActivity.this); } });
        openDownloads.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openDownloads(); } });
        later.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            if (UpdateProgress.current().phase == UpdateProgress.Phase.READY || DownloadStore.read(UpdateProgressActivity.this) != null) {
                UpdatesController.postponeDownloaded(UpdateProgressActivity.this);
            }
            finish();
        } });
    }
    @Override protected void onResume() {
        super.onResume();
        UpdatesController.onActivityResumed(this);
        UpdateProgress.listen(this);
        if (startPending && permissionInFlight && Build.VERSION.SDK_INT <= 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            permissionInFlight = false;
            askStorageOrStart();
        }
    }
    @Override protected void onPause() {
        UpdateProgress.unlisten(this);
        UpdatesController.onActivityPaused(this);
        super.onPause();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putBoolean("export_existing", existing);
        out.putBoolean("pending_start", startPending);
        out.putBoolean("permission_in_flight", permissionInFlight);
        super.onSaveInstanceState(out);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UpdatesController.onInstallPermissionResult(this, requestCode);
    }

    private void askStorageOrStart() {
        startPending = true;
        boolean legacyGrant = Build.VERSION.SDK_INT <= 28
                || (Build.VERSION.SDK_INT == 29 && UpdateProgress.current().phase == UpdateProgress.Phase.STORAGE_PERMISSION);
        if (legacyGrant && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            new AlertDialog.Builder(this).setTitle("Сохранение в Download")
                    .setMessage("Система требует разрешение на запись файлов, чтобы сохранить проверенный APK в Download. Разрешение запрашивается только для этой операции.")
                    .setPositiveButton("Продолжить", (d,w) -> {
                        permissionInFlight = true;
                        requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_STORAGE);
                    })
                    .setNegativeButton("Не сейчас", (d,w) -> {
                        startPending = false;
                        UpdateProgress.publishIfIdle(Build.VERSION.SDK_INT == 29 ? UpdateProgress.Phase.STORAGE_PERMISSION : UpdateProgress.Phase.ERROR,
                                expectedVersion, "Сохранение в Download отменено: разрешение не предоставлено.",0,0);
                    }).setCancelable(false).show();
            return;
        }
        startPending = false;
        permissionInFlight = false;
        if (existing) UpdateService.startExportExisting(this);
        else UpdateService.startDownload(this, expectedVersion, expectedCode, approvedFingerprint);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_STORAGE) {
            if (!startPending) return;
            permissionInFlight = false;
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) askStorageOrStart();
            else {
                startPending = false;
                UpdateProgress.publishIfIdle(Build.VERSION.SDK_INT == 29 ? UpdateProgress.Phase.STORAGE_PERMISSION : UpdateProgress.Phase.ERROR,
                        expectedVersion, "Нет разрешения для сохранения в Download. Можно повторить или открыть настройки приложения.",0,0);
            }
        }
    }
    @Override public void onUpdate(UpdateProgress.Snapshot s) {
        if (isFinishing()) return;
        boolean ready = s.phase == UpdateProgress.Phase.READY;
        if (s.phase == UpdateProgress.Phase.IDLE) {
            DownloadStore.Record record = DownloadStore.read(this);
            if (record != null) {
                version.setText("Версия " + record.versionName);
                state.setText("Ранее сохранённый APK. Перед установкой файл будет проверен заново.");
                details.setText("Файл: " + record.name);
                bar.setVisibility(View.GONE); cancel.setVisibility(View.GONE); retry.setVisibility(View.GONE);
                install.setVisibility(View.VISIBLE); openDownloads.setVisibility(View.VISIBLE); later.setVisibility(View.VISIBLE);
                return;
            }
            try {
                com.smartcall.ru.update.UpdateState.Downloaded previous = UpdatesController.engine(this).state().downloaded();
                if (previous != null && previous.versionCode > UpdatesController.installedVersionCode(this)) {
                    version.setText("Версия " + previous.versionName);
                    state.setText("Ранее скачанный APK хранится в приложении. Перед установкой он будет проверен и сохранён в Download.");
                    details.setText(""); bar.setVisibility(View.GONE); cancel.setVisibility(View.GONE); retry.setVisibility(View.GONE);
                    install.setVisibility(View.VISIBLE); openDownloads.setVisibility(View.VISIBLE); later.setVisibility(View.VISIBLE);
                    return;
                }
            } catch (RuntimeException e) {
                version.setText("Версия: неизвестна");
                state.setText("Не удалось прочитать сведения о ранее скачанном APK.");
                details.setText(""); bar.setVisibility(View.GONE); cancel.setVisibility(View.GONE);
                retry.setVisibility(View.VISIBLE); install.setVisibility(View.GONE);
                openDownloads.setVisibility(View.VISIBLE); later.setVisibility(View.VISIBLE);
                CallController.log("Обновления: состояние загрузки недоступно");
                return;
            }
        }
        version.setText("Версия: " + (s.version.isEmpty() ? (expectedVersion.isEmpty() ? "уточняется" : expectedVersion) : s.version));
        state.setText(s.message.isEmpty() ? phaseText(s.phase) : s.message);
        if (lastAnnouncedPhase != null && lastAnnouncedPhase != s.phase) {
            state.announceForAccessibility(state.getText());
        }
        lastAnnouncedPhase = s.phase;
        details.setText(UpdateProgressText.progress(s.downloaded, s.total));
        int percent = UpdateProgressText.percent(s.downloaded, s.total);
        bar.setVisibility(s.running() || ready ? View.VISIBLE : View.GONE);
        bar.setIndeterminate(percent < 0 && s.running());
        if (percent >= 0) bar.setProgress(percent);
        bar.setContentDescription(percent < 0 ? "Прогресс скачивания: размер неизвестен" : "Прогресс скачивания: " + percent + " процентов");
        cancel.setVisibility(s.running() ? View.VISIBLE : View.GONE);
        retry.setText(s.phase == UpdateProgress.Phase.RECHECK ? "Проверить обновления"
                : s.phase == UpdateProgress.Phase.STORAGE_PERMISSION ? "Разрешить и повторить" : "Повторить");
        retry.setVisibility((s.phase == UpdateProgress.Phase.ERROR || s.phase == UpdateProgress.Phase.CANCELLED
                || s.phase == UpdateProgress.Phase.RECHECK || s.phase == UpdateProgress.Phase.STORAGE_PERMISSION)
                ? View.VISIBLE : View.GONE);
        install.setVisibility(ready ? View.VISIBLE : View.GONE);
        openDownloads.setVisibility(ready ? View.VISIBLE : View.GONE);
        later.setVisibility(s.running() ? View.GONE : View.VISIBLE);
    }
    private static String phaseText(UpdateProgress.Phase phase) {
        switch (phase) {
            case CONNECTING: return "Подключение…";
            case DOWNLOADING: return "Скачивание…";
            case VERIFYING: return "Проверка файла…";
            case SAVING: return "Сохранение проверенного файла…";
            case READY: return "APK скачан и проверен. Файл сохранён в папке Download";
            case CANCELLED: return "Скачивание отменено";
            case ERROR: return "Не удалось скачать обновление";
            case RECHECK: return "Обновление изменилось. Проверьте обновления ещё раз.";
            case STORAGE_PERMISSION: return "Для сохранения требуется разрешение на запись файлов.";
            default: return "Нет активного скачивания";
        }
    }
    private void openDownloads() {
        try { startActivity(new Intent("android.intent.action.VIEW_DOWNLOADS")); }
        catch (RuntimeException e) {
            try { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivity(i); }
            catch (RuntimeException ignored) { new AlertDialog.Builder(this).setMessage("Не удалось открыть загрузки. Откройте папку Download в файловом менеджере.").setPositiveButton("ОК",null).show(); }
        }
    }
}
