package com.smartcall.ru;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;

import com.smartcall.ru.update.ApkVerifier;
import com.smartcall.ru.update.Downloader;
import com.smartcall.ru.update.Sha256;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateConfig;
import com.smartcall.ru.update.UpdateException;
import com.smartcall.ru.update.UpdateState;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Export a verified private APK into Download. The shared copy is always untrusted on re-use. */
public final class DownloadStore {
    private static final String PREFS = "verified_download_export";
    private DownloadStore() { }

    public static final class Record {
        public final Uri uri;
        public final String name;
        public final long size;
        public final String sha256;
        public final long versionCode;
        public final String versionName;
        Record(Uri uri, String name, long size, String sha256, long versionCode, String versionName) {
            this.uri=uri; this.name=name; this.size=size; this.sha256=sha256;
            this.versionCode=versionCode; this.versionName=versionName;
        }
    }

    public static Record read(Context context) {
        try {
        SharedPreferences p = context.getSharedPreferences(PREFS, 0);
        String location = p.getString("uri", null), name = p.getString("name", null);
        String hash = p.getString("sha256", null), version = p.getString("versionName", null);
        long size = p.getLong("size", 0), code = p.getLong("versionCode", 0);
        if (location == null || name == null || version == null || size <= 0
                || size > UpdateConfig.defaults().maxApkBytes() || code <= 0
                || Sha256.normalizeHex64(hash) == null) return null;
        Uri uri = Uri.parse(location);
        String scheme = uri.getScheme();
        if (!("content".equals(scheme) && "media".equals(uri.getAuthority()))
                && !"file".equals(scheme)) return null;
        return new Record(uri, name, size, hash, code, version);
        } catch (RuntimeException corrupt) {
            return null;
        }
    }

    /** Must be called with a freshly verified private file and matching metadata. */
    public static Record export(Context context, File verified, UpdateState.Downloaded d,
                                Downloader.CancelSignal cancel) throws UpdateException {
        if (d == null || d.versionName == null || !d.versionName.matches("[A-Za-z0-9._+\\-]{1,64}"))
            throw new UpdateException(StatusCode.STATE, "недопустимая версия сохранённого APK");
        ApkVerifier.Expectations expected = new ApkVerifier.Expectations(d.sizeBytes, d.sha256, d.versionCode, d.versionName);
        ApkVerifier.verify(verified, expected, UpdateConfig.defaults());
        String name = "SmartCall-" + d.versionName + "-signed.apk";
        return Build.VERSION.SDK_INT >= 29 ? exportMedia(context, verified, d, name, cancel)
                : exportLegacy(context, verified, d, name, cancel);
    }

    private static Record exportMedia(Context context, File src, UpdateState.Downloaded d,
                                      String name, Downloader.CancelSignal cancel) throws UpdateException {
        ContentResolver resolver = context.getContentResolver();
        Uri uri = null;
        boolean done = false;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("система не создала запись Download");
            try (InputStream in = new FileInputStream(src); OutputStream out = resolver.openOutputStream(uri, "w")) {
                if (out == null) throw new IOException("не удалось открыть Download для записи");
                copyChecked(in, out, d.sizeBytes, d.sha256, cancel);
                out.flush();
            }
            try (InputStream in = resolver.openInputStream(uri)) {
                if (in == null) throw new IOException("не удалось повторно прочитать файл Download");
                copyChecked(in, null, d.sizeBytes, d.sha256, cancel);
            }
            String actual = queryName(resolver, uri, name);
            Record r = new Record(uri, actual, d.sizeBytes, d.sha256, d.versionCode, d.versionName);
            checkCancelled(cancel);
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0);
            if (resolver.update(uri, values, null, null) != 1) throw new IOException("не удалось завершить сохранение в Download");
            if (!save(context, r)) throw new IOException("не удалось сохранить сведения о файле");
            done = true;
            return r;
        } catch (UpdateException e) { throw e;
        } catch (IOException | RuntimeException e) {
            throw new UpdateException(StatusCode.STORAGE, "сохранение в Download: " + e.getMessage(), e);
        } finally {
            // Only the row inserted by this operation is ever removed, never a pre-existing file.
            if (!done && uri != null) try { resolver.delete(uri, null, null); } catch (RuntimeException ignored) { }
        }
    }

    @SuppressWarnings("deprecation")
    private static Record exportLegacy(Context context, File src, UpdateState.Downloaded d,
                                       String name, Downloader.CancelSignal cancel) throws UpdateException {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File temp = null;
        try {
            if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("папка Download недоступна");
            temp = File.createTempFile(".smartcall-", ".part", dir);
            try (InputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(temp)) {
                copyChecked(in, out, d.sizeBytes, d.sha256, cancel);
                out.flush(); out.getFD().sync();
            }
            try (InputStream in = new FileInputStream(temp)) { copyChecked(in, null, d.sizeBytes, d.sha256, cancel); }
            checkCancelled(cancel);
            File target = null;
            for (int i = 0; i < 1000; i++) {
                String candidate = i == 0 ? name : name.substring(0, name.length()-4) + " (" + i + ").apk";
                File dest = new File(dir, candidate);
                try {
                    // link() is atomic and fails if dest already exists. Never overwrite a user's file.
                    Os.link(temp.getAbsolutePath(), dest.getAbsolutePath());
                    target = dest; break;
                } catch (ErrnoException e) {
                    if (e.errno == OsConstants.EPERM || e.errno == OsConstants.EOPNOTSUPP
                            || e.errno == OsConstants.ENOSYS) {
                        // DocumentsContract does not promise exclusive creation or a no-replace rename.
                        // Even an explicitly selected Download tree cannot safely replace link() here.
                        throw new IOException("файловая система не поддерживает безопасное сохранение в Download; "
                                + "выбор папки Download через SAF пока не поддерживается безопасно", e);
                    }
                    if (e.errno != OsConstants.EEXIST) throw new IOException("не удалось безопасно создать файл: " + e.getMessage(), e);
                }
            }
            if (target == null) throw new IOException("слишком много файлов с этим именем");
            // Shared storage can be changed by other applications; never mark ready without re-reading the published name.
            try (InputStream in = new FileInputStream(target)) {
                copyChecked(in, null, d.sizeBytes, d.sha256, cancel);
            }
            Record r = new Record(Uri.fromFile(target), target.getName(), d.sizeBytes, d.sha256, d.versionCode, d.versionName);
            if (!save(context, r)) throw new IOException("файл создан, но сведения о нём не сохранены: " + target.getName());
            MediaScannerConnection.scanFile(context, new String[]{target.getAbsolutePath()},
                    new String[]{"application/vnd.android.package-archive"}, null);
            return r;
        } catch (UpdateException e) { throw e;
        } catch (IOException | RuntimeException e) {
            throw new UpdateException(StatusCode.STORAGE, "сохранение в Download: " + e.getMessage(), e);
        } finally {
            if (temp != null && temp.isFile()) temp.delete();
        }
    }

    /** Read the actual exported copy, then verify that exact private snapshot before granting it. */
    public static File snapshotForInstall(Context context, Record r, long installedVersion) throws UpdateException {
        if (r == null) throw new UpdateException(StatusCode.NO_FILE, "нет сохранённого файла в Download");
        if (r.versionCode <= installedVersion) throw new UpdateException(StatusCode.UP_TO_DATE, "скачанная версия не новее установленной");
        File dir = new File(context.getFilesDir(), "updates");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new UpdateException(StatusCode.STORAGE, "приватный каталог недоступен");
        File snapshot = null;
        try {
            if ("file".equals(r.uri.getScheme())) {
                File publicFile = new File(r.uri.getPath()).getCanonicalFile();
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getCanonicalFile();
                if (!downloads.equals(publicFile.getParentFile())) throw new IOException("файл вне Download");
            }
            snapshot = File.createTempFile("work-install-", ".tmp", dir);
            try (InputStream in = context.getContentResolver().openInputStream(r.uri);
                 FileOutputStream out = new FileOutputStream(snapshot)) {
                if (in == null) throw new IOException("сохранённый файл не найден");
                copyChecked(in, out, r.size, r.sha256, Downloader.NEVER_CANCELLED);
                out.flush(); out.getFD().sync();
            }
            ApkVerifier.Expectations expected = new ApkVerifier.Expectations(r.size, r.sha256, r.versionCode, r.versionName);
            ApkVerifier.verify(snapshot, expected, UpdateConfig.defaults());
            // Reuse valid snapshots, but never overwrite one already granted to an installer.
            String prefix = "install-" + r.sha256.toLowerCase(java.util.Locale.ROOT);
            for (int attempt = 0; attempt < 3; attempt++) {
                File stable = new File(dir, prefix + (attempt == 0 ? "" : "-" + attempt) + ".snapshot");
                if (stable.exists()) {
                    try {
                        ApkVerifier.verify(stable, expected, UpdateConfig.defaults());
                    } catch (UpdateException corruptOldSnapshot) {
                        continue; // leave a possibly granted file untouched; try another name
                    }
                    if (!snapshot.delete()) throw new IOException("не удалось убрать временную копию");
                    return stable;
                }
                if (!snapshot.renameTo(stable)) throw new IOException("не удалось закрепить проверенную копию");
                return stable;
            }
            throw new IOException("приватные копии повреждены; требуется очистка данных обновлений");
        } catch (UpdateException e) {
            if (snapshot != null) snapshot.delete();
            throw e;
        } catch (java.io.FileNotFoundException | SecurityException e) {
            if (snapshot != null) snapshot.delete();
            throw new UpdateException(StatusCode.NO_FILE, "файл Download недоступен: " + e.getMessage(), e);
        } catch (IOException | RuntimeException e) {
            if (snapshot != null) snapshot.delete();
            throw new UpdateException(StatusCode.STORAGE, "не удалось подготовить APK: " + e.getMessage(), e);
        }
    }

    private static boolean save(Context context, Record r) {
        SharedPreferences p = context.getSharedPreferences(PREFS, 0);
        String[] keys = {"uri", "name", "size", "sha256", "versionCode", "versionName"};
        java.util.Map<String, ?> all = p.getAll();
        java.util.Map<String, Object> previous = new java.util.HashMap<>();
        for (String key : keys) {
            if (all.containsKey(key)) {
                Object value = all.get(key);
                if (value instanceof java.util.Set) value = new java.util.HashSet<>((java.util.Set<String>) value);
                previous.put(key, value);
            }
        }
        if (p.edit().putString("uri", r.uri.toString())
                .putString("name", r.name).putLong("size", r.size).putString("sha256", r.sha256)
                .putLong("versionCode", r.versionCode).putString("versionName", r.versionName).commit()) return true;

        // commit(false) has already updated the in-memory map. Restore only our keys.
        SharedPreferences.Editor restore = p.edit();
        for (String key : keys) {
            if (!previous.containsKey(key)) { restore.remove(key); continue; }
            Object value = previous.get(key);
            if (value instanceof String || value == null) restore.putString(key, (String) value);
            else if (value instanceof Long) restore.putLong(key, (Long) value);
            else if (value instanceof Integer) restore.putInt(key, (Integer) value);
            else if (value instanceof Boolean) restore.putBoolean(key, (Boolean) value);
            else if (value instanceof Float) restore.putFloat(key, (Float) value);
            else if (value instanceof java.util.Set) restore.putStringSet(key, (java.util.Set<String>) value);
        }
        if (!restore.commit()) {
            // Memory is restored even on false, but the final disk state is unknown.
            // The file/URI is always rechecked by snapshotForInstall before installation.
            return false;
        }
        return false;
    }

    private static String queryName(ContentResolver resolver, Uri uri, String fallback) {
        try (Cursor c = resolver.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) { String name = c.getString(0); if (name != null && !name.isEmpty()) return name; }
        } catch (RuntimeException ignored) { }
        return fallback;
    }

    private static void checkCancelled(Downloader.CancelSignal cancel) throws UpdateException {
        if (cancel != null && cancel.isCancelled()) throw new UpdateException(StatusCode.CANCELLED);
    }

    static void copyChecked(InputStream in, OutputStream out, long expected, String expectedHash,
                            Downloader.CancelSignal cancel) throws IOException, UpdateException {
        MessageDigest md;
        try { md = MessageDigest.getInstance("SHA-256"); } catch (NoSuchAlgorithmException e) { throw new IOException(e); }
        byte[] buf = new byte[65536]; long count = 0; int n;
        while ((n = in.read(buf)) != -1) {
            checkCancelled(cancel);
            count += n;
            if (count > expected) throw new UpdateException(StatusCode.SIZE_MISMATCH, "файл длиннее ожидаемого");
            md.update(buf, 0, n); if (out != null) out.write(buf, 0, n);
        }
        checkCancelled(cancel);
        if (count != expected) throw new UpdateException(StatusCode.SIZE_MISMATCH, "файл имеет неверный размер");
        StringBuilder hex = new StringBuilder(64);
        for (byte b : md.digest()) hex.append(String.format(java.util.Locale.US, "%02x", b & 255));
        if (!Sha256.hexEquals(hex.toString(), expectedHash)) throw new UpdateException(StatusCode.HASH_MISMATCH, "контрольная сумма файла изменилась");
    }
}
