package com.smartcall.ru;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * One-shot migration of 2.3.x preferences to the 2.3.7 profile schema.
 *
 * Rules (see tests/SettingsMigrationTest.java):
 *  - Runs at most once; marker is written last in the same editor transaction.
 *  - Explicit 2.3.x values are copied verbatim: engines, voices, rates, volume,
 *    audio channel, enabled flags, repeat count.
 *  - A function explicitly disabled in 2.3.x is never re-enabled.
 *  - Keys never written by 2.3.x keep their old runtime default (true for the
 *    TTS switches), because that is what 2.3.6 actually did; the UI used to
 *    display false, which was a display/behaviour mismatch, not consent data.
 *  - The legacy "other" profile is copied into three independent profiles:
 *    other, viber and imo (calls and messages separately).
 *  - Legacy shared repeat count is copied to every call profile; the new
 *    per-profile delay starts at 0 seconds.
 *  - Locked-screen message mode is never enabled automatically: default is
 *    0 = do not speak, and reading text stays behind its own switch.
 *  - Unknown keys are left untouched; no key is deleted.
 */
public final class SettingsMigration {
    public static final int SCHEMA_VERSION = 2;
    static final String KEY_SCHEMA = "schema_version";

    static final String[] CALL_CHANNELS = {"sim", "wa", "tg", "other", "viber", "imo", "sms"};
    static final String[] MESSAGE_CHANNELS = {"sms", "wa", "tg", "other", "viber", "imo"};

    private SettingsMigration() {}

    private static volatile boolean attempted;

    /**
     * Runs the migration at most once per process, from the single settings
     * accessor every component already uses. A failed commit leaves the marker
     * absent, so the next process start retries.
     */
    public static void ensure(Context context) {
        if (attempted || context == null) return;
        synchronized (SettingsMigration.class) {
            if (attempted) return;
            attempted = true;
            try {
                boolean changed = migrate(context.getSharedPreferences("call_prefs", 0));
                if (changed) android.util.Log.i("SmartCall", "Настройки обновлены до схемы 2.3.7");
            } catch (RuntimeException ex) {
                android.util.Log.w("SmartCall", "Миграция настроек: " + ex.getClass().getSimpleName());
            }
        }
    }

    /** Legacy source channel for the split profiles. */
    static String legacyChannel(String channel) {
        return ("viber".equals(channel) || "imo".equals(channel)) ? "other" : channel;
    }

    static boolean bool(SharedPreferences p, String key, boolean runtimeDefault) {
        return p.getBoolean(key, runtimeDefault);
    }

    /**
     * @return true when a migration was performed by this call.
     * Never throws for missing keys; type errors from a corrupt file abort
     * before the marker is written, so the next start retries safely.
     */
    public static boolean migrate(SharedPreferences prefs) {
        if (prefs == null) return false;
        if (prefs.getInt(KEY_SCHEMA, 0) >= SCHEMA_VERSION) return false;

        boolean master = bool(prefs, "tts_enabled", true);
        boolean textAllowed = bool(prefs, "tts_sms_text", true);
        int legacyRepeat = prefs.getInt("tts_repeat", 2);
        if (legacyRepeat < 1) legacyRepeat = 1;
        if (legacyRepeat > 5) legacyRepeat = 5;
        String legacyVoice = prefs.getString("tts_voice_name", "default");
        if (legacyVoice == null) legacyVoice = "default";

        SharedPreferences.Editor e = prefs.edit();

        for (String channel : CALL_CHANNELS) {
            String legacy = legacyChannel(channel);
            boolean enabled = master && bool(prefs, "tts_app_" + legacy, true);

            // Call profile: engine / voice / speed / repeats / delay.
            putBool(e, "call_enabled_" + channel, enabled);
            putString(e, "call_eng_" + channel, str(prefs, "tts_eng_" + legacy, "default"));
            String voice = str(prefs, "tts_voice_" + legacy, null);
            if (voice == null) voice = "sim".equals(channel) ? legacyVoice : "default";
            putString(e, "call_voice_" + channel, voice);
            putInt(e, "call_rate_" + channel, prefs.getInt("tts_rate_" + legacy, 100));
            putInt(e, "call_repeat_" + channel, legacyRepeat);
            putInt(e, "call_delay_" + channel, 0);
        }

        for (String channel : MESSAGE_CHANNELS) {
            String legacy = legacyChannel(channel);
            // 2.3.6 gates: master switch, SMS profile gate, text switch and the
            // per-source gate all had to be open before anything was spoken.
            boolean announce = master && bool(prefs, "tts_app_sms", true)
                    && textAllowed && bool(prefs, "tts_app_" + legacy, true);
            putBool(e, "msg_enabled_" + channel, announce);
            putBool(e, "msg_read_text_" + channel, announce);
            putString(e, "msg_eng_" + channel, str(prefs, "tts_eng_" + legacy, "default"));
            String voice = str(prefs, "tts_voice_" + legacy, null);
            if (voice == null) voice = "default";
            putString(e, "msg_voice_" + channel, voice);
            putInt(e, "msg_rate_" + channel, prefs.getInt("tts_rate_" + legacy, 100));
            // Never speak message text while the screen is locked unless the
            // user later chooses mode 2/3 explicitly.
            putInt(e, "msg_lock_mode_" + channel, 0);
        }

        // Shared audio settings keep their legacy keys and defaults.
        e.putInt("tts_audio_mode", prefs.getInt("tts_audio_mode", 0));
        e.putInt("tts_custom_vol", prefs.getInt("tts_custom_vol", 100));
        e.putBoolean("tts_read_unknown", bool(prefs, "tts_read_unknown", true));

        e.putInt(KEY_SCHEMA, SCHEMA_VERSION);
        return e.commit();
    }

    private static String str(SharedPreferences p, String key, String fallback) {
        String v = p.getString(key, fallback);
        if (v == null && fallback != null) return fallback;
        return v;
    }

    private static void putBool(SharedPreferences.Editor e, String k, boolean v) {
        e.putBoolean(k, v);
    }

    private static void putString(SharedPreferences.Editor e, String k, String v) {
        e.putString(k, v);
    }

    private static void putInt(SharedPreferences.Editor e, String k, int v) {
        e.putInt(k, v);
    }

    /** Names of settings written by the migration; used by tests and diagnostics. */
    public static Map<String, Object> describe() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put(KEY_SCHEMA, SCHEMA_VERSION);
        return m;
    }
}
