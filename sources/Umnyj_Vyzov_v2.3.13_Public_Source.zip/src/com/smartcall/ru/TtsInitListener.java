package com.smartcall.ru;

import android.media.AudioAttributes;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Locale;
import java.util.Set;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class TtsInitListener implements TextToSpeech.OnInitListener {
    public int repeatCount;
    public String text;
    public TextToSpeech tts;
    public String voiceName;

    public TtsInitListener(TextToSpeech textToSpeech, String str, int i, String str2) {
        this.tts = textToSpeech;
        this.text = str;
        this.repeatCount = i;
        this.voiceName = str2;
    }

    @Override // android.speech.tts.TextToSpeech.OnInitListener
    public void onInit(int i) {
        Set<Voice> voices;
        String name;
        try {
            if (i != 0) {
                CallController.log("TTS Ошибка инициализации движка: status=" + i);
                return;
            }
            TextToSpeech textToSpeech = this.tts;
            if (textToSpeech == null && (textToSpeech = CallController.ttsInstance) == null) {
                return;
            }
            try {
                textToSpeech.setLanguage(Locale.getDefault());
            } catch (Throwable th) {
            }
            try {
                String str = this.voiceName;
                if (str != null && !"default".equals(str) && !str.contains("preset_") && (voices = textToSpeech.getVoices()) != null) {
                    for (Voice voice : voices) {
                        if (voice != null && (name = voice.getName()) != null && str.equals(name)) {
                            textToSpeech.setVoice(voice);
                            break;
                        }
                    }
                }
                textToSpeech.setPitch(1.0f);
                textToSpeech.setSpeechRate(1.0f);
            } catch (Throwable th2) {
            }
            if (this.text != null) {
                int i2 = 3;
                int i3 = 1;
                if (CallController.lastCallState == 1) {
                    i2 = 2;
                    i3 = 6;
                }
                try {
                    textToSpeech.setAudioAttributes(new AudioAttributes.Builder().setUsage(i3).setContentType(1).build());
                } catch (Throwable th3) {
                }
                Bundle bundle = new Bundle();
                bundle.putInt("streamType", i2);
                bundle.putFloat("volume", 1.0f);
                String str2 = this.text;
                if (str2 != null) {
                    int i4 = this.repeatCount;
                    if (i4 <= 0) {
                        i4 = 1;
                    }
                    CallController.log("TTS: произнесение запущено (код=" + textToSpeech.speak(str2, 0, bundle, "smartcall_utt_0") + ", поток=" + i2 + ")");
                    for (int i5 = 1; i5 < i4; i5++) {
                        textToSpeech.speak(" " + str2, 1, bundle, "smartcall_utt_rep");
                    }
                }
            }
        } catch (Throwable th4) {
        }
    }
}
