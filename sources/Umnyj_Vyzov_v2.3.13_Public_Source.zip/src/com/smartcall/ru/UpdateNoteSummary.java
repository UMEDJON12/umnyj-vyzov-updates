package com.smartcall.ru;

/** Compact, plain-text summary; release metadata remains available in the channel. */
public final class UpdateNoteSummary {
    private UpdateNoteSummary() { }
    public static String summarize(String notes) {
        if (notes == null) return "";
        StringBuilder out = new StringBuilder();
        int lines = 0;
        for (String line : notes.split("\\r?\\n")) {
            String text = line.trim();
            if (text.isEmpty()) continue;
            while (text.startsWith("#")) text = text.substring(1).trim();
            if (text.isEmpty()) continue;
            if (lines++ > 0) out.append('\n');
            out.append(text);
            if (lines >= 4 || out.length() >= 360) break;
        }
        if (out.length() > 360) return out.substring(0, 357) + "…";
        return out.toString();
    }
}
