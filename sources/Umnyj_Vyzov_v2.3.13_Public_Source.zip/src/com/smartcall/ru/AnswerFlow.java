package com.smartcall.ru;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes2-original.dex */
public final class AnswerFlow {
    private final Actions actions;
    private boolean canceled;
    private final Scheduler scheduler;

    public interface Actions {
        void completed(int i);

        int liveState();

        void log(String str);

        void notification();

        void telecom();

        void ui();
    }

    public interface Scheduler {
        void later(Runnable runnable, long j);
    }

    public AnswerFlow(Actions actions, Scheduler scheduler) {
        this.actions = actions;
        this.scheduler = scheduler;
    }

    public void cancel() {
        this.canceled = true;
    }

    public void start() {
        step(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void step(final int i) {
        if (this.canceled) {
            return;
        }
        int iLiveState = this.actions.liveState();
        if (iLiveState != 1) {
            this.actions.log(iLiveState == 2 ? "Ответ: принятый звонок подтверждён состоянием Android" : "Ответ: входящий звонок больше не подтверждается");
            this.actions.completed(iLiveState);
            return;
        }
        if (i == 3) {
            this.actions.log("Ответ: после резервных способов звонок всё ещё входящий");
            this.actions.completed(1);
            return;
        }
        try {
            if (i == 0) {
                this.actions.telecom();
            } else if (i == 1) {
                this.actions.notification();
            } else {
                this.actions.ui();
            }
        } catch (RuntimeException e) {
            this.actions.log("Ответ: ошибка способа " + i + " " + e);
        }
        this.scheduler.later(new Runnable() { // from class: com.smartcall.ru.AnswerFlow.1
            @Override // java.lang.Runnable
            public void run() {
                AnswerFlow.this.step(i + 1);
            }
        }, i == 0 ? 250 : 450);
    }
}
