package com.smartcall.ru;

import java.util.HashMap;
import java.util.Map;

/** Trusts explicit SIM telephony events, never notification removal or audio volume.
 * A temporary IDLE reading from aggregate getCallState cannot erase RINGING.
 */
public final class SimCallEvidence {
    private static final class Status { int state; long sinceMs; String source; }
    private final Map<Integer, Status> slots = new HashMap<Integer, Status>();
    private int globalState;
    private long globalSince;
    private String globalSource = "нет";
    private int lastObserved;
    private long lastObservedMs;

    public synchronized void event(int subscription, int state, long nowMs, String source) {
        if (state < 0 || state > 2) return;
        if (subscription >= 0) {
            Status status = slots.get(subscription);
            if (status == null) { status = new Status(); slots.put(subscription, status); }
            status.state = state; status.sinceMs = nowMs; status.source = source;
        } else {
            globalState = state; globalSince = nowMs; globalSource = source;
            // Global IDLE is authoritative only if no per-SIM active state persists.
            if (state == 0) {
                // Treat broadcast IDLE as a global call-end signal only for the global source.
                // Active subscriptions must report their own ending to avoid cross-SIM races.
            }
        }
    }
    public synchronized void observed(int state, long nowMs) {
        lastObserved = state;
        lastObservedMs = nowMs;
    }
    public synchronized int authoritative(long nowMs, long maxAgeMs) {
        boolean ringing = false, offhook = false;
        for (Status st : slots.values()) {
            if (nowMs >= st.sinceMs && nowMs - st.sinceMs <= maxAgeMs) {
                if (st.state == 1) ringing = true;
                if (st.state == 2) offhook = true;
            }
        }
        if (ringing) return 1;
        if (offhook) return 2;
        if (nowMs >= globalSince && nowMs - globalSince <= maxAgeMs) {
            if (globalState == 1 || globalState == 2) return globalState;
        }
        return 0;
    }
    public synchronized String snapshot(long nowMs) {
        StringBuilder s = new StringBuilder("общий=").append(globalState)
            .append(" (").append(globalSource).append(", возраст=").append(nowMs-globalSince).append("мс)")
            .append(", опрос=").append(lastObserved).append(" (").append(nowMs-lastObservedMs).append("мс)");
        for (Map.Entry<Integer,Status> e : slots.entrySet()) {
            Status st=e.getValue();
            s.append("; SIM#").append(e.getKey()).append('=').append(st.state)
                .append(" (").append(st.source).append(", ").append(nowMs-st.sinceMs).append("мс)");
        }
        return s.toString();
    }
}
