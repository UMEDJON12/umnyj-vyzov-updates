package com.smartcall.ru;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.SystemClock;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class ProximitySensorListener implements SensorEventListener {
    private Context context;

    public ProximitySensorListener(Context context) {
        this.context = context;
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor;
        int i;
        if (sensorEvent != null) {
            try {
                Context context = this.context;
                if (context != null) {
                    if ((CallController.lastCallState == 1 || CallController.voipIncoming) && (sensor = sensorEvent.sensor) != null) {
                        int type = sensor.getType();
                        float[] fArr = sensorEvent.values;
                        if (fArr == null || fArr.length <= 0 || type != 8 || (i = (int) fArr[0]) < 0) {
                            return;
                        }
                        if (i != 0) {
                            CallController.proxSawFar = true;
                            return;
                        }
                        if (CallController.proxSawFar) {
                            long j = CallController.callRingStartTime;
                            if (j <= 0 || SystemClock.elapsedRealtime() - j < 1200) {
                                return;
                            }
                            if (SystemClock.elapsedRealtime() - CallController.proxRegTime >= 800) {
                                CallController.unregisterProximitySensor(context);
                                CallController.log("Датчик приближения (у уха): телефон поднесён к уху -> ПОДНЯТЬ ТРУБКУ");
                                CallController.answerCall(context);
                            }
                        }
                    }
                }
            } catch (Throwable th) {
            }
        }
    }
}
