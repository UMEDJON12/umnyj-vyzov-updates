package com.smartcall.ru;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/** Read-only URI grants for app-private snapshots verified immediately before use. */
public final class UpdateInstallProvider extends ContentProvider {
    public static final String AUTHORITY = "com.smartcall.ru.update.install";
    private static final String PREFS = "update_install_grant";
    private static final String MIME = "application/vnd.android.package-archive";

    public static Uri authorizeSnapshot(Context context, File file, String displayName) throws IOException {
        File base = new File(context.getFilesDir(), "updates").getCanonicalFile();
        File actual = file.getCanonicalFile();
        String name = actual.getName();
        if (!base.equals(actual.getParentFile()) || !name.startsWith("install-")
                || !name.endsWith(".snapshot") || !actual.isFile()) throw new IOException("недопустимый проверенный файл");
        if (displayName == null || displayName.isEmpty() || displayName.contains("/") || displayName.contains("\\"))
            throw new IOException("недопустимое отображаемое имя");
        if (!context.getSharedPreferences(PREFS, 0).edit().putString("file." + name, displayName)
                .commit()) throw new IOException("не удалось подготовить доступ установщика");
        return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath("update").appendPath(name).build();
    }
    @Override public boolean onCreate() { return true; }

    private File resolve(Uri uri) throws FileNotFoundException {
        Context context = getContext();
        if (context == null || uri == null || !"content".equals(uri.getScheme())
                || !AUTHORITY.equals(uri.getAuthority())) throw new FileNotFoundException("недопустимый URI");
        List<String> segments = uri.getPathSegments();
        if (segments.size() != 2 || !"update".equals(segments.get(0))) throw new FileNotFoundException("недопустимый путь");
        String name = segments.get(1);
        String approved = name == null ? null : context.getSharedPreferences(PREFS, 0).getString("file." + name, null);
        if (name == null || approved == null || !name.startsWith("install-")
                || !name.endsWith(".snapshot") || name.contains("/") || name.contains("\\") || name.contains(".."))
            throw new FileNotFoundException("доступ к файлу не разрешён");
        try {
            File base = new File(context.getFilesDir(), "updates").getCanonicalFile();
            File f = new File(base, name).getCanonicalFile();
            if (!base.equals(f.getParentFile()) || !f.isFile()) throw new FileNotFoundException("файл не найден");
            return f;
        } catch (IOException e) {
            throw new FileNotFoundException("файл недоступен");
        }
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("доступ только на чтение");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public String getType(Uri uri) {
        try { resolve(uri); return MIME; } catch (FileNotFoundException e) { return null; }
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File f = resolve(uri);
            String[] columns = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
            MatrixCursor cursor = new MatrixCursor(columns, 1);
            MatrixCursor.RowBuilder row = cursor.newRow();
            String display = getContext().getSharedPreferences(PREFS, 0).getString("file." + f.getName(), "SmartCall.apk");
            for (String column : columns) {
                if (OpenableColumns.DISPLAY_NAME.equals(column)) row.add(display);
                else if (OpenableColumns.SIZE.equals(column)) row.add(f.length());
                else row.add(null);
            }
            return cursor;
        } catch (FileNotFoundException e) { return null; }
    }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
