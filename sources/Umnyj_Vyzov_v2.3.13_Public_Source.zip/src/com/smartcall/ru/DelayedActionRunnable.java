package com.smartcall.ru;

import android.content.Context;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class DelayedActionRunnable implements Runnable {
    private Context context;
    private int mode;

    public DelayedActionRunnable(Context context, int i) {
        this.context = context;
        this.mode = i;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            Context context = this.context;
            int i = this.mode;
            if (i == 1) {
                if (context != null) {
                    CallController.answerCallPulse(context);
                    return;
                }
                return;
            }
            if (i == 2) {
                if (context != null) {
                    CallController.log("Отложенный сброс отклонён: не является новым действием пользователя");
                    return;
                }
                return;
            }
            if (i == 5) {
                if (context != null) {
                    CallController.checkRingtoneStep(context);
                }
            } else if (i == 6) {
                if (context != null) {
                    CallController.confirmRingtoneSilenced(context);
                }
            } else if (i == 7) {
                if (context != null) {
                    CallController.checkDelayedCaller(context);
                }
            } else if (i == 8 && context != null) {
                CallControlAccessibilityService.performDelayedSwipeUp(context);
            }
        } catch (Throwable th) {
        }
    }
}
