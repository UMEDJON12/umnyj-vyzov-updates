package com.smartcall.ru;

import android.content.Context;
import android.content.res.Configuration;

/**
 * Material 3 colour roles (baseline light / dark) applied programmatically so
 * the app needs no resource table changes. Values follow the Material 3
 * baseline palettes; the active variant follows the system night mode or the
 * explicit theme choice stored under "theme_mode".
 */
public final class UiTheme {
    private UiTheme() {}

    public static boolean dark(Context c) {
        try {
            return (c.getResources().getConfiguration().uiMode
                    & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static int window(Context c)   { return dark(c) ? 0xFF1C1B1F : 0xFFFEF7FF; }
    public static int surface(Context c)  { return dark(c) ? 0xFF1C1B1F : 0xFFFFFBFE; }
    public static int surfaceVariant(Context c) { return dark(c) ? 0xFF49454F : 0xFFE7E0EC; }
    public static int onSurface(Context c)      { return dark(c) ? 0xFFE6E1E5 : 0xFF1C1B1F; }
    public static int onSurfaceVariant(Context c) { return dark(c) ? 0xFFCAC4D0 : 0xFF49454F; }
    public static int primary(Context c)        { return dark(c) ? 0xFFD0BCFF : 0xFF6750A4; }
    public static int onPrimary(Context c)      { return dark(c) ? 0xFF381E72 : 0xFFFFFFFF; }
    public static int primaryContainer(Context c) { return dark(c) ? 0xFF4F378B : 0xFFEADDFF; }
    public static int onPrimaryContainer(Context c) { return dark(c) ? 0xFFE8DEFF : 0xFF21005D; }
    public static int secondaryContainer(Context c) { return dark(c) ? 0xFF4A4458 : 0xFFE8DEF8; }
    public static int errorContainer(Context c) { return dark(c) ? 0xFF8C1D18 : 0xFFF9DEDC; }
    public static int outline(Context c)        { return dark(c) ? 0xFF938F99 : 0xFF79747E; }

    public static android.graphics.drawable.Drawable rounded(Context c, int colour, float radiusDp) {
        android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
        shape.setColor(colour);
        shape.setCornerRadius(radiusDp * c.getResources().getDisplayMetrics().density);
        android.content.res.ColorStateList ripple = android.content.res.ColorStateList.valueOf(
                dark(c) ? 0x33FFFFFF : 0x22000000);
        return new android.graphics.drawable.RippleDrawable(ripple, shape, null);
    }
}
