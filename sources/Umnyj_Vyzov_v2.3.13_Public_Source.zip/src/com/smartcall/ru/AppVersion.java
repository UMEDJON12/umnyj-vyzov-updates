package com.smartcall.ru;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

/** Информация из установленного манифеста, не из строки в интерфейсе. */
public final class AppVersion {
    private AppVersion() { }

    public static String name(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            if (info.versionName != null && !info.versionName.trim().isEmpty()) return info.versionName;
        } catch (PackageManager.NameNotFoundException | RuntimeException ignored) { }
        return "неизвестна";
    }

    public static long code(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
        } catch (PackageManager.NameNotFoundException | RuntimeException ignored) { }
        return 0;
    }
}
