package com.smartcall.ru;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Отдельный экран журнала диагностики: просмотр, сохранение, отправка, очистка. */
public class DiagActivity extends Activity implements View.OnClickListener {
    private TextView logView;

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 36, 36, 36);
        root.setBackgroundColor(UiTheme.window(this));

        TextView title = new TextView(this);
        title.setText("Диагностика");
        title.setTextSize(22.0f);
        title.setTextColor(UiTheme.onSurface(this));
        root.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Журнал содержит события управления звонками и озвучкой. Перед отправкой проверьте, что в нём нет личных данных.");
        hint.setTextSize(13.0f);
        hint.setTextColor(UiTheme.onSurfaceVariant(this));
        hint.setPadding(0, 8, 0, 24);
        root.addView(hint);

        ScrollView scroll = new ScrollView(this);
        TextView log = new TextView(this);
        log.setTextSize(12.0f);
        log.setTextColor(UiTheme.onSurface(this));
        log.setBackgroundColor(UiTheme.surfaceVariant(this));
        log.setPadding(24, 24, 24, 24);
        this.logView = log;
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, 24, 0, 0);
        actions.addView(actionButton("Сохранить", 105));
        actions.addView(actionButton("Отправить", 106));
        actions.addView(actionButton("Очистить", 107));
        root.addView(actions);

        setContentView(root);
        refresh();
    }

    private TextView actionButton(String text, int id) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextSize(15.0f);
        button.setPadding(24, 24, 24, 24);
        button.setTextColor(UiTheme.onPrimary(this));
        button.setBackgroundColor(UiTheme.primary(this));
        button.setId(id);
        button.setFocusable(true);
        button.setOnClickListener(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 0, 16, 0);
        button.setLayoutParams(params);
        return button;
    }

    private void refresh() {
        if (this.logView != null) {
            String report = CallController.getDiagReport(this);
            this.logView.setText(report == null || report.isEmpty() ? "Журнал пуст." : report);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        try {
            int id = view.getId();
            if (id == 105) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Диагностика сохранена")
                        .setMessage(CallController.saveDiagToDownload(this))
                        .setNegativeButton("ОК", null).show();
            } else if (id == 106) {
                startActivity(Intent.createChooser(
                        new Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, CallController.getDiagReport(this)),
                        "Отправить диагностику «Умный Вызов»"));
            } else if (id == 107) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Очистить журнал")
                        .setMessage("Журнал диагностики будет очищен. Сохранённые файлы не удалятся.")
                        .setPositiveButton("Очистить", new android.content.DialogInterface.OnClickListener() {
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(android.content.DialogInterface dialog, int which) {
                                CallController.clearDiagLog();
                                refresh();
                            }
                        })
                        .setNegativeButton("Отмена", null).show();
            }
        } catch (Throwable th) {
            CallController.log(th.toString());
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        refresh();
    }
}
