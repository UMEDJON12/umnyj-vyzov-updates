package com.smartcall.ru;

import android.app.ActivityOptions;
import android.app.Notification;
import android.app.PendingIntent;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class CallNotificationListenerService extends NotificationListenerService {
    public static CallNotificationListenerService instance;

    public CallNotificationListenerService() {
        instance = this;
    }

    public static String findActiveCallTitle() {
        StatusBarNotification[] activeNotifications;
        String str;
        Bundle bundle;
        Object obj;
        try {
            CallNotificationListenerService callNotificationListenerService = instance;
            if (callNotificationListenerService != null && (activeNotifications = callNotificationListenerService.getActiveNotifications()) != null) {
                for (StatusBarNotification statusBarNotification : activeNotifications) {
                    if (statusBarNotification != null) {
                        String packageName = statusBarNotification.getPackageName();
                        Notification notification = statusBarNotification.getNotification();
                        if (notification != null && (str = notification.category) != null && "call".equals(str) && (bundle = notification.extras) != null && (obj = bundle.get("android.title")) != null) {
                            String string = obj.toString();
                            if (string.length() > 0) {
                                CallController.lastCallPkg = packageName;
                                return string;
                            }
                        }
                    }
                }
            }
            return null;
        } catch (Throwable th) {
            return null;
        }
    }

    public static boolean isExcludedText(String str) {
        if (str != null) {
            return str.contains("сообщ") || str.contains("быстр") || str.contains("sms") || str.contains("смс") || str.contains("msg") || str.contains("message") || str.contains("reply") || str.contains("напомн") || str.contains("remind") || str.contains("перезвон") || str.contains("обратн") || str.contains("снова") || str.contains("callback") || str.contains("call back") || str.contains("again") || str.contains("не отвеч") || str.contains("без ответ") || str.contains("автоответ") || str.contains("picker");
        }
        return false;
    }

    public static boolean isNegativeText(String str) {
        if (str == null) {
            return false;
        }
        String lowerCase = str.toLowerCase();
        if (isExcludedText(lowerCase)) {
            return false;
        }
        return lowerCase.contains("отклон") || lowerCase.contains("сброс") || lowerCase.contains("заверш") || lowerCase.contains("отбой") || lowerCase.contains("полож") || lowerCase.contains("decline") || lowerCase.contains("reject") || lowerCase.contains("hang") || lowerCase.contains("end_call") || lowerCase.contains("end call") || lowerCase.contains("endcall") || lowerCase.contains("leave") || lowerCase.contains("disconnect") || lowerCase.contains("puck");
    }

    public static boolean isPositiveText(String str) {
        if (str == null) {
            return false;
        }
        String lowerCase = str.toLowerCase();
        if (isExcludedText(lowerCase)) {
            return false;
        }
        return lowerCase.contains("ответить") || lowerCase.contains("принять") || lowerCase.contains("поднять") || lowerCase.contains("соединить") || lowerCase.contains("answer") || lowerCase.contains("accept") || lowerCase.contains("pickup") || lowerCase.contains("voip_accept") || lowerCase.contains("btn_answer") || lowerCase.contains("call_answer") || lowerCase.contains("puck");
    }

    /* JADX WARN: Code duplicated, block: B:33:0x005b A[Catch: all -> 0x00ad, TryCatch #0 {all -> 0x00ad, blocks: (B:3:0x0005, B:5:0x0009, B:7:0x000f, B:9:0x0013, B:11:0x0017, B:13:0x001d, B:15:0x0025, B:17:0x002b, B:19:0x002f, B:21:0x0037, B:23:0x003b, B:29:0x004b, B:31:0x0053, B:60:0x00a5, B:59:0x00a0, B:33:0x005b, B:35:0x005f, B:39:0x0065, B:41:0x0069, B:43:0x006d, B:45:0x0077, B:48:0x007e, B:50:0x0082, B:52:0x0086, B:54:0x0090, B:56:0x0096, B:61:0x00a8), top: B:65:0x0005 }] */
    /* JADX WARN: Code duplicated, block: B:55:0x0094 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:56:0x0096 A[Catch: all -> 0x00ad, TryCatch #0 {all -> 0x00ad, blocks: (B:3:0x0005, B:5:0x0009, B:7:0x000f, B:9:0x0013, B:11:0x0017, B:13:0x001d, B:15:0x0025, B:17:0x002b, B:19:0x002f, B:21:0x0037, B:23:0x003b, B:29:0x004b, B:31:0x0053, B:60:0x00a5, B:59:0x00a0, B:33:0x005b, B:35:0x005f, B:39:0x0065, B:41:0x0069, B:43:0x006d, B:45:0x0077, B:48:0x007e, B:50:0x0082, B:52:0x0086, B:54:0x0090, B:56:0x0096, B:61:0x00a8), top: B:65:0x0005 }] */
    /* JADX WARN: Code duplicated, block: B:60:0x00a5 A[Catch: all -> 0x00ad, TryCatch #0 {all -> 0x00ad, blocks: (B:3:0x0005, B:5:0x0009, B:7:0x000f, B:9:0x0013, B:11:0x0017, B:13:0x001d, B:15:0x0025, B:17:0x002b, B:19:0x002f, B:21:0x0037, B:23:0x003b, B:29:0x004b, B:31:0x0053, B:60:0x00a5, B:59:0x00a0, B:33:0x005b, B:35:0x005f, B:39:0x0065, B:41:0x0069, B:43:0x006d, B:45:0x0077, B:48:0x007e, B:50:0x0082, B:52:0x0086, B:54:0x0090, B:56:0x0096, B:61:0x00a8), top: B:65:0x0005 }] */
    /* JADX WARN: Code duplicated, block: B:75:0x00a8 A[ADDED_TO_REGION, SYNTHETIC] */
    public static void refreshCallStatus() {
        // Reconstructed from original DEX control flow (labels L5b, L94, La0, La5).
        CallController.voipIncoming = false;
        CallController.voipOngoing = false;
        try {
            CallNotificationListenerService service = instance;
            if (service == null) return;
            StatusBarNotification[] notifications = service.getActiveNotifications();
            if (notifications == null) return;
            for (StatusBarNotification item : notifications) {
                if (item == null) continue;
                String pkg = item.getPackageName();
                if (pkg == null || "com.smartcall.ru".equals(pkg)) continue;
                Notification notification = item.getNotification();
                if (notification == null || !"call".equals(notification.category)) continue;
                Bundle extras = notification.extras;
                if (extras != null) {
                    int type = extras.getInt("android.callType", 0);
                    if (type == 1 || type == 3) { CallController.voipIncoming = true; continue; }
                    if (type == 2) { CallController.voipOngoing = true; continue; }
                    if (extras.containsKey("android.answerIntent") || extras.containsKey("android.declineIntent")) {
                        CallController.voipIncoming = true; continue;
                    }
                }
                Notification.Action[] actions = notification.actions;
                boolean positive = false;
                if (actions != null) {
                    for (Notification.Action action : actions) {
                        if (action != null && action.title != null && isPositiveText(action.title.toString())) {
                            positive = true; break;
                        }
                    }
                }
                if (positive) { CallController.voipIncoming = true; continue; }
                boolean negative = false;
                if (actions != null) {
                    for (Notification.Action action : actions) {
                        if (action != null && action.title != null && isNegativeText(action.title.toString())) {
                            negative = true; break;
                        }
                    }
                }
                if (negative || (extras != null && extras.containsKey("android.hangUpIntent"))) {
                    CallController.voipOngoing = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    public static boolean sendPiWithBal(PendingIntent pendingIntent) {
        if (pendingIntent == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                pendingIntent.send(null, 0, null, null, null, null, ActivityOptions.makeBasic().setPendingIntentBackgroundActivityStartMode(1).toBundle());
                return true;
            } catch (Throwable th) {
            }
        }
        try {
            pendingIntent.send();
            return true;
        } catch (Throwable th2) {
            return false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:53:0x009d  */
    public static boolean triggerCallNotificationAction(boolean z) {
        StatusBarNotification[] activeNotifications;
        Notification notification;
        String str;
        CharSequence charSequence;
        PendingIntent pendingIntent;
        try {
            CallNotificationListenerService callNotificationListenerService = instance;
            if (callNotificationListenerService == null || (activeNotifications = callNotificationListenerService.getActiveNotifications()) == null) {
                return false;
            }
            for (StatusBarNotification statusBarNotification : activeNotifications) {
                if (statusBarNotification != null && (notification = statusBarNotification.getNotification()) != null && (str = notification.category) != null && "call".equals(str)) {
                    Bundle bundle = notification.extras;
                    if (bundle != null) {
                        if (z) {
                            Object obj = bundle.get("android.answerIntent");
                            if (obj != null && sendPiWithBal((PendingIntent) obj)) {
                                CallController.log("Уведомление: отправлен CallStyle answerIntent");
                                return true;
                            }
                        } else {
                            Object obj2 = bundle.get("android.declineIntent");
                            if (obj2 != null && sendPiWithBal((PendingIntent) obj2)) {
                                CallController.log("Уведомление: отправлен CallStyle declineIntent");
                                return true;
                            }
                            Object obj3 = bundle.get("android.hangUpIntent");
                            if (obj3 != null && sendPiWithBal((PendingIntent) obj3)) {
                                CallController.log("Уведомление: отправлен CallStyle hangUpIntent");
                                return true;
                            }
                        }
                    }
                    Notification.Action[] actionArr = notification.actions;
                    if (actionArr != null && (actionArr.length) > 0) {
                        for (Notification.Action action : actionArr) {
                            if (action != null && (charSequence = action.title) != null) {
                                String string = charSequence.toString();
                                // Both branches converge at L9d in the original DEX.
                                if (z ? isPositiveText(string) : isNegativeText(string)) {
                                    if ((pendingIntent = action.actionIntent) == null) {
                                        break;
                                    }
                                    if (sendPiWithBal(pendingIntent)) {
                                        CallController.log("Уведомление: нажата кнопка действия");
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            return false;
        }
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerConnected() {
        instance = this;
        CallController.log("Служба уведомлений подключена");
        refreshCallStatus();
    }

    @Override // android.service.notification.NotificationListenerService
    public void onListenerDisconnected() {
        instance = null;
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        String packageName;
        instance = this;
        try {
            if (CallController.isPrefEnabled(this, "tts_enabled", true) && CallController.isPrefEnabled(this, "tts_app_sms", true) && CallController.isPrefEnabled(this, "tts_sms_text", true) && !CallController.isMediaOrOngoingNotification(statusBarNotification) && SmartCallFeatures.handleMessageNotification(this, statusBarNotification)) {
                return;
            }
            refreshCallStatus();
            if (statusBarNotification != null && (packageName = statusBarNotification.getPackageName()) != null) {
                if ("com.smartcall.ru".equals(packageName)) {
                    return;
                }
                Notification notification = statusBarNotification.getNotification();
                if (notification != null) {
                    String str = notification.category;
                    Bundle bundle = notification.extras;
                    String string = "";
                    if (bundle != null) {
                        Object obj = bundle.get("android.title");
                        string = obj != null ? obj.toString() : "";
                    }
                    if (str != null && "call".equals(str)) {
                        CallController.lastCallPkg = packageName;
                        CallController.lastCallerTitle = string;
                        if (!CallController.voipIncoming) {
                            if ((CallController.getRingtoneMask(this) & 5) != 0) {
                                CallController.voipIncoming = true;
                            }
                        }
                        if (string.length() > 0) {
                            CallController.announceIncomingCall(this, packageName, string);
                        }
                    }
                }
            }
            if (CallController.voipIncoming) {
                CallController.recordActiveCallState(1);
                CallController.startRingtoneWatcher(this);
            } else if (CallController.voipOngoing) {
                if ((CallController.getRingtoneMask(this) & 5) == 0) {
                    CallController.stopTts();
                    CallController.recordActiveCallState(2);
                } else {
                    CallController.recordActiveCallState(1);
                    CallController.startRingtoneWatcher(this);
                }
            }
        } catch (Throwable th) {
        }
    }

    @Override // android.service.notification.NotificationListenerService
    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
        instance = this;
        refreshCallStatus();
        if (CallController.voipIncoming) {
            return;
        }
        CallController.stopTts();
        if (CallController.voipOngoing || (CallController.getRingtoneMask(this) & 5) != 0) {
            return;
        }
        // Notification removal is not a trustworthy SIM IDLE transition.
        if (SimCallMonitor.hardwareState(this) != 1 && SimCallMonitor.hardwareState(this) != 2) {
            CallController.recordActiveCallState(0);
        } else {
            CallController.log("Уведомление снято, но SIM ещё не подтверждён как IDLE");
        }
    }
}
