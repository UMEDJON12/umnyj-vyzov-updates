package com.smartcall.ru;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import com.smartcall.ru.update.Downloader;
import com.smartcall.ru.update.ReleaseManifest;
import com.smartcall.ru.update.StatusCode;
import com.smartcall.ru.update.UpdateEngine;
import com.smartcall.ru.update.UpdateException;
import com.smartcall.ru.update.UpdateState;
import java.io.File;

/** Foreground download, signature verification and export to public Download. */
public final class UpdateService extends Service {
    public static final String ACTION_DOWNLOAD = "com.smartcall.ru.action.DOWNLOAD";
    public static final String ACTION_EXPORT_EXISTING = "com.smartcall.ru.action.EXPORT_EXISTING";
    public static final String ACTION_CANCEL = "com.smartcall.ru.action.CANCEL";
    private static final String EXTRA_VERSION = "expected_version";
    private static final String EXTRA_CODE = "expected_code";
    private static final String EXTRA_APPROVAL = "release_fingerprint";
    private static final String EXTRA_EPOCH = "progress_epoch";
    private static final String CHANNEL_ID = "smartcall_updates";
    private static final int NOTIF_ID = 4207;
    private volatile boolean cancelled;
    private volatile boolean running;
    private volatile String currentVersion = "";
    private volatile long downloaded, total;
    private long lastNotificationAt;
    private int latestStartId;
    private volatile long generation;
    private volatile long progressEpoch;
    private final android.os.Handler mainHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    public static void startDownload(Context context, String version, long code, String approval) {
        Intent i = new Intent(context, UpdateService.class).setAction(ACTION_DOWNLOAD);
        i.putExtra(EXTRA_VERSION, version); i.putExtra(EXTRA_CODE, code); i.putExtra(EXTRA_APPROVAL, approval);
        startForegroundOperation(context, i, version);
    }
    public static void startExportExisting(Context context) {
        startForegroundOperation(context, new Intent(context, UpdateService.class).setAction(ACTION_EXPORT_EXISTING), "");
    }
    private static void startForegroundOperation(Context context, Intent i, String version) {
        if (!UpdateProgress.begin(version)) return;
        long epoch = UpdateProgress.epoch();
        i.putExtra(EXTRA_EPOCH, epoch);
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i); else context.startService(i);
        } catch (RuntimeException e) {
            CallController.log("Обновления: служба не запущена: " + e.getClass().getSimpleName());
            UpdateProgress.publishFor(epoch, UpdateProgress.Phase.ERROR, version, "Не удалось запустить загрузку: " + e.getClass().getSimpleName(), 0, 0);
        }
    }
    public static void cancel(Context context) {
        try { context.startService(new Intent(context, UpdateService.class).setAction(ACTION_CANCEL)); }
        catch (RuntimeException e) { CallController.log("Обновления: не удалось отправить отмену"); }
    }
    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        latestStartId = startId;
        String action = intent == null ? null : intent.getAction();
        if (ACTION_CANCEL.equals(action)) {
            if (running) {
                cancelled = true;
                UpdateProgress.publishFor(progressEpoch, UpdateProgress.current().phase, currentVersion, "Отмена…", downloaded, total);
                notifyProgress("Отмена…", true);
            }
            else stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (!ACTION_DOWNLOAD.equals(action) && !ACTION_EXPORT_EXISTING.equals(action)) {
            stopSelf(startId); return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        long receivedEpoch = intent.getLongExtra(EXTRA_EPOCH, -1);
        if (receivedEpoch <= 0 || receivedEpoch != UpdateProgress.epoch()) {
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }
        progressEpoch = receivedEpoch;
        running = true; cancelled = false;
        downloaded = 0; total = 0; lastNotificationAt = 0;
        final long operation = ++generation;
        currentVersion = intent.getStringExtra(EXTRA_VERSION);
        if (currentVersion == null) currentVersion = "";
        final long expectedCode = intent.getLongExtra(EXTRA_CODE, 0);
        final String approval = intent.getStringExtra(EXTRA_APPROVAL);
        final boolean existing = ACTION_EXPORT_EXISTING.equals(action);
        try { startForeground(NOTIF_ID, buildNotification("Подключение…", true, false)); }
        catch (RuntimeException e) {
            running = false;
            UpdateProgress.publishFor(progressEpoch, UpdateProgress.Phase.ERROR, currentVersion, "Не удалось запустить фоновую загрузку", 0, 0);
            stopSelf(startId); return START_NOT_STICKY;
        }
        new Thread(new Runnable() { public void run() { runOperation(operation, existing, expectedCode, approval); } }, "smartcall-update").start();
        return START_NOT_STICKY;
    }
    private void runOperation(long operation, boolean existing, long expectedCode, String approval) {
        try {
            UpdateEngine engine = UpdatesController.engine(this);
            DownloadStore.Record exported;
            synchronized (engine) {
                engine.cleanupStaleWork();
                com.smartcall.ru.update.ApkVerifier.Result verified;
                if (!existing) {
                    ReleaseManifest manifest = engine.check(UpdatesController.installedVersionCode(this));
                    if (cancelled) throw new UpdateException(StatusCode.CANCELLED);
                    if (expectedCode <= 0 || manifest.versionCode != expectedCode
                            || !com.smartcall.ru.update.ApprovedRelease.matches(manifest, approval)) {
                        throw new UpdateException(StatusCode.RELEASE_CHANGED, "версия изменилась после подтверждения; проверьте обновления ещё раз");
                    }
                    currentVersion = manifest.versionName;
                    verified = engine.download(UpdatesController.installedVersionCode(this), manifest,
                            new Downloader.ProgressListener() {
                                @Override public void onProgress(long got, long size, int percent, long remaining) {
                                    if (!running || generation != operation || cancelled) return;
                                    downloaded=got; total=size;
                                    UpdateProgress.Phase phase = size > 0 && got >= size
                                            ? UpdateProgress.Phase.VERIFYING : UpdateProgress.Phase.DOWNLOADING;
                                    UpdateProgress.publishFor(progressEpoch, phase,currentVersion,"",got,size);
                                    long now = SystemClock.elapsedRealtime();
                                    if (now-lastNotificationAt >= 700 || got == size) {
                                        lastNotificationAt=now;
                                        notifyProgress(phase == UpdateProgress.Phase.VERIFYING ? "Проверка APK…" : UpdateProgressText.progress(got,size), false);
                                    }
                                }
                            }, new Downloader.CancelSignal() { public boolean isCancelled() { return cancelled; } });
                } else {
                    UpdateProgress.publishFor(progressEpoch, UpdateProgress.Phase.VERIFYING,currentVersion,"Проверка ранее скачанного APK…",0,0);
                    verified = engine.verifyDownloaded(UpdatesController.installedVersionCode(this));
                }
                if (cancelled) throw new UpdateException(StatusCode.CANCELLED);
                UpdateState.Downloaded d = engine.state().downloaded();
                if (d == null) throw new UpdateException(StatusCode.NO_FILE, "нет сведений о скачанном APK");
                currentVersion = d.versionName;
                if (existing) { downloaded = d.sizeBytes; total = d.sizeBytes; }
                File verifiedFile = engine.downloadedFile(verified);
                if (verifiedFile == null) throw new UpdateException(StatusCode.STATE, "сведения о проверенном APK изменились");
                UpdateProgress.publishFor(progressEpoch, UpdateProgress.Phase.SAVING,currentVersion,"Сохранение проверенного файла в Download…",downloaded,total);
                notifyProgress("Сохранение в Download…", false);
                exported = DownloadStore.export(this, verifiedFile, d,
                        new Downloader.CancelSignal() { public boolean isCancelled() { return cancelled; } });
            }
            CallController.log("Обновления: проверенный APK сохранён в Download: " + exported.name);
            finishWith(operation, UpdateProgress.Phase.READY, "APK скачан и проверен", "Файл сохранён в папке Download", true);
        } catch (UpdateException e) {
            boolean cancelledResult = e.status() == StatusCode.CANCELLED;
            boolean permissionNeeded = Build.VERSION.SDK_INT == 29 && e.status() == StatusCode.STORAGE
                    && hasPermissionFailure(e)
                    && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED;
            CallController.log("Обновления: " + e.userMessage());
            UpdateProgress.Phase phase = cancelledResult ? UpdateProgress.Phase.CANCELLED
                    : permissionNeeded ? UpdateProgress.Phase.STORAGE_PERMISSION
                    : e.status() == StatusCode.RELEASE_CHANGED ? UpdateProgress.Phase.RECHECK : UpdateProgress.Phase.ERROR;
            String detail = permissionNeeded ? "Система отклонила сохранение. Для повтора требуется разрешение на запись файлов." : e.userMessage();
            finishWith(operation, phase, cancelledResult ? "Скачивание отменено" : "Не удалось подготовить обновление", detail, false);
        } catch (RuntimeException e) {
            CallController.log("Обновления: ошибка " + e.getClass().getSimpleName());
            finishWith(operation, UpdateProgress.Phase.ERROR, "Не удалось подготовить обновление",
                    e instanceof IllegalStateException ? "Состояние обновлений повреждено или недоступно."
                            : "Ошибка: " + e.getClass().getSimpleName(), false);
        }
    }
    private static boolean hasPermissionFailure(Throwable error) {
        for (Throwable current = error; current != null; current = current.getCause()) {
            if (current instanceof SecurityException) return true;
            String message = current.getMessage();
            if (message != null) {
                String lower = message.toLowerCase(java.util.Locale.ROOT);
                if (lower.contains("permission denied") || lower.contains("permission denial") || lower.contains("eacces")) return true;
            }
        }
        return false;
    }
    private void finishWith(final long operation, final UpdateProgress.Phase phase,
                            final String title, final String text, final boolean ready) {
        mainHandler.post(new Runnable() { public void run() {
            // onStartCommand, completion and stopSelfResult are serialized on the main thread.
            if (!running || generation != operation) return;
            if (progressEpoch != UpdateProgress.epoch()) {
                running = false;
                try { stopForeground(true); } catch (RuntimeException ignored) { }
                stopSelfResult(latestStartId);
                return;
            }
            running = false;
            UpdateProgress.publishFor(progressEpoch, phase,currentVersion,ready ? "APK скачан и проверен. Файл сохранён в папке Download" : text,downloaded,total);
            try { stopForeground(true); } catch (RuntimeException ignored) { }
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(NOTIF_ID, buildNotification(title + ". " + text, false, ready));
            } catch (RuntimeException e) { CallController.log("Обновления: уведомление недоступно"); }
            stopSelfResult(latestStartId);
        }});
    }
    private void notifyProgress(String text, boolean cancelling) {
        if (progressEpoch != UpdateProgress.epoch()) return;
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification(text, true, false));
        } catch (RuntimeException e) { CallController.log("Обновления: уведомление прогресса недоступно"); }
    }
    private Notification buildNotification(String text, boolean ongoing, boolean ready) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setSmallIcon(ready ? android.R.drawable.stat_sys_download_done : android.R.drawable.stat_sys_download)
                .setContentTitle(ready ? "APK скачан и проверен" : "Обновление «Умный Вызов»")
                .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing).setAutoCancel(!ongoing).setOnlyAlertOnce(true)
                .setContentIntent(openProgressIntent());
        if (ongoing) {
            int p = UpdateProgressText.percent(downloaded,total);
            b.setProgress(100, Math.max(0,p), p < 0).addAction(0,"Отменить",cancelIntent());
        }
        return b.build();
    }
    private PendingIntent openProgressIntent() {
        Intent open = UpdateProgressActivity.openIntent(this);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(this, 4207, open, flags);
    }
    private PendingIntent cancelIntent() {
        Intent i = new Intent(this, UpdateService.class).setAction(ACTION_CANCEL);
        return PendingIntent.getService(this, 4208, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel c = new NotificationChannel(CHANNEL_ID,"Обновления приложения",NotificationManager.IMPORTANCE_LOW);
                c.setDescription("Прогресс и результат скачивания обновлений"); nm.createNotificationChannel(c);
            }
        }
    }
    @Override public void onDestroy() {
        if (running) {
            cancelled=true;
            running=false;
            generation++;
            UpdateProgress.publishFor(progressEpoch, UpdateProgress.Phase.ERROR,currentVersion,"Загрузка прервана системой. Повторите действие.",downloaded,total);
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
