package com.smartcall.ru.update;

/**
 * Персистентное состояние обновлений (приватный файл/SharedPreferences):
 *
 * <ul>
 *   <li>{@code updates_auto_check} — автопроверка при открытии (по умолчанию включена);</li>
 *   <li>{@code updates_later_version} — версия, отложенная кнопкой «Позже»;</li>
 *   <li>{@code updates_known_version_code} — наибольшая известная версия
 *       (защита от отката: значение никогда не уменьшается);</li>
 *   <li>{@code updates_downloaded_*} — метаданные скачанного APK.</li>
 * </ul>
 */
public final class UpdateState {

    /** Метаданные уже скачанного APK (null-поля, если ничего не скачано). */
    public static final class Downloaded {
        public final long versionCode;
        public final String versionName;
        public final String sha256;
        public final long sizeBytes;
        public final String fileName;

        public Downloaded(long versionCode, String versionName, String sha256,
                          long sizeBytes, String fileName) {
            this.versionCode = versionCode;
            this.versionName = versionName;
            this.sha256 = sha256;
            this.sizeBytes = sizeBytes;
            this.fileName = fileName;
        }
    }

    private final KeyValueStore store;

    public UpdateState(KeyValueStore store) {
        this.store = store;
    }

    // ---- автопроверка ---------------------------------------------------

    /** По умолчанию включена: ключ отсутствует → true. */
    public boolean isAutoCheckEnabled() {
        return store.getBoolean(UpdateConfig.KEY_AUTO_CHECK, true);
    }

    public void setAutoCheckEnabled(boolean enabled) {
        store.putBoolean(UpdateConfig.KEY_AUTO_CHECK, enabled);
    }

    // ---- «Позже» --------------------------------------------------------

    /** Версия, отложенная пользователем (0 — ничего не откладывали). */
    public long laterVersion() {
        return store.getLong(UpdateConfig.KEY_LATER_VERSION, 0L);
    }

    /** «Позже»: запомнить версию (только вперёд, без скатывания назад). */
    public void postpone(long versionCode) {
        if (versionCode <= 0) {
            return;
        }
        synchronized (store) {
            long cur = laterVersion();
            if (versionCode > cur) {
                store.putLong(UpdateConfig.KEY_LATER_VERSION, versionCode);
            }
        }
    }

    /** Не показывать уведомление о версии ≤ отложенной (до следующей версии). */
    public boolean isDeferred(long versionCode) {
        return versionCode > 0 && versionCode <= laterVersion();
    }

    // ---- защита от отката ----------------------------------------------

    /** Наибольшая уже известная версия (0 — неизвестно). */
    public long knownVersionCode() {
        return store.getLong(UpdateConfig.KEY_KNOWN_VERSION, 0L);
    }

    /**
     * Запомнить версию: значение только растёт (max), никогда не уменьшается —
     * даже если приложение откатили вручную, персистентное значение хранится
     * в отдельном приватном файле/SharedPreferences.
     */
    public void noteKnownVersion(long versionCode) {
        if (versionCode <= 0) {
            return;
        }
        synchronized (store) {
            long cur = knownVersionCode();
            if (versionCode > cur) {
                store.putLong(UpdateConfig.KEY_KNOWN_VERSION, versionCode);
            }
        }
    }

    /** Актуальная база для проверки отката: max(установленная, известная). */
    public long effectiveKnown(long installedVersionCode) {
        long known = knownVersionCode();
        return Math.max(known, installedVersionCode);
    }

    // ---- скачанный APK --------------------------------------------------

    public void saveDownloaded(long versionCode, String versionName, String sha256,
                               long sizeBytes, String fileName) {
        synchronized (store) {
            java.util.Map<String, Object> changes = new java.util.LinkedHashMap<String, Object>();
            changes.put(UpdateConfig.KEY_DOWNLOADED_VERSION, versionCode);
            changes.put(UpdateConfig.KEY_DOWNLOADED_VERSION_NAME, versionName);
            changes.put(UpdateConfig.KEY_DOWNLOADED_SHA256, sha256);
            changes.put(UpdateConfig.KEY_DOWNLOADED_SIZE, sizeBytes);
            changes.put(UpdateConfig.KEY_DOWNLOADED_FILE, fileName);
            changes.put(UpdateConfig.KEY_KNOWN_VERSION, Math.max(knownVersionCode(), versionCode));
            store.applyBatch(changes);
        }
    }

    public Downloaded downloaded() {
        synchronized (store) {
            long vc = store.getLong(UpdateConfig.KEY_DOWNLOADED_VERSION, 0L);
            String vn = store.getString(UpdateConfig.KEY_DOWNLOADED_VERSION_NAME, null);
            String sha = store.getString(UpdateConfig.KEY_DOWNLOADED_SHA256, null);
            long size = store.getLong(UpdateConfig.KEY_DOWNLOADED_SIZE, 0L);
            String file = store.getString(UpdateConfig.KEY_DOWNLOADED_FILE, null);
            if (vc <= 0 || vn == null || sha == null || size <= 0 || file == null) {
                return null;
            }
            if (Sha256.normalizeHex64(sha) == null) {
                return null;
            }
            return new Downloaded(vc, vn, sha, size, file);
        }
    }

    public void clearDownloaded() {
        java.util.Map<String, Object> changes = new java.util.LinkedHashMap<String, Object>();
        changes.put(UpdateConfig.KEY_DOWNLOADED_VERSION, null);
        changes.put(UpdateConfig.KEY_DOWNLOADED_VERSION_NAME, null);
        changes.put(UpdateConfig.KEY_DOWNLOADED_SHA256, null);
        changes.put(UpdateConfig.KEY_DOWNLOADED_SIZE, null);
        changes.put(UpdateConfig.KEY_DOWNLOADED_FILE, null);
        store.applyBatch(changes);
    }
}
