package com.smartcall.ru.update;

/** Shared rule for both private and public saved APKs. */
public final class InstallVersionPolicy {
    private InstallVersionPolicy() { }
    public static StatusCode status(long installed, long highestKnown, long candidate) {
        if (installed <= 0 || candidate <= 0 || highestKnown < 0) return StatusCode.STATE;
        if (candidate <= installed) return StatusCode.UP_TO_DATE;
        if (candidate < highestKnown) return StatusCode.ROLLBACK;
        return StatusCode.OK;
    }
}
