package com.smartcall.ru.update;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.CodeSigner;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

/**
 * Проверка скачанного APK перед установкой — только «fail-closed»:
 *
 * <ol>
 *   <li>размер: существует, совпадает с каналом, в лимите;</li>
 *   <li>SHA-256 файла совпадает с каналом;</li>
 *   <li>целостность ZIP (чтение всех записей, CRC);</li>
 *   <li>обязательная криптографическая v1-подпись всех записей вне META-INF:
 *       JarFile проверяет подписи и привязку к закреплённому сертификату;
 *       APK только с v2/v3 намеренно отклоняются;</li>
 *   <li>package/versionCode/versionName из бинарного манифеста — точно
 *       совпадают с каналом и с ожидаемым пакетом;</li>
 *   <li>при наличии v2/v3 извлекаемые сертификаты дополнительно сверяются с v1;
 *       сама криптографическая проверка v2/v3 здесь не выполняется и остаётся
 *       задачей системного установщика.</li>
 * </ol>
 */
public final class ApkVerifier {

    /** Результат успешной проверки. */
    public static final class Result {
        public final String packageName;
        public final long versionCode;
        public final String versionName;
        public final long sizeBytes;
        public final String sha256;
        public final List<String> certSha256s;

        public Result(String packageName, long versionCode, String versionName,
                      long sizeBytes, String sha256, List<String> certSha256s) {
            this.packageName = packageName;
            this.versionCode = versionCode;
            this.versionName = versionName;
            this.sizeBytes = sizeBytes;
            this.sha256 = sha256;
            this.certSha256s = certSha256s;
        }
    }

    /**
     * Ожидания по скачанному файлу: из валидированного stable.json либо из
     * сохранённых метаданных ранее скачанного APK.
     */
    public static final class Expectations {
        public final long sizeBytes;
        public final String sha256;
        public final long versionCode;
        public final String versionName;

        public Expectations(long sizeBytes, String sha256, long versionCode, String versionName) {
            this.sizeBytes = sizeBytes;
            this.sha256 = sha256;
            this.versionCode = versionCode;
            this.versionName = versionName;
        }

        public static Expectations of(ReleaseManifest m) {
            return new Expectations(m.sizeBytes, m.sha256, m.versionCode, m.versionName);
        }
    }

    private ApkVerifier() {
    }

    /**
     * Проверить файл по ожиданиям канала и конфигурации.
     *
     * @param exp ожидаемые размер/SHA-256/версии (из канала или из хранилища)
     * @param cfg конфигурация (пакет, лимиты, ожидаемый сертификат)
     */
    public static Result verify(File apk, Expectations exp, UpdateConfig cfg)
            throws UpdateException {
        if (apk == null || !apk.isFile()) {
            throw new UpdateException(StatusCode.NO_FILE,
                    apk == null ? "" : apk.getName());
        }
        long size = apk.length();
        if (size <= 0) {
            throw new UpdateException(StatusCode.APK_INVALID, "файл пустой");
        }
        if (size > cfg.maxApkBytes()) {
            throw new UpdateException(StatusCode.TOO_LARGE,
                    size + " > лимита " + cfg.maxApkBytes());
        }
        if (size != exp.sizeBytes) {
            throw new UpdateException(StatusCode.SIZE_MISMATCH,
                    "файл " + size + " байт, ожидалось " + exp.sizeBytes);
        }

        String sha;
        try {
            sha = Sha256.ofFile(apk);
        } catch (IOException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "не удалось прочитать файл: " + e.getMessage(), e);
        }
        if (!Sha256.hexEquals(sha, exp.sha256)) {
            throw new UpdateException(StatusCode.HASH_MISMATCH, "SHA-256 файла не совпадает");
        }

        // 1. Целостность ZIP: читаем каждую запись до конца (проверяется CRC).
        checkZipIntegrity(apk, cfg);

        // 2. Обязательная криптографическая проверка v1 для каждой записи.
        List<String> v1 = checkJarSignature(apk, cfg.expectedCertSha256());

        // 3. Пакет и версии из бинарного манифеста.
        AxmlManifestParser.Info info = readManifestInfo(apk);
        if (!cfg.packageName().equals(info.packageName)) {
            throw new UpdateException(StatusCode.PACKAGE_MISMATCH, info.packageName);
        }
        if (exp.versionCode != info.versionCode) {
            throw new UpdateException(StatusCode.VERSION_MISMATCH,
                    "versionCode в APK " + info.versionCode + ", ожидался " + exp.versionCode);
        }
        if (exp.versionName == null || !exp.versionName.equals(info.versionName)) {
            throw new UpdateException(StatusCode.VERSION_MISMATCH,
                    "versionName в APK " + info.versionName + ", ожидался " + exp.versionName);
        }

        // 4. Сверка сертификатов v2/v3 с уже проверенным v1 (не верификация v2/v3).
        List<String> v23 = v23CertFingerprints(apk);
        if (v1.isEmpty() && v23.isEmpty()) {
            throw new UpdateException(StatusCode.CERT_MISMATCH, "в APK нет данных о подписи");
        }
        if (!v1.isEmpty() && !v23.isEmpty()) {
            boolean overlap = false;
            for (String a : v1) {
                if (v23.contains(a)) {
                    overlap = true;
                    break;
                }
            }
            if (!overlap) {
                throw new UpdateException(StatusCode.CERT_MISMATCH,
                        "подписи v1 и v2/v3 указывают на разные сертификаты");
            }
        }
        Set<String> all = new HashSet<String>();
        all.addAll(v1);
        all.addAll(v23);
        String want = cfg.expectedCertSha256();
        boolean matched = false;
        for (String s : all) {
            if (Sha256.hexEquals(s, want)) {
                matched = true;
                break;
            }
        }
        if (!matched) {
            throw new UpdateException(StatusCode.CERT_MISMATCH,
                    "отпечаток подписи не совпадает с ожидаемым");
        }

        return new Result(info.packageName, info.versionCode, info.versionName,
                size, sha, new ArrayList<String>(all));
    }

    // ---- шаги проверки --------------------------------------------------

    private static void checkZipIntegrity(File apk, UpdateConfig cfg) throws UpdateException {
        ZipInputStream zin = null;
        long uncompressed = 0;
        try {
            zin = new ZipInputStream(new java.io.FileInputStream(apk));
            ZipEntry e;
            boolean any = false;
            while ((e = zin.getNextEntry()) != null) {
                any = true;
                if (e.isDirectory()) {
                    continue;
                }
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = zin.read(buf)) != -1) {
                    uncompressed += n;
                    if (uncompressed > cfg.maxApkBytes() * 10L) {
                        throw new UpdateException(StatusCode.APK_INVALID,
                                "подозрительно большой несжатый объём архива");
                    }
                }
            }
            if (!any) {
                throw new UpdateException(StatusCode.APK_INVALID, "архив пуст");
            }
        } catch (IOException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "архив повреждён: " + e.getMessage(), e);
        } finally {
            Sha256.closeQuietly(zin);
        }
    }

    /** Проверить v1 и привязать каждый файл вне META-INF к единственному signer. */
    private static List<String> checkJarSignature(File apk, String expected) throws UpdateException {
        JarFile jar = null;
        boolean anyProtected = false;
        Set<String> names = new HashSet<String>();
        try {
            jar = new JarFile(apk, true);
            Enumeration<JarEntry> en = jar.entries();
            while (en.hasMoreElements()) {
                JarEntry entry = en.nextElement();
                if (!names.add(entry.getName())) {
                    throw new UpdateException(StatusCode.APK_INVALID,
                            "повторяющаяся запись архива: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    continue;
                }
                InputStream in = jar.getInputStream(entry);
                if (in == null) {
                    throw new UpdateException(StatusCode.APK_INVALID,
                            "нет потока для записи " + entry.getName());
                }
                try {
                    byte[] buf = new byte[64 * 1024];
                    while (in.read(buf) != -1) {
                        // Верификация завершается только после полного чтения.
                    }
                } finally {
                    Sha256.closeQuietly(in);
                }
                if (entry.getName().toUpperCase(java.util.Locale.ROOT).startsWith("META-INF/")) {
                    continue;
                }
                anyProtected = true;
                CodeSigner[] signers = entry.getCodeSigners();
                if (signers == null || signers.length != 1) {
                    throw new UpdateException(StatusCode.CERT_MISMATCH,
                            "запись не подписана единственным подписантом: " + entry.getName());
                }
                List<? extends Certificate> chain = signers[0].getSignerCertPath().getCertificates();
                if (chain.isEmpty() || !Sha256.hexEquals(Sha256.ofBytes(chain.get(0).getEncoded()), expected)) {
                    throw new UpdateException(StatusCode.CERT_MISMATCH,
                            "неверный сертификат подписанта записи: " + entry.getName());
                }
            }
            if (!anyProtected) {
                throw new UpdateException(StatusCode.APK_INVALID, "нет защищаемых записей APK");
            }
            List<String> result = new ArrayList<String>();
            result.add(expected.toLowerCase(java.util.Locale.ROOT));
            return result;
        } catch (SecurityException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "подпись содержимого (v1) не прошла проверку: " + e.getMessage(), e);
        } catch (CertificateException e) {
            throw new UpdateException(StatusCode.CERT_MISMATCH,
                    "не удалось прочитать сертификат подписанта", e);
        } catch (IOException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "не удалось проверить подпись содержимого: " + e.getMessage(), e);
        } finally {
            if (jar != null) {
                try {
                    jar.close();
                } catch (IOException ignored) {
                    // закрытие не влияет на результат
                }
            }
        }
    }

    private static AxmlManifestParser.Info readManifestInfo(File apk) throws UpdateException {
        ZipFile zf = null;
        try {
            zf = new ZipFile(apk);
            ZipEntry me = zf.getEntry("AndroidManifest.xml");
            if (me == null) {
                throw new UpdateException(StatusCode.APK_INVALID, "нет AndroidManifest.xml");
            }
            InputStream in = zf.getInputStream(me);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            try {
                byte[] buf = new byte[64 * 1024];
                int n;
                long total = 0;
                while ((n = in.read(buf)) != -1) {
                    total += n;
                    if (total > 2 * 1024 * 1024) {
                        throw new UpdateException(StatusCode.APK_INVALID,
                                "AndroidManifest.xml подозрительно большой");
                    }
                    bos.write(buf, 0, n);
                }
            } finally {
                Sha256.closeQuietly(in);
            }
            return AxmlManifestParser.parse(bos.toByteArray());
        } catch (IOException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "не удалось прочитать манифест: " + e.getMessage(), e);
        } finally {
            if (zf != null) {
                try {
                    zf.close();
                } catch (IOException ignored) {
                    // закрытие не влияет на результат
                }
            }
        }
    }

    /** Сертификаты из APK Signing Block (v2/v3), DER → hex SHA-256. */
    private static List<String> v23CertFingerprints(File apk) throws UpdateException {
        List<byte[]> ders = SigningBlockCerts.read(apk);
        List<String> out = new ArrayList<String>();
        for (byte[] der : ders) {
            out.add(Sha256.ofBytes(der));
        }
        return out;
    }
}
