package com.smartcall.ru.update;

/**
 * Канал: stable.json + публичный release. Никаких токенов — только
 * публичный HTTPS. Все ответы валидируются, любое сомнение — отказ.
 */
public final class ChannelChecker {

    private final UpdateConfig cfg;
    private final HttpTransport transport;
    private final int deviceSdk;

    public ChannelChecker(UpdateConfig cfg, HttpTransport transport, int deviceSdk) {
        this.cfg = cfg;
        this.transport = transport;
        this.deviceSdk = deviceSdk;
    }

    /**
     * Полная проверка канала.
     *
     * @param currentVersionCode версия установленного приложения
     * @param knownVersionCode   наибольшая уже известная версия (защита от отката)
     * @return кандидат на обновление
     */
    public ReleaseManifest check(long currentVersionCode, long knownVersionCode)
            throws UpdateException {
        byte[] stableBytes = getOrNullIf404(cfg.stableJsonUrl());
        byte[] releaseBytes = getOrNullIf404(cfg.releaseApiUrl());
        if (stableBytes == null && releaseBytes == null) {
            checkPublicRepository();
            throw new UpdateException(StatusCode.NO_PUBLISHED_UPDATES);
        }
        if (stableBytes == null || releaseBytes == null) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    stableBytes == null ? "stable.json отсутствует (HTTP 404)"
                            : "releases/latest отсутствует (HTTP 404)");
        }
        ReleaseManifest manifest = ReleaseManifest.parseAndValidate(stableBytes, cfg, deviceSdk);

        // Строго больше текущей версии.
        if (manifest.versionCode <= currentVersionCode) {
            throw new UpdateException(StatusCode.NOT_NEWER,
                    "в канале " + manifest.versionCode + ", установлено " + currentVersionCode);
        }
        // Защита от отката: не принимаем версию меньше уже известной.
        if (manifest.versionCode < knownVersionCode) {
            throw new UpdateException(StatusCode.ROLLBACK,
                    "в канале " + manifest.versionCode + ", уже известна " + knownVersionCode);
        }

        ReleaseInfo.parseAndCrossCheck(releaseBytes, manifest);

        return manifest;
    }

    private void checkPublicRepository() throws UpdateException {
        byte[] bytes;
        try {
            bytes = HttpSupport.getBounded(transport, UpdateConfig.REPOSITORY_API_URL,
                    UpdateConfig.HostPolicy.of(UpdateConfig.REPOSITORY_API_URL), cfg);
        } catch (HttpSupport.HttpStatusException e) {
            if (e.httpStatus() == 404) {
                throw new UpdateException(StatusCode.CHANNEL_INVALID,
                        "публичный репозиторий недоступен (HTTP 404)", e);
            }
            throw e;
        }
        java.util.Map<String, Object> repo;
        try {
            repo = Json.parseObject(bytes);
        } catch (UpdateException e) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    "некорректные данные репозитория", e);
        }
        Object owner = repo.get("owner");
        if (!Boolean.FALSE.equals(repo.get("private"))
                || !UpdateConfig.REPO_NAME.equalsIgnoreCase(stringValue(repo.get("name")))
                || !(owner instanceof java.util.Map)
                || !UpdateConfig.REPO_OWNER.equalsIgnoreCase(
                        stringValue(((java.util.Map<?, ?>) owner).get("login")))) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    "репозиторий не является закреплённым публичным репозиторием");
        }
    }

    private static String stringValue(Object value) {
        return value instanceof String ? (String) value : "";
    }

    private byte[] getOrNullIf404(String url) throws UpdateException {
        try {
            return HttpSupport.getBounded(transport, url, cfg.metadataHosts(), cfg);
        } catch (HttpSupport.HttpStatusException e) {
            if (e.httpStatus() == 404) {
                return null;
            }
            throw e;
        }
    }
}
