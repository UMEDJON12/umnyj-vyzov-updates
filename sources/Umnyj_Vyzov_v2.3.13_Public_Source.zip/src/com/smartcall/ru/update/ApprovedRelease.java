package com.smartcall.ru.update;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** Identity of the exact release displayed when the user chose Download. */
public final class ApprovedRelease {
    private ApprovedRelease() { }
    public static String fingerprint(ReleaseManifest m) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(bytes);
            out.writeInt(m.schemaVersion); out.writeUTF(m.packageName); out.writeUTF(m.variant);
            out.writeBoolean(m.testOnly); out.writeLong(m.versionCode); out.writeUTF(m.versionName);
            out.writeLong(m.minSdk); out.writeUTF(m.signingCertificateSha256); out.writeLong(m.sizeBytes);
            out.writeUTF(m.sha256); out.writeUTF(m.apkFileName); out.writeUTF(m.apkUrl);
            out.writeUTF(m.releaseNotes == null ? "" : m.releaseNotes);
            out.writeBoolean(m.ready); out.writeUTF(m.tagName);
            out.writeUTF(m.publishedAt == null ? "" : m.publishedAt);
            out.flush();
            return Sha256.ofBytes(bytes.toByteArray());
        } catch (IOException impossible) { throw new IllegalStateException(impossible); }
    }
    public static boolean matches(ReleaseManifest m, String approved) {
        return approved != null && Sha256.hexEquals(fingerprint(m), approved);
    }
}
