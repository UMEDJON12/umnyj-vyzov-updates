package com.smartcall.ru.update;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/**
 * Извлечение X.509-сертификатов из APK Signing Block (схемы подписи v2/v3).
 * Блок лежит непосредственно перед центральным каталогом ZIP и начинается с
 * магии «APK Sig Block 42». Любая повреждённая структура при НАЛИЧИИ блока —
 * отказ (fail-closed): доверять такой подписи нельзя.
 */
public final class SigningBlockCerts {

    private static final byte[] MAGIC = {
            'A', 'P', 'K', ' ', 'S', 'i', 'g', ' ', 'B', 'l', 'o', 'c', 'k', ' ', '4', '2'
    };
    private static final long ID_V2 = 0x7109871AL;
    private static final long ID_V3 = 0xF05368C0L;

    private SigningBlockCerts() {
    }

    /**
     * Прочитать сертификаты (DER) из блока подписи.
     *
     * @return список DER-сертификатов; пустой список — блока v2/v3 нет
     *         (APK подписан только v1 — это нормально для minSdk 24)
     * @throws UpdateException блок есть, но его структура повреждена
     */
    public static List<byte[]> read(File apk) throws UpdateException {
        RandomAccessFile raf = null;
        try {
            raf = new RandomAccessFile(apk, "r");
            long fileLen = raf.length();
            long eocd = findEocd(raf, fileLen);
            if (eocd < 0) {
                throw new UpdateException(StatusCode.APK_INVALID, "в файле нет конца ZIP");
            }
            raf.seek(eocd + 12);
            long cdSize = readU32(raf);   // размер центрального каталога
            raf.seek(eocd + 16);
            long cdOffset = readU32(raf); // смещение центрального каталога
            if (cdOffset < 0 || cdOffset + 16 > fileLen) {
                throw new UpdateException(StatusCode.APK_INVALID, "смещение центрального каталога повреждено");
            }
            if (cdOffset + cdSize != eocd) {
                throw new UpdateException(StatusCode.APK_INVALID, "центральный каталог ZIP повреждён");
            }
            // Магия ровно перед центральным каталогом.
            byte[] magic = new byte[16];
            raf.seek(cdOffset - 16);
            raf.readFully(magic);
            if (!matchesMagic(magic)) {
                return new ArrayList<byte[]>(); // блока подписи нет
            }
            raf.seek(cdOffset - 24);
            long sizeEnd = readU64(raf);
            long blockStart = cdOffset - sizeEnd - 8;
            if (sizeEnd < 32 || blockStart < 0) {
                throw new UpdateException(StatusCode.APK_INVALID, "повреждённый APK Signing Block");
            }
            raf.seek(blockStart);
            long sizeStart = readU64(raf);
            if (sizeStart != sizeEnd) {
                throw new UpdateException(StatusCode.APK_INVALID,
                        "размеры APK Signing Block не совпадают");
            }
            long pairsStart = blockStart + 8;
            long pairsEnd = cdOffset - 24;
            List<byte[]> certs = new ArrayList<byte[]>();
            long pos = pairsStart;
            while (pos < pairsEnd) {
                if (pos + 12 > pairsEnd) {
                    throw new UpdateException(StatusCode.APK_INVALID, "обрыв пар в Signing Block");
                }
                raf.seek(pos);
                long pairLen = readU64(raf);
                long pairId = readU32(raf);
                if (pairLen < 4 || pos + 8 + pairLen > pairsEnd) {
                    throw new UpdateException(StatusCode.APK_INVALID, "повреждённая пара Signing Block");
                }
                if (pairId == ID_V2 || pairId == ID_V3) {
                    byte[] value = new byte[(int) (pairLen - 4)];
                    raf.readFully(value);
                    parseSigners(value, certs);
                }
                pos += 8 + pairLen;
            }
            return certs;
        } catch (IOException e) {
            throw new UpdateException(StatusCode.APK_INVALID,
                    "не удалось прочитать APK Signing Block: " + e.getMessage(), e);
        } finally {
            if (raf != null) {
                try {
                    raf.close();
                } catch (IOException ignored) {
                    // закрытие read-only дескриптора не влияет на результат
                }
            }
        }
    }

    /**
     * Разбор value пары v2/v3: length-prefixed sequence of signer,
     * signer = length-prefixed { signedData (length-prefixed), ... },
     * signedData = length-prefixed { digests, certificates, ... }.
     * Для v3 первые поля signer/signedData совпадают с v2.
     */
    static void parseSigners(byte[] value, List<byte[]> out) throws UpdateException {
        Cursor c = new Cursor(value);
        int signersLen = c.u32("длина signers");
        c.requireEnd(signersLen, "signers");
        while (c.remaining() > 0) {
            int signerLen = c.u32("длина signer");
            byte[] signer = c.bytes(signerLen, "signer");
            parseSigner(signer, out);
        }
    }

    private static void parseSigner(byte[] signer, List<byte[]> out) throws UpdateException {
        Cursor c = new Cursor(signer);
        int signedDataLen = c.u32("длина signedData");
        byte[] signedData = c.bytes(signedDataLen, "signedData");
        parseSignedData(signedData, out);
        // Остальные поля (signatures, publicKey) не нужны — сертификаты уже извлечены.
    }

    private static void parseSignedData(byte[] signedData, List<byte[]> out) throws UpdateException {
        Cursor c = new Cursor(signedData);
        int digestsLen = c.u32("длина digests");
        c.bytes(digestsLen, "digests");
        int certsBlockLen = c.u32("длина certificates");
        byte[] certsBlock = c.bytes(certsBlockLen, "certificates");
        Cursor cc = new Cursor(certsBlock);
        while (cc.remaining() > 0) {
            int certLen = cc.u32("длина сертификата");
            if (certLen <= 0 || certLen > cc.remaining()) {
                throw new UpdateException(StatusCode.APK_INVALID, "повреждённый сертификат в подписи");
            }
            out.add(cc.bytes(certLen, "сертификат"));
        }
    }

    private static final class Cursor {
        private final byte[] data;
        private int pos;

        Cursor(byte[] data) {
            this.data = data;
        }

        int remaining() {
            return data.length - pos;
        }

        int u32(String what) throws UpdateException {
            if (remaining() < 4) {
                throw new UpdateException(StatusCode.APK_INVALID, "обрыв данных: " + what);
            }
            int v = (int) AxmlManifestParser.u32(data, pos);
            pos += 4;
            return v;
        }

        byte[] bytes(int n, String what) throws UpdateException {
            if (n < 0 || n > remaining()) {
                throw new UpdateException(StatusCode.APK_INVALID,
                        "недопустимая длина (" + what + "): " + n);
            }
            byte[] out = new byte[n];
            System.arraycopy(data, pos, out, 0, n);
            pos += n;
            return out;
        }

        void requireEnd(int blockLen, String what) throws UpdateException {
            if (blockLen != remaining()) {
                throw new UpdateException(StatusCode.APK_INVALID,
                        "несовпадение длины блока " + what);
            }
        }
    }

    private static long findEocd(RandomAccessFile raf, long fileLen) throws IOException {
        // EOCD: 22 байта + комментарий (≤ 65535). Ищем с конца и проверяем
        // длину комментария, чтобы не принять мусор внутри комментария.
        long maxBack = Math.min(fileLen, 65535L + 22L);
        long start = fileLen - maxBack;
        byte[] buf = new byte[(int) maxBack];
        raf.seek(start);
        raf.readFully(buf);
        for (long i = buf.length - 22; i >= 0; i--) {
            if (buf[(int) i] == 0x50 && buf[(int) i + 1] == 0x4B
                    && buf[(int) i + 2] == 0x05 && buf[(int) i + 3] == 0x06) {
                long commentLen = AxmlManifestParser.u16(buf, (int) i + 20);
                long eocd = start + i;
                if (eocd + 22 + commentLen == fileLen) {
                    return eocd;
                }
            }
        }
        return -1;
    }

    private static boolean matchesMagic(byte[] m) {
        if (m.length != MAGIC.length) {
            return false;
        }
        for (int i = 0; i < MAGIC.length; i++) {
            if (m[i] != MAGIC[i]) {
                return false;
            }
        }
        return true;
    }

    private static long readU32(RandomAccessFile raf) throws IOException {
        int b0 = raf.read();
        int b1 = raf.read();
        int b2 = raf.read();
        int b3 = raf.read();
        if ((b0 | b1 | b2 | b3) < 0) {
            throw new EOFException();
        }
        return (b0 & 0xFFL) | ((b1 & 0xFFL) << 8) | ((b2 & 0xFFL) << 16) | ((b3 & 0xFFL) << 24);
    }

    private static long readU64(RandomAccessFile raf) throws IOException {
        long lo = readU32(raf);
        long hi = readU32(raf);
        return lo | (hi << 32);
    }
}
