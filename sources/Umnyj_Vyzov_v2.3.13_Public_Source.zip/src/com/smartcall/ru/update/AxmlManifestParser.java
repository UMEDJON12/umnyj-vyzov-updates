package com.smartcall.ru.update;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Минимальный строгий парсер бинарного AndroidManifest.xml (AXML) из APK:
 * читает package, versionCode, versionName у корневого элемента manifest.
 * Любая повреждённая/неожиданная структура — отказ (fail-closed).
 */
public final class AxmlManifestParser {

    private static final int RES_XML_TYPE = 0x0003;
    private static final int RES_STRING_POOL_TYPE = 0x0001;
    private static final int RES_XML_START_ELEMENT_TYPE = 0x0102;
    private static final int UTF8_FLAG = 0x00000100;
    private static final int TYPE_STRING = 0x03;
    private static final int TYPE_INT_DEC = 0x10;
    private static final int TYPE_INT_HEX = 0x11;
    private static final int NO_INDEX = 0xFFFFFFFF;
    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";

    /** Результат разбора manifest. */
    public static final class Info {
        public final String packageName;
        public final long versionCode;   // 0 — атрибут отсутствует/недоступен
        public final String versionName; // null — атрибут отсутствует

        public Info(String packageName, long versionCode, String versionName) {
            this.packageName = packageName;
            this.versionCode = versionCode;
            this.versionName = versionName;
        }
    }

    private AxmlManifestParser() {
    }

    public static Info parse(byte[] xml) throws UpdateException {
        if (xml == null || xml.length < 8) {
            throw bad("слишком короткий AndroidManifest.xml");
        }
        int type = u16(xml, 0);
        int headerSize = u16(xml, 2);
        long totalSize = u32(xml, 4);
        if (type != RES_XML_TYPE) {
            throw bad("это не AXML (type=0x" + Integer.toHexString(type) + ")");
        }
        if (headerSize != 8 || totalSize < 8 || totalSize > xml.length) {
            throw bad("повреждённый заголовок AXML");
        }
        int end = (int) totalSize;

        String[] strings = null;
        String packageName = null;
        long versionCode = 0;
        String versionName = null;
        boolean manifestSeen = false;

        long off = headerSize;
        while (off + 8 <= end) {
            int cType = u16(xml, (int) off);
            int cHeader = u16(xml, (int) off + 2);
            long cSize = u32(xml, (int) off + 4);
            if (cHeader < 8 || cSize < cHeader || off + cSize > end) {
                throw bad("повреждённый чанк AXML");
            }
            if (cType == RES_STRING_POOL_TYPE) {
                strings = parseStringPool(xml, (int) off, (int) cSize);
            } else if (cType == RES_XML_START_ELEMENT_TYPE && strings != null && !manifestSeen) {
                Element el = parseStartElement(xml, (int) off, (int) cSize, strings);
                if ("manifest".equals(el.name)) {
                    manifestSeen = true;
                    for (Attribute a : el.attrs) {
                        if ("package".equals(a.name) && a.ns == null) {
                            packageName = a.stringValue;
                        } else if ("versionCode".equals(a.name) && ANDROID_NS.equals(a.ns)) {
                            if (a.type == TYPE_INT_DEC || a.type == TYPE_INT_HEX) {
                                versionCode = a.intData & 0xFFFFFFFFL;
                            }
                        } else if ("versionName".equals(a.name) && ANDROID_NS.equals(a.ns)) {
                            versionName = a.stringValue;
                        }
                    }
                }
            }
            off += cSize;
        }
        if (strings == null) {
            throw bad("в AXML нет пула строк");
        }
        if (!manifestSeen) {
            throw bad("в AXML нет корневого элемента manifest");
        }
        if (packageName == null || packageName.isEmpty()) {
            throw bad("в manifest нет packageName");
        }
        return new Info(packageName, versionCode, versionName);
    }

    // ---- разбор чанков --------------------------------------------------

    private static final class Attribute {
        final String ns;       // null — без пространства имён
        final String name;
        final String stringValue; // разрешённая строка (или null)
        final int type;
        final int intData;

        Attribute(String ns, String name, String stringValue, int type, int intData) {
            this.ns = ns;
            this.name = name;
            this.stringValue = stringValue;
            this.type = type;
            this.intData = intData;
        }
    }

    private static final class Element {
        final String name;
        final List<Attribute> attrs;

        Element(String name, List<Attribute> attrs) {
            this.name = name;
            this.attrs = attrs;
        }
    }

    private static Element parseStartElement(byte[] xml, int off, int size, String[] strings)
            throws UpdateException {
        if (size < 36) {
            throw bad("слишком короткий START_ELEMENT");
        }
        int nameIdx = u32i(xml, off + 20);
        int attrStart = u16(xml, off + 24);
        int attrSize = u16(xml, off + 26);
        int attrCount = u16(xml, off + 28);
        String name = strAt(strings, nameIdx);
        if (name == null) {
            throw bad("имя элемента вне пула строк");
        }
        if (attrSize != 20 || attrStart != 20) {
            throw bad("неожиданный формат атрибутов (" + attrSize + "/" + attrStart + ")");
        }
        int attrsOff = off + 16 + attrStart; // 16 = размер element-заголовка до attrExt
        long needed = (long) attrsOff + (long) attrCount * 20L;
        if (needed > off + size) {
            throw bad("атрибуты выходят за чанк");
        }
        List<Attribute> attrs = new ArrayList<Attribute>(attrCount);
        for (int i = 0; i < attrCount; i++) {
            int a = attrsOff + i * 20;
            long nsIdx = u32(xml, a);
            int nmIdx = u32i(xml, a + 4);
            long rawIdx = u32(xml, a + 8);
            int vSize = u16(xml, a + 12);
            int vType = xml[a + 15] & 0xFF;
            int vData = u32i(xml, a + 16);
            if (vSize != 8) {
                throw bad("неожиданный размер значения атрибута");
            }
            String ns = nsIdx == NO_INDEX ? null : strAt(strings, (int) nsIdx);
            String nm = strAt(strings, nmIdx);
            if (nm == null) {
                throw bad("имя атрибута вне пула строк");
            }
            String sv = null;
            if (vType == TYPE_STRING) {
                long idx = rawIdx != NO_INDEX ? rawIdx : (vData & 0xFFFFFFFFL);
                if (idx != NO_INDEX) {
                    sv = strAt(strings, (int) idx);
                }
            }
            attrs.add(new Attribute(ns, nm, sv, vType, vData));
        }
        return new Element(name, attrs);
    }

    private static String[] parseStringPool(byte[] xml, int off, int size) throws UpdateException {
        if (size < 28) {
            throw bad("повреждённый пул строк");
        }
        int count = u32i(xml, off + 8);
        int flags = u32i(xml, off + 16);
        int stringsStart = u32i(xml, off + 20);
        if (count < 0 || count > 1_000_000) {
            throw bad("недопустимое число строк");
        }
        long offsetsEnd = (long) off + 28 + (long) count * 4L;
        if (offsetsEnd > off + size) {
            throw bad("таблица смещений строк выходит за чанк");
        }
        boolean utf8 = (flags & UTF8_FLAG) != 0;
        String[] out = new String[count];
        for (int i = 0; i < count; i++) {
            long so = u32(xml, off + 28 + i * 4);
            long p = (long) off + stringsStart + so;
            if (p < off + stringsStart || p >= off + size) {
                throw bad("смещение строки вне пула");
            }
            if (utf8) {
                // u8 charLen (возможно 2 байта), u8 byteLen (возможно 2 байта), байты
                long[] r1 = readU8WithHigh(xml, p, off + size);
                long[] r2 = readU8WithHigh(xml, r1[1], off + size);
                long byteLen = r2[0];
                long start = r2[1];
                if (start + byteLen > off + size) {
                    throw bad("строка выходит за пределы пула");
                }
                byte[] raw = new byte[(int) byteLen];
                System.arraycopy(xml, (int) start, raw, 0, (int) byteLen);
                out[i] = new String(raw, StandardCharsets.UTF_8);
            } else {
                long[] r = readU16WithHigh(xml, p, off + size);
                long charLen = r[0];
                long start = r[1];
                if (start + charLen * 2 > off + size) {
                    throw bad("строка выходит за пределы пула");
                }
                out[i] = new String(xml, (int) start, (int) charLen * 2, StandardCharsets.UTF_16LE);
            }
        }
        return out;
    }

    /** u8: если старший бит установлен — длина из двух байт. Возвращает [значение, позиция]. */
    private static long[] readU8WithHigh(byte[] b, long p, long limit) throws UpdateException {
        if (p >= limit) {
            throw bad("неожиданный конец пула строк");
        }
        int v = b[(int) p] & 0xFF;
        if ((v & 0x80) != 0) {
            if (p + 1 >= limit) {
                throw bad("неожиданный конец пула строк");
            }
            int v2 = b[(int) p + 1] & 0xFF;
            return new long[]{((v & 0x7F) << 8) | v2, p + 2};
        }
        return new long[]{v, p + 1};
    }

    /** u16: если старший бит установлен — длина из двух u16. Возвращает [значение, позиция]. */
    private static long[] readU16WithHigh(byte[] b, long p, long limit) throws UpdateException {
        if (p + 2 > limit) {
            throw bad("неожиданный конец пула строк");
        }
        int v = u16(b, (int) p);
        if ((v & 0x8000) != 0) {
            if (p + 4 > limit) {
                throw bad("неожиданный конец пула строк");
            }
            int v2 = u16(b, (int) p + 2);
            return new long[]{((long) (v & 0x7FFF) << 16) | v2, p + 4};
        }
        return new long[]{v, p + 2};
    }

    private static String strAt(String[] strings, int idx) {
        if (idx < 0 || idx >= strings.length) {
            return null;
        }
        return strings[idx];
    }

    // ---- little-endian чтение ------------------------------------------

    static int u16(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
    }

    static long u32(byte[] b, int off) {
        return ((long) (b[off] & 0xFF))
                | ((long) (b[off + 1] & 0xFF) << 8)
                | ((long) (b[off + 2] & 0xFF) << 16)
                | ((long) (b[off + 3] & 0xFF) << 24);
    }

    static int u32i(byte[] b, int off) {
        return (int) u32(b, off);
    }

    private static UpdateException bad(String why) {
        return new UpdateException(StatusCode.APK_INVALID, "манифест APK: " + why);
    }
}
