package com.smartcall.ru.update;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Продакшен-транспорт на HttpURLConnection. Редиректы выключены —
 * их контролирует {@link HttpSupport} (белый список хостов, только HTTPS).
 * Работает и на Android, и на host-JVM; в тестах не используется.
 */
public final class UrlConnectionTransport implements HttpTransport {

    @Override
    public Reply execute(String url, int connectTimeoutMs, int readTimeoutMs) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(connectTimeoutMs);
        conn.setReadTimeout(readTimeoutMs);
        conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("User-Agent", UpdateConfig.USER_AGENT);
        conn.setRequestProperty("Accept", "application/json, application/octet-stream, */*");
        int status;
        try {
            status = conn.getResponseCode();
        } catch (IOException e) {
            conn.disconnect();
            throw e;
        }
        String location = conn.getHeaderField("Location");
        long contentLength = conn.getContentLengthLong();
        InputStream body;
        if (status >= 400) {
            body = conn.getErrorStream();
            if (body == null) {
                body = new java.io.ByteArrayInputStream(new byte[0]);
            }
        } else {
            body = conn.getInputStream();
        }
        final HttpURLConnection c = conn;
        return new Reply(status, location, contentLength, body) {
            @Override
            public void close() {
                super.close();
                c.disconnect();
            }
        };
    }
}
