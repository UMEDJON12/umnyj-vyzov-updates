package com.smartcall.ru.update;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Строгий минимальный JSON-парсер (без сторонних библиотек — работает и на
 * host-JVM, и на Android). Любая сомнительная структура — отказ (BAD_JSON):
 * повторяющиеся ключи, запятые после последнего элемента, «висящие» разделители,
 * управляющие символы внутри строк, лишний мусор в конце, излишняя вложенность.
 */
public final class Json {

    private static final int MAX_DEPTH = 32;
    private static final int MAX_LEN = 512 * 1024;

    private final String src;
    private int pos;

    private Json(String src) {
        this.src = src;
    }

    /** Разобрать байты UTF-8 в JSON-объект (корнем может быть только object). */
    public static Map<String, Object> parseObject(byte[] utf8) throws UpdateException {
        return parseObject(decodeUtf8(utf8));
    }

    public static Map<String, Object> parseObject(String text) throws UpdateException {
        Json parser = new Json(text);
        Object v = parser.parseValue(0);
        parser.skipWs();
        if (parser.pos != text.length()) {
            throw bad("лишние данные после JSON");
        }
        if (!(v instanceof Map)) {
            throw bad("корнем должен быть JSON-объект");
        }
        @SuppressWarnings("unchecked")
        Map<String, Object> m = (Map<String, Object>) v;
        return m;
    }

    static String decodeUtf8(byte[] bytes) throws UpdateException {
        if (bytes == null || bytes.length == 0) {
            throw bad("пустой ответ");
        }
        if (bytes.length > MAX_LEN) {
            throw bad("ответ больше " + MAX_LEN + " байт");
        }
        try {
            String s = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes))
                    .toString();
            return s;
        } catch (CharacterCodingException e) {
            throw new UpdateException(StatusCode.BAD_JSON, "текст не является корректным UTF-8", e);
        }
    }

    private Object parseValue(int depth) throws UpdateException {
        if (depth > MAX_DEPTH) {
            throw bad("слишком глубокая вложенность");
        }
        skipWs();
        if (pos >= src.length()) {
            throw bad("неожиданный конец данных");
        }
        char c = src.charAt(pos);
        switch (c) {
            case '{':
                return parseObjectValue(depth + 1);
            case '[':
                return parseArray(depth + 1);
            case '"':
                return parseString();
            case 't':
                expect("true");
                return Boolean.TRUE;
            case 'f':
                expect("false");
                return Boolean.FALSE;
            case 'n':
                expect("null");
                return null;
            default:
                if (c == '-' || (c >= '0' && c <= '9')) {
                    return parseNumber();
                }
                throw bad("неожиданный символ '" + c + "' на позиции " + pos);
        }
    }

    private Map<String, Object> parseObjectValue(int depth) throws UpdateException {
        pos++; // {
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        skipWs();
        if (peek() == '}') {
            pos++;
            return out;
        }
        while (true) {
            skipWs();
            if (peek() != '"') {
                throw bad("ожидался ключ-строка");
            }
            String key = parseString();
            if (out.containsKey(key)) {
                throw bad("повторяющийся ключ \"" + key + "\"");
            }
            skipWs();
            if (peek() != ':') {
                throw bad("ожидался ':' после ключа \"" + key + "\"");
            }
            pos++;
            Object val = parseValue(depth);
            out.put(key, val);
            skipWs();
            char c = peek();
            if (c == ',') {
                pos++;
                continue;
            }
            if (c == '}') {
                pos++;
                return out;
            }
            throw bad("ожидался ',' или '}' в объекте");
        }
    }

    private List<Object> parseArray(int depth) throws UpdateException {
        pos++; // [
        List<Object> out = new ArrayList<Object>();
        skipWs();
        if (peek() == ']') {
            pos++;
            return out;
        }
        while (true) {
            out.add(parseValue(depth));
            skipWs();
            char c = peek();
            if (c == ',') {
                pos++;
                continue;
            }
            if (c == ']') {
                pos++;
                return out;
            }
            throw bad("ожидался ',' или ']' в массиве");
        }
    }

    private String parseString() throws UpdateException {
        pos++; // "
        StringBuilder sb = new StringBuilder();
        while (true) {
            if (pos >= src.length()) {
                throw bad("незакрытая строка");
            }
            char c = src.charAt(pos++);
            if (c == '"') {
                return sb.toString();
            }
            if (c == '\\') {
                if (pos >= src.length()) {
                    throw bad("незавершённая escape-последовательность");
                }
                char e = src.charAt(pos++);
                switch (e) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (pos + 4 > src.length()) {
                            throw bad("неполный \\u-escape");
                        }
                        String hex = src.substring(pos, pos + 4);
                        try {
                            sb.append((char) Integer.parseInt(hex, 16));
                        } catch (NumberFormatException nfe) {
                            throw bad("некорректный \\u-escape: " + hex);
                        }
                        pos += 4;
                        break;
                    default:
                        throw bad("неизвестный escape '\\" + e + "'");
                }
                continue;
            }
            if (c < 0x20) {
                throw bad("управляющий символ внутри строки");
            }
            sb.append(c);
        }
    }

    private Object parseNumber() throws UpdateException {
        int start = pos;
        if (peek() == '-') {
            pos++;
        }
        // целая часть: 0 | [1-9][0-9]*
        if (pos >= src.length() || src.charAt(pos) < '0' || src.charAt(pos) > '9') {
            throw bad("некорректное число");
        }
        if (src.charAt(pos) == '0') {
            pos++;
            if (pos < src.length() && Character.isDigit(src.charAt(pos))) {
                throw bad("ведущие нули в числе запрещены");
            }
        } else {
            while (pos < src.length() && Character.isDigit(src.charAt(pos))) {
                pos++;
            }
        }
        boolean isDouble = false;
        if (pos < src.length() && src.charAt(pos) == '.') {
            isDouble = true;
            pos++;
            if (pos >= src.length() || !Character.isDigit(src.charAt(pos))) {
                throw bad("некорректная дробная часть числа");
            }
            while (pos < src.length() && Character.isDigit(src.charAt(pos))) {
                pos++;
            }
        }
        if (pos < src.length() && (src.charAt(pos) == 'e' || src.charAt(pos) == 'E')) {
            isDouble = true;
            pos++;
            if (pos < src.length() && (src.charAt(pos) == '+' || src.charAt(pos) == '-')) {
                pos++;
            }
            if (pos >= src.length() || !Character.isDigit(src.charAt(pos))) {
                throw bad("некорректная экспонента числа");
            }
            while (pos < src.length() && Character.isDigit(src.charAt(pos))) {
                pos++;
            }
        }
        String num = src.substring(start, pos);
        try {
            if (!isDouble) {
                return Long.valueOf(num);
            }
            double d = Double.parseDouble(num);
            if (Double.isNaN(d) || Double.isInfinite(d)) {
                throw bad("число вне допустимого диапазона");
            }
            return Double.valueOf(d);
        } catch (NumberFormatException nfe) {
            throw new UpdateException(StatusCode.BAD_JSON, "некорректное число: " + num, nfe);
        }
    }

    private void expect(String word) throws UpdateException {
        if (!src.startsWith(word, pos)) {
            throw bad("ожидалось " + word);
        }
        pos += word.length();
    }

    private char peek() throws UpdateException {
        if (pos >= src.length()) {
            throw bad("неожиданный конец данных");
        }
        return src.charAt(pos);
    }

    private void skipWs() {
        while (pos < src.length()) {
            char c = src.charAt(pos);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                pos++;
            } else {
                break;
            }
        }
    }

    private static UpdateException bad(String why) {
        return new UpdateException(StatusCode.BAD_JSON, why);
    }

    // ---- строгие доступчики полей -------------------------------------

    public static String reqString(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (!(v instanceof String)) {
            throw field(key, "строка");
        }
        return (String) v;
    }

    public static String optString(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (v == null) {
            return null;
        }
        if (!(v instanceof String)) {
            throw field(key, "строка");
        }
        return (String) v;
    }

    public static long reqLong(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (!(v instanceof Long)) {
            throw field(key, "целое число");
        }
        return ((Long) v).longValue();
    }

    public static long optLong(Map<String, Object> m, String key, long def) throws UpdateException {
        Object v = m.get(key);
        if (v == null) {
            return def;
        }
        if (!(v instanceof Long)) {
            throw field(key, "целое число");
        }
        return ((Long) v).longValue();
    }

    public static boolean reqBoolean(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (!(v instanceof Boolean)) {
            throw field(key, "логическое значение");
        }
        return ((Boolean) v).booleanValue();
    }

    public static boolean optBoolean(Map<String, Object> m, String key, boolean def) throws UpdateException {
        Object v = m.get(key);
        if (v == null) {
            return def;
        }
        if (!(v instanceof Boolean)) {
            throw field(key, "логическое значение");
        }
        return ((Boolean) v).booleanValue();
    }

    @SuppressWarnings("unchecked")
    public static List<Object> reqArray(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (!(v instanceof List)) {
            throw field(key, "массив");
        }
        return (List<Object>) v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> reqObject(Map<String, Object> m, String key) throws UpdateException {
        Object v = m.get(key);
        if (!(v instanceof Map)) {
            throw field(key, "объект");
        }
        return (Map<String, Object>) v;
    }

    public static boolean has(Map<String, Object> m, String key) {
        return m.containsKey(key) && m.get(key) != null;
    }

    private static UpdateException field(String key, String expected) {
        return new UpdateException(StatusCode.BAD_JSON,
                "поле \"" + key + "\" должно быть: " + expected);
    }
}
