package com.smartcall.ru.update;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** SHA-256: потоковый расчёт файла/байтов и работа с hex-строками. */
public final class Sha256 {

    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private Sha256() {
    }

    public static String ofBytes(byte[] data) {
        return toHex(newDigest().digest(data));
    }

    /** Расчёт SHA-256 файла целиком. Бросает IOException при ошибке чтения. */
    public static String ofFile(File file) throws IOException {
        InputStream in = new FileInputStream(file);
        try {
            return ofStream(in);
        } finally {
            closeQuietly(in);
        }
    }

    public static String ofStream(InputStream in) throws IOException {
        MessageDigest md = newDigest();
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) {
            md.update(buf, 0, n);
        }
        return toHex(md.digest());
    }

    public static MessageDigest newDigest() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            // На Android и host-JVM SHA-256 обязателен спецификацией.
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    /** hex64 в нижнем регистре или null, если строка не является hex-SHA-256. */
    public static String normalizeHex64(String s) {
        if (s == null || s.length() != 64) {
            return null;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
            if (!hex) {
                return null;
            }
        }
        return s.toLowerCase(java.util.Locale.ROOT);
    }

    /** Сравнение hex-строк без учёта регистра, устойчивое к таймингу. */
    public static boolean hexEquals(String a, String b) {
        if (a == null || b == null) {
            return false;
        }
        if (a.length() != b.length()) {
            return false;
        }
        int diff = 0;
        for (int i = 0; i < a.length(); i++) {
            diff |= a.charAt(i) ^ b.charAt(i);
        }
        return diff == 0;
    }

    public static String toHex(byte[] raw) {
        char[] out = new char[raw.length * 2];
        for (int i = 0; i < raw.length; i++) {
            int v = raw[i] & 0xFF;
            out[i * 2] = HEX[v >>> 4];
            out[i * 2 + 1] = HEX[v & 0x0F];
        }
        return new String(out);
    }

    static void closeQuietly(java.io.Closeable c) {
        if (c == null) {
            return;
        }
        try {
            c.close();
        } catch (IOException ignored) {
            // намеренно подавлено
        }
    }
}
