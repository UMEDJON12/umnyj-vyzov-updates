package com.smartcall.ru.update;

/**
 * Ключ-значение хранилище состояния обновлений.
 * На Android — приватный SharedPreferences (файл в /data/data/...),
 * в тестах — in-memory и файловый варианты на host-JVM.
 */
public interface KeyValueStore {

    String getString(String key, String defValue);

    void putString(String key, String value);

    long getLong(String key, long defValue);

    void putLong(String key, long value);

    boolean getBoolean(String key, boolean defValue);

    void putBoolean(String key, boolean value);

    void remove(String key);

    /** Batch values are String, Long, Boolean or null (remove).
     * Legacy implementations are sequential; persistent stores should override atomically. */
    default void applyBatch(java.util.Map<String, Object> changes) {
        for (java.util.Map.Entry<String, Object> entry : changes.entrySet()) {
            Object value = entry.getValue();
            if (value == null) remove(entry.getKey());
            else if (value instanceof String) putString(entry.getKey(), (String) value);
            else if (value instanceof Long) putLong(entry.getKey(), (Long) value);
            else if (value instanceof Boolean) putBoolean(entry.getKey(), (Boolean) value);
            else throw new IllegalArgumentException("Unsupported batch value");
        }
    }
}
