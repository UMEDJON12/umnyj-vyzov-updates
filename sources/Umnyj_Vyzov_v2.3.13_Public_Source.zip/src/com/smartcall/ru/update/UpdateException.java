package com.smartcall.ru.update;

/**
 * Отказ модуля обновлений: код статуса + понятный русский текст.
 * Ожидаемые отказы (нет сети, битый файл и т.п.) — не исключения верхнего
 * уровня, а именно этот тип: вызывающий код обязан его ловить и показывать
 * статус, а не падать.
 */
public class UpdateException extends Exception {

    private static final long serialVersionUID = 1L;

    private final StatusCode status;
    private final String detail;

    public UpdateException(StatusCode status, String detail) {
        super(buildMessage(status, detail));
        this.status = status;
        this.detail = detail == null ? "" : detail;
    }

    public UpdateException(StatusCode status, String detail, Throwable cause) {
        super(buildMessage(status, detail), cause);
        this.status = status;
        this.detail = detail == null ? "" : detail;
    }

    public UpdateException(StatusCode status) {
        this(status, null);
    }

    private static String buildMessage(StatusCode status, String detail) {
        String base = status == null ? StatusCode.UNKNOWN.text() : status.text();
        if (detail == null || detail.isEmpty()) {
            return base;
        }
        return base + ": " + detail;
    }

    public StatusCode status() {
        return status == null ? StatusCode.UNKNOWN : status;
    }

    public String detail() {
        return detail;
    }

    /** Полный понятный текст для пользователя. */
    public String userMessage() {
        return getMessage();
    }
}
