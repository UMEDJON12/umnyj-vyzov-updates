package com.smartcall.ru.update;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.PortUnreachableException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.Locale;

import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;

/**
 * Общий HTTP-слой: follow только по HTTPS и только внутри белого списка хостов,
 * таймауты, классификация ошибок в русские статусы, лимит размера тела.
 */
public final class HttpSupport {

    private HttpSupport() {
    }

    /**
     * Открыть поток тела, следуя по редиректам (не более
     * {@link UpdateConfig#MAX_REDIRECTS}), валидируя схему и хост каждого шага.
     * Тела промежуточных редиректов закрываются.
     */
    public static HttpTransport.Reply openFollowing(HttpTransport transport, String url,
                                                    UpdateConfig.HostPolicy policy,
                                                    UpdateConfig cfg) throws UpdateException {
        String current = url;
        for (int hop = 0; hop <= UpdateConfig.MAX_REDIRECTS; hop++) {
            validateHttpsUrl(current, cfg);
            String host = hostOf(current);
            if (!policy.allows(host)) {
                throw new UpdateException(StatusCode.BAD_URL, "хост " + host + " не в белом списке");
            }
            HttpTransport.Reply reply;
            try {
                reply = transport.execute(current, cfg.connectTimeoutMs(), cfg.readTimeoutMs());
            } catch (IOException e) {
                throw classify(e, current);
            }
            int st = reply.status;
            if (st == 200) {
                return reply;
            }
            if (st == 301 || st == 302 || st == 303 || st == 307 || st == 308) {
                String loc = reply.location;
                reply.close();
                if (loc == null || loc.isEmpty()) {
                    throw new UpdateException(StatusCode.BAD_RESPONSE, "редирект без Location");
                }
                current = resolve(current, loc);
                continue;
            }
            reply.close();
            throw httpError(st);
        }
        throw new UpdateException(StatusCode.BAD_RESPONSE,
                "слишком много редиректов (> " + UpdateConfig.MAX_REDIRECTS + ")");
    }

    /** GET с ограничением размера тела — для метаданных (JSON). */
    public static byte[] getBounded(HttpTransport transport, String url,
                                    UpdateConfig.HostPolicy policy, UpdateConfig cfg)
            throws UpdateException {
        HttpTransport.Reply reply = openFollowing(transport, url, policy, cfg);
        try {
            long declared = reply.contentLength;
            if (declared > cfg.maxMetadataBytes()) {
                throw new UpdateException(StatusCode.BAD_RESPONSE,
                        "ответ больше лимита (" + cfg.maxMetadataBytes() + " байт)");
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream(
                    declared > 0 ? (int) declared : 8192);
            byte[] buf = new byte[8192];
            int n;
            long total = 0;
            try {
                while ((n = reply.body.read(buf)) != -1) {
                    total += n;
                    if (total > cfg.maxMetadataBytes()) {
                        throw new UpdateException(StatusCode.BAD_RESPONSE,
                                "ответ больше лимита (" + cfg.maxMetadataBytes() + " байт)");
                    }
                    out.write(buf, 0, n);
                }
            } catch (IOException e) {
                throw classify(e, url);
            }
            return out.toByteArray();
        } finally {
            reply.close();
        }
    }

    /** Строгая проверка URL: только https, с хостом, без userinfo/фрагмента. */
    public static void validateHttpsUrl(String url, UpdateConfig cfg) throws UpdateException {
        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            throw new UpdateException(StatusCode.BAD_URL, "некорректный URL", e);
        }
        if (!"https".equalsIgnoreCase(uri.getScheme())) {
            throw new UpdateException(StatusCode.BAD_URL, "разрешён только HTTPS: " + url);
        }
        if (uri.getHost() == null || uri.getHost().isEmpty()) {
            throw new UpdateException(StatusCode.BAD_URL, "URL без хоста: " + url);
        }
        if (uri.getUserInfo() != null) {
            throw new UpdateException(StatusCode.BAD_URL, "URL с логином/паролем запрещён");
        }
        if (uri.getFragment() != null) {
            throw new UpdateException(StatusCode.BAD_URL, "URL с фрагментом запрещён");
        }
    }

    /** Классификация IOException в понятный русский статус. */
    public static UpdateException classify(IOException e, String url) {
        String host = hostOf(url);
        String detail = host == null ? "" : host;
        if (e instanceof UnknownHostException
                || e instanceof ConnectException
                || e instanceof NoRouteToHostException
                || e instanceof PortUnreachableException) {
            return new UpdateException(StatusCode.NO_INTERNET, detail, e);
        }
        if (e instanceof SocketTimeoutException) {
            return new UpdateException(StatusCode.TIMEOUT, detail, e);
        }
        if (e instanceof SSLHandshakeException || e instanceof SSLPeerUnverifiedException
                || e instanceof SSLException) {
            return new UpdateException(StatusCode.SSL, detail, e);
        }
        if (e instanceof SocketException) {
            return new UpdateException(StatusCode.NETWORK, detail, e);
        }
        return new UpdateException(StatusCode.NETWORK,
                e.getMessage() == null ? detail : e.getMessage(), e);
    }

    /** HTTP status is kept separately from the human-readable message. */
    public static final class HttpStatusException extends UpdateException {
        private static final long serialVersionUID = 1L;
        private final int httpStatus;

        private HttpStatusException(int httpStatus, String detail) {
            super(StatusCode.HTTP, detail);
            this.httpStatus = httpStatus;
        }

        public int httpStatus() {
            return httpStatus;
        }
    }

    public static UpdateException httpError(int status) {
        String detail = "HTTP " + status;
        if (status == 403 || status == 429) {
            detail += " (возможно, лимит запросов GitHub — повторите позже)";
        }
        return new HttpStatusException(status, detail);
    }

    public static String hostOf(String url) {
        try {
            return new URI(url).getHost();
        } catch (URISyntaxException e) {
            return null;
        }
    }

    /** Разрешить Location относительно текущего URL (после валидации схемы). */
    static String resolve(String base, String location) throws UpdateException {
        try {
            URI b = new URI(base);
            URI resolved = b.resolve(location);
            String s = resolved.toASCIIString();
            return s;
        } catch (URISyntaxException e) {
            throw new UpdateException(StatusCode.BAD_URL, "некорректный редирект: " + location, e);
        }
    }

    /** Скачивание потока не используется здесь; лежит в {@link Downloader}. */
    static long readFully(InputStream in, byte[] buf) throws IOException {
        long total = 0;
        int n;
        while ((n = in.read(buf)) != -1) {
            total += n;
        }
        return total;
    }

    static String lower(String s) {
        return s == null ? null : s.toLowerCase(Locale.ROOT);
    }
}
