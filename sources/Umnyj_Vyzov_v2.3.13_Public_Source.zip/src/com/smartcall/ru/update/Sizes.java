package com.smartcall.ru.update;

/** Форматирование размеров и прогресса для уведомлений/статусов (по-русски). */
public final class Sizes {

    private Sizes() {
    }

    /** 0 → «0 Б», 1536 → «1,5 КБ», 5*1024*1024 → «5 МБ». */
    public static String human(long bytes) {
        if (bytes < 0) {
            return "—";
        }
        if (bytes < 1024) {
            return bytes + " Б";
        }
        long kb = bytes / 1024;
        if (kb < 1024) {
            long frac = ((bytes % 1024) * 10) / 1024;
            if (frac == 0) {
                return kb + " КБ";
            }
            return kb + "," + frac + " КБ";
        }
        long mb = kb / 1024;
        if (mb < 1024) {
            long frac = ((kb % 1024) * 10) / 1024;
            if (frac == 0) {
                return mb + " МБ";
            }
            return mb + "," + frac + " МБ";
        }
        long gb = mb / 1024;
        long frac = ((mb % 1024) * 10) / 1024;
        if (frac == 0) {
            return gb + " ГБ";
        }
        return gb + "," + frac + " ГБ";
    }

    /** Проценты загрузки: 0..100, без выхода за границы. */
    public static int percent(long downloaded, long total) {
        if (total <= 0 || downloaded <= 0) {
            return 0;
        }
        if (downloaded >= total) {
            return 100;
        }
        return (int) ((downloaded * 100) / total);
    }

    /** Оставшиеся байты: не меньше нуля. */
    public static long remaining(long downloaded, long total) {
        if (total <= 0 || downloaded >= total) {
            return 0;
        }
        return total - downloaded;
    }

    /**
     * Строка прогресса: «Загружено 1,5 МБ из 5 МБ (30%) · осталось 3,5 МБ».
     */
    public static String progressLine(long downloaded, long total, int percent) {
        return "Загружено " + human(downloaded) + " из " + human(total)
                + " (" + percent + "%) · осталось " + human(remaining(downloaded, total));
    }
}
