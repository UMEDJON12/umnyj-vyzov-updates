package com.smartcall.ru.update;

/**
 * Все статусы модуля обновлений. Тексты — по-русски, единая точка правды.
 * Информационные статусы (fail == false) не считаются ошибками.
 */
public enum StatusCode {
    OK("Готово", false),
    UP_TO_DATE("Установлена актуальная версия", false),
    NO_PUBLISHED_UPDATES("Опубликованных обновлений пока нет", false),
    DEFERRED("Обновление отложено до следующей версии", false),
    CANCELLED("Скачивание отменено", false),

    NO_INTERNET("Нет соединения с интернетом", true),
    TIMEOUT("Сервер не отвечает (тайм-аут)", true),
    NETWORK("Сетевая ошибка при запросе обновления", true),
    SSL("Ошибка защищённого соединения (TLS)", true),
    HTTP("Сервер вернул ошибку", true),
    BAD_URL("Недопустимый адрес в данных обновления", true),
    BAD_JSON("Некорректный формат данных обновления", true),
    BAD_RESPONSE("Сервер вернул неожиданные данные", true),
    CHANNEL_INVALID("Данные канала обновлений не прошли проверку", true),
    NOT_READY("Канал обновлений ещё не опубликован", true),
    WRONG_PACKAGE("Канал обновлений предназначен для другого приложения", true),
    NOT_NEWER("Установлена актуальная версия", false),
    ROLLBACK("Запрещён откат на более раннюю версию", true),
    OLD_ANDROID("На этом устройстве недоступна данная версия обновления", true),
    TOO_LARGE("Файл обновления больше допустимого лимита", true),
    SIZE_MISMATCH("Размер файла не совпадает с указанным в описании обновления", true),
    HASH_MISMATCH("Контрольная сумма файла (SHA-256) не совпадает", true),
    CERT_MISMATCH("Подпись APK не совпадает с подписью установленного приложения", true),
    APK_INVALID("Файл обновления повреждён или непригоден для установки", true),
    PACKAGE_MISMATCH("APK содержит другой пакет приложения", true),
    VERSION_MISMATCH("Версия в APK не совпадает с описанием обновления", true),
    DRAFT("Релиз обновления ещё не опубликован (черновик)", true),
    PRERELEASE("Релиз обновления помечен как предварительный", true),
    RELEASE_MISMATCH("Описание обновления не соответствует опубликованному релизу", true),
    RELEASE_CHANGED("Релиз изменился во время скачивания, повторите проверку", true),
    DOWNLOAD_FAILED("Не удалось скачать обновление", true),
    INTERRUPTED("Соединение прервалось, скачивание остановлено", true),
    STORAGE("Не удалось записать файл обновления", true),
    NO_FILE("Скачанный файл обновления не найден", true),
    INSTALL_UNAVAILABLE("Не найдено приложение для установки APK", true),
    BUSY("Операция обновления уже выполняется", true),
    STATE("Ошибка внутреннего состояния обновления", true),
    UNKNOWN("Неизвестная ошибка обновления", true);

    private final String text;
    private final boolean failure;

    StatusCode(String text, boolean failure) {
        this.text = text;
        this.failure = failure;
    }

    /** Понятный пользователю текст статуса (по-русски). */
    public String text() {
        return text;
    }

    /** true — если статус означает ошибку/отказ, false — информационный исход. */
    public boolean isFailure() {
        return failure;
    }
}
