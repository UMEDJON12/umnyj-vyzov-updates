package com.smartcall.ru.update;

import java.util.List;
import java.util.Map;

/**
 * Публичный GitHub Release (api.github.com/.../releases/latest) + склейка
 * с stable.json. Проверяются draft/prerelease, тег и точное соответствие
 * ассета релиза описанию канала.
 */
public final class ReleaseInfo {

    public final String tagName;
    public final boolean draft;
    public final boolean prerelease;
    public final String name;
    public final String assetName;
    public final long assetSize;
    public final String assetUrl;

    private ReleaseInfo(String tagName, boolean draft, boolean prerelease, String name,
                        String assetName, long assetSize, String assetUrl) {
        this.tagName = tagName;
        this.draft = draft;
        this.prerelease = prerelease;
        this.name = name;
        this.assetName = assetName;
        this.assetSize = assetSize;
        this.assetUrl = assetUrl;
    }

    /**
     * Разбор release JSON и проверка против stable.json.
     * Бросает UpdateException при любом несоответствии (fail-closed).
     */
    public static ReleaseInfo parseAndCrossCheck(byte[] jsonBytes, ReleaseManifest manifest)
            throws UpdateException {
        Map<String, Object> m = Json.parseObject(jsonBytes);

        // GitHub API отдаёт "tag_name"; собственный канал — "tagName".
        String tagName = m.containsKey("tag_name")
                ? Json.reqString(m, "tag_name")
                : Json.reqString(m, "tagName");
        boolean draft = Json.reqBoolean(m, "draft");
        boolean prerelease = Json.reqBoolean(m, "prerelease");

        if (draft) {
            throw new UpdateException(StatusCode.DRAFT, tagName);
        }
        if (prerelease) {
            throw new UpdateException(StatusCode.PRERELEASE, tagName);
        }
        if (!manifest.tagName.equals(tagName)) {
            throw new UpdateException(StatusCode.RELEASE_MISMATCH,
                    "релиз " + tagName + ", в канале " + manifest.tagName);
        }

        String name = Json.optString(m, "name");

        List<Object> assets = Json.reqArray(m, "assets");
        int matches = 0;
        String assetName = null;
        long assetSize = -1;
        String assetUrl = null;
        for (Object o : assets) {
            if (!(o instanceof Map)) {
                throw new UpdateException(StatusCode.BAD_RESPONSE, "некорректный элемент assets");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> a = (Map<String, Object>) o;
            String an = Json.reqString(a, "name");
            if (manifest.apkFileName.equals(an)) {
                matches++;
                assetName = an;
                assetSize = Json.reqLong(a, "size");
                assetUrl = Json.reqString(a, "browser_download_url");
            }
        }
        if (matches == 0) {
            throw new UpdateException(StatusCode.RELEASE_MISMATCH,
                    "в релизе нет ассета " + manifest.apkFileName);
        }
        if (matches > 1) {
            throw new UpdateException(StatusCode.RELEASE_MISMATCH,
                    "в релизе несколько ассетов с именем " + manifest.apkFileName);
        }
        if (assetSize != manifest.sizeBytes) {
            throw new UpdateException(StatusCode.SIZE_MISMATCH,
                    "релиз: " + assetSize + ", канал: " + manifest.sizeBytes);
        }
        if (!manifest.apkUrl.equals(assetUrl)) {
            throw new UpdateException(StatusCode.RELEASE_MISMATCH,
                    "URL ассета релиза не совпадает с каналом");
        }
        HttpSupport.validateHttpsUrl(assetUrl, UpdateConfig.defaults());

        return new ReleaseInfo(tagName, draft, prerelease, name, assetName, assetSize, assetUrl);
    }

    /** Полное равенство «канал ↔ релиз ↔ скачанный кандидат» для повторной проверки. */
    public static boolean sameAs(ReleaseManifest a, ReleaseManifest b) {
        return a.versionCode == b.versionCode
                && a.sizeBytes == b.sizeBytes
                && a.sha256.equals(b.sha256)
                && a.tagName.equals(b.tagName)
                && a.apkUrl.equals(b.apkUrl)
                && a.apkFileName.equals(b.apkFileName)
                && a.versionName.equals(b.versionName);
    }
}
