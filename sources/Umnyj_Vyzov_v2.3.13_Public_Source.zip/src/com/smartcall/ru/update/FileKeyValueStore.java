package com.smartcall.ru.update;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;

/** Host file store. Writes use a synced sibling and a same-directory rename.
 * Corrupt/unreadable state raises IllegalStateException, never defaults.
 * Atomic rename and durability depend on the filesystem; Java's portable API
 * does not sync the parent directory. Multiple instances/processes need external
 * locking. A missing file after restart cannot be distinguished from first use.
 * Legacy properties have no checksum and cannot detect all corruption. */
public final class FileKeyValueStore implements KeyValueStore {
    private static final byte[] MAGIC = new byte[]{0, 'S', 'C', 'U', 'P', 'D', 1};
    private static final int MAX_BYTES = 1024 * 1024;
    private final File file;
    private boolean observedFile;

    public FileKeyValueStore(File file) { this.file = file.getAbsoluteFile(); }

    private static byte[] digest(byte[] data) {
        try { return MessageDigest.getInstance("SHA-256").digest(data); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    private Properties load() {
        Properties p = new Properties();
        if (!file.exists()) {
            if (observedFile) throw new IllegalStateException("Update state file disappeared");
            return p;
        }
        observedFile = true;
        try {
            byte[] bytes;
            try (FileInputStream in = new FileInputStream(file);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (out.size() + n > MAX_BYTES) throw new IOException("State too large");
                    out.write(buf, 0, n);
                }
                bytes = out.toByteArray();
            }
            if (bytes.length == 0) throw new IOException("Empty state file");
            if (bytes[0] == 0) {
                DataInputStream in = new DataInputStream(new ByteArrayInputStream(bytes));
                byte[] magic = new byte[MAGIC.length];
                in.readFully(magic);
                if (!java.util.Arrays.equals(magic, MAGIC)) throw new IOException("Bad state header");
                int length = in.readInt();
                if (length < 0 || length != bytes.length - MAGIC.length - 4 - 32)
                    throw new IOException("Bad state length");
                byte[] expected = new byte[32];
                in.readFully(expected);
                byte[] payload = new byte[length];
                in.readFully(payload);
                if (!MessageDigest.isEqual(expected, digest(payload))) throw new IOException("State checksum mismatch");
                p.load(new ByteArrayInputStream(payload));
            } else {
                // Properties.store from 2.3.8 emits this header; requiring it also
                // prevents a damaged new-format header being mistaken for legacy.
                String text = new String(bytes, "ISO-8859-1");
                if (!text.startsWith("#smartcall update state\n") &&
                    !text.startsWith("#smartcall update state\r\n"))
                    throw new IOException("Unknown legacy state format");
                for (byte b : bytes) if (b == 0) throw new IOException("Invalid legacy state");
                p.load(new ByteArrayInputStream(bytes));
            }
            return p;
        } catch (IOException | IllegalArgumentException e) {
            throw new IllegalStateException("Cannot read update state", e);
        }
    }

    private void save(Properties p) {
        File temp = null;
        try {
            File parent = file.getParentFile();
            if (!parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory())
                throw new IOException("Cannot create state directory");
            ByteArrayOutputStream payloadOut = new ByteArrayOutputStream();
            p.store(payloadOut, "smartcall update state");
            byte[] payload = payloadOut.toByteArray();
            if (payload.length + MAGIC.length + 36 > MAX_BYTES) throw new IOException("State too large");
            temp = File.createTempFile(".smartcall-state-", ".tmp", parent);
            try (FileOutputStream raw = new FileOutputStream(temp);
                 DataOutputStream out = new DataOutputStream(raw)) {
                out.write(MAGIC);
                out.writeInt(payload.length);
                out.write(digest(payload));
                out.write(payload);
                out.flush();
                raw.getFD().sync();
            }
            if (!temp.renameTo(file)) throw new IOException("Cannot replace update state");
            observedFile = true;
        } catch (IOException e) {
            throw new IllegalStateException("Cannot write update state", e);
        } finally {
            if (temp != null && temp.exists()) temp.delete();
        }
    }

    @Override public synchronized void applyBatch(Map<String, Object> changes) {
        Properties p = load();
        for (Map.Entry<String, Object> e : changes.entrySet()) {
            Object value = e.getValue();
            if (value == null) p.remove(e.getKey());
            else if (value instanceof String || value instanceof Long || value instanceof Boolean)
                p.setProperty(e.getKey(), value.toString());
            else throw new IllegalArgumentException("Unsupported batch value");
        }
        save(p);
    }
    @Override public synchronized String getString(String key, String defValue) {
        return load().getProperty(key, defValue);
    }
    @Override public void putString(String key, String value) { applyBatch(Collections.<String, Object>singletonMap(key, value)); }
    @Override public synchronized long getLong(String key, long defValue) {
        String value = load().getProperty(key);
        if (value == null) return defValue;
        try { return Long.parseLong(value); }
        catch (NumberFormatException e) { throw new IllegalStateException("Invalid long state: " + key, e); }
    }
    @Override public void putLong(String key, long value) { applyBatch(Collections.<String, Object>singletonMap(key, value)); }
    @Override public synchronized boolean getBoolean(String key, boolean defValue) {
        String value = load().getProperty(key);
        if (value == null) return defValue;
        if ("true".equals(value)) return true;
        if ("false".equals(value)) return false;
        throw new IllegalStateException("Invalid boolean state: " + key);
    }
    @Override public void putBoolean(String key, boolean value) { applyBatch(Collections.<String, Object>singletonMap(key, value)); }
    @Override public void remove(String key) { applyBatch(Collections.<String, Object>singletonMap(key, null)); }
}
