package com.smartcall.ru.update;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

/**
 * Абстракция HTTP-запроса: продакшен — HttpURLConnection, тесты — fake-стабы
 * с предсказуемыми ответами (включая обрывы и редиректы). Никаких токенов.
 */
public interface HttpTransport {

    /**
     * Выполнить GET по {@code url}. Редиректы НЕ следуют автоматически —
     * их разрешает {@link HttpSupport} с проверкой белого списка хостов.
     *
     * @throws IOException сетевые ошибки (классифицируются в HttpSupport)
     */
    Reply execute(String url, int connectTimeoutMs, int readTimeoutMs) throws IOException;

    /** Ответ сервера. Тело закрывается методом {@link #close()}. */
    class Reply implements Closeable {
        public final int status;
        public final String location;
        public final long contentLength;
        public final InputStream body;

        public Reply(int status, String location, long contentLength, InputStream body) {
            this.status = status;
            this.location = location;
            this.contentLength = contentLength;
            this.body = body;
        }

        @Override
        public void close() {
            Sha256.closeQuietly(body);
        }
    }
}
