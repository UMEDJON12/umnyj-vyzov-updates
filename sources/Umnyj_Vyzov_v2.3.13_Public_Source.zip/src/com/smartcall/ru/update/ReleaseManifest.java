package com.smartcall.ru.update;

import java.util.Map;

/**
 * Стабильный JSON канала (updates/stable.json), строгая схема по образцу
 * calculator-umedjon-updates. Обязательные поля и их значения проверяются
 * «fail-closed»: любое сомнение — отказ, ничего не устанавливается.
 */
public final class ReleaseManifest {

    public static final int SCHEMA_VERSION = 1;
    public static final String REQUIRED_VARIANT = "standard";

    public final int schemaVersion;
    public final String packageName;
    public final String variant;
    public final boolean testOnly;
    public final long versionCode;
    public final String versionName;
    public final long minSdk;
    public final String signingCertificateSha256; // hex64, нижний регистр
    public final long sizeBytes;
    public final String sha256;                   // hex64, нижний регистр
    public final String apkFileName;
    public final String apkUrl;
    public final String releaseNotes;
    public final boolean ready;
    public final String tagName;
    public final String publishedAt;

    private ReleaseManifest(int schemaVersion, String packageName, String variant,
                            boolean testOnly, long versionCode, String versionName, long minSdk,
                            String signingCertificateSha256, long sizeBytes, String sha256,
                            String apkFileName, String apkUrl, String releaseNotes,
                            boolean ready, String tagName, String publishedAt) {
        this.schemaVersion = schemaVersion;
        this.packageName = packageName;
        this.variant = variant;
        this.testOnly = testOnly;
        this.versionCode = versionCode;
        this.versionName = versionName;
        this.minSdk = minSdk;
        this.signingCertificateSha256 = signingCertificateSha256;
        this.sizeBytes = sizeBytes;
        this.sha256 = sha256;
        this.apkFileName = apkFileName;
        this.apkUrl = apkUrl;
        this.releaseNotes = releaseNotes;
        this.ready = ready;
        this.tagName = tagName;
        this.publishedAt = publishedAt;
    }

    /** Разбор + полная валидация против конфигурации. Бросает UpdateException. */
    public static ReleaseManifest parseAndValidate(byte[] jsonBytes, UpdateConfig cfg,
                                                   int deviceSdk) throws UpdateException {
        Map<String, Object> m = Json.parseObject(jsonBytes);

        long schemaVersion = Json.reqLong(m, "schemaVersion");
        if (schemaVersion != SCHEMA_VERSION) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    "неподдерживаемая schemaVersion=" + schemaVersion);
        }

        String packageName = Json.reqString(m, "packageName");
        if (!cfg.packageName().equals(packageName)) {
            throw new UpdateException(StatusCode.WRONG_PACKAGE, packageName);
        }

        String variant = Json.reqString(m, "variant");
        if (!REQUIRED_VARIANT.equals(variant)) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "variant=" + variant);
        }

        boolean testOnly = Json.reqBoolean(m, "testOnly");
        if (testOnly) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "testOnly=true");
        }

        boolean ready = Json.reqBoolean(m, "ready");
        if (!ready) {
            throw new UpdateException(StatusCode.NOT_READY, "ready=false");
        }

        long versionCode = Json.reqLong(m, "versionCode");
        if (versionCode < 1 || versionCode > Integer.MAX_VALUE) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    "versionCode вне диапазона: " + versionCode);
        }

        String versionName = Json.reqString(m, "versionName");
        checkVersionName(versionName);

        long minSdk = Json.reqLong(m, "minSdk");
        if (minSdk < 1 || minSdk > 100) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "minSdk=" + minSdk);
        }
        if (deviceSdk > 0 && minSdk > deviceSdk) {
            throw new UpdateException(StatusCode.OLD_ANDROID,
                    "обновление требует Android " + minSdk + ", на устройстве " + deviceSdk);
        }

        String cert = Json.reqString(m, "signingCertificateSha256");
        String certNorm = Sha256.normalizeHex64(cert);
        if (certNorm == null) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID,
                    "signingCertificateSha256 не является SHA-256");
        }
        if (!Sha256.hexEquals(certNorm, cfg.expectedCertSha256())) {
            throw new UpdateException(StatusCode.CERT_MISMATCH,
                    "канал объявил чужой сертификат подписи");
        }

        long sizeBytes = Json.reqLong(m, "sizeBytes");
        if (sizeBytes <= 0) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "sizeBytes=" + sizeBytes);
        }
        if (sizeBytes > cfg.maxApkBytes()) {
            throw new UpdateException(StatusCode.TOO_LARGE,
                    sizeBytes + " > лимита " + cfg.maxApkBytes());
        }

        String sha256 = Json.reqString(m, "sha256");
        String shaNorm = Sha256.normalizeHex64(sha256);
        if (shaNorm == null) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "sha256 не является SHA-256");
        }

        String apkFileName = Json.reqString(m, "apkFileName");
        checkFileName(apkFileName);

        String tagName = Json.reqString(m, "tagName");
        checkTagName(tagName);

        String apkUrl = Json.reqString(m, "apkUrl");
        String canonical = cfg.canonicalApkUrl(tagName, apkFileName);
        if (!canonical.equals(apkUrl)) {
            throw new UpdateException(StatusCode.BAD_URL,
                    "apkUrl не соответствует каноническому URL релиза");
        }
        HttpSupport.validateHttpsUrl(apkUrl, cfg);
        String host = HttpSupport.hostOf(apkUrl);
        if (!cfg.downloadHosts().allows(host)) {
            throw new UpdateException(StatusCode.BAD_URL, "хост " + host + " не в белом списке");
        }

        String releaseNotes = Json.optString(m, "releaseNotes");
        if (releaseNotes == null) {
            releaseNotes = "";
        }
        if (releaseNotes.length() > 4000) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "releaseNotes длиннее 4000");
        }
        for (int i = 0; i < releaseNotes.length(); i++) {
            char c = releaseNotes.charAt(i);
            if (c < 0x20 && c != '\n' && c != '\t' && c != '\r') {
                throw new UpdateException(StatusCode.CHANNEL_INVALID,
                        "управляющие символы в releaseNotes");
            }
        }

        String publishedAt = Json.optString(m, "publishedAt");
        if (publishedAt != null && publishedAt.length() > 64) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "publishedAt длиннее 64");
        }

        return new ReleaseManifest((int) schemaVersion, packageName, variant, testOnly,
                versionCode, versionName, minSdk, certNorm, sizeBytes, shaNorm,
                apkFileName, apkUrl, releaseNotes, ready, tagName, publishedAt);
    }

    static void checkVersionName(String v) throws UpdateException {
        if (v == null || v.isEmpty() || v.length() > 64) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "недопустимый versionName");
        }
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z') || c == '.' || c == '_' || c == '-' || c == '+';
            if (!ok) {
                throw new UpdateException(StatusCode.CHANNEL_INVALID,
                        "versionName содержит недопустимый символ '" + c + "'");
            }
        }
    }

    static void checkFileName(String f) throws UpdateException {
        if (f == null || f.length() > 128 || !f.endsWith(".apk")) {
            throw new UpdateException(StatusCode.BAD_URL, "недопустимое имя APK: " + f);
        }
        for (int i = 0; i < f.length(); i++) {
            char c = f.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z') || c == '.' || c == '_' || c == '-';
            if (!ok) {
                throw new UpdateException(StatusCode.BAD_URL,
                        "имя APK содержит недопустимый символ '" + c + "'");
            }
        }
        if (f.contains("..")) {
            throw new UpdateException(StatusCode.BAD_URL, "имя APK содержит «..»");
        }
    }

    static void checkTagName(String t) throws UpdateException {
        if (t == null || t.isEmpty() || t.length() > 64) {
            throw new UpdateException(StatusCode.CHANNEL_INVALID, "недопустимый tagName");
        }
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z') || c == '.' || c == '_' || c == '-';
            if (!ok) {
                throw new UpdateException(StatusCode.CHANNEL_INVALID,
                        "tagName содержит недопустимый символ '" + c + "'");
            }
        }
    }
}
