package com.smartcall.ru.update;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Конфигурация канала обновлений. Секретов и токенов нет и быть не может:
 * канал — публичный HTTPS без авторизации.
 */
public final class UpdateConfig {

    public static final String REPO_OWNER = "UMEDJON12";
    public static final String REPO_NAME = "umnyj-vyzov-updates";

    /** Стабильный JSON канала (по образцу calculator-umedjon-updates). */
    public static final String DEFAULT_STABLE_JSON_URL =
            "https://raw.githubusercontent.com/" + REPO_OWNER + "/" + REPO_NAME + "/main/updates/stable.json";

    /** Анонимная проверка существования именно закреплённого публичного репозитория. */
    public static final String REPOSITORY_API_URL =
            "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME;

    /** Публичный GitHub API релизов (без токена, лимит 60 запросов/час на IP). */
    public static final String DEFAULT_RELEASE_API_URL = REPOSITORY_API_URL + "/releases/latest";

    public static final String PACKAGE_NAME = "com.smartcall.ru";

    /** Ожидаемый SHA-256 сертификата подписи APK (отпечаток DER-сертификата). */
    public static final String EXPECTED_SIGNING_CERT_SHA256 =
            "baedb1a77af5b2a9a0f34de72e7f88526e0e82c508eb07fee8b04ce2cf023c01";

    /** MIME тип APK. */
    public static final String APK_MIME = "application/vnd.android.package-archive";

    /** Имя файла-хранилища настроек (приватный SharedPreferences). */
    public static final String PREFS_NAME = "smartcall_updates";

    public static final String KEY_AUTO_CHECK = "updates_auto_check";
    public static final String KEY_LATER_VERSION = "updates_later_version";
    public static final String KEY_KNOWN_VERSION = "updates_known_version_code";
    public static final String KEY_DOWNLOADED_VERSION = "updates_downloaded_version_code";
    public static final String KEY_DOWNLOADED_VERSION_NAME = "updates_downloaded_version_name";
    public static final String KEY_DOWNLOADED_SHA256 = "updates_downloaded_sha256";
    public static final String KEY_DOWNLOADED_SIZE = "updates_downloaded_size";
    public static final String KEY_DOWNLOADED_FILE = "updates_downloaded_file";

    /** Authority провайдера безопасной отдачи APK системному установщику. */
    public static final String INSTALL_AUTHORITY = PACKAGE_NAME + ".update.install";

    /** Лимит размера APK (защита от исчерпания места и от «вечных» загрузок). */
    public static final long DEFAULT_MAX_APK_BYTES = 100L * 1024 * 1024; // 100 МиБ

    /** Лимит размера метаданных (stable.json, release JSON). */
    public static final int DEFAULT_MAX_METADATA_BYTES = 256 * 1024;

    public static final int DEFAULT_CONNECT_TIMEOUT_MS = 10_000;
    public static final int DEFAULT_READ_TIMEOUT_MS = 30_000;
    public static final int MAX_REDIRECTS = 5;

    public static final String USER_AGENT = "SmartCall-Update/1.0";

    private final String stableJsonUrl;
    private final String releaseApiUrl;
    private final String packageName;
    private final String expectedCertSha256;
    private final long maxApkBytes;
    private final int maxMetadataBytes;
    private final int connectTimeoutMs;
    private final int readTimeoutMs;
    private final String userAgent;
    private final HostPolicy metadataHosts;
    private final HostPolicy downloadHosts;

    private UpdateConfig(Builder b) {
        this.stableJsonUrl = b.stableJsonUrl;
        this.releaseApiUrl = b.releaseApiUrl;
        this.packageName = b.packageName;
        this.expectedCertSha256 = b.expectedCertSha256;
        this.maxApkBytes = b.maxApkBytes;
        this.maxMetadataBytes = b.maxMetadataBytes;
        this.connectTimeoutMs = b.connectTimeoutMs;
        this.readTimeoutMs = b.readTimeoutMs;
        this.userAgent = b.userAgent;
        this.metadataHosts = HostPolicy.of(b.stableJsonUrl, b.releaseApiUrl)
                .mergedWith(HostPolicy.githubMetadata());
        this.downloadHosts = HostPolicy.githubDownloads();
    }

    public static UpdateConfig defaults() {
        return new Builder().build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public String stableJsonUrl() {
        return stableJsonUrl;
    }

    public String releaseApiUrl() {
        return releaseApiUrl;
    }

    public String packageName() {
        return packageName;
    }

    public String expectedCertSha256() {
        return expectedCertSha256;
    }

    public long maxApkBytes() {
        return maxApkBytes;
    }

    public int maxMetadataBytes() {
        return maxMetadataBytes;
    }

    public int connectTimeoutMs() {
        return connectTimeoutMs;
    }

    public int readTimeoutMs() {
        return readTimeoutMs;
    }

    public String userAgent() {
        return userAgent;
    }

    public HostPolicy metadataHosts() {
        return metadataHosts;
    }

    public HostPolicy downloadHosts() {
        return downloadHosts;
    }

    /**
     * Адрес релиза APK обязан быть ровно этим каноническим URL
     * (учитывает владельца/репозиторий/тег/имя файла — строгая склейка
     * stable.json с конкретным публичным релизом).
     */
    public String canonicalApkUrl(String tagName, String apkFileName) {
        return "https://github.com/" + REPO_OWNER + "/" + REPO_NAME
                + "/releases/download/" + tagName + "/" + apkFileName;
    }

    /** Белый список хостов для конкретного вида запроса (только HTTPS). */
    public static final class HostPolicy {
        private final List<String> exact;
        private final List<String> suffixes;

        private HostPolicy(List<String> exact, List<String> suffixes) {
            this.exact = Collections.unmodifiableList(exact);
            this.suffixes = Collections.unmodifiableList(suffixes);
        }

        static HostPolicy of(String... urls) {
            List<String> exact = new ArrayList<String>();
            for (String u : urls) {
                String host = hostOf(u);
                if (host != null && !exact.contains(host)) {
                    exact.add(host);
                }
            }
            return new HostPolicy(exact, Collections.<String>emptyList());
        }

        /** Метаданные: raw.githubusercontent.com, api.github.com, github.com. */
        public static HostPolicy githubMetadata() {
            List<String> exact = new ArrayList<String>();
            exact.add("raw.githubusercontent.com");
            exact.add("api.github.com");
            exact.add("github.com");
            return new HostPolicy(exact, Collections.<String>emptyList());
        }

        /** Загрузки: github.com, *.github.com, *.githubusercontent.com. */
        public static HostPolicy githubDownloads() {
            List<String> exact = new ArrayList<String>();
            exact.add("github.com");
            List<String> suffixes = new ArrayList<String>();
            suffixes.add(".github.com");
            suffixes.add(".githubusercontent.com");
            return new HostPolicy(exact, suffixes);
        }

        HostPolicy mergedWith(HostPolicy other) {
            List<String> ex = new ArrayList<String>(exact);
            for (String e : other.exact) {
                if (!ex.contains(e)) {
                    ex.add(e);
                }
            }
            List<String> su = new ArrayList<String>(suffixes);
            for (String s : other.suffixes) {
                if (!su.contains(s)) {
                    su.add(s);
                }
            }
            return new HostPolicy(ex, su);
        }

        public boolean allows(String host) {
            if (host == null || host.isEmpty()) {
                return false;
            }
            String h = host.toLowerCase(Locale.ROOT);
            for (String e : exact) {
                if (h.equals(e)) {
                    return true;
                }
            }
            for (String s : suffixes) {
                if (h.endsWith(s) && h.length() > s.length()) {
                    return true;
                }
            }
            return false;
        }

        static String hostOf(String url) {
            try {
                java.net.URI uri = new java.net.URI(url);
                return uri.getHost();
            } catch (java.net.URISyntaxException e) {
                return null;
            }
        }
    }

    public static final class Builder {
        private String stableJsonUrl = DEFAULT_STABLE_JSON_URL;
        private String releaseApiUrl = DEFAULT_RELEASE_API_URL;
        private String packageName = PACKAGE_NAME;
        private String expectedCertSha256 = EXPECTED_SIGNING_CERT_SHA256;
        private long maxApkBytes = DEFAULT_MAX_APK_BYTES;
        private int maxMetadataBytes = DEFAULT_MAX_METADATA_BYTES;
        private int connectTimeoutMs = DEFAULT_CONNECT_TIMEOUT_MS;
        private int readTimeoutMs = DEFAULT_READ_TIMEOUT_MS;
        private String userAgent = USER_AGENT;

        public Builder stableJsonUrl(String v) {
            this.stableJsonUrl = v;
            return this;
        }

        public Builder releaseApiUrl(String v) {
            this.releaseApiUrl = v;
            return this;
        }

        public Builder packageName(String v) {
            this.packageName = v;
            return this;
        }

        public Builder expectedCertSha256(String v) {
            this.expectedCertSha256 = v;
            return this;
        }

        public Builder maxApkBytes(long v) {
            this.maxApkBytes = v;
            return this;
        }

        public Builder maxMetadataBytes(int v) {
            this.maxMetadataBytes = v;
            return this;
        }

        public Builder connectTimeoutMs(int v) {
            this.connectTimeoutMs = v;
            return this;
        }

        public Builder readTimeoutMs(int v) {
            this.readTimeoutMs = v;
            return this;
        }

        public Builder userAgent(String v) {
            this.userAgent = v;
            return this;
        }

        public UpdateConfig build() {
            if (stableJsonUrl == null || !stableJsonUrl.startsWith("https://")) {
                throw new IllegalArgumentException("stableJsonUrl должен быть HTTPS");
            }
            if (releaseApiUrl == null || !releaseApiUrl.startsWith("https://")) {
                throw new IllegalArgumentException("releaseApiUrl должен быть HTTPS");
            }
            if (maxApkBytes <= 0 || maxMetadataBytes <= 0) {
                throw new IllegalArgumentException("лимиты должны быть положительными");
            }
            return new UpdateConfig(this);
        }
    }
}
