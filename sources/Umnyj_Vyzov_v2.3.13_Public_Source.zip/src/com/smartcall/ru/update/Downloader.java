package com.smartcall.ru.update;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Скачивание APK в приватный каталог: реальный прогресс (байты/всего/
 * осталось/проценты), отмена, лимит размера, только HTTPS внутри белого
 * списка, запись во временный .part и атомарное переименование.
 */
public final class Downloader {

    /** Колбэк прогресса — вызывается на каждом прочитанном чанке. */
    public interface ProgressListener {
        void onProgress(long downloaded, long totalBytes, int percent, long remainingBytes);
    }

    /** Сигнал отмены (например, пользователь нажал «Отменить»). */
    public interface CancelSignal {
        boolean isCancelled();
    }

    /** Никогда не отменять (удобно для тестов и синхронных вызовов). */
    public static final CancelSignal NEVER_CANCELLED = new CancelSignal() {
        @Override
        public boolean isCancelled() {
            return false;
        }
    };

    private static final int BUFFER = 64 * 1024;

    private final UpdateConfig cfg;
    private final HttpTransport transport;

    public Downloader(UpdateConfig cfg, HttpTransport transport) {
        this.cfg = cfg;
        this.transport = transport;
    }

    /**
     * Скачать {@code manifest.apkUrl} в {@code dir}/{@code manifest.apkFileName}.
     *
     * @return полностью скачанный и сверенный по размеру файл
     * @throws UpdateException CANCELLED / INTERRUPTED / SIZE_MISMATCH /
     *                         TOO_LARGE / HTTP / STORAGE и др.
     */
    public File download(ReleaseManifest manifest, File dir,
                         ProgressListener listener, CancelSignal cancel)
            throws UpdateException {
        if (dir == null || (!dir.isDirectory() && !dir.mkdirs())) {
            throw new UpdateException(StatusCode.STORAGE,
                    "нет доступа к каталогу обновлений");
        }
        ReleaseManifest.checkFileName(manifest.apkFileName);
        File target = new File(dir, manifest.apkFileName);
        File part = new File(dir, manifest.apkFileName + ".part");
        if (part.exists() && !part.delete()) {
            throw new UpdateException(StatusCode.STORAGE, "не удалось удалить временный файл");
        }

        final long total = manifest.sizeBytes;
        if (total > cfg.maxApkBytes()) {
            throw new UpdateException(StatusCode.TOO_LARGE,
                    total + " > лимита " + cfg.maxApkBytes());
        }
        if (listener != null) {
            listener.onProgress(0, total, 0, total);
        }

        HttpTransport.Reply reply = HttpSupport.openFollowing(
                transport, manifest.apkUrl, cfg.downloadHosts(), cfg);
        boolean renamed = false;
        try {
            long declared = reply.contentLength;
            if (declared >= 0 && declared != total) {
                throw new UpdateException(StatusCode.SIZE_MISMATCH,
                        "сервер сообщил " + declared + ", канал обещает " + total);
            }

            OutputStream fos = null;
            long downloaded = 0;
            try {
                fos = new FileOutputStream(part);
                byte[] buf = new byte[BUFFER];
                int n;
                while ((n = reply.body.read(buf)) != -1) {
                    if (cancel != null && cancel.isCancelled()) {
                        throw new UpdateException(StatusCode.CANCELLED);
                    }
                    downloaded += n;
                    if (downloaded > total) {
                        throw new UpdateException(StatusCode.SIZE_MISMATCH,
                                "получено больше " + total + " байт");
                    }
                    if (downloaded > cfg.maxApkBytes()) {
                        throw new UpdateException(StatusCode.TOO_LARGE,
                                "превышен лимит " + cfg.maxApkBytes());
                    }
                    fos.write(buf, 0, n);
                    if (listener != null) {
                        listener.onProgress(downloaded, total,
                                Sizes.percent(downloaded, total),
                                Sizes.remaining(downloaded, total));
                    }
                }
                if (cancel != null && cancel.isCancelled()) {
                    throw new UpdateException(StatusCode.CANCELLED);
                }
                if (downloaded < total) {
                    throw new UpdateException(StatusCode.INTERRUPTED,
                            "получено " + downloaded + " из " + total + " байт");
                }
                fos.flush();
                try {
                    ((FileOutputStream) fos).getFD().sync();
                } catch (IOException syncErr) {
                    // sync — желателен, но его отказ не критичен: файл ещё
                    // будет проверен по размеру и SHA-256 до установки.
                }
                fos.close();
                fos = null;
            } catch (IOException ioe) {
                throw new UpdateException(StatusCode.INTERRUPTED, ioe.getMessage(), ioe);
            } finally {
                Sha256.closeQuietly(fos);
            }

            if (part.length() != total) {
                throw new UpdateException(StatusCode.SIZE_MISMATCH,
                        "записано " + part.length() + " из " + total + " байт");
            }
            if (target.exists() && !target.delete()) {
                throw new UpdateException(StatusCode.STORAGE, "не удалось заменить старый файл");
            }
            if (!part.renameTo(target)) {
                throw new UpdateException(StatusCode.STORAGE, "не удалось переместить файл");
            }
            renamed = true;
            if (listener != null) {
                listener.onProgress(total, total, 100, 0);
            }
            return target;
        } finally {
            reply.close();
            if (!renamed && part.exists()) {
                part.delete(); // остатки не должны остаться в хранилище
            }
        }
    }
}
