package com.smartcall.ru.update;

import java.io.File;
import java.io.IOException;

/**
 * Оркестратор: проверка канала → скачивание → повторная проверка
 * release/asset → верификация APK → метаданные для установки.
 * Вся логика чистая (без android.*), тестируется на host-JVM.
 */
public final class UpdateEngine {

    /** Необязательное логирование (на Android — android.util.Log). */
    public interface Logger {
        void log(String message);
    }

    public static final Logger NO_LOG = new Logger() {
        @Override
        public void log(String message) {
            // без логирования
        }
    };

    private final UpdateConfig cfg;
    private final HttpTransport transport;
    private final UpdateState state;
    private final File apkDir;
    private final int deviceSdk;
    private final Logger logger;

    public UpdateEngine(UpdateConfig cfg, HttpTransport transport, UpdateState state,
                        File apkDir, int deviceSdk, Logger logger) {
        this.cfg = cfg;
        this.transport = transport;
        this.state = state;
        this.apkDir = apkDir;
        this.deviceSdk = deviceSdk;
        this.logger = logger == null ? NO_LOG : logger;
    }

    public UpdateState state() {
        return state;
    }

    public File apkDir() {
        return apkDir;
    }

    // ---- проверка -------------------------------------------------------

    /**
     * Проверка канала: stable.json + release, защита от отката по
     * персистентному knownVersionCode.
     *
     * @param currentVersionCode versionCode установленного приложения
     */
    public synchronized ReleaseManifest check(long currentVersionCode) throws UpdateException {
        state.noteKnownVersion(currentVersionCode);
        long known = state.knownVersionCode();
        ReleaseManifest m = new ChannelChecker(cfg, transport, deviceSdk)
                .check(currentVersionCode, known);
        logger.log("Проверка: доступна версия " + m.versionName
                + " (versionCode " + m.versionCode + ")");
        return m;
    }

    /**
     * Автозаметка установленной версии (вызывается при открытии приложения):
     * персистентная база защиты от отката.
     */
    public void noteInstalled(long currentVersionCode) {
        state.noteKnownVersion(currentVersionCode);
        // Keep download metadata: the user may still open the saved file in Download.
        // verifyDownloaded refuses equal or older versions without deleting anything.
    }

    /**
     * Уведомлять ли об обновлении: «Позже» запоминает версию
     * ({@code updates_later_version}) и до следующей версии не повторяем.
     *
     * @param manual ручная проверка — всегда показываем
     */
    public boolean shouldOffer(ReleaseManifest candidate, boolean manual) {
        if (manual) {
            return true;
        }
        return !state.isDeferred(candidate.versionCode);
    }

    // ---- скачивание -----------------------------------------------------

    /**
     * Скачать кандидата, затем ПОВТОРНО проверить stable.json + release
     * (draft/prerelease/ассет не изменились) и только после этого верифицировать
     * файл (SHA-256/размер/пакет/версии/подпись). Успех → метаданные сохраняются.
     */
    public synchronized ApkVerifier.Result download(long currentVersionCode, ReleaseManifest candidate,
                                        Downloader.ProgressListener listener,
                                        Downloader.CancelSignal cancel)
            throws UpdateException {
        logger.log("Скачивание " + candidate.apkFileName + " (" + candidate.sizeBytes + " байт)");
        if (!isDirectoryUsable(apkDir)) throw new UpdateException(StatusCode.STORAGE, "нет приватного каталога обновлений");
        File staging = new File(apkDir, "work-" + java.util.UUID.randomUUID().toString());
        if (!staging.mkdir()) throw new UpdateException(StatusCode.STORAGE, "не удалось создать временный каталог");
        File file = null;
        try {
            // A fresh app-private directory prevents a failed download replacing an older verified APK.
            file = new Downloader(cfg, transport).download(candidate, staging, listener, cancel);
            ReleaseManifest again;
            try {
                again = check(currentVersionCode);
            } catch (UpdateException e) {
                if (e.status() == StatusCode.NOT_NEWER || e.status() == StatusCode.ROLLBACK
                        || e.status() == StatusCode.NO_PUBLISHED_UPDATES) {
                    throw new UpdateException(StatusCode.RELEASE_CHANGED, e.detail(), e);
                }
                throw e;
            }
            if (cancel != null && cancel.isCancelled()) throw new UpdateException(StatusCode.CANCELLED);
            if (!ReleaseInfo.sameAs(candidate, again)
                    || !ApprovedRelease.matches(again, ApprovedRelease.fingerprint(candidate))) {
                throw new UpdateException(StatusCode.RELEASE_CHANGED,
                        "описание обновления изменилось во время скачивания");
            }
            ApkVerifier.Expectations expected = ApkVerifier.Expectations.of(again);
            ApkVerifier.Result result = ApkVerifier.verify(file, expected, cfg);
            if (cancel != null && cancel.isCancelled()) throw new UpdateException(StatusCode.CANCELLED);
            String name = "verified-" + result.sha256 + ".apk";
            File target = new File(apkDir, name);
            if (target.exists()) {
                // Never overwrite even an existing private file; reuse only after full verification.
                ApkVerifier.verify(target, expected, cfg);
            } else if (!file.renameTo(target)) {
                throw new UpdateException(StatusCode.STORAGE, "не удалось закрепить проверенный APK");
            }
            state.saveDownloaded(result.versionCode, result.versionName, result.sha256, result.sizeBytes, name);
            state.noteKnownVersion(result.versionCode);
            logger.log("Файл проверен: " + result.sha256);
            return result;
        } finally {
            // staging was allocated exclusively by this operation under app-private storage.
            if (file != null && file.isFile()) deleteQuietly(file);
            File[] children = staging.listFiles();
            if (children != null) for (File child : children) {
                if (child.isFile() && (child.getName().endsWith(".part") || child.getName().endsWith(".apk"))) deleteQuietly(child);
            }
            staging.delete();
        }
    }

    // ---- установка ранее скачанного -------------------------------------

    /**
     * Повторная верификация ранее скачанного APK перед запуском установщика.
     * Файл сверяется с сохранёнными метаданными и с закреплённым сертификатом;
     * при любом расхождении — отказ; метаданные и файл не уничтожаются.
     */
    public synchronized ApkVerifier.Result verifyDownloaded(long currentVersionCode) throws UpdateException {
        UpdateState.Downloaded d = state.downloaded();
        if (d == null) {
            throw new UpdateException(StatusCode.NO_FILE, "нет сохранённых метаданных");
        }
        StatusCode versionStatus = InstallVersionPolicy.status(currentVersionCode, state.knownVersionCode(), d.versionCode);
        if (versionStatus != StatusCode.OK) {
            throw new UpdateException(versionStatus, "скачанная версия " + d.versionCode
                    + ", установлена " + currentVersionCode + ", ранее известная " + state.knownVersionCode());
        }
        try {
            ReleaseManifest.checkFileName(d.fileName);
            File file = new File(apkDir, d.fileName);
            ApkVerifier.Expectations exp = new ApkVerifier.Expectations(
                    d.sizeBytes, d.sha256, d.versionCode, d.versionName);
            ApkVerifier.Result r = ApkVerifier.verify(file, exp, cfg);
            logger.log("Повторная проверка файла пройдена: " + d.fileName);
            return r;
        } catch (UpdateException e) {
            // Keep metadata even for transient I/O failures; never trust it without re-verification.
            throw e;
        } catch (RuntimeException e) {
            throw new UpdateException(StatusCode.APK_INVALID, e.getMessage(), e);
        }
    }

    /** Путь к сохранённому APK (после успешной verifyDownloaded). */
    public synchronized File downloadedFile(ApkVerifier.Result verified) {
        UpdateState.Downloaded d = state.downloaded();
        if (d == null || verified == null || !cfg.packageName().equals(verified.packageName)
                || d.versionCode != verified.versionCode || !d.versionName.equals(verified.versionName)
                || d.sizeBytes != verified.sizeBytes || !Sha256.hexEquals(d.sha256, verified.sha256)) return null;
        try { ReleaseManifest.checkFileName(d.fileName); }
        catch (UpdateException invalid) { return null; }
        return new File(apkDir, d.fileName);
    }

    // ---- служебное ------------------------------------------------------

    /** Clean only owned, app-private temporary work left by an interrupted process. */
    public synchronized void cleanupStaleWork() {
        try {
            File root = apkDir.getCanonicalFile();
            File[] entries = root.listFiles();
            if (entries == null) return;
            for (File entry : entries) {
                File actual = entry.getCanonicalFile();
                if (!entry.getAbsoluteFile().equals(actual) || !root.equals(actual.getParentFile())) continue;
                String name = entry.getName();
                if (entry.isFile() && name.matches("work-install-[0-9]+\\.tmp")) {
                    entry.delete();
                } else if (entry.isDirectory() && name.matches("work-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")) {
                    File[] children = entry.listFiles();
                    if (children != null) for (File child : children) {
                        File canonical = child.getCanonicalFile();
                        if (child.getAbsoluteFile().equals(canonical) && actual.equals(canonical.getParentFile()) && child.isFile()
                                && (child.getName().endsWith(".part") || child.getName().endsWith(".apk"))) child.delete();
                    }
                    entry.delete(); // succeeds only when empty
                }
            }
        } catch (IOException e) {
            logger.log("Временные файлы обновления не удалось проверить: " + e.getClass().getSimpleName());
        }
    }

    /** Отложить версию («Позже»): ключ updates_later_version. */
    public void postpone(long versionCode) {
        state.postpone(versionCode);
        logger.log("Версия " + versionCode + " отложена пользователем");
    }

    /** Вызывается после успешного обновления (установленная версия). */
    public void markInstalled(long versionCode) {
        state.noteKnownVersion(versionCode);
        // Saved files and their metadata remain available after installation.
    }

    private void cleanupOtherFiles(String keepName) {
        File[] files = apkDir.listFiles();
        if (files == null) {
            return;
        }
        for (File f : files) {
            String nm = f.getName();
            if (nm.equals(keepName)) {
                continue;
            }
            if (nm.endsWith(".apk") || nm.endsWith(".part")) {
                deleteQuietly(f);
            }
        }
    }

    static void deleteQuietly(File f) {
        if (f != null && f.exists()) {
            // noinspection ResultOfMethodCallIgnored
            f.delete();
        }
    }

    static boolean isDirectoryUsable(File dir) {
        return dir != null && (dir.isDirectory() || dir.mkdirs());
    }

    static IOException io(String msg) {
        return new IOException(msg);
    }
}
