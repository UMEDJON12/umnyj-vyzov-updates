package com.smartcall.ru;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class MainActivity extends Activity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private Button btnAudioMode;
    private Button btnCustomVol;
    private Button btnEngOther;
    private Button btnEngSim;
    private Button btnEngSms;
    private Button btnEngTg;
    private Button btnEngWa;
    private Button btnRateOther;
    private Button btnRateSim;
    private Button btnRateSms;
    private Button btnRateTg;
    private Button btnRateWa;
    private Button btnTtsRepeat;
    private Button btnTtsVoice;
    private CheckBox cbAnsVolDown;
    private CheckBox cbAnsVolUp;
    private CheckBox cbEndVolDown;
    private CheckBox cbEndVolUp;
    private boolean checkPermissionsOnResume;
    private boolean autoCheckOnNextResume = true;
    private TextView diagTextView;
    private String[] dialogEnginePkgs;
    private TextView statusTextView;
    private TextView overviewTextView;
    private TextView btnTheme;
    private TextView btnUpdatesAuto;
    private View[] sections = new View[4];
    private TextView[] tabs = new TextView[4];
    private int currentTab;
    private String dialogChannel;
    private final java.util.ArrayList<Button> permissionActions = new java.util.ArrayList<>();
    static final String[] CALL_PROFILES = {"sim", "wa", "tg", "viber", "imo", "other"};
    static final String[] CALL_LABELS = {"SIM (Обычные звонки)", "WhatsApp", "Telegram", "Viber", "Imo", "Другие приложения"};
    static final String[] MSG_PROFILES = {"sms", "wa", "tg", "viber", "imo", "other"};
    static final String[] MSG_LABELS = {"SMS", "WhatsApp", "Telegram", "Viber", "Imo", "Другие"};
    private final Button[] btnCallEngine = new Button[6];
    private final Button[] btnCallVoice = new Button[6];
    private final Button[] btnCallRate = new Button[6];
    private final Button[] btnCallRepeat = new Button[6];
    private final Button[] btnCallDelay = new Button[6];
    private final Button[] btnCallTest = new Button[6];
    private final Button[] btnMsgEngine = new Button[6];
    private final Button[] btnMsgVoice = new Button[6];
    private final Button[] btnMsgRate = new Button[6];
    private final Button[] btnMsgLock = new Button[6];
    private final Button[] btnMsgTest = new Button[6];

    public Button addActionButton(LinearLayout linearLayout, String str, int i, int i2) {
        Button button = new Button(this);
        button.setText(str);
        button.setTextColor(UiTheme.onSurface(this));
        button.setTextSize(16f);
        button.setAllCaps(false);
        button.setMinHeight(dp(48));
        button.setPadding(dp(16), dp(12), dp(16), dp(12));
        button.setBackground(UiTheme.rounded(this, i2, 18));
        button.setId(i);
        button.setOnClickListener(this);
        if (i >= 101 && i <= 104) permissionActions.add(button);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 0, 0, dp(8));
        linearLayout.addView(button, layoutParams);
        return button;
    }

    public void addCheckBox(LinearLayout linearLayout, String str, int i, String str2) {
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(str);
        checkBox.setTextSize(16f);
        checkBox.setTextColor(UiTheme.onSurface(this));
        checkBox.setMinHeight(dp(48));
        checkBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        checkBox.setId(i);
        boolean z = false;
        if (i == 200 || i == 201 || i == 205 || i == 207 || (i >= 210 && i <= 217)) {
            z = true;
        }
        checkBox.setChecked(CallController.isPrefEnabled(this, str2, z));
        checkBox.setOnCheckedChangeListener(this);
        linearLayout.addView(checkBox);
        if (i == 201) {
            this.cbAnsVolUp = checkBox;
            return;
        }
        if (i == 202) {
            this.cbAnsVolDown = checkBox;
        } else if (i == 205) {
            this.cbEndVolDown = checkBox;
        } else if (i == 206) {
            this.cbEndVolUp = checkBox;
        }
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        String str;
        if (compoundButton != null) {
            try {
                int id = compoundButton.getId();
                if (id == 200) {
                    str = "enabled";
                } else if (id == 201) {
                    str = "ans_vol_up";
                    if (z) {
                        CallController.setPrefEnabled(this, "ans_vol_down", false);
                        CheckBox checkBox = this.cbAnsVolDown;
                        if (checkBox != null) {
                            checkBox.setChecked(false);
                        }
                    }
                } else if (id == 202) {
                    str = "ans_vol_down";
                    if (z) {
                        CallController.setPrefEnabled(this, "ans_vol_up", false);
                        CheckBox checkBox2 = this.cbAnsVolUp;
                        if (checkBox2 != null) {
                            checkBox2.setChecked(false);
                        }
                    }
                } else if (id == 205) {
                    str = "end_vol_down";
                    if (z) {
                        CallController.setPrefEnabled(this, "end_vol_up", false);
                        CheckBox checkBox3 = this.cbEndVolUp;
                        if (checkBox3 != null) {
                            checkBox3.setChecked(false);
                        }
                    }
                } else if (id == 206) {
                    str = "end_vol_up";
                    if (z) {
                        CallController.setPrefEnabled(this, "end_vol_down", false);
                        CheckBox checkBox4 = this.cbEndVolDown;
                        if (checkBox4 != null) {
                            checkBox4.setChecked(false);
                        }
                    }
                } else if (id == 207) {
                    str = "ear_pickup";
                } else if (id == 210) {
                    str = "tts_enabled";
                } else if (id == 211) {
                    str = "tts_read_unknown";
                } else if (id == 212) {
                    str = "call_enabled_sim";
                } else if (id == 213) {
                    str = "call_enabled_wa";
                } else if (id == 214) {
                    str = "call_enabled_tg";
                } else if (id == 215) {
                    str = "call_enabled_other";
                } else if (id == 216) {
                    str = "tts_app_sms";
                } else if (id == 217) {
                    str = "tts_sms_text";
                } else if (id == 218) {
                    str = "call_enabled_viber";
                } else if (id == 219) {
                    str = "call_enabled_imo";
                } else if (id >= 230 && id <= 235) {
                    str = "msg_enabled_" + MSG_PROFILES[id - 230];
                } else if (id >= 240 && id <= 245) {
                    str = "msg_read_text_" + MSG_PROFILES[id - 240];
                } else {
                    return;
                }
                CallController.setPrefEnabled(this, str, z);
                refreshStatusText();
            } catch (Throwable th) {
            }
        }
    }

    /* JADX WARN: Unreachable blocks removed: 1, instructions: 1 */
    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int i;
        if (view != null) {
            try {
                int id = view.getId();
                if (id == 101) {
                    requestPhonePermissionsNow(true);
                } else if (id == 102) {
                    openSystemSetting("android.settings.ACCESSIBILITY_SETTINGS", false);
                } else if (id == 103) {
                    openSystemSetting("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS", false);
                } else if (id == 104) {
                    openSystemSetting("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", true);
                } else if (id == 105) {
                    new AlertDialog.Builder(this).setTitle("Диагностика сохранена").setMessage(CallController.saveDiagToDownload(this)).setNegativeButton("ОК", (DialogInterface.OnClickListener) null).show();
                    refreshStatusText();
                } else if (id == 106) {
                    shareDiagReport();
                } else if (id == 107) {
                    CallController.clearDiagLog();
                    refreshStatusText();
                } else if (id == 110) {
                    int prefInt = CallController.getPrefInt(this, "tts_repeat", 2);
                    if (prefInt == 1) {
                        i = 2;
                    } else if (prefInt == 2) {
                        i = 3;
                    } else {
                        i = prefInt == 3 ? 5 : 1;
                    }
                    CallController.setPrefInt(this, "tts_repeat", i);
                    refreshStatusText();
                } else if (id == 111) {
                    showTtsEngineDialog(11, "Выберите движок TTS для Обычных звонков (SIM)");
                } else if (id == 112) {
                    showTtsEngineDialog(12, "Выберите движок TTS для WhatsApp");
                } else if (id == 113) {
                    showTtsEngineDialog(13, "Выберите движок TTS для Telegram");
                } else if (id == 114) {
                    showTtsEngineDialog(14, "Выберите движок TTS для Viber / Imo / Других");
                } else if (id == 115) {
                    showTtsEngineDialog(15, "Выберите движок TTS для Входящих SMS");
                } else if (id == 116) {
                    CallController.lastCallState = 0;
                    CallController.speakText(this, "Проверка голосовой озвучки Умный Вызов. Звонит Абонент.", CallController.getPrefStr(this, "tts_eng_sim", "default"), 1);
                    refreshStatusText();
                } else if (id == 117) {
                    showTtsVoiceDialog();
                } else if (id == 121) {
                    showTtsRateDialog(21, "Скорость речи: Обычный звонок (SIM)");
                } else if (id == 122) {
                    showTtsRateDialog(22, "Скорость речи: WhatsApp");
                } else if (id == 123) {
                    showTtsRateDialog(23, "Скорость речи: Telegram");
                } else if (id == 124) {
                    showTtsRateDialog(24, "Скорость речи: Viber / Imo / Другие");
                } else if (id == 125) {
                    showTtsRateDialog(25, "Скорость речи: Входящие SMS");
                } else if (id == 126) {
                    showTtsAudioModeDialog();
                } else if (id == 127) {
                    showTtsCustomVolDialog();
                } else if (id == 108) {
                    startActivity(new Intent(this, DiagActivity.class));
                } else if (id == 142) {
                    CallController.stopTts();
                    CallController.log("Проверка озвучки остановлена пользователем");
                    refreshStatusText();
                } else if (id == 190) {
                    UpdatesController.checkManually(this);
                } else if (id == 191) {
                    UpdatesController.installDownloaded(this);
                }
            } catch (Throwable th) {
                CallController.log(th.toString());
            }
        }
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(applyThemeMode(newBase));
    }

    /** 0 = follow the system, 1 = light, 2 = dark; applied before any view is built. */
    static Context applyThemeMode(Context base) {
        try {
            int mode = base.getSharedPreferences("call_prefs", 0).getInt("theme_mode", 0);
            if (mode != 1 && mode != 2) {
                return base;
            }
            Configuration config = new Configuration(base.getResources().getConfiguration());
            config.uiMode = (config.uiMode & ~Configuration.UI_MODE_NIGHT_MASK)
                    | (mode == 2 ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
            return base.createConfigurationContext(config);
        } catch (RuntimeException e) {
            return base;
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.checkPermissionsOnResume = true;
            CallController.sanitizeButtonPrefs(this);
            CallController.log("Открыто приложение «Умный Вызов» v" + AppVersion.name(this));
            CallController.ensureNotificationListenerBound(this);

            int tab = bundle != null ? bundle.getInt("ui_tab", 0) : CallController.getPrefInt(this, "ui_tab", 0);
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundColor(UiTheme.window(this));
            FrameLayout content = new FrameLayout(this);
            root.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));
            this.sections = new View[]{buildHomeSection(), buildCallsSection(), buildSpeechSection(), buildSettingsSection()};
            for (int i = 0; i < this.sections.length; i++) {
                View section = this.sections[i];
                section.setVisibility(View.GONE);
                content.addView(section, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            }
            root.addView(buildBottomBar());
            setContentView(root);
            switchTab(tab);
            refreshStatusText();
        } catch (Throwable th) {
            CallController.log(th.toString());
        }
    }

    /** Tab 0 = Главная, 1 = Звонки, 2 = Озвучивание, 3 = Настройки. */
    void switchTab(int index) {
        if (index < 0 || index > 3) index = 0;
        this.currentTab = index;
        for (int i = 0; i < this.sections.length; i++) {
            this.sections[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
        }
        for (int i = 0; i < this.tabs.length; i++) {
            View tab = this.tabs[i];
            boolean selected = i == index;
            tab.setSelected(selected);
            if (tab instanceof TextView) {
                TextView label = (TextView) tab;
                label.setTypeface(null, selected ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
                label.setTextColor(selected ? UiTheme.primary(this) : UiTheme.onSurface(this));
                label.setBackground(UiTheme.rounded(this, selected ? UiTheme.primaryContainer(this) : UiTheme.surface(this), 20));
                label.setContentDescription("Раздел " + label.getText() + (selected ? ", выбран" : ", не выбран"));
                label.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
            }
        }
        CallController.setPrefInt(this, "ui_tab", index);
        if (index == 2) refreshStatusText();
    }

    private View buildBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(UiTheme.surface(this));
        bar.setElevation(8f);
        android.widget.HorizontalScrollView scroller = new android.widget.HorizontalScrollView(this);
        scroller.setFillViewport(true);
        scroller.setHorizontalScrollBarEnabled(false);
        scroller.addView(bar);
        String[] labels = {"Главная", "Звонки", "Озвучивание", "Настройки"};
        this.tabs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            Button item = new Button(this);
            item.setAllCaps(false);
            item.setText(labels[i]);
            item.setTextSize(14.0f);
            item.setGravity(android.view.Gravity.CENTER);
            item.setFocusable(true);
            item.setPadding(dp(4), dp(12), dp(4), dp(12));
            item.setMinHeight(dp(56));
            item.setMinWidth(dp(80));
            item.setSingleLine(false);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
            item.setLayoutParams(params);
            item.setContentDescription("Раздел " + labels[i]);
            item.setOnClickListener(new View.OnClickListener() {
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    switchTab(index);
                }
            });
            this.tabs[i] = item;
            bar.addView(item);
        }
        return scroller;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private View wrapSection(LinearLayout inner) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(inner);
        return scroll;
    }

    private LinearLayout newSection() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(24), dp(20), dp(24));
        layout.setBackgroundColor(UiTheme.window(this));
        return layout;
    }

    private TextView sectionTitle(LinearLayout parent, String text) {
        TextView title = new TextView(this);
        title.setText(text);
        title.setTextSize(24.0f);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setTextColor(UiTheme.onSurface(this));
        title.setPadding(0, 0, 0, dp(8));
        if (Build.VERSION.SDK_INT >= 28) title.setAccessibilityHeading(true);
        parent.addView(title);
        return title;
    }

    private TextView sectionHint(LinearLayout parent, String text) {
        TextView hint = new TextView(this);
        hint.setText(text);
        hint.setTextSize(15.0f);
        hint.setTextColor(UiTheme.onSurfaceVariant(this));
        hint.setPadding(0, 0, 0, dp(16));
        parent.addView(hint);
        return hint;
    }

    private TextView groupHeader(LinearLayout parent, String text) {
        TextView header = new TextView(this);
        header.setText(text);
        header.setTextSize(18.0f);
        header.setTypeface(null, android.graphics.Typeface.BOLD);
        header.setTextColor(UiTheme.primary(this));
        header.setPadding(0, dp(20), 0, dp(8));
        if (Build.VERSION.SDK_INT >= 28) header.setAccessibilityHeading(true);
        parent.addView(header);
        return header;
    }

    /** Главная: состояние, главный переключатель, разрешения, краткий обзор. */
    private View buildHomeSection() {
        LinearLayout layout = newSection();
        sectionTitle(layout, "Умный Вызов");
        sectionHint(layout, "Управление звонками кнопками громкости и датчиком у уха, голосовая озвучка звонков и сообщений.");
        TextView status = new TextView(this);
        status.setTextSize(14.0f);
        status.setPadding(24, 24, 24, 24);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        this.statusTextView = status;
        layout.addView(status);
        addCheckBox(layout, "Включить управление звонками кнопками и датчиком", 200, "enabled");
        groupHeader(layout, "Быстрые действия");
        addActionButton(layout, "1. Выдать разрешения (Телефон / Контакты / SMS)", 101, UiTheme.primaryContainer(this));
        addActionButton(layout, "2. Включить Спец. возможности (Кнопки и Датчик уха)", 102, UiTheme.secondaryContainer(this));
        addActionButton(layout, "3. Доступ к уведомлениям (Мессенджеры и Озвучка)", 103, UiTheme.primaryContainer(this));
        addActionButton(layout, "4. Отключить экономию батареи (Samsung / Xiaomi)", 104, UiTheme.secondaryContainer(this));
        groupHeader(layout, "Активные функции");
        TextView overview = new TextView(this);
        overview.setTextSize(14.0f);
        overview.setTextColor(UiTheme.onSurface(this));
        overview.setPadding(0, 0, 0, 24);
        overview.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        this.overviewTextView = overview;
        layout.addView(overview);
        return wrapSection(layout);
    }

    /** Звонки: кнопки громкости, ответ/завершение, датчик приближения. */
    private View buildCallsSection() {
        LinearLayout layout = newSection();
        sectionTitle(layout, "Звонки");
        sectionHint(layout, "Обрабатывается только достоверно зарегистрированное нажатие назначенной кнопки. Изменение громкости или окончание мелодии нажатием не считаются.");
        groupHeader(layout, "Поднять трубку (только ОДНА кнопка громкости)");
        addCheckBox(layout, "Поднять трубку при поднесении телефона к уху (Датчик приближения)", 207, "ear_pickup");
        addCheckBox(layout, "Кнопка увеличения громкости (Громкость +)", 201, "ans_vol_up");
        addCheckBox(layout, "Кнопка уменьшения громкости (Громкость -)", 202, "ans_vol_down");
        groupHeader(layout, "Завершить звонок (только ОДНА кнопка громкости)");
        addCheckBox(layout, "Кнопка уменьшения громкости (Громкость -)", 205, "end_vol_down");
        addCheckBox(layout, "Кнопка увеличения громкости (Громкость +)", 206, "end_vol_up");
        TextView note = new TextView(this);
        note.setText("Автоответ использует переход «далеко → близко» и задержки. Работа датчика зависит от устройства; случайное перекрытие может быть ошибочно принято за жест.");
        note.setTextSize(15.0f);
        note.setTextColor(UiTheme.onSurfaceVariant(this));
        note.setPadding(0, 24, 0, 0);
        layout.addView(note);
        return wrapSection(layout);
    }

    /** Компактный список источников; одновременно раскрыт не более одного профиля. */
    private View buildSpeechSection() {
        LinearLayout layout = newSection();
        sectionTitle(layout, "Озвучивание");
        sectionHint(layout, "Выберите источник, чтобы открыть настройки звонков и сообщений.");
        addCheckBox(layout, "Включить голосовую озвучку звонящего и сообщений", 210, "tts_enabled");
        addCheckBox(layout, "Читать номер, если его нет в контактах", 211, "tts_read_unknown");
        addCheckBox(layout, "Озвучивать входящие сообщения (глобально)", 216, "tts_app_sms");
        addCheckBox(layout, "Читать текст сообщений (глобально)", 217, "tts_sms_text");

        groupHeader(layout, "Источники");
        final LinearLayout[] details = new LinearLayout[CALL_PROFILES.length];
        final Button[] selectors = new Button[CALL_PROFILES.length];
        final String[] labels = {"SIM и SMS", "WhatsApp", "Telegram", "Viber", "Imo", "Другие приложения"};
        final int[] callSwitchIds = {212, 213, 214, 218, 219, 215};
        final int[] msgSwitchIds = {230, 231, 232, 233, 234, 235};
        final int[] msgTextIds = {240, 241, 242, 243, 244, 245};
        for (int i = 0; i < CALL_PROFILES.length; i++) {
            final int index = i;
            final String call = CALL_PROFILES[i];
            final String msg = MSG_PROFILES[i];
            Button selector = addActionButton(layout, labels[i] + " — открыть настройки", 0, UiTheme.surfaceVariant(this));
            selector.setContentDescription(labels[i] + ", настройки свёрнуты, нажмите, чтобы открыть");
            selectors[i] = selector;

            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(12), dp(4), dp(12), dp(12));
            panel.setVisibility(View.GONE);
            panel.setBackground(UiTheme.rounded(this, UiTheme.surface(this), 16));
            details[i] = panel;
            layout.addView(panel);
            selector.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    boolean open = details[index].getVisibility() != View.VISIBLE;
                    for (int j = 0; j < details.length; j++) {
                        boolean selected = open && j == index;
                        details[j].setVisibility(selected ? View.VISIBLE : View.GONE);
                        selectors[j].setText(labels[j] + (selected ? " — закрыть настройки" : " — открыть настройки"));
                        selectors[j].setContentDescription(labels[j] + (selected
                                ? ", настройки раскрыты, нажмите, чтобы закрыть"
                                : ", настройки свёрнуты, нажмите, чтобы открыть"));
                    }
                    refreshProfileLabels();
                    view.sendAccessibilityEvent(android.view.accessibility.AccessibilityEvent.TYPE_VIEW_SELECTED);
                }
            });

            groupHeader(panel, "Звонки");
            addCheckBox(panel, "Озвучивать звонки", callSwitchIds[i], "call_enabled_" + call);
            btnCallEngine[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnCallVoice[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnCallRate[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnCallRepeat[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnCallDelay[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnCallTest[i] = addActionButton(panel, "Проверить озвучивание звонков", 0, UiTheme.primaryContainer(this));
            btnCallTest[i].setContentDescription("Проверить озвучивание звонков: " + CALL_LABELS[i]);
            btnCallEngine[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallEngineDialog(index); } });
            btnCallVoice[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallVoicePicker(index); } });
            btnCallRate[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallRateDialog(index); } });
            btnCallRepeat[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallRepeatDialog(index); } });
            btnCallDelay[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallDelayDialog(index); } });
            btnCallTest[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openCallTestDialog(index); } });

            groupHeader(panel, "Сообщения");
            addCheckBox(panel, "Озвучивать сообщения", msgSwitchIds[i], "msg_enabled_" + msg);
            addCheckBox(panel, "Читать текст сообщения", msgTextIds[i], "msg_read_text_" + msg);
            btnMsgEngine[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnMsgVoice[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnMsgRate[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnMsgLock[i] = addActionButton(panel, "", 0, UiTheme.surfaceVariant(this));
            btnMsgTest[i] = addActionButton(panel, "Проверить озвучивание сообщений", 0, UiTheme.primaryContainer(this));
            btnMsgTest[i].setContentDescription("Проверить озвучивание сообщений: " + MSG_LABELS[i]);
            btnMsgEngine[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMsgEngineDialog(index); } });
            btnMsgVoice[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMsgVoicePicker(index); } });
            btnMsgRate[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMsgRateDialog(index); } });
            btnMsgLock[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMsgLockDialog(index); } });
            btnMsgTest[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMsgTestDialog(index); } });
        }
        groupHeader(layout, "Общие настройки озвучивания");
        btnAudioMode = addActionButton(layout, "Аудиоканал озвучивания", 126, UiTheme.surfaceVariant(this));
        btnCustomVol = addActionButton(layout, "Собственная громкость TTS", 127, UiTheme.surfaceVariant(this));
        addActionButton(layout, "Остановить проверку озвучивания", 142, UiTheme.errorContainer(this));
        return wrapSection(layout);
    }

    /** Настройки: оформление, разрешения, обновления, диагностика, информация. */
    private View buildSettingsSection() {
        LinearLayout layout = newSection();
        sectionTitle(layout, "Настройки");
        groupHeader(layout, "Оформление");
        this.btnTheme = addActionButton(layout, "", 0, UiTheme.surfaceVariant(this));
        this.btnTheme.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openThemeDialog(); }
        });
        groupHeader(layout, "Разрешения и службы");
        addActionButton(layout, "Выдать разрешения (Телефон / Контакты / SMS)", 101, UiTheme.primaryContainer(this));
        addActionButton(layout, "Спец. возможности (Кнопки и Датчик уха)", 102, UiTheme.secondaryContainer(this));
        addActionButton(layout, "Доступ к уведомлениям (Мессенджеры и Озвучка)", 103, UiTheme.primaryContainer(this));
        addActionButton(layout, "Отключить экономию батареи (Samsung / Xiaomi)", 104, UiTheme.secondaryContainer(this));
        groupHeader(layout, "Обновления");
        this.btnUpdatesAuto = addActionButton(layout, "", 0, UiTheme.surfaceVariant(this));
        this.btnUpdatesAuto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { toggleAutoUpdates(); }
        });
        addActionButton(layout, "Проверить обновления", 190, UiTheme.primaryContainer(this));
        addActionButton(layout, "Установить ранее скачанное обновление", 191, UiTheme.secondaryContainer(this));
        groupHeader(layout, "Диагностика");
        addActionButton(layout, "Открыть журнал диагностики", 108, UiTheme.primaryContainer(this));
        addActionButton(layout, "Сохранить диагностику в папку Download", 105, UiTheme.surfaceVariant(this));
        addActionButton(layout, "Отправить диагностику (Поделиться)", 106, UiTheme.surfaceVariant(this));
        addActionButton(layout, "Очистить журнал диагностики", 107, UiTheme.errorContainer(this));
        groupHeader(layout, "Информация о приложении");
        TextView about = new TextView(this);
        about.setTextSize(13.0f);
        about.setTextColor(UiTheme.onSurfaceVariant(this));
        about.setText("«Умный Вызов» v" + AppVersion.name(this) + " (код " + AppVersion.code(this) + ")\nПакет: com.smartcall.ru\nМинимальная версия Android: 7.0 (API 24)\nПодпись: оригинальный ключ разработчика\nОбновления: UMEDJON12/umnyj-vyzov-updates");
        about.setPadding(0, 0, 0, 24);
        layout.addView(about);
        // Полный журнал находится на отдельном экране, а не в длинном списке настроек.
        this.diagTextView = null;
        return wrapSection(layout);
    }

    public void onDialogPositiveAction(int i, int i2) {
        String str;
        String str2;
        int i3;
        String str3;
        String str4;
        try {
            if (i == 1) {
                requestPhonePermissionsNow(true);
                return;
            }
            if (i == 2) {
                openSystemSetting("android.settings.ACCESSIBILITY_SETTINGS", false);
                return;
            }
            if (i == 3) {
                openSystemSetting("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS", false);
                return;
            }
            if (i == 4) {
                openSystemSetting("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", true);
                return;
            }
            if (i == 26) {
                if (i2 < 0 || i2 > 3) {
                    return;
                }
                CallController.setPrefInt(this, "tts_audio_mode", i2);
                refreshStatusText();
                SmartCallFeatures.speak(this, "Проверка выбранного аудиоканала", "tts_eng_sim", 1);
                return;
            }
            if (i == 27) {
                int i4 = 100;
                if (i2 == 0) {
                    i4 = 15;
                } else if (i2 == 1) {
                    i4 = 30;
                } else if (i2 == 2) {
                    i4 = 45;
                } else if (i2 == 3) {
                    i4 = 60;
                } else if (i2 == 4) {
                    i4 = 75;
                } else if (i2 == 5) {
                    i4 = 90;
                }
                CallController.setPrefInt(this, "tts_custom_vol", i4);
                refreshStatusText();
                SmartCallFeatures.speak(this, "Проверка собственной громкости озвучки", "tts_eng_sim", 1);
                return;
            }
            if (i < 21 || i > 25) {
                String[] strArr = this.dialogEnginePkgs;
                if (strArr == null || i2 < 0 || i2 >= strArr.length || (str = strArr[i2]) == null) {
                    return;
                }
                if ("open_tts_settings".equals(str)) {
                    openSystemSetting("com.android.settings.TTS_SETTINGS", false);
                    return;
                }
                if (i == 11) {
                    str2 = "tts_eng_sim";
                } else if (i == 12) {
                    str2 = "tts_eng_wa";
                } else if (i == 13) {
                    str2 = "tts_eng_tg";
                } else if (i != 14) {
                    str2 = i != 15 ? "tts_voice_name" : "tts_eng_sms";
                } else {
                    str2 = "tts_eng_other";
                }
                CallController.setPrefStr(this, str2, str);
                if (i != 16) {
                    SmartCallFeatures.onEngineChanged(this, str2);
                    CallController.reinitTts(this, str);
                }
                CallController.log("Сохранена настройка TTS [" + str2 + "] = " + CallController.formatEngineLabel(str));
                refreshStatusText();
                return;
            }
            if (i2 == 0) {
                i3 = 50;
            } else if (i2 == 1) {
                i3 = 75;
            } else if (i2 == 2) {
                i3 = 90;
            } else if (i2 == 3) {
                i3 = 100;
            } else if (i2 == 4) {
                i3 = 115;
            } else if (i2 == 5) {
                i3 = 125;
            } else if (i2 == 6) {
                i3 = 150;
            } else {
                i3 = i2 == 7 ? 175 : 200;
            }
            if (i == 21) {
                str3 = "tts_rate_sim";
                str4 = "tts_eng_sim";
            } else if (i == 22) {
                str3 = "tts_rate_wa";
                str4 = "tts_eng_wa";
            } else if (i == 23) {
                str3 = "tts_rate_tg";
                str4 = "tts_eng_tg";
            } else if (i != 24) {
                str3 = "tts_rate_sms";
                str4 = "tts_eng_sms";
            } else {
                str3 = "tts_rate_other";
                str4 = "tts_eng_other";
            }
            CallController.setPrefInt(this, str3, i3);
            refreshStatusText();
            SmartCallFeatures.speak(this, "Проверка выбранной скорости речи", str4, 1);
            return;
        } catch (Throwable th) {
        }
    }

    /** Handlers for the 2.3.7 per-profile dialogs (ids 30 and 40..50). */
    public void onProfileDialog(int i, int i2) {
        try {
            if (i == 30) {
                if (i2 < 0 || i2 > 2) return;
                CallController.setPrefInt(this, "theme_mode", i2);
                recreate();
                return;
            }
            if (i == 40 || i == 47) {
                String[] pkgs = this.dialogEnginePkgs;
                if (pkgs == null || i2 < 0 || i2 >= pkgs.length || pkgs[i2] == null) return;
                String engine = pkgs[i2];
                if ("open_tts_settings".equals(engine)) {
                    openSystemSetting("com.android.settings.TTS_SETTINGS", false);
                    return;
                }
                String prefix = (i == 40) ? "call_" : "msg_";
                String key = prefix + "eng_" + this.dialogChannel;
                String previousEngine = CallController.getPrefStr(this, key, "default");
                CallController.setPrefStr(this, key, engine);
                // Voice IDs belong to a specific engine; keep them when the engine is unchanged.
                if (!engine.equals(previousEngine)) {
                    getSharedPreferences("call_prefs", 0).edit()
                            .putString(prefix + "voice_" + this.dialogChannel, "default")
                            .remove(prefix + "voice_" + this.dialogChannel + "_label").apply();
                }
                CallController.log("Сохранена настройка TTS [" + key + "] = " + CallController.formatEngineLabel(engine));
                CallController.reinitTts(this, engine);
                refreshStatusText();
                return;
            }
            if (i == 41 || i == 48) {
                int[] rates = {50, 75, 90, 100, 115, 125, 150, 175, 200};
                if (i2 < 0 || i2 >= rates.length) return;
                String prefix = (i == 41) ? "call_" : "msg_";
                CallController.setPrefInt(this, prefix + "rate_" + this.dialogChannel, rates[i2]);
                refreshStatusText();
                SmartCallFeatures.enqueueTest(this, "Проверка выбранной скорости речи", this.dialogChannel, i == 41, 1);
                return;
            }
            if (i == 43) {
                if (i2 < 0 || i2 > 4) return;
                CallController.setPrefInt(this, "call_repeat_" + this.dialogChannel, i2 + 1);
                refreshStatusText();
                return;
            }
            if (i == 44) {
                if (i2 < 0 || i2 > 30) return;
                CallController.setPrefInt(this, "call_delay_" + this.dialogChannel, i2);
                refreshStatusText();
                return;
            }
            if (i == 46) {
                if (i2 == 0) {
                    SmartCallFeatures.enqueueTest(this, "Проверка голоса. Звонит Абонент.", this.dialogChannel, true, 1);
                } else if (i2 == 1) {
                    SmartCallFeatures.enqueueTest(this, "Проверка повторений. Звонит Абонент.", this.dialogChannel, true, 2);
                } else {
                    CallController.stopTts();
                }
                return;
            }
            if (i == 49) {
                if (i2 < 0 || i2 > 2) return;
                CallController.setPrefInt(this, "msg_lock_mode_" + this.dialogChannel, i2);
                refreshStatusText();
                return;
            }
            if (i == 50) {
                if (i2 == 0) {
                    SmartCallFeatures.enqueueTest(this, "Проверка озвучки сообщений. Отправитель, текст сообщения.", this.dialogChannel, false, 1);
                } else {
                    CallController.stopTts();
                }
            }
        } catch (Throwable th) {
            CallController.log("Диалог настроек: " + th);
        }
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        try {
            refreshStatusText();
            if (CallController.hasPhonePermissions(this)) {
                promptMissingServicesIfAny();
            } else {
                new AlertDialog.Builder(this).setTitle("Необходимы разрешения").setMessage("Вы запретили одно или несколько разрешений. Для работы управления звонками и озвучивания контактов/SMS выдайте запрашиваемые разрешения.").setPositiveButton("Выдать разрешения", new DialogClickListener(this, 1)).setNegativeButton("Закрыть", (DialogInterface.OnClickListener) null).show();
            }
        } catch (Throwable th) {
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        UpdatesController.onActivityResumed(this);
        try {
            CallController.ensureNotificationListenerBound(this);
            if (CallController.ttsInstance == null) {
                CallController.reinitTts(this, CallController.getPrefStr(this, "tts_eng_sim", "default"));
            }
            refreshStatusText();
            if (consumeUpdateIntent()) {
                // Old 2.3.8 notification is routed to a screen with an explicit Install action.
            } else if (this.autoCheckOnNextResume) {
                this.autoCheckOnNextResume = false;
                UpdatesController.autoCheck(this);
            }
            if (this.checkPermissionsOnResume) {
                this.checkPermissionsOnResume = false;
                if (CallController.hasPhonePermissions(this)) {
                    promptMissingServicesIfAny();
                } else {
                    requestPhonePermissionsNow(false);
                }
            }
        } catch (Throwable th) {
            CallController.log(th.toString());
        }
    }

    @Override protected void onPause() {
        UpdatesController.onActivityPaused(this);
        super.onPause();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        consumeUpdateIntent();
    }

    private boolean consumeUpdateIntent() {
        Intent intent = getIntent();
        if (intent == null || !intent.getBooleanExtra("install_update", false)) return false;
        intent.removeExtra("install_update");
        startActivity(UpdateProgressActivity.openIntent(this));
        return true;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UpdatesController.onInstallPermissionResult(this, requestCode);
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.checkPermissionsOnResume = true;
        this.autoCheckOnNextResume = true;
    }

    public void openSystemSetting(String str, boolean z) {
        try {
            Intent intent = new Intent(str);
            if (z) {
                intent = intent.setData(Uri.parse("package:" + getPackageName()));
            }
            startActivity(intent.addFlags(268435456));
        } catch (Throwable th) {
        }
    }

    public void promptMissingServicesIfAny() {
        try {
            if (!CallController.isBatteryOptimizationIgnored(this)) {
                new AlertDialog.Builder(this).setTitle("Разрешите работу в фоне").setMessage("Для стабильной работы на Samsung, Xiaomi и других телефонах разрешите работу в фоне без экономии батареи.").setPositiveButton("Разрешить", new DialogClickListener(this, 4)).setNegativeButton("Позже", (DialogInterface.OnClickListener) null).show();
            } else if (!CallController.isNotificationListenerEnabled(this)) {
                new AlertDialog.Builder(this).setTitle("Доступ к звонкам и озвучке").setMessage("Включите «Умный Вызов» в списке доступа к уведомлениям, чтобы принимать и завершать звонки в WhatsApp, Telegram, Viber, Imo и озвучивать звонки и сообщения.").setPositiveButton("Включить", new DialogClickListener(this, 3)).setNegativeButton("Позже", (DialogInterface.OnClickListener) null).show();
            } else {
                if (CallController.isAccessibilityEnabled(this)) {
                    return;
                }
                new AlertDialog.Builder(this).setTitle("Включите перехват кнопок").setMessage("Включите службу «Умный Вызов» в разделе Специальные возможности, чтобы кнопки громкости и датчик приближения могли поднимать и класть трубку.").setPositiveButton("Включить", new DialogClickListener(this, 2)).setNegativeButton("Позже", (DialogInterface.OnClickListener) null).show();
            }
        } catch (Throwable th) {
        }
    }

    public void refreshStatusText() {
        try {
            TextView textView = this.statusTextView;
            if (textView != null) {
                textView.setText((!CallController.hasPhonePermissions(this) ? "✗ 1. Разрешения телефона/Контактов/SMS: НЕ ВСЕ ВЫДАНЫ\n" : "✓ 1. Разрешения телефона: ВЫДАНЫ\n") + (!CallController.isAccessibilityEnabled(this) ? "✗ 2. Спец. возможности (Кнопки и Датчик уха): ВЫКЛЮЧЕНО\n" : "✓ 2. Спец. возможности (Кнопки и Датчик уха): ВКЛЮЧЕНО\n") + (!CallController.isNotificationListenerEnabled(this) ? "✗ 3. Доступ к уведомлениям (Мессенджеры/Озвучка): ВЫКЛЮЧЕНО\n" : "✓ 3. Доступ к уведомлениям (Мессенджеры/Озвучка): ВКЛЮЧЕНО\n") + (!CallController.isBatteryOptimizationIgnored(this) ? "✗ 4. Работа в фоне без ограничений: ВЫКЛЮЧЕНО" : "✓ 4. Работа в фоне без ограничений: АКТИВНО"));
                if (CallController.areAllPermissionsGranted(this)) {
                    textView.setBackgroundColor(-1245707);
                    textView.setTextColor(-16359610);
                } else {
                    textView.setBackgroundColor(-68878);
                    textView.setTextColor(-6743269);
                }
            }
            Button button = this.btnTtsRepeat;
            if (button != null) {
                button.setText("Количество повторений имени: " + CallController.getPrefInt(this, "tts_repeat", 2) + " раз(а) (Нажмите для смены)");
            }
            Button button2 = this.btnEngSim;
            if (button2 != null) {
                button2.setText("Движок TTS [Обычный звонок]: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_eng_sim", "default")));
            }
            Button button3 = this.btnEngWa;
            if (button3 != null) {
                button3.setText("Движок TTS [WhatsApp]: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_eng_wa", "default")));
            }
            Button button4 = this.btnEngTg;
            if (button4 != null) {
                button4.setText("Движок TTS [Telegram]: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_eng_tg", "default")));
            }
            Button button5 = this.btnEngOther;
            if (button5 != null) {
                button5.setText("Движок TTS [Viber / Imo / Другие]: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_eng_other", "default")));
            }
            Button button6 = this.btnEngSms;
            if (button6 != null) {
                button6.setText("Движок TTS [Входящие SMS]: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_eng_sms", "default")));
            }
            Button button7 = this.btnRateSim;
            if (button7 != null) {
                button7.setText("Скорость речи [Обычный звонок]: " + CallController.formatRateLabel(CallController.getPrefInt(this, "tts_rate_sim", 100)));
            }
            Button button8 = this.btnRateWa;
            if (button8 != null) {
                button8.setText("Скорость речи [WhatsApp]: " + CallController.formatRateLabel(CallController.getPrefInt(this, "tts_rate_wa", 100)));
            }
            Button button9 = this.btnRateTg;
            if (button9 != null) {
                button9.setText("Скорость речи [Telegram]: " + CallController.formatRateLabel(CallController.getPrefInt(this, "tts_rate_tg", 100)));
            }
            Button button10 = this.btnRateOther;
            if (button10 != null) {
                button10.setText("Скорость речи [Viber / Imo / Другие]: " + CallController.formatRateLabel(CallController.getPrefInt(this, "tts_rate_other", 100)));
            }
            Button button11 = this.btnRateSms;
            if (button11 != null) {
                button11.setText("Скорость речи [Входящие SMS]: " + CallController.formatRateLabel(CallController.getPrefInt(this, "tts_rate_sms", 100)));
            }
            Button button12 = this.btnAudioMode;
            if (button12 != null) {
                button12.setText("Аудиоканал озвучки (TTS): " + CallController.formatAudioModeLabel(CallController.getPrefInt(this, "tts_audio_mode", 0)));
            }
            Button button13 = this.btnCustomVol;
            if (button13 != null) {
                button13.setText("Собственная громкость TTS (отдельно): " + CallController.getPrefInt(this, "tts_custom_vol", 100) + "%");
            }
            Button button14 = this.btnTtsVoice;
            if (button14 != null) {
                button14.setText("Голос внутри движка TTS: " + CallController.formatEngineLabel(CallController.getPrefStr(this, "tts_voice_name", "default")));
            }
            TextView textView2 = this.diagTextView;
            if (textView2 != null) {
                textView2.setText(CallController.getDiagReport(this));
            }
            refreshProfileLabels();
            refreshPermissionActions();
            TextView overview = this.overviewTextView;
            if (overview != null) {
                overview.setText(buildOverview());
            }
        } catch (Throwable th) {
        }
    }

    /** Скрывает уже выполненные действия, оставляя краткий статус разрешений. */
    private void refreshPermissionActions() {
        boolean[] granted = {CallController.hasPhonePermissions(this),
                CallController.isAccessibilityEnabled(this),
                CallController.isNotificationListenerEnabled(this),
                CallController.isBatteryOptimizationIgnored(this)};
        for (Button button : permissionActions) {
            int index = button.getId() - 101;
            if (index >= 0 && index < granted.length) {
                button.setVisibility(granted[index] ? View.GONE : View.VISIBLE);
            }
        }
    }

    /** Keeps every per-profile button label in sync with the stored settings. */
    void refreshProfileLabels() {
        try {
            android.content.SharedPreferences p = getSharedPreferences("call_prefs", 0);
            for (int i = 0; i < CALL_PROFILES.length; i++) {
                String ch = CALL_PROFILES[i];
                String legacy = legacyChannel(ch);
                if (btnCallEngine[i] != null) {
                    String eng = p.contains("call_eng_" + ch) ? p.getString("call_eng_" + ch, "default")
                            : p.getString("tts_eng_" + legacy, "default");
                    btnCallEngine[i].setText("Движок: " + CallController.formatEngineLabel(eng));
                }
                if (btnCallVoice[i] != null) {
                    String fallback = ("sim".equals(ch)) ? p.getString("tts_voice_name", "default") : "default";
                    String voice = p.contains("call_voice_" + ch) ? p.getString("call_voice_" + ch, fallback)
                            : p.getString("tts_voice_" + legacy, fallback);
                    String label = p.getString("call_voice_" + ch + "_label", null);
                    btnCallVoice[i].setText("Голос: "
                            + ("default".equals(voice) ? "по умолчанию"
                            : label != null ? label : "выбранный голос (" + voice + ")"));
                }
                if (btnCallRate[i] != null) {
                    int rate = p.contains("call_rate_" + ch) ? p.getInt("call_rate_" + ch, 100) : p.getInt("tts_rate_" + legacy, 100);
                    btnCallRate[i].setText("Скорость: " + rateLabel(rate));
                }
                if (btnCallRepeat[i] != null) {
                    int repeat = p.getInt("call_repeat_" + ch, 2);
                    btnCallRepeat[i].setText("Повторений имени: " + repeat);
                }
                if (btnCallDelay[i] != null) {
                    int delay = p.getInt("call_delay_" + ch, 0);
                    btnCallDelay[i].setText("Задержка между повторами: " + delay + " сек.");
                }
            }
            for (int i = 0; i < MSG_PROFILES.length; i++) {
                String ch = MSG_PROFILES[i];
                String legacy = legacyChannel(ch);
                if (btnMsgEngine[i] != null) {
                    String eng = p.contains("msg_eng_" + ch) ? p.getString("msg_eng_" + ch, "default")
                            : p.getString("tts_eng_" + legacy, "default");
                    btnMsgEngine[i].setText("Движок: " + CallController.formatEngineLabel(eng));
                }
                if (btnMsgVoice[i] != null) {
                    String voice = p.contains("msg_voice_" + ch) ? p.getString("msg_voice_" + ch, "default")
                            : p.getString("tts_voice_" + legacy, "default");
                    String label = p.getString("msg_voice_" + ch + "_label", null);
                    btnMsgVoice[i].setText("Голос: "
                            + ("default".equals(voice) ? "по умолчанию"
                            : label != null ? label : "выбранный голос (" + voice + ")"));
                }
                if (btnMsgRate[i] != null) {
                    int rate = p.contains("msg_rate_" + ch) ? p.getInt("msg_rate_" + ch, 100) : p.getInt("tts_rate_" + legacy, 100);
                    btnMsgRate[i].setText("Скорость: " + rateLabel(rate));
                }
                if (btnMsgLock[i] != null) {
                    int mode = p.getInt("msg_lock_mode_" + ch, 0);
                    btnMsgLock[i].setText("При заблокированном экране: " + lockLabel(mode));
                }
            }
            for (int i = 0; i < CALL_PROFILES.length; i++) {
                describeProfileButton(btnCallEngine[i], "Звонки", CALL_LABELS[i]);
                describeProfileButton(btnCallVoice[i], "Звонки", CALL_LABELS[i]);
                describeProfileButton(btnCallRate[i], "Звонки", CALL_LABELS[i]);
                describeProfileButton(btnCallRepeat[i], "Звонки", CALL_LABELS[i]);
                describeProfileButton(btnCallDelay[i], "Звонки", CALL_LABELS[i]);
                describeProfileButton(btnMsgEngine[i], "Сообщения", MSG_LABELS[i]);
                describeProfileButton(btnMsgVoice[i], "Сообщения", MSG_LABELS[i]);
                describeProfileButton(btnMsgRate[i], "Сообщения", MSG_LABELS[i]);
                describeProfileButton(btnMsgLock[i], "Сообщения", MSG_LABELS[i]);
            }
            TextView theme = this.btnTheme;
            if (theme != null) {
                theme.setText("Тема: " + themeLabel(CallController.getPrefInt(this, "theme_mode", 0)));
            }
            TextView updates = this.btnUpdatesAuto;
            if (updates != null) {
                updates.setText("Автопроверка обновлений: "
                        + (UpdatesController.isAutoCheckEnabled(this) ? "включена" : "выключена"));
            }
        } catch (Throwable th) {
        }
    }

    private void describeProfileButton(Button button, String kind, String source) {
        if (button != null) button.setContentDescription(kind + ", " + source + ": " + button.getText());
    }

    public void requestPhonePermissionsNow(boolean z) {
        // Runtime permission dialogs were introduced in API 23; do not launch a fallback action.
        if (Build.VERSION.SDK_INT < 23) return;
        String[] strArr;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                strArr = new String[7];
                strArr[6] = "android.permission.POST_NOTIFICATIONS";
            } else {
                strArr = new String[6];
            }
            strArr[0] = "android.permission.READ_PHONE_STATE";
            strArr[1] = "android.permission.CALL_PHONE";
            strArr[2] = "android.permission.ANSWER_PHONE_CALLS";
            strArr[3] = "android.permission.READ_CONTACTS";
            strArr[4] = "android.permission.RECEIVE_SMS";
            strArr[5] = "android.permission.READ_SMS";
            if (!z || shouldShowRequestPermissionRationale("android.permission.READ_PHONE_STATE")) {
                requestPermissions(strArr, 1001);
            } else {
                requestPermissions(strArr, 1001);
                openSystemSetting("android.settings.APPLICATION_DETAILS_SETTINGS", true);
            }
        } catch (Throwable th) {
        }
    }

    public void shareDiagReport() {
        try {
            startActivity(Intent.createChooser(new Intent("android.intent.action.SEND").setType("text/plain").putExtra("android.intent.extra.TEXT", CallController.getDiagReport(this)), "Отправить диагностику «Умный Вызов»"));
        } catch (Throwable th) {
        }
    }

    public void showTtsAudioModeDialog() {
        try {
            new AlertDialog.Builder(this).setTitle("Выберите аудиоканал озвучки (TTS)").setItems(new CharSequence[]{"1. Канал Специальные возможности (TalkBack / Accessibility)", "2. Канал Мультимедиа (Громкость музыки и медиа)", "3. Канал Звонка (Громкость мелодии вызова)", "4. Собственная громкость (Регулируется отдельно в приложении)"}, new DialogClickListener(this, 26)).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
        } catch (Throwable th) {
        }
    }

    public void showTtsCustomVolDialog() {
        try {
            new AlertDialog.Builder(this).setTitle("Собственная громкость озвучки TTS (отдельно)").setItems(new CharSequence[]{"15% — Очень тихо", "30% — Тихо", "45% — Умеренно тихо", "60% — Средняя громкость", "75% — Комфортная громкость", "90% — Громко", "100% — Максимальная громкость"}, new DialogClickListener(this, 27)).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
        } catch (Throwable th) {
        }
    }

    public void showTtsEngineDialog(int i, String str) {
        try {
            TextToSpeech textToSpeech = CallController.ttsInstance;
            if (textToSpeech == null) {
                textToSpeech = new TextToSpeech(this, null);
            }
            List<TextToSpeech.EngineInfo> engines = textToSpeech.getEngines();
            int size = engines != null ? engines.size() : 0;
            int i2 = size + 1;
            CharSequence[] charSequenceArr = new CharSequence[i2];
            String[] strArr = new String[i2];
            charSequenceArr[0] = "Системный движок (По умолчанию)";
            strArr[0] = "default";
            for (int i3 = 0; i3 < size; i3++) {
                TextToSpeech.EngineInfo engineInfo = engines.get(i3);
                int i4 = i3 + 1;
                if (engineInfo != null) {
                    String str2 = engineInfo.name;
                    String str3 = engineInfo.label;
                    if (str3 == null) {
                        str3 = str2;
                    }
                    strArr[i4] = str2;
                    charSequenceArr[i4] = str3 + " [" + strArr[i4] + "]";
                }
            }
            this.dialogEnginePkgs = strArr;
            new AlertDialog.Builder(this).setTitle(str).setItems(charSequenceArr, new DialogClickListener(this, i)).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
        } catch (Throwable th) {
        }
    }

    public void showTtsRateDialog(int i, String str) {
        try {
            new AlertDialog.Builder(this).setTitle(str).setItems(new CharSequence[]{"0.5x — Очень медленно (50%)", "0.75x — Медленно (75%)", "0.9x — Чуть медленнее (90%)", "1.0x — Обычная скорость (100%)", "1.15x — Чуть быстрее (115%)", "1.25x — Быстро (125%)", "1.5x — Очень быстро (150%)", "1.75x — Ускоренная (175%)", "2.0x — Максимальная скорость (200%)"}, new DialogClickListener(this, i)).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
        } catch (Throwable th) {
        }
    }

    public void showTtsVoiceDialog() {
        Voice next;
        String name;
        Set<Voice> voices = null;
        try {
            TextToSpeech textToSpeech = CallController.ttsInstance;
            if (textToSpeech != null) {
                voices = textToSpeech.getVoices();
            }
        } catch (Throwable th) {
            voices = null;
        }
        int i = 0;
        if (voices != null) {
            try {
                Iterator<Voice> it = voices.iterator();
                while (it.hasNext() && ((next = it.next()) == null || next.getName() == null || (i = i + 1) < 60)) {
                }
            } catch (Throwable th2) {
                return;
            }
        }
        int i2 = i + 2;
        CharSequence[] charSequenceArr = new CharSequence[i2];
        String[] strArr = new String[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            charSequenceArr[i3] = "По умолчанию (Стандартный голос движка)";
            strArr[i3] = "default";
        }
        int i4 = 1;
        if (voices != null && i > 0) {
            Iterator<Voice> it2 = voices.iterator();
            int i5 = i2 - 1;
            while (i4 < i5 && it2.hasNext()) {
                Voice next2 = it2.next();
                if (next2 != null && (name = next2.getName()) != null) {
                    strArr[i4] = name;
                    Locale locale = next2.getLocale();
                    String displayName = "";
                    if (locale != null && (displayName = locale.getDisplayName()) == null) {
                        displayName = "";
                    }
                    charSequenceArr[i4] = name + " (" + displayName + ")";
                    i4++;
                }
            }
        }
        int i6 = i2 - 1;
        charSequenceArr[i6] = "Системные настройки голосов TTS (Выбор диктора в системе)...";
        strArr[i6] = "open_tts_settings";
        this.dialogEnginePkgs = strArr;
        new AlertDialog.Builder(this).setTitle("Выберите голос внутри движка TTS").setItems(charSequenceArr, new DialogClickListener(this, 16)).setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }

    // ---------------------------------------------------------------------
    // 2.3.7 per-profile dialogs
    // ---------------------------------------------------------------------
    private void openCallEngineDialog(int i) { dialogChannel = CALL_PROFILES[i]; showTtsEngineDialog(40, "Движок TTS [" + CALL_LABELS[i] + "]"); }
    private void openCallRateDialog(int i) { dialogChannel = CALL_PROFILES[i]; showTtsRateDialog(41, "Скорость речи [" + CALL_LABELS[i] + "]"); }
    private void openCallVoicePicker(int i) { SmartCallFeatures.showVoicePicker(this, CALL_PROFILES[i], CALL_LABELS[i], "call_", btnCallVoice[i]); }
    private void openCallRepeatDialog(int i) {
        dialogChannel = CALL_PROFILES[i];
        new AlertDialog.Builder(this).setTitle("Количество повторений имени [" + CALL_LABELS[i] + "]")
                .setItems(new CharSequence[]{"1 раз", "2 раза", "3 раза", "4 раза", "5 раза"}, new DialogClickListener(this, 43))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void openCallDelayDialog(int i) {
        dialogChannel = CALL_PROFILES[i];
        CharSequence[] items = new CharSequence[31];
        for (int k = 0; k <= 30; k++) items[k] = k + " сек.";
        new AlertDialog.Builder(this).setTitle("Задержка между повторениями [" + CALL_LABELS[i] + "]")
                .setItems(items, new DialogClickListener(this, 44))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void openCallTestDialog(int i) {
        dialogChannel = CALL_PROFILES[i];
        new AlertDialog.Builder(this).setTitle("Проверка озвучки [" + CALL_LABELS[i] + "]")
                .setItems(new CharSequence[]{"Проверить голос (один раз)", "Проверить повторения с задержкой", "Остановить проверку"}, new DialogClickListener(this, 46))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void openMsgEngineDialog(int i) { dialogChannel = MSG_PROFILES[i]; showTtsEngineDialog(47, "Движок TTS сообщений [" + MSG_LABELS[i] + "]"); }
    private void openMsgRateDialog(int i) { dialogChannel = MSG_PROFILES[i]; showTtsRateDialog(48, "Скорость речи сообщений [" + MSG_LABELS[i] + "]"); }
    private void openMsgVoicePicker(int i) { SmartCallFeatures.showVoicePicker(this, MSG_PROFILES[i], MSG_LABELS[i], "msg_", btnMsgVoice[i]); }
    private void openMsgLockDialog(int i) {
        dialogChannel = MSG_PROFILES[i];
        new AlertDialog.Builder(this).setTitle("Чтение при заблокированном экране [" + MSG_LABELS[i] + "]")
                .setItems(new CharSequence[]{"1. Не озвучивать", "2. Только отправитель", "3. Отправитель и текст сообщения"}, new DialogClickListener(this, 49))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void openMsgTestDialog(int i) {
        dialogChannel = MSG_PROFILES[i];
        new AlertDialog.Builder(this).setTitle("Проверка озвучки сообщений [" + MSG_LABELS[i] + "]")
                .setItems(new CharSequence[]{"Проверить озвучку сообщения", "Остановить проверку"}, new DialogClickListener(this, 50))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void openThemeDialog() {
        int mode = CallController.getPrefInt(this, "theme_mode", 0);
        new AlertDialog.Builder(this).setTitle("Оформление приложения")
                .setSingleChoiceItems(new CharSequence[]{"Как в системе", "Светлая", "Тёмная"}, mode, new DialogClickListener(this, 30))
                .setNegativeButton("Отмена", (DialogInterface.OnClickListener) null).show();
    }
    private void toggleAutoUpdates() {
        boolean enabled = !UpdatesController.isAutoCheckEnabled(this);
        UpdatesController.setAutoCheckEnabled(this, enabled);
        refreshStatusText();
    }

    /** Short, non-sensitive overview of the active functions for the home tab. */
    private String buildOverview() {
        StringBuilder sb = new StringBuilder();
        sb.append("• Управление звонками: ").append(CallController.isPrefEnabled(this, "enabled", true) ? "включено" : "выключено").append('\n');
        sb.append("• Ответ датчиком у уха: ").append(CallController.isPrefEnabled(this, "ear_pickup", true) ? "включён" : "выключен").append('\n');
        sb.append("• Озвучка звонков: SIM — ").append(onOff(profileOn("call_enabled_sim", "tts_app_sim")))
          .append(", WhatsApp — ").append(onOff(profileOn("call_enabled_wa", "tts_app_wa")))
          .append(", Telegram — ").append(onOff(profileOn("call_enabled_tg", "tts_app_tg"))).append('\n');
        sb.append("• Озвучка сообщений: SMS — ").append(onOff(profileOn("msg_enabled_sms", "tts_app_sms")))
          .append(", текст=").append(CallController.isPrefEnabled(this, "tts_sms_text", true) ? "читается" : "выключен").append('\n');
        sb.append("• Тема: ").append(themeLabel(CallController.getPrefInt(this, "theme_mode", 0)));
        return sb.toString();
    }

    private static String onOff(boolean enabled) {
        return enabled ? "включена" : "выключена";
    }

    private boolean profileOn(String newKey, String legacyKey) {
        return getSharedPreferences("call_prefs", 0).contains(newKey)
                ? CallController.isPrefEnabled(this, newKey, false)
                : CallController.isPrefEnabled(this, legacyKey, true);
    }

    private static String themeLabel(int mode) {
        return mode == 1 ? "светлая" : (mode == 2 ? "тёмная" : "как в системе");
    }

    private static String legacyChannel(String channel) {
        return ("viber".equals(channel) || "imo".equals(channel)) ? "other" : channel;
    }

    private static String rateLabel(int rate) {
        return CallController.formatRateLabel(rate);
    }

    private static String lockLabel(int mode) {
        return mode == 1 ? "только отправитель" : (mode == 2 ? "отправитель и текст" : "не озвучивать");
    }
}
