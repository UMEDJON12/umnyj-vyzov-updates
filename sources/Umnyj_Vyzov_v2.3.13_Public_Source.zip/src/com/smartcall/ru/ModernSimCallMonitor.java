package com.smartcall.ru;

import android.content.Context;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import java.util.ArrayList;
import java.util.List;

/** API 31+: subscription-aware callback; instantiated only on supported Android. */
public final class ModernSimCallMonitor {
    private final List<TelephonyManager> managers=new ArrayList<TelephonyManager>();
    private final List<TelephonyCallback> callbacks=new ArrayList<TelephonyCallback>();
    public void start(final Context context) {
        if (Build.VERSION.SDK_INT<31 || !CallController.hasPermission(context,"android.permission.READ_PHONE_STATE")) return;
        try {
            TelephonyManager base=(TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
            if(base==null)return;
            SubscriptionManager sm=(SubscriptionManager)context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            List<SubscriptionInfo> subs=sm!=null?sm.getActiveSubscriptionInfoList():null;
            if(subs==null||subs.isEmpty()) register(context,base,-1);
            else for(SubscriptionInfo si:subs) if(si!=null) {
                int id=si.getSubscriptionId(); register(context,base.createForSubscriptionId(id),id);
            }
        }catch (RuntimeException e) { CallController.log("SIM callbacks: "+e.getClass().getSimpleName()); }
    }
    private void register(final Context ctx,TelephonyManager manager,final int sub) {
        try {
            StateCallback callback=new StateCallback(ctx,sub);
            manager.registerTelephonyCallback(ctx.getMainExecutor(),callback);
            managers.add(manager); callbacks.add(callback);
            CallController.log("SIM callback зарегистрирован для SIM#"+sub);
        }catch(RuntimeException e) { CallController.log("SIM callback ошибка SIM#"+sub+": "+e.getClass().getSimpleName()); }
    }
    public void stop() {
        for(int i=0;i<managers.size();i++) {
            try { managers.get(i).unregisterTelephonyCallback(callbacks.get(i)); }
            catch(RuntimeException ignored) {}
        }
        managers.clear(); callbacks.clear();
    }
    private static final class StateCallback extends TelephonyCallback implements TelephonyCallback.CallStateListener {
        private final Context ctx; private final int sub;
        StateCallback(Context c,int s) { ctx=c.getApplicationContext();sub=s; }
        @Override public void onCallStateChanged(int state) { SimCallMonitor.event(ctx,sub,state,"TelephonyCallback"); }
    }
}
