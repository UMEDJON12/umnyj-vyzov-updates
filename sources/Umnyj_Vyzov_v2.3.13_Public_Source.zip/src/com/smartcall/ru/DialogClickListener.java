package com.smartcall.ru;

import android.content.DialogInterface;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes.dex */
public class DialogClickListener implements DialogInterface.OnClickListener {
    private MainActivity activity;
    private int mode;

    public DialogClickListener(MainActivity mainActivity, int i) {
        this.activity = mainActivity;
        this.mode = i;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        if (this.mode >= 30 && this.mode <= 50) {
            this.activity.onProfileDialog(this.mode, i);
        } else {
            this.activity.onDialogPositiveAction(this.mode, i);
        }
    }
}
