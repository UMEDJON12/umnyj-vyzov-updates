package com.smartcall.ru;

import java.util.LinkedHashMap;
import java.util.Locale;

/* JADX INFO: loaded from: /root/workspace/java-recovery/features-experiment/classes2-original.dex */
public final class SpeechPolicy {
    private SpeechPolicy() {
    }

    public static String channel(String str) {
        String lowerCase = str == null ? "sim" : str.toLowerCase(Locale.ROOT);
        if (lowerCase.contains("whatsapp")) {
            return "wa";
        }
        if (lowerCase.contains("telegram") || lowerCase.contains("nekogram") || lowerCase.contains("challegram")) {
            return "tg";
        }
        return (lowerCase.equals("sim") || lowerCase.equals("sms") || lowerCase.contains("messaging") || lowerCase.contains("mms")) ? "sms" : "other";
    }

    public static String cleanCaller(String str) {
        if (str == null) {
            return "";
        }
        String strTrim = str.trim();
        String lowerCase = strTrim.toLowerCase(Locale.ROOT);
        return (lowerCase.equals("whatsapp") || lowerCase.equals("telegram") || lowerCase.equals("телефон") || lowerCase.equals("входящий вызов") || lowerCase.equals("incoming call") || lowerCase.contains("meta ai") || lowerCase.contains("для поиска") || lowerCase.contains("поиск") || lowerCase.contains("search") || lowerCase.contains("ask meta") || lowerCase.contains("запрос для")) ? "" : strTrim.replaceFirst("(?iu)^(звонит|позвонить|входящий вызов от|звонок ватсап от|звонок телеграм от|звонок от|звонок)\\s+", "").replaceAll("[\\s\\p{Punct}…。，،]+$", "").trim();
    }

    public static boolean callerNode(String str, String str2, boolean z) {
        if (z || cleanCaller(str2).isEmpty() || str == null) {
            return false;
        }
        String lowerCase = str.toLowerCase(Locale.ROOT);
        return lowerCase.contains("caller_name") || lowerCase.contains("contact_name") || lowerCase.contains("call_name") || lowerCase.contains("calling_name") || lowerCase.contains("voip_name") || lowerCase.contains("peer_name");
    }

    public static String voiceKey(String str) {
        return "tts_voice_" + str;
    }

    public static String engineKey(String str) {
        return "tts_eng_" + str;
    }

    public static final class Dedup {
        private final LinkedHashMap<String, String> seen = new LinkedHashMap<>();

        public synchronized boolean accept(String str, String str2) {
            if (str2.equals(this.seen.get(str))) {
                return false;
            }
            this.seen.put(str, str2);
            if (this.seen.size() > 128) {
                this.seen.remove(this.seen.keySet().iterator().next());
            }
            return true;
        }
    }
}
