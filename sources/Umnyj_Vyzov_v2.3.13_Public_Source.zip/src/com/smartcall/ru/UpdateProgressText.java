package com.smartcall.ru;

import java.util.Locale;

/** Presentation of actual transferred bytes; no timer-based or simulated progress. */
public final class UpdateProgressText {
    private UpdateProgressText() { }
    public static int percent(long downloaded, long total) {
        if (total <= 0) return -1;
        if (downloaded <= 0) return 0;
        if (downloaded >= total) return 100;
        return (int) ((downloaded * 100.0) / total);
    }
    public static String bytes(long n) {
        if (n < 1024) return Math.max(0,n) + " Б";
        if (n < 1024L*1024L) return String.format(Locale.US, "%.1f КБ", n / 1024.0);
        return String.format(Locale.US, "%.2f МБ", n / (1024.0*1024.0));
    }
    public static String progress(long downloaded, long total) {
        if (total <= 0) return "Получено " + bytes(downloaded) + "; общий размер неизвестен";
        return percent(downloaded,total) + "% · получено " + bytes(downloaded) + " из " + bytes(total)
                + " · осталось " + bytes(Math.max(0,total-downloaded));
    }
}
