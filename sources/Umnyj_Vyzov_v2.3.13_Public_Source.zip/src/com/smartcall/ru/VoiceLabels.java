package com.smartcall.ru;

import java.util.Locale;

/** Читаемая метка без изменения идентификатора голоса, возвращённого движком. */
public final class VoiceLabels {
    private VoiceLabels() { }

    public static String label(Locale locale, int ordinal, boolean needsNetwork) {
        String language = locale == null ? "Язык не указан" : locale.getDisplayName(new Locale("ru"));
        if (language == null || language.trim().isEmpty()) language = "Язык не указан";
        String first = language.substring(0, 1).toUpperCase(new Locale("ru"));
        return first + language.substring(1) + " · голос " + ordinal
                + (needsNetwork ? " · требуется интернет" : " · без интернета");
    }
}
