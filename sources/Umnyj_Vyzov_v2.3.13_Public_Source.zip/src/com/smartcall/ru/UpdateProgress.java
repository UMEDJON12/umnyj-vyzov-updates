package com.smartcall.ru;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.CopyOnWriteArrayList;

/** Process-local observable snapshot. Persistent readiness is stored separately in DownloadStore. */
public final class UpdateProgress {
    public enum Phase { IDLE, CONNECTING, DOWNLOADING, VERIFYING, SAVING, READY, CANCELLED, ERROR, RECHECK, STORAGE_PERMISSION }
    public static final class Snapshot {
        public final Phase phase;
        public final String version, message;
        public final long downloaded, total;
        Snapshot(Phase phase, String version, String message, long downloaded, long total) {
            this.phase=phase; this.version=version; this.message=message;
            this.downloaded=downloaded; this.total=total;
        }
        public boolean running() { return phase == Phase.CONNECTING || phase == Phase.DOWNLOADING
                || phase == Phase.VERIFYING || phase == Phase.SAVING; }
    }
    public interface Listener { void onUpdate(Snapshot snapshot); }
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final CopyOnWriteArrayList<Listener> LISTENERS = new CopyOnWriteArrayList<>();
    private static volatile Snapshot current = new Snapshot(Phase.IDLE, "", "", 0, 0);
    private static long epoch;
    private UpdateProgress() { }
    public static Snapshot current() { return current; }
    public static void listen(Listener listener) { LISTENERS.addIfAbsent(listener); listener.onUpdate(current); }
    public static void unlisten(Listener listener) { LISTENERS.remove(listener); }
    public static synchronized boolean begin(String version) {
        if (current.running()) return false;
        epoch++;
        publish(Phase.CONNECTING, version, "Подключение…", 0, 0);
        return true;
    }
    public static synchronized boolean publishIfIdle(Phase phase, String version, String message, long downloaded, long total) {
        if (current.running()) return false;
        publish(phase, version, message, downloaded, total);
        return true;
    }
    public static synchronized long epoch() { return epoch; }
    public static synchronized boolean publishFor(long expectedEpoch, Phase phase, String version, String message, long downloaded, long total) {
        if (epoch != expectedEpoch) return false;
        publish(phase, version, message, downloaded, total);
        return true;
    }
    public static synchronized void publish(Phase phase, String version, String message, long downloaded, long total) {
        final Snapshot next = new Snapshot(phase, version == null ? "" : version,
                message == null ? "" : message, Math.max(0, downloaded), Math.max(0, total));
        current = next;
        MAIN.post(new Runnable() { public void run() {
            // Drop stale queued updates instead of moving the UI backwards.
            if (current != next) return;
            for (Listener listener : LISTENERS) listener.onUpdate(next);
        }});
    }
}
