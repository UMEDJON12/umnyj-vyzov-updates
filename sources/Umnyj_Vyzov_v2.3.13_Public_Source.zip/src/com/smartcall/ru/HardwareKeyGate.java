package com.smartcall.ru;

/** Only a real AccessibilityService ACTION_DOWN can request an answer.
 * This class does not observe broadcasts, ringer level or audio stream changes.
 */
public final class HardwareKeyGate {
    private long lastMs = -1;
    private int lastAction;
    private int lastKey;

    /** 1 = answer, 2 = end, 0 = no action. */
    public synchronized boolean allow(int key, int action, long nowMs) {
        if (action == 0 || (action != 1 && action != 2)) return false;
        if (lastMs >= 0 && nowMs >= lastMs && nowMs - lastMs < 1600L
                && lastAction == action && lastKey == key) return false;
        lastMs = nowMs;
        lastAction = action;
        lastKey = key;
        return true;
    }

    public synchronized void reset() {
        lastMs = -1;
        lastAction = 0;
        lastKey = 0;
    }
}
